#ifndef _ADATA_AVR2S_STRUCT_H
#define _ADATA_AVR2S_STRUCT_H

/*
** <avr2s/struct.h> - structs used in AVR2 SMBUS API
**
** (C) Copyright Alpha Data 2017
*/

/* Nothing here yet */

#endif
