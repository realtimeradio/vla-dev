#ifndef _ADATA_AVR2S_STATUS_H
#define _ADATA_AVR2S_STATUS_H

/*
** <avr2s/status.h> - status codes returned by AVR2 SMBUS API calls
**
** (C) Copyright Alpha Data 2017
*/

/*
** Base value for error status codes
*/
#define AVR2S_STATUS_ERROR_CODE_START (0x200U)

/*
** Status and error codes
*/
typedef enum _AVR2S_STATUS
{
    AVR2S_SUCCESS                 = 0,

    /* An error in the API logic was detected */
    AVR2S_INTERNAL_ERROR          = AVR2S_STATUS_ERROR_CODE_START,

    /* An unexpected error caused the operation to fail */
    AVR2S_UNEXPECTED_ERROR,

    /* The driver may not be correctly installed */
    AVR2S_BAD_DRIVER,

    /* Couldn't allocate memory required to complete operation */
    AVR2S_NO_MEMORY,

    /* The calling process does not have permission to perform the operation */
    AVR2S_ACCESS_DENIED,

    /* Failed to open the device with the specified index */
    AVR2S_DEVICE_NOT_FOUND,

    /* An error in the hardware was detected */
    AVR2S_HARDWARE_ERROR,

    /* The supplied buffer was invalid and could not be read/written */
    AVR2S_INVALID_BUFFER,

    /* A flag was invalid or not recognized */
    AVR2S_INVALID_FLAG,

    /* The device handle was invalid */
    AVR2S_INVALID_HANDLE,

    /* The index parameter was invalid */
    AVR2S_INVALID_INDEX,

    /* The offset and/or length parameters were invalid */
    AVR2S_INVALID_REGION,

    /* A NULL pointer was passed where non-NULL was required */
    AVR2S_NULL_POINTER,

    /* The operation was cancelled */
    AVR2S_CANCELLED,

    /* A resource limit was reached */
    AVR2S_RESOURCE_LIMIT,

    /* The specified region was too large for a single operation */
    AVR2S_REGION_TOO_LARGE,

    /* Reserved status code */
    AVR2S_STATUS_RESERVED1,

    /* The operation was attempted when the device was not in the proper mode */
    AVR2S_WRONG_MODE,

    /* The operation is not supported for this device */
    AVR2S_NOT_SUPPORTED,

    /* A parameter had an illegal value */
    AVR2S_INVALID_PARAMETER,

    /* The operation did not complete within the timeout period */
    AVR2S_TIMEOUT,

    /* The length of the command was less than 2 bytes */
    AVR2S_SHORT_COMMAND,

    AVR2S_STATUS_FORCE32BITS = 0x7FFFFFFF
} AVR2S_STATUS;

#endif
