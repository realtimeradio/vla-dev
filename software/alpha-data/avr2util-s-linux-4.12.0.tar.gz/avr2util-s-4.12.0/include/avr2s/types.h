#ifndef _ADATA_AVR2S_TYPES_H
#define _ADATA_AVR2S_TYPES_H

/*
** <avr2s/types.h> - scalar datatypes used in AVR2 SMBUS API
**
** (C) Copyright Alpha Data 2017
*/

/* Flags for use with AVR2S_Command */

/* Do not expect or wait for a response for this command */
#define AVR2S_FLAG_SKIP_RESPONSE (0x1)

#endif
