#ifndef _ADATA_AVR2IPMI_TYPES_H
#define _ADATA_AVR2IPMI_TYPES_H

/*
** <avr2ipmi/types.h> - scalar datatypes used in AVR2 IPMI API
**
** (C) Copyright Alpha Data 2017
*/

typedef enum _AVR2IPMI_BACKEND_TYPE {
  AVR2IPMI_BACKEND_FREEIPMI = 1
} AVR2IPMI_BACKEND_TYPE;

typedef enum _AVR2IPMI_AUTHENTICATION_TYPE {
  AVR2IPMI_AUTHENTICATION_NONE              = 0,
  AVR2IPMI_AUTHENTICATION_MD2               = 1,
  AVR2IPMI_AUTHENTICATION_MD5               = 2,
  AVR2IPMI_AUTHENTICATION_STRAIGHT_PASSWORD = 4
} AVR2IPMI_AUTHENTICATION_TYPE;

/* Flags for use with AVR2IPMI_Command */

/* Do not expect or wait for a response for this command; used primarily with the BoardMan2/BootMan2 Set SMBUS Chip Address command */
#define AVR2IPMI_FLAG_SKIP_RESPONSE (0x1)

#endif
