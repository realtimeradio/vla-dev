#ifndef _ADATA_AVR2IPMI_STRUCT_H
#define _ADATA_AVR2IPMI_STRUCT_H

/*
** <avr2ipmi/struct.h> - structs used in AVR2 IPMI API
**
** (C) Copyright Alpha Data 2017
*/

typedef struct _AVR2IPMI_OPTIONSA {
  AVR2IPMI_BACKEND_TYPE        Backend;
  AVR2IPMI_AUTHENTICATION_TYPE Authentication;
  char                         Hostname[256];
  char                         Username[256];
  char                         Password[256];
  uint8_t                      BusID;
  uint8_t                      ChipAddress;
  union {
    struct {
      _AVR2IPMI_BOOL           EnableDebug;
    } FreeIPMI;
  } Variant;
} AVR2IPMI_OPTIONSA;

#if defined(_WIN32) || defined(_MSC_VER)

typedef struct _AVR2IPMI_OPTIONSW {
  AVR2IPMI_BACKEND_TYPE        Backend;
  AVR2IPMI_AUTHENTICATION_TYPE AuthenticationType;
  wchar_t                      Hostname[256];
  wchar_t                      Username[256];
  wchar_t                      Password[256];
  uint8_t                      BusID;
  uint8_t                      ChipAddress;
  union {
    struct {
      _AVR2IPMI_BOOL           EnableDebug;
    } FreeIPMI;
  } Variant;
} AVR2IPMI_OPTIONSW;

#endif

#if defined(_UNICODE)
# define AVR2IPMI_OPTIONS AVR2IPMI_OPTIONSW
#else
# define AVR2IPMI_OPTIONS AVR2IPMI_OPTIONSA
#endif

typedef struct _AVR2IPMI_ERROR_DETAILA {
  /* A textual description of the error, valid for all AVR2IPMI_STATUS codes */
  char Description[256];

  /* The last error returned by an AVR2IPMI_* API function */
  AVR2IPMI_STATUS Status;

  /* The backend IPMI library that generated the error */
  AVR2IPMI_BACKEND_TYPE Backend;

  /* Valid if: Status is AVR2IPMI_IPMI_COMPLETION_ERROR */
  uint8_t Completion;

  /* Valid if: Status is AVR2IPMI_IPMI_SHORT_RESPONSE */
  uint8_t ResponseLength;

  union {
    /* Valid if: Backend is FreeIPMI */
    struct {
      /* Valid if: Status is AVR2IPMI_BACKEND_INIT_FAILED */
      int Errno;           /* Value of errno */
      /* Valid if: Status is AVR2IPMI_BACKEND_ERROR or AVR2IPMI_SESSION_ERROR */
      int ErrorNumber;     /* Value of ipmi_ctx_errnum() */
    } FreeIPMI;
  } Variant;
} AVR2IPMI_ERROR_DETAILA;

#if defined(_WIN32) || defined(_MSC_VER)

typedef struct _AVR2IPMI_ERROR_DETAILW {
  /* A textual description of the error, valid for all AVR2IPMI_STATUS codes */
  wchar_t Description[256];

  /* The last error returned by an AVR2IPMI_* API function */
  AVR2IPMI_STATUS Status;

  /* The backend IPMI library that generated the error */
  AVR2IPMI_BACKEND_TYPE Backend;

  /* Valid if: Status is AVR2IPMI_IPMI_COMPLETION_ERROR */
  uint8_t Completion;

  /* Valid if: Status is AVR2IPMI_IPMI_SHORT_RESPONSE */
  uint8_t ResponseLength;

  union {
    /* Valid if: Backend is FreeIPMI */
    struct {
      /* Valid if: Status is AVR2IPMI_BACKEND_INIT_FAILED */
      int Errno;           /* Value of errno */
      /* Valid if: Status is AVR2IPMI_BACKEND_ERROR or AVR2IPMI_SESSION_ERROR */
      int ErrorNumber;     /* Value of ipmi_ctx_errnum() */
    } FreeIPMI;
  } Variant;
} AVR2IPMI_ERROR_DETAILW;

#endif

#if defined(_UNICODE)
# define AVR2IPMI_ERROR_DETAIL AVR2IPMI_ERROR_DETAILW
#else
# define AVR2IPMI_ERROR_DETAIL AVR2IPMI_ERROR_DETAILA
#endif

#endif
