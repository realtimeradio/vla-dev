#ifndef _ADATA_AVR2IPMI_PLATFORM_H
#define _ADATA_AVR2IPMI_PLATFORM_H

/*
** <avr2ipmi/platform.h> - define elementary datatypes used by AVR2 IPMI API
**
** (C) Copyright Alpha Data 2017
**
** The integer datatypes defined below prefixed by "_AVR2IPMI_", such as
** "_AVR2IPMI_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that
** makes use of the AVR2 API.
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

typedef INT32  _AVR2IPMI_INT32;
typedef INT16  _AVR2IPMI_INT16;
typedef UINT64 _AVR2IPMI_UINT64;
typedef UINT32 _AVR2IPMI_UINT32;
typedef UINT16 _AVR2IPMI_UINT16;
typedef UINT8  _AVR2IPMI_UINT8;
typedef UINT8  _AVR2IPMI_BYTE;
typedef BOOL   _AVR2IPMI_BOOL;

struct _AVR2IPMI_SESSION_STRUCT;
typedef struct _AVR2IPMI_SESSION_STRUCT* AVR2IPMI_SESSION;

/* This value is invalid for an AVR2IPMI_SESSION */ 
# define AVR2IPMI_SESSION_INVALID_VALUE ((AVR2IPMI_SESSION)NULL)

#elif defined(__linux) || defined(__VXWORKS__) || defined(__vxworks)

/* Linux or VxWorks - assume C99-compliant */

# if defined(__linux)
#   include <stdint.h>
# endif

typedef int32_t  _AVR2IPMI_INT32;
typedef int16_t  _AVR2IPMI_INT16;
typedef uint64_t _AVR2IPMI_UINT64;
typedef uint32_t _AVR2IPMI_UINT32;
typedef uint16_t _AVR2IPMI_UINT16;
typedef uint8_t  _AVR2IPMI_UINT8;
typedef uint8_t  _AVR2IPMI_BYTE;
typedef int      _AVR2IPMI_BOOL;

struct _AVR2IPMI_SESSION_STRUCT;
typedef struct _AVR2IPMI_SESSION_STRUCT* AVR2IPMI_SESSION;

/* This value is invalid for an AVR2IPMI_SESSION */ 
# define AVR2IPMI_SESSION_INVALID_VALUE ((AVR2IPMI_SESSION)NULL)

#else

# error Cannot detect target operating system.

#endif

#endif
