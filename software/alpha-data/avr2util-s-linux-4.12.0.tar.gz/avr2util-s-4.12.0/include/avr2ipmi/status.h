#ifndef _ADATA_AVR2IPMI_STATUS_H
#define _ADATA_AVR2IPMI_STATUS_H

/*
** <avr2ipmi/status.h> - status codes returned by AVR2 IPMI API calls
**
** (C) Copyright Alpha Data 2017
*/

/*
** Base value for error status codes
*/
#define AVR2IPMI_STATUS_ERROR_CODE_START (0x200U)

/*
** Status and error codes
*/
typedef enum _AVR2IPMI_STATUS
{
    AVR2IPMI_SUCCESS                 = 0,

    /* An error in the API logic was detected */
    AVR2IPMI_INTERNAL_ERROR          = AVR2IPMI_STATUS_ERROR_CODE_START,

    /* An unexpected error caused the operation to fail */
    AVR2IPMI_UNEXPECTED_ERROR,

    /* An invalid session handle was passed */
    AVR2IPMI_INVALID_SESSION,
    
    /* A NULL pointer was passed where a non-NULL pointer was required */
    AVR2IPMI_NULL_POINTER,
    
    /* An allocation failed */
    AVR2IPMI_INSUFFICIENT_RESOURCES,

    /* The options string was not in the form "<backend> [option ...]" */
    AVR2IPMI_BAD_OPTIONS_FORMAT,

    /* The name of an option was missing, e.g. "-" , or "-=value" */ 
    AVR2IPMI_OPTION_NAME_MISSING,

    /* An option value was missing, e.g. nothing after a "-"-style option or nothing after a "-option="-style option */ 
    AVR2IPMI_OPTION_VALUE_MISSING,

    /* An option was not recognized */ 
    AVR2IPMI_OPTION_UNRECOGNIZED,

    /* The backend IPMI library name (freeipmi, openipmi etc.) was not recognized */
    AVR2IPMI_BACKEND_UNRECOGNIZED,

    /* The requested authentication type was not recognized */
    AVR2IPMI_AUTHENTICATION_UNRECOGNIZED,

    /* The requested backend IPMI library (freeipmi, openipmi etc.) is not available in this system */
    AVR2IPMI_BACKEND_NOT_AVAILABLE,

    /* The specified IPMI Bus ID was not a number in the range 0 to 0xFF */
    AVR2IPMI_BAD_IPMI_BUS_ID,

    /* The specified SMBUS chip address was not a number in the range 0 to 0x7F */
    AVR2IPMI_BAD_IPMI_CHIP_ADDR,

    /* The backend IPMI library reported that an IPMI command failed for an unexpected reason */
    AVR2IPMI_BACKEND_ERROR,

    /* The backend IPMI library reported that opening a session failed for an unexpected reason */
    AVR2IPMI_SESSION_ERROR,

    /* The backend IPMI library did not find a local IPMI MC */
    AVR2IPMI_NO_LOCAL_IPMI_MC,

    /* Initialization of the backend IPMI library failed for an unexpected reason */
    AVR2IPMI_BACKEND_INIT_FAILED,

    /* MC returned a response that was too short to be valid (< 2 bytes) */
    AVR2IPMI_IPMI_SHORT_RESPONSE,

    /* MC returned an error (nonzero) completion code that was not one of the expected values */
    AVR2IPMI_IPMI_COMPLETION_ERROR,

    /* A parameter had an illegal value */
    AVR2IPMI_INVALID_PARAMETER,

    /* The operation did not complete within the timeout period */
    AVR2IPMI_TIMEOUT,

    /* The length of the command was less than 2 bytes */
    AVR2IPMI_SHORT_COMMAND,

    AVR2IPMI_STATUS_FORCE32BITS = 0x7FFFFFFF
} AVR2IPMI_STATUS;

#endif
