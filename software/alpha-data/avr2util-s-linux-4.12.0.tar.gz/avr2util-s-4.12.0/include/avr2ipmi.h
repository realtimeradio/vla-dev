#ifndef _ADATA_AVR2IPMI_H
#define _ADATA_AVR2IPMI_H

/*
** <avr2ipmi.h> - AVR2 IPMI API header file (AVR2IPMI interface)
**
** (C) Copyright 2017 Alpha Data
**
** The integer datatypes used below that are prefixed by "_AVR2IPMI_", such
** as "_AVR2IPMI_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that makes
** use of the AVR2IPMI API.
**
** Applications should use OS-specific types such as UINT32 (Windows) or
** uint32_t (Linux C99).
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

# include <windows.h>
# include <tchar.h>

# if defined(AVR2IPMI_DLL)
    /* Compiling API library into a DLL */
#   define AVR2IPMI_EXPORT __declspec(dllexport)
# else
    /* Importing API library from DLL */
#   define AVR2IPMI_EXPORT __declspec(dllimport)
# endif
# define AVR2IPMI_CALLING_CONVENTION __cdecl

#elif defined(__linux)

/* Linux */

# include <stdint.h>
# include <wchar.h>

# define AVR2IPMI_EXPORT
# define AVR2IPMI_CALLING_CONVENTION

#elif defined(__VXWORKS__) || defined(__vxworks)

# include <vxWorks.h>
# include <semLib.h>

# define AVR2IPMI_EXPORT
# define AVR2IPMI_CALLING_CONVENTION

#else

# error Cannot detect target operating system.

#endif

#include <avr2ipmi/platform.h>
#include <avr2ipmi/status.h>
#include <avr2ipmi/types.h>
#include <avr2ipmi/struct.h>

/* Revision of the AVR2 SMBUS API */
#define AVR2IPMI_H_MAKE_VERSION(super, major, minor) ((super) * 65536 + (major) * 256 + (minor))
#define AVR2IPMI_H_VERSION_SUPER (1)
#define AVR2IPMI_H_VERSION_MAJOR (0)
#define AVR2IPMI_H_VERSION_MINOR (0)
#define AVR2IPMI_H_VERSION AVR2IPMI_H_MAKE_VERSION(AVR2IPMI_H_VERSION_SUPER, AVR2IPMI_H_VERSION_MAJOR, AVR2IPMI_H_VERSION_MINOR)

/*
** Function prototypes
*/
#ifdef __cplusplus
extern "C" {
#endif

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_CloseSession(
  AVR2IPMI_SESSION        hSession);

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_Command(
  AVR2IPMI_SESSION        hSession,
  _AVR2IPMI_UINT32        flags,
  _AVR2IPMI_UINT32        timeoutUs,
  _AVR2IPMI_UINT32        commandLength,
  const _AVR2IPMI_UINT8*  pCommand,
  _AVR2IPMI_UINT8         responseAddrOverride,
  _AVR2IPMI_UINT32        responseLength,
  _AVR2IPMI_UINT8*        pResponse,
  _AVR2IPMI_UINT32*       pActualResponseLength);

#if defined(_UNICODE)
# define AVR2IPMI_GetBackends AVR2IPMI_GetBackendsW
#else
# define AVR2IPMI_GetBackends AVR2IPMI_GetBackendsA
#endif

AVR2IPMI_EXPORT const char**
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetBackendsA(
  void);

#if defined(_WIN32) || defined(_MSC_VER)
AVR2IPMI_EXPORT const wchar_t**
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetBackendsW(
  void);
#endif

#if defined(_UNICODE)
# define AVR2IPMI_GetErrorDetail AVR2IPMI_GetErrorDetailW
#else
# define AVR2IPMI_GetErrorDetail AVR2IPMI_GetErrorDetailA
#endif

AVR2IPMI_EXPORT void
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetErrorDetailA(
  AVR2IPMI_ERROR_DETAILA* pErrorDetail);

#if defined(_WIN32) || defined(_MSC_VER)
AVR2IPMI_EXPORT void
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetErrorDetailW(
  AVR2IPMI_ERROR_DETAILW* pErrorDetail);
#endif

#if defined(_UNICODE)
# define AVR2IPMI_GetStatusString AVR2IPMI_GetStatusStringW
#else
# define AVR2IPMI_GetStatusString AVR2IPMI_GetStatusStringA
#endif

AVR2IPMI_EXPORT const char*
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetStatusStringA(
  AVR2IPMI_STATUS         code,
  _AVR2IPMI_BOOL          bShort);

#if defined(_WIN32) || defined(_MSC_VER)
AVR2IPMI_EXPORT const wchar_t*
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetStatusStringW(
  AVR2IPMI_STATUS         code,
  _AVR2IPMI_BOOL          bShort);
#endif

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_OpenSession(
  const AVR2IPMI_OPTIONS* pOptions,
  AVR2IPMI_SESSION*       phSession);

#if defined(_UNICODE)
# define AVR2IPMI_ParseOptions AVR2IPMI_ParseOptionsW
#else
# define AVR2IPMI_ParseOptions AVR2IPMI_ParseOptionsA
#endif

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_ParseOptionsA(
  const char*             pOptionsString,
  AVR2IPMI_OPTIONS*       pOptions);

#if defined(_WIN32) || defined(_MSC_VER)
AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_ParseOptionsW(
  const wchar_t*          pOptionsString,
  AVR2IPMI_OPTIONS*       pOptions);
#endif

#ifdef __cplusplus
}
#endif

#endif
