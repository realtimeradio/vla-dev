#ifndef _ADATA_AVR2S_H
#define _ADATA_AVR2S_H

/*
** <avr2s.h> - AVR2 SMBUS API header file (AVR2 interface)
**
** (C) Copyright 2017 Alpha Data
**
** The integer datatypes used below that are prefixed by "_AVR2S_", such
** as "_AVR2S_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that makes
** use of the AVR2S API.
**
** Applications should use OS-specific types such as UINT32 (Windows) or
** uint32_t (Linux C99).
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

# include <windows.h>
# include <tchar.h>

# if defined(AVR2S_DLL)
    /* Compiling API library into a DLL */
#   define AVR2S_EXPORT __declspec(dllexport)
# else
    /* Importing API library from DLL */
#   define AVR2S_EXPORT __declspec(dllimport)
# endif
# define AVR2S_CALLING_CONVENTION __cdecl

#elif defined(__linux)

/* Linux */

# include <stdint.h>
# include <wchar.h>

# define AVR2S_EXPORT
# define AVR2S_CALLING_CONVENTION

#elif defined(__VXWORKS__) || defined(__vxworks)

# include <vxWorks.h>
# include <semLib.h>

# define AVR2S_EXPORT
# define AVR2S_CALLING_CONVENTION

#else

# error Cannot detect target operating system.

#endif

#include <avr2s/platform.h>
#include <avr2s/status.h>
#include <avr2s/types.h>
#include <avr2s/struct.h>

/* Revision of the AVR2 SMBUS API */
#define AVR2S_H_MAKE_VERSION(super, major, minor) ((super) * 65536 + (major) * 256 + (minor))
#define AVR2S_H_VERSION_SUPER (1)
#define AVR2S_H_VERSION_MAJOR (0)
#define AVR2S_H_VERSION_MINOR (0)
#define AVR2S_H_VERSION AVR2S_H_MAKE_VERSION(AVR2S_H_VERSION_SUPER, AVR2S_H_VERSION_MAJOR, AVR2S_H_VERSION_MINOR)

/*
** Function prototypes
*/
#ifdef __cplusplus
extern "C" {
#endif

AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_Close(
  AVR2S_HANDLE             hDevice);

AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_Command(
  AVR2S_HANDLE             hDevice,
  _AVR2S_UINT32            flags,
  _AVR2S_UINT32            timeoutUs,
  _AVR2S_UINT32            commandLength,
  const _AVR2S_UINT8*      pCommand,
  _AVR2S_UINT8             responseAddrOverride,
  _AVR2S_UINT32            responseLength,
  _AVR2S_UINT8*            pResponse,
  _AVR2S_UINT32*           pActualResponseLength);

#if defined(_UNICODE)
# define AVR2S_GetStatusString AVR2S_GetStatusStringW
#else
# define AVR2S_GetStatusString AVR2S_GetStatusStringA
#endif

AVR2S_EXPORT const char*
AVR2S_CALLING_CONVENTION
AVR2S_GetStatusStringA(
  AVR2S_STATUS             code,
  _AVR2S_BOOL              bShort);

#if defined(_WIN32) || defined(_MSC_VER)
AVR2S_EXPORT const wchar_t*
AVR2S_CALLING_CONVENTION
AVR2S_GetStatusStringW(
  AVR2S_STATUS             code,
  _AVR2S_BOOL              bShort);
#endif

#if defined(_UNICODE)
# define AVR2S_OpenDevice AVR2S_OpenDeviceW
#else
# define AVR2S_OpenDevice AVR2S_OpenDeviceA
#endif

AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_OpenDeviceA(
  const char*             pDeviceName,
  _AVR2S_UINT8            chipAddress, /* 7-bit SMBUS chip address */
  AVR2S_HANDLE*           phDevice);

#if defined(_WIN32) || defined(_MSC_VER)
AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_OpenDeviceW(
  const wchar_t*          pDeviceName,
  AVR2S_HANDLE*           phDevice);
#endif

#ifdef __cplusplus
}
#endif

#endif
