#ifndef _ADATA_ADB3_STATUS_H
#define _ADATA_ADB3_STATUS_H

/*
** status.h - status codes returned by ADB3 API calls
**
** (C) Copyright Alpha Data 2011
*/

/*
** Base value for error status codes
*/
#define ADB3_STATUS_ERROR_CODE_START (0x200U)

/*
** Status and error codes
*/
typedef enum _ADB3_STATUS
{
    ADB3_SUCCESS                 = 0,

    /* An error in the API logic was detected */
    ADB3_INTERNAL_ERROR          = ADB3_STATUS_ERROR_CODE_START,

    /* An unexpected error caused the operation to fail */
    ADB3_UNEXPECTED_ERROR,

    /* The driver may not be correctly installed */
    ADB3_BAD_DRIVER,

    /* Couldn't allocate memory required to complete operation */
    ADB3_NO_MEMORY,

    /* The calling process does not have permission to perform the operation */
    ADB3_ACCESS_DENIED,

    /* Failed to open the device with the specified index */
    ADB3_DEVICE_NOT_FOUND,

    /* An error in the hardware was detected */
    ADB3_HARDWARE_ERROR,

    /* The supplied buffer was invalid and could not be read/written */
    ADB3_INVALID_BUFFER,

    /* A flag was invalid or not recognized */
    ADB3_INVALID_FLAG,

    /* The device handle was invalid */
    ADB3_INVALID_HANDLE,

    /* The index parameter was invalid */
    ADB3_INVALID_INDEX,

    /* The offset and/or length parameters were invalid */
    ADB3_INVALID_REGION,

    /* A NULL pointer was passed where non-NULL was required */
    ADB3_NULL_POINTER,

    /* The operation was cancelled */
    ADB3_CANCELLED,

    /* A resource limit was reached */
    ADB3_RESOURCE_LIMIT,

    /* The specified region was too large for a single operation */
    ADB3_REGION_TOO_LARGE,

    /* The datatype was invalid for the specified sensor */
    ADB3_DATATYPE_MISMATCH,

    /* The operation was attempted when the device was not in the proper mode */
    ADB3_WRONG_MODE,

    /* The operation is not supported for this device */
    ADB3_NOT_SUPPORTED,

    /* A parameter had an illegal value */
    ADB3_INVALID_PARAMETER,

    /* The operation did not complete within the timeout period */
    ADB3_TIMEOUT,

    ADB3_STATUS_FORCE32BITS = 0x7FFFFFFF
} ADB3_STATUS;

#endif
