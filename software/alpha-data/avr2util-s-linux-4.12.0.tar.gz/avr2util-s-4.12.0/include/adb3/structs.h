#ifndef _ADATA_ADB3_STRUCTS_H
#define _ADATA_ADB3_STRUCTS_H

/*
** structs.h - structs used in ADB3 API
**
** (C) Copyright Alpha Data 2011, 2015
*/

/*
** This structure contains a universally unique identifier for a Gen 3 Alpha
** Data reconfigurable computing card. The combined 64-bit value is unique
** across all Gen 3 models.
**
** It can be used to find the ADMXRC3 device that corresponds to an ADB3
** device, or to find the ADB3 device that corresponds to an ADMXRC3 device.
*/
typedef struct _ADB3_UNIQUE_ID {
  _ADB3_UINT32 SerialNumber;    /* Serial number of card                    */
  _ADB3_UINT32 Model;           /* Model of card                            */
} ADB3_UNIQUE_ID;

/*
** Production test information structure, returned by ADB3_GetProdTestInfo
*/

typedef struct _ADB3_PRODTEST_INFO {
  _ADB3_UINT32 SerialNumber;    /* Serial number of card                    */
  _ADB3_UINT8  CPLDRevision;    /* CPLD revision, 0xXY => X.Y               */
  _ADB3_UINT8  PCBRevision;     /* PCB revision, 0xXY => X.Y                */
  _ADB3_UINT8  BridgeRevision;  /* Bridge PCI-E revision ID                 */
  _ADB3_UINT8  _Reserved1;
  _ADB3_UINT32 BridgeDate;      /* Bridge build date, BCD format 0xDDMMYYYY */
  _ADB3_UINT32 BridgeTime;      /* Bridge build date, BCD format 0xHHMMSS-- */
} ADB3_PRODTEST_INFO;

#endif
