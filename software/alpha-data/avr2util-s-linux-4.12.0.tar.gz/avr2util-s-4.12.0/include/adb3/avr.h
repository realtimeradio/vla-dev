#ifndef _ADATA_ADB3_AVR_H
#define _ADATA_ADB3_AVR_H

/*
** <adb3/avr.h> - ADB3 API header file (ADB3 interface),
**                AVR interface extensions.
**
** (C) Copyright 2017 Alpha Data
**
** The integer datatypes used below that are prefixed by "_ADB3_", such
** as "_ADB3_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that makes
** use of the ADMXRC3 API.
**
** Applications should use OS-specific types such as UINT32 (Windows) or
** uint32_t (Linux C99).
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

# include <windows.h>
# include <tchar.h>

#ifndef ADB3_EXPORT
# if defined(ADB3_DLL)
    /* Compiling API library into a DLL */
#   define ADB3_EXPORT __declspec(dllexport)
# else
    /* Importing API library from DLL */
#   define ADB3_EXPORT __declspec(dllimport)
# endif
#endif
#ifndef ADB3_CALLING_CONVENTION
# define ADB3_CALLING_CONVENTION __cdecl
#endif

#elif defined(__linux)

/* Linux */

# include <stdint.h>
# include <wchar.h>

#ifndef ADB3_EXPORT
# define ADB3_EXPORT
#endif
#ifndef ADB3_CALLING_CONVENTION
# define ADB3_CALLING_CONVENTION
#endif

#elif defined(__VXWORKS__) || defined(__vxworks)

# include <vxWorks.h>
# include <semLib.h>

#ifndef ADB3_EXPORT
# define ADB3_EXPORT
#endif
#ifndef ADB3_CALLING_CONVENTION
# define ADB3_CALLING_CONVENTION
#endif

#else

# error Cannot detect target operating system.

#endif

#include <adb3/platform.h>
#include <adb3/status.h>
#include <adb3/types.h>
#include <adb3/structs.h>

typedef union _ADB3_AVR_STATUS {
  struct {
    _ADB3_UINT32 ServiceMode     : 1;
    _ADB3_UINT32 RXProtocolError : 1;
    _ADB3_UINT32 TXFramingError  : 1;
    _ADB3_UINT32 Reserved1       : 29;
  } Flags;
  _ADB3_UINT32 AsUINT32;
} ADB3_AVR_STATUS;

/*
** Function prototypes
*/
#ifdef __cplusplus
extern "C" {
#endif

ADB3_EXPORT ADB3_STATUS
ADB3_CALLING_CONVENTION
ADB3_CommandAVR(
  ADB3_HANDLE             hCard,
  _ADB3_UINT32            flags,
  _ADB3_UINT32            timeoutUs,
  _ADB3_UINT32            commandLength,
  const _ADB3_UINT8*      pCommand,
  _ADB3_UINT32            responseLength,
  _ADB3_UINT8*            pResponse,
  _ADB3_UINT32*           pActualResponseLength);

ADB3_EXPORT ADB3_STATUS
ADB3_CALLING_CONVENTION
ADB3_GetAVRStatus(
  ADB3_HANDLE             hCard,
  ADB3_AVR_STATUS*        pAVR2Status);

#ifdef __cplusplus
}
#endif

#endif
