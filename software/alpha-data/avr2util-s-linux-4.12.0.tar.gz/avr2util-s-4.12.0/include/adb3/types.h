#ifndef _ADATA_ADB3_TYPES_H
#define _ADATA_ADB3_TYPES_H

/*
** types.h - scalar datatypes used in ADB3 API
**
** (C) Copyright Alpha Data 2011
*/

/* Cooperative level flags for ADB3_Open */
#define ADB3_COOP_SHARED    (0x0 << 0) /* Succeeds unless card is open (EXCLUSIVE and read/write) somewhere else */
#define ADB3_COOP_EXCLUSIVE (0x1 << 0) /* Fails if card is open read/write somewhere else */

#endif
