#ifndef _ADATA_ADB3_IPROGT_H
#define _ADATA_ADB3_IPROGT_H

/*
** iprogt.h - datatypes used in <adb3/iprog.h>
**
** (C) Copyright Alpha Data 2015
*/

/* Flags for ADB3_ScheduleIPROG & ADB3_StatusIPROG */
#define ADB3_IPROG_FROMNOW (0x1 << 0) /* IPROG reconfiguration for specified time from now */
#define ADB3_IPROG_ONSTOP  (0x1 << 1) /* IPROG reconfiguration for specified time from device stopped */

#endif
