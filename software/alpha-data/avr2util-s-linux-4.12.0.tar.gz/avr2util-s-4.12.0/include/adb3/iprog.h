#ifndef _ADATA_ADB3_IPROG_H
#define _ADATA_ADB3_IPROG_H

/*
** <adb3/iprog.h> - ADB3 API header file (ADB3 interface),
**                  IPROG extensions.
**
** (C) Copyright 2015 Alpha Data
**
** The integer datatypes used below that are prefixed by "_ADB3_", such
** as "_ADB3_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that makes
** use of the ADMXRC3 API.
**
** Applications should use OS-specific types such as UINT32 (Windows) or
** uint32_t (Linux C99).
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

# include <windows.h>
# include <tchar.h>

#ifndef ADB3_EXPORT
# if defined(ADB3_DLL)
    /* Compiling API library into a DLL */
#   define ADB3_EXPORT __declspec(dllexport)
# else
    /* Importing API library from DLL */
#   define ADB3_EXPORT __declspec(dllimport)
# endif
#endif
#ifndef ADB3_CALLING_CONVENTION
# define ADB3_CALLING_CONVENTION __cdecl
#endif

#elif defined(__linux)

/* Linux */

# include <stdint.h>
# include <wchar.h>

#ifndef ADB3_EXPORT
# define ADB3_EXPORT
#endif
#ifndef ADB3_CALLING_CONVENTION
# define ADB3_CALLING_CONVENTION
#endif

#elif defined(__VXWORKS__) || defined(__vxworks)

# include <vxWorks.h>
# include <semLib.h>

#ifndef ADB3_EXPORT
# define ADB3_EXPORT
#endif
#ifndef ADB3_CALLING_CONVENTION
# define ADB3_CALLING_CONVENTION
#endif

#else

# error Cannot detect target operating system.

#endif

#include <adb3/platform.h>
#include <adb3/status.h>
#include <adb3/types.h>
#include <adb3/structs.h>
#include <adb3/iprogt.h>

/*
** Function prototypes
*/
#ifdef __cplusplus
extern "C" {
#endif

ADB3_EXPORT ADB3_STATUS
ADB3_CALLING_CONVENTION
ADB3_AbortIPROG(
  ADB3_HANDLE             hCard,
  unsigned int            targetIndex);

ADB3_EXPORT ADB3_STATUS
ADB3_CALLING_CONVENTION
ADB3_ScheduleIPROG(
  ADB3_HANDLE             hCard,
  unsigned int            targetIndex,
  _ADB3_UINT32            flags,
  _ADB3_UINT64            address,
  _ADB3_UINT32            delayMs);

ADB3_EXPORT ADB3_STATUS
ADB3_CALLING_CONVENTION
ADB3_StatusIPROG(
  ADB3_HANDLE             hCard,
  unsigned int            targetIndex,
  _ADB3_UINT32*           pFlags,
  _ADB3_UINT64*           pAddress,
  _ADB3_UINT32*           pDelayMs);

#ifdef __cplusplus
}
#endif

#endif
