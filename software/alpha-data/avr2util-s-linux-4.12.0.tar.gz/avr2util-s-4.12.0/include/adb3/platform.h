#ifndef _ADATA_ADB3_PLATFORM_H
#define _ADATA_ADB3_PLATFORM_H

/*
** platform.h - define elementary datatypes used by API
**
** (C) Copyright Alpha Data 2011
**
** The integer datatypes defined below prefixed by "_ADB3_", such as
** "_ADB3_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that
** makes use of the ADB3 API.
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

typedef INT32  _ADB3_INT32;
typedef INT16  _ADB3_INT16;
typedef UINT64 _ADB3_UINT64;
typedef UINT32 _ADB3_UINT32;
typedef UINT16 _ADB3_UINT16;
typedef UINT8  _ADB3_UINT8;
typedef UINT8  _ADB3_BYTE;
typedef BOOL   _ADB3_BOOL;

typedef HANDLE ADB3_HANDLE;

/* This value is invalid for an ADB3_HANDLE */ 
# define ADB3_HANDLE_INVALID_VALUE (NULL)

#elif defined(__linux) || defined(__VXWORKS__) || defined(__vxworks)

/* Linux or VxWorks - assume C99-compliant */

# if defined(__linux)
#   include <stdint.h>
# endif

typedef int32_t  _ADB3_INT32;
typedef int16_t  _ADB3_INT16;
typedef uint64_t _ADB3_UINT64;
typedef uint32_t _ADB3_UINT32;
typedef uint16_t _ADB3_UINT16;
typedef uint8_t  _ADB3_UINT8;
typedef uint8_t  _ADB3_BYTE;
typedef int      _ADB3_BOOL;

typedef int ADB3_HANDLE;

/* This value is invalid for an ADB3_HANDLE */ 
# define ADB3_HANDLE_INVALID_VALUE (-1)

#else

# error Cannot detect target operating system.

#endif

#endif
