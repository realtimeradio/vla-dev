#ifndef _ADATA_AVR2_TYPES_H
#define _ADATA_AVR2_TYPES_H

/*
** <avr2/types.h> - scalar types used in AVR2 API
**
** (C) Copyright Alpha Data 2019
*/

/* Firmware 2.3.x.y or lower sends an exta bogus EOP at the end of the I2CWrite response. */
/* Define a flag for working around this issue. */
#define AVR2_COMMAND_FLAG_EXPECT_BOGUS_EOP (0x1)

#endif
