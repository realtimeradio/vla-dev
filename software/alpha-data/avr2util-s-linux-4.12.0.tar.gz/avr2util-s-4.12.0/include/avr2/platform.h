#ifndef _ADATA_AVR2_PLATFORM_H
#define _ADATA_AVR2_PLATFORM_H

/*
** <avr2/platform.h> - define elementary datatypes used by API
**
** (C) Copyright Alpha Data 2016
**
** The integer datatypes defined below prefixed by "_AVR2_", such as
** "_AVR2_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that
** makes use of the AVR2 API.
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

typedef INT32  _AVR2_INT32;
typedef INT16  _AVR2_INT16;
typedef UINT64 _AVR2_UINT64;
typedef UINT32 _AVR2_UINT32;
typedef UINT16 _AVR2_UINT16;
typedef UINT8  _AVR2_UINT8;
typedef UINT8  _AVR2_BYTE;
typedef BOOL   _AVR2_BOOL;

typedef HANDLE AVR2_HANDLE;

/* This value is invalid for an AVR2_HANDLE */ 
# define AVR2_HANDLE_INVALID_VALUE (NULL)

#elif defined(__linux) || defined(__VXWORKS__) || defined(__vxworks)

/* Linux or VxWorks - assume C99-compliant */

# if defined(__linux)
#   include <stdint.h>
# endif

typedef int32_t  _AVR2_INT32;
typedef int16_t  _AVR2_INT16;
typedef uint64_t _AVR2_UINT64;
typedef uint32_t _AVR2_UINT32;
typedef uint16_t _AVR2_UINT16;
typedef uint8_t  _AVR2_UINT8;
typedef uint8_t  _AVR2_BYTE;
typedef int      _AVR2_BOOL;

typedef int AVR2_HANDLE;

/* This value is invalid for an AVR2_HANDLE */ 
# define AVR2_HANDLE_INVALID_VALUE (-1)

#else

# error Cannot detect target operating system.

#endif

#endif
