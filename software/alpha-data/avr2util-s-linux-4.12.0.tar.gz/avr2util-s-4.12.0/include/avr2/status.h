#ifndef _ADATA_AVR2_STATUS_H
#define _ADATA_AVR2_STATUS_H

/*
** <avr2/status.h> - status codes returned by AVR2 API calls
**
** (C) Copyright Alpha Data 2016
*/

/*
** Base value for error status codes
*/
#define AVR2_STATUS_ERROR_CODE_START (0x200U)

/*
** Status and error codes
*/
typedef enum _AVR2_STATUS
{
    AVR2_SUCCESS                 = 0,

    /* An error in the API logic was detected */
    AVR2_INTERNAL_ERROR          = AVR2_STATUS_ERROR_CODE_START,

    /* An unexpected error caused the operation to fail */
    AVR2_UNEXPECTED_ERROR,

    /* The driver may not be correctly installed */
    AVR2_BAD_DRIVER,

    /* Couldn't allocate memory required to complete operation */
    AVR2_NO_MEMORY,

    /* The calling process does not have permission to perform the operation */
    AVR2_ACCESS_DENIED,

    /* Failed to open the device with the specified index */
    AVR2_DEVICE_NOT_FOUND,

    /* An error in the hardware was detected */
    AVR2_HARDWARE_ERROR,

    /* The supplied buffer was invalid and could not be read/written */
    AVR2_INVALID_BUFFER,

    /* A flag was invalid or not recognized */
    AVR2_INVALID_FLAG,

    /* The device handle was invalid */
    AVR2_INVALID_HANDLE,

    /* The index parameter was invalid */
    AVR2_INVALID_INDEX,

    /* The offset and/or length parameters were invalid */
    AVR2_INVALID_REGION,

    /* A NULL pointer was passed where non-NULL was required */
    AVR2_NULL_POINTER,

    /* The operation was cancelled */
    AVR2_CANCELLED,

    /* A resource limit was reached */
    AVR2_RESOURCE_LIMIT,

    /* The specified region was too large for a single operation */
    AVR2_REGION_TOO_LARGE,

    /* Reserved status code */
    AVR2_STATUS_RESERVED1,

    /* The operation was attempted when the device was not in the proper mode */
    AVR2_WRONG_MODE,

    /* The operation is not supported for this device */
    AVR2_NOT_SUPPORTED,

    /* A parameter had an illegal value */
    AVR2_INVALID_PARAMETER,

    /* The operation did not complete within the timeout period */
    AVR2_TIMEOUT,

    /* The length of the command was less than 2 bytes */
    AVR2_SHORT_COMMAND,

    /* Failed to set baud rate */
    AVR2_SET_BAUD_FAILED,

    AVR2_STATUS_FORCE32BITS = 0x7FFFFFFF
} AVR2_STATUS;

#endif
