#ifndef _ADATA_AVR2_STRUCT_H
#define _ADATA_AVR2_STRUCT_H

/*
** <avr2/struct.h> - structs used in AVR2 API
**
** (C) Copyright Alpha Data 2016
*/

/* Nothing here yet */

#endif
