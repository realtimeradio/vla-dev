#ifndef _ADATA_ADMXRC3_TICKET_H
#define _ADATA_ADMXRC3_TICKET_H

/*
** ticket.h - define ADMXRC3_TICKET datatype (if supported on platform)
**
** (C) Copyright Alpha Data 2010
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

typedef struct _ADMXRC3_TICKET {
  OVERLAPPED Overlapped;
} ADMXRC3_TICKET;

#elif defined(__linux) || defined(__VXWORKS__) || defined(__vxworks)

/* Linux or VxWorks */

typedef struct _ADMXRC3_TICKET {
  void* pReserved; /* Do not touch */
} ADMXRC3_TICKET;

#else

# error Cannot detect target operating system.

#endif

#endif
