#ifndef _ADATA_ADMXRC3_STATUS_H
#define _ADATA_ADMXRC3_STATUS_H

/*
** status.h - status codes returned by ADMXRC3 API calls
**
** (C) Copyright Alpha Data 2009-2010
*/

/*
** Base value for error status codes
*/
#define ADMXRC3_STATUS_ERROR_CODE_START (0x100U)

/*
** Status and error codes
*/
typedef enum _ADMXRC3_STATUS
{
    ADMXRC3_SUCCESS                 = 0,

    /* An error in the API logic was detected */
    ADMXRC3_INTERNAL_ERROR          = ADMXRC3_STATUS_ERROR_CODE_START,

    /* An unexpected error caused the operation to fail */
    ADMXRC3_UNEXPECTED_ERROR,

    /* The driver may not be correctly installed */
    ADMXRC3_BAD_DRIVER,

    /* Couldn't allocate memory required to complete operation */
    ADMXRC3_NO_MEMORY,

    /* The calling process does not have permission to perform the operation */
    ADMXRC3_ACCESS_DENIED,

    /* Failed to open the device with the specified index */
    ADMXRC3_DEVICE_NOT_FOUND,

    /* Failed to open the .BIT file with the specified filename */
    ADMXRC3_FILE_NOT_FOUND,

    /* An error in the hardware was detected */
    ADMXRC3_HARDWARE_ERROR,

    /* The FPGA on the card did not match that of the bitstream file */
    ADMXRC3_FPGA_MISMATCH,

    /* The .BIT file appeared to be corrupt */
    ADMXRC3_INVALID_BITSTREAM,

    /* The supplied buffer was invalid and could not be read/written */
    ADMXRC3_INVALID_BUFFER,

    /* A flag was invalid or not recognized */
    ADMXRC3_INVALID_FLAG,

    /* The clock frequency was invalid for the specified clock generator */
    ADMXRC3_INVALID_FREQUENCY,

    /* The device handle was invalid */
    ADMXRC3_INVALID_HANDLE,

    /* The index parameter was invalid */
    ADMXRC3_INVALID_INDEX,

    /* The offset and/or length parameters were invalid */
    ADMXRC3_INVALID_REGION,

    /* A NULL pointer was passed where non-NULL was required */
    ADMXRC3_NULL_POINTER,

    /* There is already an operation in progress for the specified device */
    ADMXRC3_BUSY,

    /* There is nothing to cancel */
    ADMXRC3_CANCEL_FAILED,

    /* The operation was cancelled */
    ADMXRC3_CANCELLED,

    /* A resource limit was reached */
    ADMXRC3_RESOURCE_LIMIT,

    /* The specified region was too large for a single operation */
    ADMXRC3_REGION_TOO_LARGE,

    /* The specified operation couldn't be started immediately */
    ADMXRC3_MUST_WAIT,

    /* The buffer handle belongs to a different device handle */
    ADMXRC3_NOT_OWNER,

    /* The non-blocking operation is not yet complete */
    ADMXRC3_PENDING,

    /* There is no non-blocking operation to finish */
    ADMXRC3_NONBLOCK_IDLE,

    /* The buffer handle was invalid */
    ADMXRC3_INVALID_BUFFER_HANDLE,

    /* The local address region was invalid */
    ADMXRC3_INVALID_LOCAL_REGION,

    /* The datatype was invalid for the specified sensor */
    ADMXRC3_DATATYPE_MISMATCH,

    /* The hardware does not support the requested operation */
    ADMXRC3_NOT_SUPPORTED,

    ADMXRC3_STATUS_FORCE32BITS = 0x7FFFFFFF
} ADMXRC3_STATUS;

#endif
