#ifndef _ADATA_ADMXRC3_STRUCTS_H
#define _ADATA_ADMXRC3_STRUCTS_H

/*
** structs.h - structs used in ADMXRC3 API
**
** (C) Copyright Alpha Data 2009-2010
*/

/*
** Bank information structure, returned by ADMXRC3_GetBankInfo
*/

typedef struct _ADMXRC3_BANK_INFO {
  _ADMXRC3_UINT64 MaximumFrequency;  /* Maximum operating frequency, in Hz                */
  _ADMXRC3_UINT64 MinimumFrequency;  /* Minimum operating frequency, in Hz                */
  _ADMXRC3_UINT64 PhysicalSize;      /* Number of physical data words                     */
  _ADMXRC3_UINT16 PhysicalDataWidth; /* Number of physical data lines                     */
  _ADMXRC3_UINT16 PhysicalECCWidth;  /* Number of physical ECC lines                      */
  _ADMXRC3_UINT16 PhysicalWidth;     /* Number of physical data & ECC lines               */
  _ADMXRC3_UINT16 Reserved1;
  _ADMXRC3_UINT32 TypeMask;          /* Bitmask of RAM mode(s) supported                  */
  _ADMXRC3_UINT32 ConnectivityMask;  /* Bitmask of target FPGAs that bank is connected to */
  _ADMXRC3_BOOL   Present;           /* TRUE if physically present                        */
} ADMXRC3_BANK_INFO;

/*
** Notes:
**  1. If MaximimFrequency == 0, then both MaximimFrequency & MininimFrequency must
**     be considered unknown.
*/

/*
** Bitstream structure, returned by ADMXRC3_LoadBitstream
*/

/* ANSI string version */
typedef struct _ADMXRC3_BITSTREAMA {
  char            Identifier[32];  /* Same format as in ADMXRC3_FPGA_INFOA */
  _ADMXRC3_UINT32 Length;          /* Length in bytes of 'Data' field */
  _ADMXRC3_BYTE   Data[4];         /* Variable length array containing SelectMap data (4 bytes to avoid struct packing issues) */
} ADMXRC3_BITSTREAMA;

/* Unicode string version */
typedef struct _ADMXRC3_BITSTREAMW {
  wchar_t         Identifier[32]; /* Same format as in ADMXRC3_FPGA_INFOW */
  _ADMXRC3_UINT32 Length;         /* Length in bytes of 'Data' field */
  _ADMXRC3_BYTE   Data[4];        /* Variable length array containing SelectMap data (4 bytes to avoid struct packing issues) */
} ADMXRC3_BITSTREAMW;

#if defined(_UNICODE)
# define ADMXRC3_BITSTREAM ADMXRC3_BITSTREAMW
#else
# define ADMXRC3_BITSTREAM ADMXRC3_BITSTREAMA
#endif

/*
** Card information structure, returned by ADMXRC3_GetCardInfo
*/

typedef struct _ADMXRC3_CARD_INFO {
  _ADMXRC3_UINT32    SerialNumber;
  _ADMXRC3_UINT32    Reserved1;
  ADMXRC3_MODEL_TYPE Model;
  unsigned int       NumClockGen;
  unsigned int       NumDmaChannel;
  unsigned int       NumFlashBank;
  unsigned int       NumMemoryBank;
  unsigned int       NumTargetFpga;
  unsigned int       NumWindow;
  _ADMXRC3_UINT32    MemoryBankPresent;
} ADMXRC3_CARD_INFO;

/*
** Card information structure, returned by ADMXRC3_GetCardInfoEx
*/

typedef struct _ADMXRC3_CARD_INFOEX {
  _ADMXRC3_UINT32    SerialNumber;
  _ADMXRC3_UINT32    Reserved1;
  ADMXRC3_MODEL_TYPE Model;
  unsigned int       NumClockGen;
  unsigned int       NumDmaChannel;
  unsigned int       NumFlashBank;
  unsigned int       NumMemoryBank;
  unsigned int       NumTargetFpga;
  unsigned int       NumWindow;
  _ADMXRC3_UINT32    MemoryBankPresent;
  unsigned int       NumSensor;
  unsigned int       NumModuleSite;
  unsigned int       Reserved2;
} ADMXRC3_CARD_INFOEX;

/*
** Flash information structure, returned by ADMXRC3_GetFlashInfo
*/

typedef struct _ADMXRC3_FLASH_INFOA {
  char            Identifier[32];  /* Freeform string                                           */
  _ADMXRC3_UINT64 Size;            /* Size of Flash, in bytes                                   */
  _ADMXRC3_UINT64 UseableStart;    /* Address (in bytes) of beginning of user-programmable area */
  _ADMXRC3_UINT64 UseableLength;   /* Length (in bytes) of user-programmable area               */
} ADMXRC3_FLASH_INFOA;

typedef struct _ADMXRC3_FLASH_INFOW {
  wchar_t         Identifier[32];  /* Freeform string                                           */
  _ADMXRC3_UINT64 Size;            /* Size of Flash, in bytes                                   */
  _ADMXRC3_UINT64 UseableStart;    /* Address (in bytes) of beginning of user-programmable area */
  _ADMXRC3_UINT64 UseableLength;   /* Length (in bytes) of user-programmable area               */
} ADMXRC3_FLASH_INFOW;

#if defined(_UNICODE)
#   define ADMXRC3_FLASH_INFO ADMXRC3_FLASH_INFOW
#else
#   define ADMXRC3_FLASH_INFO ADMXRC3_FLASH_INFOA
#endif

/*
** Flash block information structure, returned by ADMXRC3_GetFlashBlockInfo
*/

typedef struct _ADMXRC3_FLASHBLOCK_INFO {
  _ADMXRC3_UINT64 Address;        /* Address (in bytes) of Flash block                         */
  _ADMXRC3_UINT64 Length;         /* Length (in bytes) of Flash block                          */
  _ADMXRC3_UINT32 Flags;          /* See flag definitions below                                */
} ADMXRC3_FLASHBLOCK_INFO;

/*
** FPGA information structure, returned by ADMXRC3_GetFpgaInfo
*/

#if defined(_UNICODE)
#   define ADMXRC3_FPGA_INFO ADMXRC3_FPGA_INFOW
#else
#   define ADMXRC3_FPGA_INFO ADMXRC3_FPGA_INFOA
#endif

/* ANSI string version */
typedef struct _ADMXRC3_FPGA_INFOA {
  char                   Identifier[32];    /* Upper case string in form as seen in .BIT file          */
  ADMXRC3_FPGA_TYPE      DeviceCode;        /* Device; see ADMXRC3_FPGA_TYPE                           */
  ADMXRC3_FAMILY_TYPE    FamilyCode;        /* Family; see ADMXRC3_FAMILY_TYPE                         */
  ADMXRC3_SUBFAMILY_TYPE SubfamilyCode;     /* Subfamily; see ADMXRC3_SUBFAMILY_TYPE                   */
  ADMXRC3_PACKAGE_TYPE   PackageCode;       /* Package; see ADMXRC3_PACKAGE_TYPE                       */
  char                   Device[16];        /* As 'DeviceCode', but upper case string e.g. "2VP7"      */
  char                   Package[16];       /* As 'Package', but upper case string e.g. "FG456"        */
  _ADMXRC3_UINT32        Flags;             /* Indicates which of following fields are valid           */
  char                   SpeedGrade[8];     /* Speed grade including "C" or "I"                        */
  char                   Stepping[8];       /* Stepping level, or -1 if not known                      */
  _ADMXRC3_BOOL          Present;           /* TRUE if the device is physically present                */ 
} ADMXRC3_FPGA_INFOA;

/* Unicode string version */
typedef struct _ADMXRC3_FPGA_INFOW {
  wchar_t                Identifier[32];    /* Upper case string in form as seen in .BIT file          */
  ADMXRC3_FPGA_TYPE      DeviceCode;        /* Device; see ADMXRC3_FPGA_TYPE                           */
  ADMXRC3_FAMILY_TYPE    FamilyCode;        /* Family; see ADMXRC3_FAMILY_TYPE                         */
  ADMXRC3_SUBFAMILY_TYPE SubfamilyCode;     /* Subfamily; see ADMXRC3_SUBFAMILY_TYPE                   */
  ADMXRC3_PACKAGE_TYPE   PackageCode;       /* Package; see ADMXRC3_PACKAGE_TYPE                       */
  wchar_t                Device[16];        /* As 'DeviceCode', but upper case string e.g. "2VP7"      */
  wchar_t                Package[16];       /* As 'Package', but upper case string e.g. "FG456"        */
  _ADMXRC3_UINT32        Flags;             /* Indicates which of following fields are valid           */
  wchar_t                SpeedGrade[8];     /* Speed grade including "C" or "I"                        */
  wchar_t                Stepping[8];       /* Stepping level, or -1 if not known                      */
  _ADMXRC3_BOOL          Present;           /* TRUE if the device is physically present                */ 
} ADMXRC3_FPGA_INFOW;

/*
** Version information structure, returned by ADMXRC3_GetVersionInfo
*/

typedef struct _ADMXRC3_VERSION_INFO {
  struct _ApiVersion {
    _ADMXRC3_UINT16 Major;
    _ADMXRC3_UINT16 Minor;
    _ADMXRC3_UINT16 Bugfix;
  } Api;
  struct _DriverVersion {
    _ADMXRC3_UINT16 Major;
    _ADMXRC3_UINT16 Minor;
    _ADMXRC3_UINT16 Bugfix;
  } Driver;
} ADMXRC3_VERSION_INFO;

/*
** Local bus window information structure, returned by ADMXRC3_GetWindowInfo
*/

typedef struct _ADMXRC3_WINDOW_INFO {
  _ADMXRC3_UINT64 BusSize;
  _ADMXRC3_UINT64 BusBase;
  _ADMXRC3_UINT64 LocalSize;    /* 0 if no presence on local bus */
  _ADMXRC3_UINT64 LocalBase;
  _ADMXRC3_UINT64 VirtualSize;
} ADMXRC3_WINDOW_INFO;

/*
** Module information structure, returned by ADMXRC3_GetModuleInfo
*/

typedef struct _ADMXRC3_MODULE_INFOA {
  char            Product[64];      /* From FRU, valid if not a legacy XRM */
  char            PartNumber[64];   /* From FRU, valid if not a legacy XRM */
  char            Manufacturer[64]; /* From FRU, valid if not a legacy XRM */
  char            SerialNumber[64]; /* From FRU, valid if not a legacy XRM */
  double          IoVoltage;        /* From FRU, valid if not a legacy XRM */
  _ADMXRC3_UINT32 ManufactureDate;  /* From FRU, valid if not a legacy XRM, number of minutes since 00:00 1/1/1996 */
  _ADMXRC3_UINT32 Flags;
  _ADMXRC3_BOOL   Present;
} ADMXRC3_MODULE_INFOA;

typedef struct _ADMXRC3_MODULE_INFOW {
  wchar_t         Product[64];      /* From FRU, valid if not a legacy XRM */
  wchar_t         PartNumber[64];   /* From FRU, valid if not a legacy XRM */
  wchar_t         Manufacturer[64]; /* From FRU, valid if not a legacy XRM */
  wchar_t         SerialNumber[64]; /* From FRU, valid if not a legacy XRM */
  double          IoVoltage;        /* From FRU, valid if not a legacy XRM */
  _ADMXRC3_UINT32 ManufactureDate;  /* From FRU, valid if not a legacy XRM, number of minutes since 00:00 1/1/1996 */
  _ADMXRC3_UINT32 Flags;
  _ADMXRC3_BOOL   Present;
} ADMXRC3_MODULE_INFOW;

#if defined(_UNICODE)
#   define ADMXRC3_MODULE_INFO ADMXRC3_MODULE_INFOW
#else
#   define ADMXRC3_MODULE_INFO ADMXRC3_MODULE_INFOA
#endif

typedef union _ADMXRC3_SENSOR_VALUE {
  _ADMXRC3_BOOL   Bool;
  double          Double;
  _ADMXRC3_INT32  Int32;
  _ADMXRC3_UINT32 UInt32;
} ADMXRC3_SENSOR_VALUE;

typedef struct _ADMXRC3_SENSOR_INFOA {
  char              Description[28];
  _ADMXRC3_UINT32   Capabilities;
  double            Error;            /* As a fraction or multiple of Unit * Exponent */
  ADMXRC3_DATA_TYPE DataType;
  ADMXRC3_UNIT_TYPE Unit;
  int               Exponent;         /* Power of 10 */
} ADMXRC3_SENSOR_INFOA;

typedef struct _ADMXRC3_SENSOR_INFOW {
  wchar_t           Description[28];
  _ADMXRC3_UINT32   Capabilities;
  double            Error;            /* As a fraction or multiple of Unit * Exponent */
  ADMXRC3_DATA_TYPE DataType;
  ADMXRC3_UNIT_TYPE Unit;
  int               Exponent;         /* Power of 10 */
} ADMXRC3_SENSOR_INFOW;

#if defined(_UNICODE)
# define ADMXRC3_SENSOR_INFO ADMXRC3_SENSOR_INFOW
#else
# define ADMXRC3_SENSOR_INFO ADMXRC3_SENSOR_INFOA
#endif

/*
** Device status structure, returned by ADMXRC3_GetDeviceStatus
*/

typedef struct _ADMXRC3_DEVICE_STATUS {
  /* Generic errors */
  _ADMXRC3_UINT32 Window;       /* Window (Direct Slave) errors, see ADMXRC3_DS_xxx below */
  _ADMXRC3_UINT32 DMA;          /* DMA engine errors, see ADMXRC3_DMA_xxx below */
  _ADMXRC3_UINT32 DirectMaster; /* Direct Master errors, see ADMXRC3_DM_xxx below */
  _ADMXRC3_UINT32 Reserved1[3];
  /* 64 bits of model-specific errors follow */
  _ADMXRC3_UINT32 ModelLow;     /* Model-specific errors low DWORD */
  _ADMXRC3_UINT32 ModelHigh;    /* Model-specific errors high DWORD */
} ADMXRC3_DEVICE_STATUS;

#endif
