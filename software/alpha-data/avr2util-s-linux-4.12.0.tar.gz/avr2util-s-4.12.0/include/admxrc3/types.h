#ifndef _ADATA_ADMXRC3_TYPES_H
#define _ADATA_ADMXRC3_TYPES_H

/*
** types.h - scalar datatypes used in ADMXRC3 API
**
** (C) Copyright Alpha Data 2009-2012
*/

/* Datatype for representing the datatype of sensor readings */
typedef enum _ADMXRC3_DATA_TYPE {
  ADMXRC3_DATA_BOOL      = 0, /* BOOL (Windows) or int (Linux / VxWorks) */
  ADMXRC3_DATA_DOUBLE    = 1, /* double */
  ADMXRC3_DATA_INT32     = 2, /* INT32 (Windows) or int32_t (Linux / VxWorks) */
  ADMXRC3_DATA_UINT32    = 3, /* UINT32 (Windows) or uint32_t (Linux / VxWorks) */
  ADMXRC3_DATA_LASTVALUE = 4, /* Reserved for adding new data types */
  ADMXRC3_DATA_FORCE32BITS = 0x7FFFFFFF
} ADMXRC3_DATA_TYPE;

/* Datatype that represents an FPGA family */
typedef enum _ADMXRC3_FAMILY_TYPE {
  ADMXRC3_FAMILY_4K             = 0,
  ADMXRC3_FAMILY_VIRTEX         = 1,
  ADMXRC3_FAMILY_VIRTEX2        = 2,
  ADMXRC3_FAMILY_VIRTEX2P       = 3,
  ADMXRC3_FAMILY_VIRTEX4        = 4,
  ADMXRC3_FAMILY_VIRTEX5        = 5,
  ADMXRC3_FAMILY_VIRTEX6        = 6,
  ADMXRC3_FAMILY_7SERIES        = 7,
  ADMXRC3_FAMILY_ULTRASCALE     = 8,
  ADMXRC3_FAMILY_VERSAL         = 9,
  ADMXRC3_FAMILY_FORCE32BITS    = 0x7FFFFFFF
} ADMXRC3_FAMILY_TYPE;

typedef enum _ADMXRC3_SUBFAMILY_TYPE {
  ADMXRC3_SUBFAMILY_NONE        = 0,
  ADMXRC3_SUBFAMILY_E           = 16,  /* Virtex-E */
  ADMXRC3_SUBFAMILY_EM          = 17,  /* Virtex-EM */
  ADMXRC3_SUBFAMILY_2PROX       = 48,  /* Virtex-II Pro-X */
  ADMXRC3_SUBFAMILY_4FX         = 64,  /* Virtex-4 FX */
  ADMXRC3_SUBFAMILY_4LX         = 65,  /* Virtex-4 LX */
  ADMXRC3_SUBFAMILY_4SX         = 66,  /* Virtex-4 SX */
  ADMXRC3_SUBFAMILY_5LX         = 80,  /* Virtex-5 LX */
  ADMXRC3_SUBFAMILY_5FXT        = 84,  /* Virtex-5 FXT */
  ADMXRC3_SUBFAMILY_5LXT        = 85,  /* Virtex-5 LXT */
  ADMXRC3_SUBFAMILY_5SXT        = 86,  /* Virtex-5 SXT */
  ADMXRC3_SUBFAMILY_6LX         = 96,  /* Virtex-6 LX */
  ADMXRC3_SUBFAMILY_6HXT        = 97,  /* Virtex-6 HXT */
  ADMXRC3_SUBFAMILY_6LXT        = 98,  /* Virtex-6 LXT */
  ADMXRC3_SUBFAMILY_6SXT        = 99,  /* Virtex-6 SXT */
  ADMXRC3_SUBFAMILY_7AT         = 112, /* Artix-7T */
  ADMXRC3_SUBFAMILY_7KT         = 113, /* Kintex-7T */
  ADMXRC3_SUBFAMILY_7VT         = 114, /* Virtex-7T */
  ADMXRC3_SUBFAMILY_7VXT        = 115, /* Virtex-7XT */
  ADMXRC3_SUBFAMILY_7VHT        = 116, /* Virtex-7HT */
  ADMXRC3_SUBFAMILY_7Z          = 117, /* Zynq-7 */
  ADMXRC3_SUBFAMILY_UK          = 128, /* Kintex Ultrascale */
  ADMXRC3_SUBFAMILY_UV          = 129, /* Virtex Ultrascale */
  ADMXRC3_SUBFAMILY_UKP         = 130, /* Kintex Ultrascale+ */
  ADMXRC3_SUBFAMILY_UVP         = 131, /* Virtex Ultrascale+ */
  ADMXRC3_SUBFAMILY_UZP         = 132, /* Zynq Ultrascale+ */
  ADMXRC3_SUBFAMILY_VC          = 136, /* Versal AI */
  ADMXRC3_SUBFAMILY_VM          = 137, /* Versal Prime */
  ADMXRC3_SUBFAMILY_VP          = 138, /* Versal Premium */
  ADMXRC3_SUBFAMILY_FORCE32BITS = 0x7FFFFFFF
} ADMXRC3_SUBFAMILY_TYPE;

/* Construct a package code */
#define ADMXRC3_PACKAGE_MAKE(t0, t1, n) (((t0) << 24) | ((t1) << 16) | ((n) & 0xffffU))
#define ADMXRC3_PACKAGE_MAKEBG(n) ADMXRC3_PACKAGE_MAKE('B', 'G', (n))
#define ADMXRC3_PACKAGE_MAKEFF(n) ADMXRC3_PACKAGE_MAKE('F', 'F', (n))
#define ADMXRC3_PACKAGE_MAKEFG(n) ADMXRC3_PACKAGE_MAKE('F', 'G', (n))
#define ADMXRC3_PACKAGE_MAKEFH(n) ADMXRC3_PACKAGE_MAKE('F', 'H', (n))
#define ADMXRC3_PACKAGE_MAKEFL(n) ADMXRC3_PACKAGE_MAKE('F', 'L', (n))

/* Construct Ultrascale pacakage codes; see Xilinx UG585 */
#define ADMXRC3_PACKAGE_MAKEFBVA(n) ADMXRC3_PACKAGE_MAKE('B', 'A', (n)) /* FBVA */
#define ADMXRC3_PACKAGE_MAKEFFVA(n) ADMXRC3_PACKAGE_MAKE('F', 'A', (n)) /* FFVA */
#define ADMXRC3_PACKAGE_MAKEFFVB(n) ADMXRC3_PACKAGE_MAKE('F', 'B', (n)) /* FFVB */
#define ADMXRC3_PACKAGE_MAKEFFVC(n) ADMXRC3_PACKAGE_MAKE('F', 'C', (n)) /* FFVC */
#define ADMXRC3_PACKAGE_MAKEFFVD(n) ADMXRC3_PACKAGE_MAKE('F', 'D', (n)) /* FFVD */
#define ADMXRC3_PACKAGE_MAKEFLVA(n) ADMXRC3_PACKAGE_MAKE('L', 'A', (n)) /* FLVA */
#define ADMXRC3_PACKAGE_MAKEFLVB(n) ADMXRC3_PACKAGE_MAKE('L', 'B', (n)) /* FLVB */
#define ADMXRC3_PACKAGE_MAKEFLVC(n) ADMXRC3_PACKAGE_MAKE('L', 'C', (n)) /* FLVC */
#define ADMXRC3_PACKAGE_MAKEFLVD(n) ADMXRC3_PACKAGE_MAKE('L', 'D', (n)) /* FLVD */
#define ADMXRC3_PACKAGE_MAKEFLVF(n) ADMXRC3_PACKAGE_MAKE('L', 'F', (n)) /* FLVF */
#define ADMXRC3_PACKAGE_MAKEFLGA(n) ADMXRC3_PACKAGE_MAKE('f', 'A', (n)) /* FLGA */
#define ADMXRC3_PACKAGE_MAKEFLGB(n) ADMXRC3_PACKAGE_MAKE('f', 'B', (n)) /* FLGB */
#define ADMXRC3_PACKAGE_MAKEFLGC(n) ADMXRC3_PACKAGE_MAKE('f', 'C', (n)) /* FLGC */

/* Deconstruct a package code */
#define ADMXRC3_PACKAGE_GETTYPE0(n) ((char)((n) >> 24))
#define ADMXRC3_PACKAGE_GETTYPE1(n) ((char)((n) >> 16))
#define ADMXRC3_PACKAGE_GETPINS(n) ((n) & 0xffffU)

/* A package code comprised of several bitfields; use above macros to manipulate */
typedef _ADMXRC3_UINT32 ADMXRC3_PACKAGE_TYPE;

/* Handle to a locked-down buffer */
typedef _ADMXRC3_UINT32 ADMXRC3_BUFFER_HANDLE;

/* Datatype that represents the FPGA family and density */
typedef enum _ADMXRC3_FPGA_TYPE {
  ADMXRC3_FPGA_RESVD0           = 0,
  ADMXRC3_FPGA_RESVD1           = 1,
  ADMXRC3_FPGA_RESVD2           = 2,
  ADMXRC3_FPGA_RESVD3           = 3,
  ADMXRC3_FPGA_V1000            = 4,
  ADMXRC3_FPGA_V400             = 5,
  ADMXRC3_FPGA_V600             = 6,
  ADMXRC3_FPGA_V800             = 7,
  ADMXRC3_FPGA_V2000E           = 8,
  ADMXRC3_FPGA_V1000E           = 9,
  ADMXRC3_FPGA_V1600E           = 10,
  ADMXRC3_FPGA_V3200E           = 11,
  ADMXRC3_FPGA_V812E            = 12,
  ADMXRC3_FPGA_V405E            = 13,
  ADMXRC3_FPGA_RESVD14          = 14,
  ADMXRC3_FPGA_RESVD15          = 15,
  ADMXRC3_FPGA_RESVD16          = 16,
  ADMXRC3_FPGA_RESVD17          = 17,
  ADMXRC3_FPGA_RESVD18          = 18,
  ADMXRC3_FPGA_RESVD19          = 19,
  ADMXRC3_FPGA_RESVD20          = 20,
  ADMXRC3_FPGA_RESVD21          = 21,
  ADMXRC3_FPGA_RESVD22          = 22,
  ADMXRC3_FPGA_RESVD23          = 23,
  ADMXRC3_FPGA_RESVD24          = 24,
  ADMXRC3_FPGA_RESVD25          = 25,
  ADMXRC3_FPGA_RESVD26          = 26,
  ADMXRC3_FPGA_RESVD27          = 27,
  ADMXRC3_FPGA_RESVD28          = 28,
  ADMXRC3_FPGA_RESVD29          = 29,
  ADMXRC3_FPGA_RESVD30          = 30,
  ADMXRC3_FPGA_RESVD31          = 31,
  ADMXRC3_FPGA_2V1000           = 32,
  ADMXRC3_FPGA_2V1500           = 33,
  ADMXRC3_FPGA_2V2000           = 34,
  ADMXRC3_FPGA_2V3000           = 35,
  ADMXRC3_FPGA_2V4000           = 36,
  ADMXRC3_FPGA_2V6000           = 37,
  ADMXRC3_FPGA_2V8000           = 38,
  ADMXRC3_FPGA_2V10000          = 39,
  ADMXRC3_FPGA_RESVD40          = 40,
  ADMXRC3_FPGA_RESVD41          = 41,
  ADMXRC3_FPGA_RESVD42          = 42,
  ADMXRC3_FPGA_RESVD43          = 43,
  ADMXRC3_FPGA_RESVD44          = 44,
  ADMXRC3_FPGA_RESVD45          = 45,
  ADMXRC3_FPGA_RESVD46          = 46,
  ADMXRC3_FPGA_RESVD47          = 47,
  ADMXRC3_FPGA_RESVD48          = 48,
  ADMXRC3_FPGA_RESVD49          = 49,
  ADMXRC3_FPGA_RESVD50          = 50,
  ADMXRC3_FPGA_RESVD51          = 51,
  ADMXRC3_FPGA_RESVD52          = 52,
  ADMXRC3_FPGA_RESVD53          = 53,
  ADMXRC3_FPGA_RESVD54          = 54,
  ADMXRC3_FPGA_RESVD55          = 55,
  ADMXRC3_FPGA_RESVD56          = 56,
  ADMXRC3_FPGA_RESVD57          = 57,
  ADMXRC3_FPGA_RESVD58          = 58,
  ADMXRC3_FPGA_RESVD59          = 59,
  ADMXRC3_FPGA_RESVD60          = 60,
  ADMXRC3_FPGA_RESVD61          = 61,
  ADMXRC3_FPGA_RESVD62          = 62,
  ADMXRC3_FPGA_RESVD63          = 63,
  ADMXRC3_FPGA_2VP2             = 64,
  ADMXRC3_FPGA_2VP4             = 65,
  ADMXRC3_FPGA_2VP7             = 66,
  ADMXRC3_FPGA_2VP20            = 67,
  ADMXRC3_FPGA_2VP30            = 68,
  ADMXRC3_FPGA_2VP40            = 69,
  ADMXRC3_FPGA_2VP50            = 70,
  ADMXRC3_FPGA_2VP100           = 71,
  ADMXRC3_FPGA_2VP125           = 72,
  ADMXRC3_FPGA_2VP70            = 73,
  ADMXRC3_FPGA_RESVD74          = 74,
  ADMXRC3_FPGA_RESVD75          = 75,
  ADMXRC3_FPGA_RESVD76          = 76,
  ADMXRC3_FPGA_RESVD77          = 77,
  ADMXRC3_FPGA_RESVD78          = 78,
  ADMXRC3_FPGA_RESVD79          = 79,
  ADMXRC3_FPGA_RESVD80          = 80,
  ADMXRC3_FPGA_RESVD81          = 81,
  ADMXRC3_FPGA_RESVD82          = 82,
  ADMXRC3_FPGA_RESVD83          = 83,
  ADMXRC3_FPGA_RESVD84          = 84,
  ADMXRC3_FPGA_RESVD85          = 85,
  ADMXRC3_FPGA_RESVD86          = 86,
  ADMXRC3_FPGA_RESVD87          = 87,
  ADMXRC3_FPGA_RESVD88          = 88,
  ADMXRC3_FPGA_RESVD89          = 89,
  ADMXRC3_FPGA_RESVD90          = 90,
  ADMXRC3_FPGA_RESVD91          = 91,
  ADMXRC3_FPGA_RESVD92          = 92,
  ADMXRC3_FPGA_RESVD93          = 93,
  ADMXRC3_FPGA_RESVD94          = 94,
  ADMXRC3_FPGA_RESVD95          = 95,
  ADMXRC3_FPGA_4VLX15           = 96,
  ADMXRC3_FPGA_4VLX25           = 97,
  ADMXRC3_FPGA_4VLX40           = 98,
  ADMXRC3_FPGA_4VLX60           = 99,
  ADMXRC3_FPGA_4VLX100          = 100,
  ADMXRC3_FPGA_4VLX160          = 101,
  ADMXRC3_FPGA_4VLX200          = 102,
  ADMXRC3_FPGA_4VLX80           = 103,
  ADMXRC3_FPGA_4VSX25           = 104,
  ADMXRC3_FPGA_4VSX35           = 105,
  ADMXRC3_FPGA_4VSX55           = 106,
  ADMXRC3_FPGA_RESVD107         = 107,
  ADMXRC3_FPGA_RESVD108         = 108,
  ADMXRC3_FPGA_RESVD109         = 109,
  ADMXRC3_FPGA_RESVD110         = 110,
  ADMXRC3_FPGA_RESVD111         = 111,
  ADMXRC3_FPGA_4VFX12           = 112,
  ADMXRC3_FPGA_4VFX20           = 113,
  ADMXRC3_FPGA_4VFX40           = 114,
  ADMXRC3_FPGA_4VFX60           = 115,
  ADMXRC3_FPGA_4VFX100          = 116,
  ADMXRC3_FPGA_4VFX140          = 117,
  ADMXRC3_FPGA_RESVD118         = 118,
  ADMXRC3_FPGA_RESVD119         = 119,
  ADMXRC3_FPGA_RESVD120         = 120,
  ADMXRC3_FPGA_RESVD121         = 121,
  ADMXRC3_FPGA_RESVD122         = 122,
  ADMXRC3_FPGA_RESVD123         = 123,
  ADMXRC3_FPGA_RESVD124         = 124,
  ADMXRC3_FPGA_RESVD125         = 125,
  ADMXRC3_FPGA_RESVD126         = 126,
  ADMXRC3_FPGA_RESVD127         = 127,
  ADMXRC3_FPGA_5VLX30           = 128,
  ADMXRC3_FPGA_5VLX50           = 129,
  ADMXRC3_FPGA_5VLX85           = 130,
  ADMXRC3_FPGA_5VLX110          = 131,
  ADMXRC3_FPGA_5VLX220          = 132,
  ADMXRC3_FPGA_5VLX330          = 133,
  ADMXRC3_FPGA_RESVD134         = 134,
  ADMXRC3_FPGA_RESVD135         = 135,
  ADMXRC3_FPGA_5VLX30T          = 136,
  ADMXRC3_FPGA_5VLX50T          = 137,
  ADMXRC3_FPGA_5VLX85T          = 138,
  ADMXRC3_FPGA_5VLX110T         = 139,
  ADMXRC3_FPGA_5VLX330T         = 140,
  ADMXRC3_FPGA_5VLX220T         = 141,
  ADMXRC3_FPGA_5VLX155T         = 142,
  ADMXRC3_FPGA_RESVD143         = 143,
  ADMXRC3_FPGA_5VSX35T          = 144,
  ADMXRC3_FPGA_5VSX50T          = 145,
  ADMXRC3_FPGA_5VSX95T          = 146,
  ADMXRC3_FPGA_5VSX240T         = 147,
  ADMXRC3_FPGA_RESVD148         = 148,
  ADMXRC3_FPGA_RESVD149         = 149,
  ADMXRC3_FPGA_RESVD150         = 150,
  ADMXRC3_FPGA_RESVD151         = 151,
  ADMXRC3_FPGA_5VFX100T         = 152,
  ADMXRC3_FPGA_5VFX130T         = 153,
  ADMXRC3_FPGA_5VFX200T         = 154,
  ADMXRC3_FPGA_5VFX30T          = 155,
  ADMXRC3_FPGA_5VFX70T          = 156,
  ADMXRC3_FPGA_RESVD157         = 157,
  ADMXRC3_FPGA_RESVD158         = 158,
  ADMXRC3_FPGA_RESVD159         = 159,
  ADMXRC3_FPGA_6VLX760          = 160,
  ADMXRC3_FPGA_RESVD161         = 161,
  ADMXRC3_FPGA_RESVD162         = 162,
  ADMXRC3_FPGA_RESVD163         = 163,
  ADMXRC3_FPGA_RESVD164         = 164,
  ADMXRC3_FPGA_RESVD165         = 165,
  ADMXRC3_FPGA_RESVD166         = 166,
  ADMXRC3_FPGA_RESVD167         = 167,
  ADMXRC3_FPGA_6VLX75T          = 168,
  ADMXRC3_FPGA_6VLX130T         = 169,
  ADMXRC3_FPGA_6VLX195T         = 170,
  ADMXRC3_FPGA_6VLX240T         = 171,
  ADMXRC3_FPGA_6VLX365T         = 172,
  ADMXRC3_FPGA_6VLX550T         = 173,
  ADMXRC3_FPGA_RESVD174         = 174,
  ADMXRC3_FPGA_RESVD175         = 175,
  ADMXRC3_FPGA_6VSX315T         = 176,
  ADMXRC3_FPGA_6VSX475T         = 177,
  ADMXRC3_FPGA_RESVD178         = 178,
  ADMXRC3_FPGA_RESVD179         = 179,
  ADMXRC3_FPGA_RESVD180         = 180,
  ADMXRC3_FPGA_RESVD181         = 181,
  ADMXRC3_FPGA_RESVD182         = 182,
  ADMXRC3_FPGA_RESVD183         = 183,
  ADMXRC3_FPGA_6VHX250T         = 184,
  ADMXRC3_FPGA_6VHX255T         = 185,
  ADMXRC3_FPGA_6VHX385T         = 186,
  ADMXRC3_FPGA_6VHX565T         = 187,
  ADMXRC3_FPGA_RESVD188         = 188,
  ADMXRC3_FPGA_RESVD189         = 189,
  ADMXRC3_FPGA_RESVD190         = 190,
  ADMXRC3_FPGA_RESVD191         = 191,
  ADMXRC3_FPGA_RESVD192         = 192, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD193         = 193, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD194         = 194, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD195         = 195, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD196         = 196, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD197         = 197, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD198         = 198, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD199         = 199, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD200         = 200, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD201         = 201, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD202         = 202, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD203         = 203, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD204         = 204, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD205         = 205, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD206         = 206, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD207         = 207, /* Reserved for Spartan-6 */
  ADMXRC3_FPGA_RESVD208         = 208,
  ADMXRC3_FPGA_RESVD209         = 209,
  ADMXRC3_FPGA_RESVD210         = 210,
  ADMXRC3_FPGA_RESVD211         = 211,
  ADMXRC3_FPGA_RESVD212         = 212,
  ADMXRC3_FPGA_RESVD213         = 213,
  ADMXRC3_FPGA_RESVD214         = 214,
  ADMXRC3_FPGA_RESVD215         = 215,
  ADMXRC3_FPGA_RESVD216         = 216,
  ADMXRC3_FPGA_RESVD217         = 217,
  ADMXRC3_FPGA_RESVD218         = 218,
  ADMXRC3_FPGA_RESVD219         = 219,
  ADMXRC3_FPGA_RESVD220         = 220,
  ADMXRC3_FPGA_RESVD221         = 221,
  ADMXRC3_FPGA_RESVD222         = 222,
  ADMXRC3_FPGA_RESVD223         = 223,
  ADMXRC3_FPGA_7A100T           = 224,
  ADMXRC3_FPGA_7A200T           = 225,
  ADMXRC3_FPGA_7A350T           = 226,
  ADMXRC3_FPGA_RESVD227         = 227,
  ADMXRC3_FPGA_RESVD228         = 228,
  ADMXRC3_FPGA_RESVD229         = 229,
  ADMXRC3_FPGA_RESVD230         = 230,
  ADMXRC3_FPGA_RESVD231         = 231,
  ADMXRC3_FPGA_7K70T            = 232,
  ADMXRC3_FPGA_7K160T           = 233,
  ADMXRC3_FPGA_7K325T           = 234,
  ADMXRC3_FPGA_7K355T           = 235,
  ADMXRC3_FPGA_7K410T           = 236,
  ADMXRC3_FPGA_7K420T           = 237,
  ADMXRC3_FPGA_7K480T           = 238,
  ADMXRC3_FPGA_RESVD239         = 239,
  ADMXRC3_FPGA_RESVD240         = 240,
  ADMXRC3_FPGA_RESVD241         = 241,
  ADMXRC3_FPGA_RESVD242         = 242,
  ADMXRC3_FPGA_RESVD243         = 243,
  ADMXRC3_FPGA_RESVD244         = 244,
  ADMXRC3_FPGA_RESVD245         = 245,
  ADMXRC3_FPGA_RESVD246         = 246,
  ADMXRC3_FPGA_RESVD247         = 247,
  ADMXRC3_FPGA_7V585T           = 248,
  ADMXRC3_FPGA_7V1500T          = 249,
  ADMXRC3_FPGA_7V2000T          = 250,
  ADMXRC3_FPGA_RESVD251         = 251,
  ADMXRC3_FPGA_RESVD252         = 252,
  ADMXRC3_FPGA_RESVD253         = 253,
  ADMXRC3_FPGA_RESVD254         = 254,
  ADMXRC3_FPGA_RESVD255         = 255,
  ADMXRC3_FPGA_7VX330T          = 256,
  ADMXRC3_FPGA_7VX415T          = 257,
  ADMXRC3_FPGA_7VX485T          = 258,
  ADMXRC3_FPGA_7VX550T          = 259,
  ADMXRC3_FPGA_7VX690T          = 260,
  ADMXRC3_FPGA_7VX980T          = 261,
  ADMXRC3_FPGA_7VX1140T         = 262,
  ADMXRC3_FPGA_RESVD263         = 263,
  ADMXRC3_FPGA_RESVD264         = 264,
  ADMXRC3_FPGA_RESVD265         = 265,
  ADMXRC3_FPGA_RESVD266         = 266,
  ADMXRC3_FPGA_RESVD267         = 267,
  ADMXRC3_FPGA_RESVD268         = 268,
  ADMXRC3_FPGA_RESVD269         = 269,
  ADMXRC3_FPGA_RESVD270         = 270,
  ADMXRC3_FPGA_RESVD271         = 271,
  ADMXRC3_FPGA_7VH290T          = 272,
  ADMXRC3_FPGA_7VH580T          = 273,
  ADMXRC3_FPGA_7VH870T          = 274,
  ADMXRC3_FPGA_RESVD275         = 275,
  ADMXRC3_FPGA_RESVD276         = 276,
  ADMXRC3_FPGA_RESVD277         = 277,
  ADMXRC3_FPGA_RESVD278         = 278,
  ADMXRC3_FPGA_RESVD279         = 279,
  ADMXRC3_FPGA_RESVD280         = 280,
  ADMXRC3_FPGA_RESVD281         = 281,
  ADMXRC3_FPGA_RESVD282         = 282,
  ADMXRC3_FPGA_RESVD283         = 283,
  ADMXRC3_FPGA_RESVD284         = 284,
  ADMXRC3_FPGA_RESVD285         = 285,
  ADMXRC3_FPGA_RESVD286         = 286,
  ADMXRC3_FPGA_RESVD287         = 287,
  ADMXRC3_FPGA_7Z010            = 288,
  ADMXRC3_FPGA_7Z015            = 289,
  ADMXRC3_FPGA_7Z020            = 290,
  ADMXRC3_FPGA_7Z030            = 291,
  ADMXRC3_FPGA_7Z045            = 292,
  ADMXRC3_FPGA_7Z100            = 293,
  ADMXRC3_FPGA_RESVD294         = 294,
  ADMXRC3_FPGA_RESVD295         = 295,
  ADMXRC3_FPGA_RESVD296         = 296,
  ADMXRC3_FPGA_RESVD297         = 297,
  ADMXRC3_FPGA_RESVD298         = 298,
  ADMXRC3_FPGA_RESVD299         = 299,
  ADMXRC3_FPGA_RESVD300         = 300,
  ADMXRC3_FPGA_RESVD301         = 301,
  ADMXRC3_FPGA_RESVD302         = 302,
  ADMXRC3_FPGA_RESVD303         = 303,
  ADMXRC3_FPGA_RESVD304         = 304,
  ADMXRC3_FPGA_RESVD305         = 305,
  ADMXRC3_FPGA_RESVD306         = 306,
  ADMXRC3_FPGA_RESVD307         = 307,
  ADMXRC3_FPGA_RESVD308         = 308,
  ADMXRC3_FPGA_RESVD309         = 309,
  ADMXRC3_FPGA_RESVD310         = 310,
  ADMXRC3_FPGA_RESVD311         = 311,
  ADMXRC3_FPGA_RESVD312         = 312,
  ADMXRC3_FPGA_RESVD313         = 313,
  ADMXRC3_FPGA_RESVD314         = 314,
  ADMXRC3_FPGA_RESVD315         = 315,
  ADMXRC3_FPGA_RESVD316         = 316,
  ADMXRC3_FPGA_RESVD317         = 307,
  ADMXRC3_FPGA_RESVD318         = 318,
  ADMXRC3_FPGA_RESVD319         = 319,
  ADMXRC3_FPGA_RESVD320         = 320,
  ADMXRC3_FPGA_KU035            = 321,
  ADMXRC3_FPGA_KU040            = 322,
  ADMXRC3_FPGA_KU060            = 323,
  ADMXRC3_FPGA_KU075            = 324, /* No longer exists as a Xilinx product */
  ADMXRC3_FPGA_KU100            = 325, /* No longer exists as a Xilinx product */
  ADMXRC3_FPGA_KU115            = 326,
  ADMXRC3_FPGA_KU025            = 327,
  ADMXRC3_FPGA_KU085            = 328,
  ADMXRC3_FPGA_KU095            = 329,
  ADMXRC3_FPGA_RESVD330         = 330,
  ADMXRC3_FPGA_RESVD331         = 331,
  ADMXRC3_FPGA_RESVD332         = 332,
  ADMXRC3_FPGA_VU065            = 333,
  ADMXRC3_FPGA_VU080            = 334,
  ADMXRC3_FPGA_VU095            = 335,
  ADMXRC3_FPGA_VU125            = 336,
  ADMXRC3_FPGA_VU145            = 337, /* No longer exists as a Xilinx product */
  ADMXRC3_FPGA_VU160            = 338,
  ADMXRC3_FPGA_VU440            = 339,
  ADMXRC3_FPGA_VU190            = 340,
  ADMXRC3_FPGA_RESVD341         = 341,
  ADMXRC3_FPGA_RESVD342         = 342,
  ADMXRC3_FPGA_RESVD343         = 343,
  ADMXRC3_FPGA_RESVD344         = 344,
  ADMXRC3_FPGA_RESVD345         = 345,
  ADMXRC3_FPGA_RESVD346         = 346,
  ADMXRC3_FPGA_RESVD347         = 347,
  ADMXRC3_FPGA_KU3P             = 348,
  ADMXRC3_FPGA_KU5P             = 349,
  ADMXRC3_FPGA_RESVD350         = 350,
  ADMXRC3_FPGA_KU9P             = 351,
  ADMXRC3_FPGA_KU11P            = 352,
  ADMXRC3_FPGA_KU13P            = 353,
  ADMXRC3_FPGA_KU15P            = 354,
  ADMXRC3_FPGA_RESVD355         = 355,
  ADMXRC3_FPGA_RESVD356         = 356,
  ADMXRC3_FPGA_RESVD357         = 357,
  ADMXRC3_FPGA_RESVD358         = 358,
  ADMXRC3_FPGA_RESVD359         = 359,
  ADMXRC3_FPGA_RESVD360         = 360,
  ADMXRC3_FPGA_VU3P             = 361,
  ADMXRC3_FPGA_VU5P             = 362,
  ADMXRC3_FPGA_VU7P             = 363,
  ADMXRC3_FPGA_VU9P             = 364,
  ADMXRC3_FPGA_VU11P            = 365,
  ADMXRC3_FPGA_VU13P            = 366,
  ADMXRC3_FPGA_VU27P            = 367,
  ADMXRC3_FPGA_VU29P            = 368,
  ADMXRC3_FPGA_VU31P            = 369,
  ADMXRC3_FPGA_VU33P            = 370,
  ADMXRC3_FPGA_VU35P            = 371,
  ADMXRC3_FPGA_VU37P            = 372,
  ADMXRC3_FPGA_RESVD373         = 373,
  ADMXRC3_FPGA_RESVD374         = 374,
  ADMXRC3_FPGA_RESVD375         = 375,
  ADMXRC3_FPGA_RESVD376         = 376,
  ADMXRC3_FPGA_ZU2EG            = 377,
  ADMXRC3_FPGA_ZU3EG            = 378,
  ADMXRC3_FPGA_ZU4EV            = 379,
  ADMXRC3_FPGA_ZU5EV            = 380,
  ADMXRC3_FPGA_ZU6EG            = 381,
  ADMXRC3_FPGA_ZU7EV            = 382,
  ADMXRC3_FPGA_RESVD383         = 383,
  ADMXRC3_FPGA_ZU9EG            = 384,
  ADMXRC3_FPGA_RESVD385         = 385,
  ADMXRC3_FPGA_ZU11EG           = 386,
  ADMXRC3_FPGA_RESVD387         = 387,
  ADMXRC3_FPGA_RESVD388         = 388,
  ADMXRC3_FPGA_RESVD389         = 389,
  ADMXRC3_FPGA_ZU15EG           = 390,
  ADMXRC3_FPGA_RESVD391         = 391,
  ADMXRC3_FPGA_ZU17EG           = 392,
  ADMXRC3_FPGA_RESVD393         = 393,
  ADMXRC3_FPGA_ZU19EG           = 394,
  ADMXRC3_FPGA_RESVD395         = 395,
  ADMXRC3_FPGA_RESVD396         = 396,
  ADMXRC3_FPGA_RESVD397         = 397,
  ADMXRC3_FPGA_RESVD398         = 398,
  ADMXRC3_FPGA_RESVD399         = 399,
  ADMXRC3_FPGA_ZU21DR           = 400,
  ADMXRC3_FPGA_ZU25DR           = 401,
  ADMXRC3_FPGA_ZU27DR           = 402,
  ADMXRC3_FPGA_ZU28DR           = 403,
  ADMXRC3_FPGA_ZU29DR           = 404,
  ADMXRC3_FPGA_RESVD405         = 405,
  ADMXRC3_FPGA_RESVD406         = 406,
  ADMXRC3_FPGA_RESVD407         = 407,
  ADMXRC3_FPGA_ZU39DR           = 408,
  ADMXRC3_FPGA_RESVD409         = 409,
  ADMXRC3_FPGA_RESVD410         = 410,
  ADMXRC3_FPGA_RESVD411         = 411,
  ADMXRC3_FPGA_RESVD412         = 412,
  ADMXRC3_FPGA_RESVD413         = 413,
  ADMXRC3_FPGA_RESVD414         = 414,
  ADMXRC3_FPGA_RESVD415         = 415,
  ADMXRC3_FPGA_ZU46DR           = 416,
  ADMXRC3_FPGA_ZU47DR           = 417,
  ADMXRC3_FPGA_ZU48DR           = 418,
  ADMXRC3_FPGA_ZU49DR           = 419,
  ADMXRC3_FPGA_RESVD420         = 420,
  ADMXRC3_FPGA_RESVD421         = 421,
  ADMXRC3_FPGA_RESVD422         = 422,
  ADMXRC3_FPGA_RESVD423         = 423,
  ADMXRC3_FPGA_VC1352           = 512,
  ADMXRC3_FPGA_VC1502           = 513,
  ADMXRC3_FPGA_VC1702           = 514,
  ADMXRC3_FPGA_VC1802           = 515,
  ADMXRC3_FPGA_VC1902           = 516,
  ADMXRC3_FPGA_RESVD517         = 517,
  ADMXRC3_FPGA_RESVD518         = 518,
  ADMXRC3_FPGA_RESVD519         = 519,
  ADMXRC3_FPGA_RESVD520         = 520,
  ADMXRC3_FPGA_RESVD521         = 521,
  ADMXRC3_FPGA_RESVD522         = 522,
  ADMXRC3_FPGA_RESVD523         = 523,
  ADMXRC3_FPGA_RESVD524         = 524,
  ADMXRC3_FPGA_RESVD525         = 525,
  ADMXRC3_FPGA_RESVD526         = 526,
  ADMXRC3_FPGA_RESVD527         = 527,
  ADMXRC3_FPGA_VM1102           = 528,
  ADMXRC3_FPGA_VM1302           = 529,
  ADMXRC3_FPGA_VM1402           = 530,
  ADMXRC3_FPGA_VM1502           = 531,
  ADMXRC3_FPGA_VM1802           = 532,
  ADMXRC3_FPGA_VM2302           = 533,
  ADMXRC3_FPGA_VM2502           = 534,
  ADMXRC3_FPGA_VM2902           = 535,
  ADMXRC3_FPGA_RESVD536         = 536,
  ADMXRC3_FPGA_RESVD537         = 537,
  ADMXRC3_FPGA_RESVD538         = 538,
  ADMXRC3_FPGA_RESVD539         = 539,
  ADMXRC3_FPGA_RESVD540         = 540,
  ADMXRC3_FPGA_RESVD541         = 541,
  ADMXRC3_FPGA_RESVD542         = 542,
  ADMXRC3_FPGA_RESVD543         = 543,
  ADMXRC3_FPGA_VP1102           = 544,
  ADMXRC3_FPGA_VP1202           = 545,
  ADMXRC3_FPGA_VP1402           = 546,
  ADMXRC3_FPGA_VP1502           = 547,
  ADMXRC3_FPGA_VP1552           = 548,
  ADMXRC3_FPGA_VP1702           = 549,
  ADMXRC3_FPGA_VP1802           = 550,
  ADMXRC3_FPGA_RESVD551         = 551,
  ADMXRC3_FPGA_RESVD552         = 552,
  ADMXRC3_FPGA_RESVD553         = 553,
  ADMXRC3_FPGA_RESVD554         = 554,
  ADMXRC3_FPGA_RESVD555         = 555,
  ADMXRC3_FPGA_RESVD556         = 556,
  ADMXRC3_FPGA_RESVD557         = 557,
  ADMXRC3_FPGA_RESVD558         = 558,
  ADMXRC3_FPGA_RESVD559         = 559,
  ADMXRC3_FPGA_LASTVALUE, /* Reserved for future products */
  ADMXRC3_FPGA_FORCE32BITS      = 0x7FFFFFFF
} ADMXRC3_FPGA_TYPE;

/* Datatype that represents a model */
typedef enum _ADMXRC3_MODEL_TYPE {
  ADMXRC3_MODEL_GENERIC         = 0,      /* Unknown model                */
  ADMXRC3_MODEL_ADMXRC2         = 4,      /* ADM-XRC-II (legacy)          */
  ADMXRC3_MODEL_ADPEXRC5T       = 0x100,  /* ADPE-XRC-5T                  */
  ADMXRC3_MODEL_ADMXRC6TL       = 0x101,  /* ADM-XRC-6TL                  */
  ADMXRC3_MODEL_ADMXRC6T1       = 0x102,  /* ADM-XRC-6T1                  */
  ADMXRC3_MODEL_ADMXRC6TGE      = 0x103,  /* ADM-XRC-6TGE                 */
  ADMXRC3_MODEL_ADMXRC6TADV8    = 0x104,  /* ADM-XRC-6T-ADV8              */
  ADMXRC3_MODEL_ADPEXRC6T       = 0x105,  /* ADPE-XRC-6T                  */
  ADMXRC3_MODEL_ADPEXRC6TL      = 0x106,  /* ADPE-XRC-6T-L                */
  ADMXRC3_MODEL_ADPEXRC6TADV_C  = 0x107,  /* ADPE-XRC-6T-ADV (controller) */
  ADMXRC3_MODEL_ADPEXRC6TADV_T  = 0x108,  /* ADPE-XRC-6T-ADV (target)     */
  ADMXRC3_MODEL_ADMXRC7K1       = 0x109,  /* ADM-XRC-7K1                  */
  ADMXRC3_MODEL_ADMXRC6TDA1     = 0x10A,  /* ADM-XRC-6T-DA1               */
  ADMXRC3_MODEL_ADMXRC7V1       = 0x10B,  /* ADM-XRC-7V1                  */
  ADMXRC3_MODEL_ADMVPX37V2      = 0x10C,  /* ADM-VPX3-7V2                 */
  ADMXRC3_MODEL_ADMXRC6TGEL     = 0x10D,  /* ADM-XRC-6TGEL                */
  ADMXRC3_MODEL_ADMPCIE7V3      = 0x10E,  /* ADM-PCIE-7V3                 */
  ADMXRC3_MODEL_ADMXRC7Z1       = 0x10F,  /* ADM-XRC-7Z1                  */
  ADMXRC3_MODEL_ADMXRC7Z2       = 0x110,  /* ADM-XRC-7Z2                  */
  ADMXRC3_MODEL_ADMXRCKU1       = 0x111,  /* ADM-XRC-KU1                  */
/*ADM-VPX3-KU2                  = 0x112,*//* Reserved for future product  */
  ADMXRC3_MODEL_ADMPCIEKU3      = 0x113,  /* ADM-PCIE-KU3                 */
  ADMXRC3_MODEL_ADMXRCKU1_P5    = 0x114,  /* ADM-XRC-KU1 (P5 endpoint)    */
  ADMXRC3_MODEL_ADMXRCKU1_P6    = 0x115,  /* ADM-XRC-KU1 (P6 endpoint)    */
  ADMXRC3_MODEL_ADMPCIE8V3      = 0x116,  /* ADM-PCIE-8V3                 */
  ADMXRC3_MODEL_ADMPCIE8K5      = 0x117,  /* ADM-PCIE-8K5                 */
/*ADM-XRC-7Z3                   = 0x118,*//* Reserved for future product  */
/*ADM-XRC-7Z4                   = 0x119,*//* Reserved for future product  */
/*ADMXRC3_MODEL_ADMVPX39Z2      = 0x11A,*//* ADM-VPX3-9Z2                 */
  ADMXRC3_MODEL_LASTVALUE,                /* Reserved for future products */
  ADMXRC3_MODEL_FORCE32BITS     = 0x7FFFFFFF
} ADMXRC3_MODEL_TYPE;

/* Datatype for representing the unit of a sensor */
typedef enum _ADMXRC3_UNIT_TYPE {
  ADMXRC3_UNIT_NONE      = 0, /* For unitless quantities */
  ADMXRC3_UNIT_A         = 1, /* Amperes */
  ADMXRC3_UNIT_V         = 2, /* Volts */
  ADMXRC3_UNIT_C         = 3, /* Degrees Celsius */
  ADMXRC3_UNIT_HZ        = 4, /* Hz */
  ADMXRC3_UNIT_RPM       = 5, /* Revolutions per minute */
  ADMXRC3_UNIT_S         = 6, /* Seconds */
  ADMXRC3_UNIT_LASTVALUE = 7, /* Reserved for adding new units */
  ADMXRC3_UNIT_FORCE32BITS = 0x7FFFFFFF
} ADMXRC3_UNIT_TYPE;

/* Flags for 'flags' parameter of ADMXRC3_Configure* functions */
#define ADMXRC3_CONFIGURE_PARTIAL (0x1U << 0)  /* Partial reconfiguration (don't assert PROG# etc.) */
#define ADMXRC3_CONFIGURE_NOCHECK (0x1U << 1)  /* Do not check bridge <-> target link status */
#define ADMXRC3_CONFIGURE_SHARE   (0x1U << 2)  /* Do not become owner */
/* Flags valid only for 'flags' parameter of ADMXRC3_ConfigureFromFile function */
#define ADMXRC3_CONFIGURE_IGNOREMISMATCH (0x1U << 3) /* Ignore mismatch between device identifier in bitstream and FPGA actually fitted */
/*
** Flag for 'flags' parameter of ADMXRC3_EraseFlash, ADMXRC3_ReadFlash or ADMXRC3_WriteFlash that
** forces a sync of Flash memory bank before function returns.
*/
#define ADMXRC3_FLASH_SYNC (0x1U << 0)

/* If this flag is present in ADMXRC3_FLASHBLOCK_INFO, the block is a boot block */
#define ADMXRC3_FLASHBLOCK_BOOT (0x1U << 0)

/* Flags for 'TypeMask' field on ADMXRC3_BANK_INFO */
#define ADMXRC3_BANK_ZBT_FT     (1 << 0) /* ZBT flowthrough        */
#define ADMXRC3_BANK_ZBT_P      (1 << 1) /* ZBT pipelined          */
#define ADMXRC3_BANK_SDRAM_DDR  (1 << 2) /* DDR SDRAM              */
#define ADMXRC3_BANK_SSRAM_DDR2 (1 << 3) /* DDR-II SSRAM           */
#define ADMXRC3_BANK_SDRAM_SDR  (1 << 4) /* SDRAM (SDR)            */
#define ADMXRC3_BANK_SDRAM_DDR2 (1 << 5) /* DDR-II SDRAM           */
#define ADMXRC3_BANK_SSRAM_QDR  (1 << 6) /* QDR SSRAM              */
#define ADMXRC3_BANK_SDRAM_DDR3 (1 << 7) /* DDR3 SDRAM             */
#define ADMXRC3_BANK_SDRAM_DDR4 (1 << 8) /* DDR4 SDRAM             */

/* Flags for 'flags' parameter of ADMXRC3_SetClockFrequency function */
#define ADMXRC3_SETCLOCK_TESTONLY (0x1U << 0)  /* Return nearest frequency without actually programming */
#define ADMXRC3_SETCLOCK_MAXIMUM  (0x1U << 1)  /* Return nearest frequency not greater than the requested frequency */
#define ADMXRC3_SETCLOCK_MINIMUM  (0x1U << 2)  /* Return nearest frequency not less than the requested frequency */

/* Special value that represents local bus clock generator when calling ADMXRC3_{Set|Get}ClockFrequency */
#define ADMXRC3_CLOCK_LCLK (0)

/* Legal values for 'notification' parameter of ADMXRC3_*Register{Win32Event|VxwSem} functions */
#define ADMXRC3_EVENT_FPGAINTERRUPT(targetIndex) ((targetIndex) | 0x100) /* Target FPGA interrupt */
#define ADMXRC3_EVENT_FPGAALERT(targetIndex)     ((targetIndex) | 0x200) /* Target FPGA overtemperature; reconfiguration pending */

/* Flags for 'flags' parameter of ADMXRC3_*{Read|Write}DMA* functions */
#define ADMXRC3_DMA_FIXEDLOCAL (0x1U << 0)  /* Constant local address */
#define ADMXRC3_DMA_DONOTQUEUE (0x1U << 31) /* Fail if cannot start DMA immediately */
/* Do not use - defined for testing ADMXRC3 API functionality */
#define ADMXRC3_DMA_QUEUETEST  (0x1U << 30) /* Exercise queueing mechanisms only, don't call core DMA routines */
#define ADMXRC3_DMA_BYPASSHW   (0x1U << 29) /* Exercise queueing mechanisms only, do everything except starting DMA transfer in hardware */

/* Flags for 'Flags' member of ADMXRC3_FPGA_INFO */
#define ADMXRC3_FPGA_SPEEDVALID      (0x1U << 0)  /* 'SpeedGrade' member is valid */
#define ADMXRC3_FPGA_STEPPINGVALID   (0x1U << 1)  /* 'Stepping' member is valid */
#define ADMXRC3_FPGA_NOTCONFIGURABLE (0x1U << 8)  /* FPGA is not configurable via the ADMXRC3 API */

/* Flags for 'flags' parameter of ADMXRC3_Read & ADMXRC3_Write functions */
#define ADMXRC3_ACCESS_CONSTANTBIT (0x100U)
#define ADMXRC3_ACCESS_CONSTANT(x) (ADMXRC3_ACCESS_CONSTANTBIT | (((x) & 0xffU) << 0)) /* Constant address mode, items are 'x' bytes each */
#define ADMXRC3_ACCESS_CONSTANT_1  (ADMXRC3_ACCESS_CONSTANTBIT | (0x1U << 0))  /* Constant address mode, items are 1 byte each */
#define ADMXRC3_ACCESS_CONSTANT_2  (ADMXRC3_ACCESS_CONSTANTBIT | (0x2U << 0))  /* Constant address mode, items are 2 bytes each */
#define ADMXRC3_ACCESS_CONSTANT_4  (ADMXRC3_ACCESS_CONSTANTBIT | (0x4U << 0))  /* Constant address mode, items are 4 bytes each */
#define ADMXRC3_ACCESS_CONSTANT_8  (ADMXRC3_ACCESS_CONSTANTBIT | (0x8U << 0))  /* Constant address mode, items are 8 bytes each */
#define ADMXRC3_ACCESS_CONSTANT_16 (ADMXRC3_ACCESS_CONSTANTBIT | (0x10U << 0)) /* Constant address mode, items are 16 bytes each */

/* Flags for ADMXRC3_MODULE_INFO */
#define ADMXRC3_MODULE_LEGACYXRM (0x1U << 0)   /* Module is a legacy XRM */
#define ADMXRC3_MODULE_FORCE2V5  (0x1U << 1)   /* Module asserts FORCE2V5 pin */
#define ADMXRC3_MODULE_ROMERROR  (0x1U << 24)  /* Module ROM data has a parse error */
#define ADMXRC3_MODULE_CSUMERROR (0x1U << 25)  /* Module ROM data has a checksum error */

/* Cooperative level flags for ADMXRC3_OpenEx */
#define ADMXRC3_COOP_SHARED    (0x0 << 0) /* Succeeds unless card is open (EXCLUSIVE and read/write) somewhere else */
#define ADMXRC3_COOP_EXCLUSIVE (0x1 << 0) /* Fails if card is open read/write somewhere else */

/* Flags for 'Capabilities' member of ADMXRC3_SENSOR_INFO */
#define ADMXRC3_SENSOR_SWVALUE (0x1U << 0)  /* Sensor is a software mechanism */

/* Flags for 'Window' member of ADMXRC3_DEVICE_STATUS */
#define ADMXRC3_DS_LOCAL_TIMEOUT(x) (0x1U << (x)) /* Direct Slave transaction on window 'x' timed out */
/* Flags for 'DMA' member of ADMXRC3_DEVICE_STATUS */
#define ADMXRC3_DMA_BUS_TIMEOUT(x)  (0x1U << (x)) /* DMA engine 'x' read timed out on I/O bus */
/* Flags for 'DirectMaster' member of ADMXRC3_DEVICE_STATUS */
#define ADMXRC3_DM_BUS_TIMEOUT      (0x1U << 0)   /* Direct Master read timed out on I/O bus */
#define ADMXRC3_DM_BAD_TRANSACTION  (0x1U << 1)   /* Bad Direct Master transaction detected */

#endif
