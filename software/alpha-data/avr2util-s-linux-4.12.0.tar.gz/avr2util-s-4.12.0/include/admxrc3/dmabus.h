#ifndef _ADATA_ADMXRC3_DMABUS_H
#define _ADATA_ADMXRC3_DMABUS_H

/*
** <admxrc3/dmabus.h> - ADMXRC3 API header file (ADMXRC3 interface),
**                      DMABus extensions.
**
** (C) Copyright 2011 Alpha Data
**
** The integer datatypes used below that are prefixed by "_ADMXRC3_", such
** as "_ADMXRC3_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that makes
** use of the ADMXRC3 API.
**
** Applications should use OS-specific types such as UINT32 (Windows) or
** uint32_t (Linux C99).
*/

#if defined(_WIN32) || defined(_MSC_VER)

/* Windows */

# include <windows.h>
# include <tchar.h>

#ifndef ADMXRC3_EXPORT
# if defined(ADMXRC3_DLL)
    /* Compiling API library into a DLL */
#   define ADMXRC3_EXPORT __declspec(dllexport)
# else
    /* Importing API library from DLL */
#   define ADMXRC3_EXPORT __declspec(dllimport)
# endif
#endif
#ifndef ADMXRC3_CALLING_CONVENTION
# define ADMXRC3_CALLING_CONVENTION __cdecl
#endif

#elif defined(__linux)

/* Linux */

# include <stdint.h>
# include <wchar.h>

#ifndef ADMXRC3_EXPORT
# define ADMXRC3_EXPORT
#endif
#ifndef ADMXRC3_CALLING_CONVENTION
# define ADMXRC3_CALLING_CONVENTION
#endif

#elif defined(__VXWORKS__) || defined(__vxworks)

# include <vxWorks.h>
# include <semLib.h>

#ifndef ADMXRC3_EXPORT
# define ADMXRC3_EXPORT
#endif
#ifndef ADMXRC3_CALLING_CONVENTION
# define ADMXRC3_CALLING_CONVENTION
#endif

#else

# error Cannot detect target operating system.

#endif

#include <admxrc3/platform.h>
#include <admxrc3/status.h>
#include <admxrc3/types.h>
#include <admxrc3/structs.h>
#include <admxrc3/ticket.h>

/*
** Function prototypes
*/
#ifdef __cplusplus
extern "C" {
#endif

ADMXRC3_EXPORT ADMXRC3_STATUS
ADMXRC3_CALLING_CONVENTION
ADMXRC3_ReadDMABus(
  ADMXRC3_HANDLE             hCard,
  unsigned int               dmaChannel,
  _ADMXRC3_UINT32            flags,
  _ADMXRC3_UINT64            busAddress,
  size_t                     length,
  _ADMXRC3_UINT64            localAddress);

ADMXRC3_EXPORT ADMXRC3_STATUS
ADMXRC3_CALLING_CONVENTION
ADMXRC3_StartReadDMABus(
  ADMXRC3_HANDLE             hCard,
  ADMXRC3_TICKET*            pTicket,
  unsigned int               dmaChannel,
  _ADMXRC3_UINT32            flags,
  _ADMXRC3_UINT64            busAddress,
  size_t                     length,
  _ADMXRC3_UINT64            localAddress);

ADMXRC3_EXPORT ADMXRC3_STATUS
ADMXRC3_CALLING_CONVENTION
ADMXRC3_StartWriteDMABus(
  ADMXRC3_HANDLE             hCard,
  ADMXRC3_TICKET*            pTicket,
  unsigned int               dmaChannel,
  _ADMXRC3_UINT32            flags,
  _ADMXRC3_UINT64            busAddress,
  size_t                     length,
  _ADMXRC3_UINT64            localAddress);

ADMXRC3_EXPORT ADMXRC3_STATUS
ADMXRC3_CALLING_CONVENTION
ADMXRC3_WriteDMABus(
  ADMXRC3_HANDLE             hCard,
  unsigned int               dmaChannel,
  _ADMXRC3_UINT32            flags,
  _ADMXRC3_UINT64            busAddress,
  size_t                     length,
  _ADMXRC3_UINT64            localAddress);

#ifdef __cplusplus
}
#endif

#endif
