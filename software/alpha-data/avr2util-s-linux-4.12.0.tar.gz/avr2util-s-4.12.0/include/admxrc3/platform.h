#ifndef _ADATA_ADMXRC3_PLATFORM_H
#define _ADATA_ADMXRC3_PLATFORM_H

/*
** platform.h - define elementary datatypes used by API
**
** (C) Copyright Alpha Data 2009-2010
**
** The integer datatypes defined below prefixed by "_ADMXRC3_", such as
** "_ADMXRC3_UINT64" are defined in order to increase the portability of
** this header file but should NOT be used by application code that
** makes use of the ADMXRC3 API.
*/

#if defined(_WIN32)

/* Windows */

#if defined(_MSC_VER)
/* MSVC */
typedef INT16  _ADMXRC3_INT16;
typedef UINT16 _ADMXRC3_UINT16;
typedef UINT8  _ADMXRC3_UINT8;
#else
/* Not MSVC, use C99 header */
#include <stdint.h>
typedef int16_t  _ADMXRC3_INT16;
typedef uint16_t _ADMXRC3_UINT16;
typedef uint8_t  _ADMXRC3_UINT8;
#endif
typedef INT32  _ADMXRC3_INT32;
typedef UINT64 _ADMXRC3_UINT64;
typedef UINT32 _ADMXRC3_UINT32;
typedef BYTE   _ADMXRC3_BYTE;
typedef BOOL   _ADMXRC3_BOOL;

typedef HANDLE ADMXRC3_HANDLE;

/* This value is invalid for an ADMXRC3_HANDLE */ 
# define ADMXRC3_HANDLE_INVALID_VALUE (NULL)

#elif defined(__linux) || defined(__VXWORKS__) || defined(__vxworks)

/* Linux or VxWorks - assume C99-compliant */

# if defined(__linux)
#   include <stdint.h>
# endif

typedef int32_t  _ADMXRC3_INT32;
typedef int16_t  _ADMXRC3_INT16;
typedef uint64_t _ADMXRC3_UINT64;
typedef uint32_t _ADMXRC3_UINT32;
typedef uint16_t _ADMXRC3_UINT16;
typedef uint8_t  _ADMXRC3_UINT8;
typedef uint8_t  _ADMXRC3_BYTE;
typedef int      _ADMXRC3_BOOL;

typedef int ADMXRC3_HANDLE;

/* This value is invalid for an ADMXRC3_HANDLE */ 
# define ADMXRC3_HANDLE_INVALID_VALUE (-1)

#else

# error Cannot detect target operating system.

#endif

#endif
