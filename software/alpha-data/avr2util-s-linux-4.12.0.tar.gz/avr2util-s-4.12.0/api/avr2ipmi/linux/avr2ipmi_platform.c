/*
** File: avr2ipmi_platform.c  
** Project: AVR2 IPMI API library
** Purpose: Win32-specific code for AVR2 IPMI library
**
** Macros that can affect compilation of this file:
**
** INCLUDE_FREEIPMI - if defined, builds with FreeIPMI backend
**
** (C) Copyright Alpha Data 2017
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/timerfd.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>
#include <stdint.h>

#if defined(INCLUDE_FREEIPMI)
# include <freeipmi/freeipmi.h>
#endif

#include <avr2ipmi.h>
#include <portability.h>

#define TRACE (0)
#define PRINT_SESSION_ERROR (0)
#define PRINT_BACKEND_ERROR (0)
#define PRINT_IPMI_ERROR (0)
#define PRINT_PEC_ERROR (0)

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

#define SESSION_MAGIC (0xC2EE2EB411)

/* IPMI command code for Master Write-Read */
#if !defined(IPMI_CMD_MASTER_WRITE_READ)
# define IPMI_CMD_MASTER_WRITE_READ (0x52)
#endif

/* SMBUS command for sending a BoardMan2 command packet (Block Write) */
#define SMBUS_CMD_BOARDMAN2_CMD  (0xE0)
/* SMBUS command for receiving a BoardMan2 response packet (Block Read) */
#define SMBUS_CMD_BOARDMAN2_RESP (0xE1)
/* SMBUS command for rewinding to last BoardMan2 response packet due to PEC error (Block Write) */
#define SMBUS_CMD_BOARDMAN2_REWIND (0xE2)

#define SMBUS_MAX_PAYLOAD_LENGTH (32)

/* Flags byte, which is first byte of a command or response packet */
#define FLAG_FIRST_PACKET     (0x1 << 0)
#define FLAG_LAST_PACKET      (0x1 << 1)

#define ARP_CRC8_POLY_BITS (0x07)

struct _AVR2IPMI_SESSION_STRUCT {
  uint64_t Magic;

  AVR2IPMI_BACKEND_TYPE Backend;

  uint8_t BusID;       /* IPMI bus ID as per Master write-read command */
  uint8_t ChipAddress; /* SMBUS address (7 bits) */

  union {
    int dummy; /* Prevent error when all backends omitted */
#if defined(INCLUDE_FREEIPMI)
    struct {
      ipmi_ctx_t hContext;
    } FreeIPMI;
#endif
  } Variant;
};

extern __thread AVR2IPMI_ERROR_DETAILA _AVR2IPMILastErrorA;

#if TRACE
static void
DumpIPMIRequest(
  uint8_t ipmiRequest[],
  int ipmiRequestLength,
  const char* pszTag)
{
  int i;

  printf("IMPI request length (%s) is %d\n", pszTag, ipmiRequestLength);
  for (i = 0; i < ipmiRequestLength; i++) {
    printf("%02X ", ipmiRequest[i]);
  }
  printf("\n");
}

static void
DumpIPMIResponse(
  uint8_t ipmiResponse[],
  int ipmiResponseLength,
  const char* pszTag)
{
  int i;

  printf("IMPI response length (%s) is %d\n", pszTag, ipmiResponseLength);
  for (i = 0; i < ipmiResponseLength; i++) {
    printf("%02X ", ipmiResponse[i]);
  }
  printf("\n");
}
#endif

static AVR2IPMI_STATUS
SetSimpleError(
  AVR2IPMI_ERROR_DETAILA* pDetail,
  AVR2IPMI_STATUS status)
{
  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(
    pDetail->Description,
    ARRAY_LENGTH(pDetail->Description),
    "%s (%s)",
    AVR2IPMI_GetStatusString(status, FALSE),
    AVR2IPMI_GetStatusString(status, TRUE));
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = status;

  return status;
}

#if defined(INCLUDE_FREEIPMI)
static AVR2IPMI_STATUS
SetFreeIPMIErrno(
  AVR2IPMI_ERROR_DETAIL* pDetail,
  int err_no)
{
  AVR2IPMI_STATUS status = AVR2IPMI_BACKEND_INIT_FAILED;

  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(pDetail->Description, ARRAY_LENGTH(pDetail->Description), "ipmi_ctx_create() failed with errno %d => %s", err_no, strerror(err_no));
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = AVR2IPMI_BACKEND_INIT_FAILED;

  pDetail->Backend = status;

  pDetail->Variant.FreeIPMI.Errno = err_no;

  return status;
}
#endif

#if defined(INCLUDE_FREEIPMI)
static AVR2IPMI_STATUS
SetFreeIPMIInBandSessionError(
  AVR2IPMI_ERROR_DETAIL* pDetail,
  int errnum,
  const char* pDescription)
{
  AVR2IPMI_STATUS status = AVR2IPMI_SESSION_ERROR;

  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(pDetail->Description, ARRAY_LENGTH(pDetail->Description), "ipmi_ctx_find_inband() failed with errnum %d => %s", errnum, pDescription);
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = status;

  pDetail->Backend = AVR2IPMI_BACKEND_FREEIPMI;

  pDetail->Variant.FreeIPMI.ErrorNumber = errnum;

  return status;
}
#endif

#if defined(INCLUDE_FREEIPMI)
static AVR2IPMI_STATUS
SetFreeIPMIOutOfBandSessionError(
  AVR2IPMI_ERROR_DETAIL* pDetail,
  int errnum,
  const char* pDescription)
{
  AVR2IPMI_STATUS status = AVR2IPMI_SESSION_ERROR;

  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(pDetail->Description, ARRAY_LENGTH(pDetail->Description), "ipmi_ctx_open_outofband() failed with errnum %d => %s", errnum, pDescription);
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = status;

  pDetail->Backend = AVR2IPMI_BACKEND_FREEIPMI;

  pDetail->Variant.FreeIPMI.ErrorNumber = errnum;

  return status;
}
#endif

#if defined(INCLUDE_FREEIPMI)
static AVR2IPMI_STATUS
SetFreeIPMIBackendError(
  AVR2IPMI_ERROR_DETAIL* pDetail,
  int errnum,
  const char* pDescription)
{
  AVR2IPMI_STATUS status = AVR2IPMI_BACKEND_ERROR;

  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(pDetail->Description, ARRAY_LENGTH(pDetail->Description), "ipmi_ctx_raw() failed with errnum %d => %s", errnum, pDescription);
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = status;

  pDetail->Backend = AVR2IPMI_BACKEND_FREEIPMI;

  pDetail->Variant.FreeIPMI.ErrorNumber = errnum;

  return status;
}
#endif

static AVR2IPMI_STATUS
SetIPMIShortResponseError(
  AVR2IPMI_ERROR_DETAIL* pDetail,
  AVR2IPMI_BACKEND_TYPE backend,
  uint8_t expectedResponseLength,
  uint8_t actualResponseLength)
{
  AVR2IPMI_STATUS status = AVR2IPMI_IPMI_SHORT_RESPONSE;

  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(
    pDetail->Description,
    ARRAY_LENGTH(pDetail->Description),
    "The backend IPMI library returned an IPMI response shorter than the minimum expected length; expected >= %d, actual %d",
    expectedResponseLength,
    actualResponseLength);
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = status;

  pDetail->Backend = backend;

  pDetail->ResponseLength = actualResponseLength;

  return status;
}

static AVR2IPMI_STATUS
SetIPMICompletionError(
  AVR2IPMI_ERROR_DETAIL* pDetail,
  AVR2IPMI_BACKEND_TYPE backend,
  uint8_t completionCode)
{
  AVR2IPMI_STATUS status = AVR2IPMI_IPMI_COMPLETION_ERROR;

  memset(pDetail, 0, sizeof(*pDetail));

  snprintf(
    pDetail->Description,
    ARRAY_LENGTH(pDetail->Description),
    "The backend IPMI library returned an unexpected IPMI completion code 0x%02X",
    completionCode);
  pDetail->Description[ARRAY_LENGTH(pDetail->Description) - 1] = '\0';

  pDetail->Status = status;

  pDetail->Backend = backend;

  pDetail->Completion = completionCode;

  return status;
}

static uint8_t
CRC8Byte(
  uint8_t nChecksum,
  uint8_t nByte)
{
  unsigned int i;
  
  nChecksum ^= nByte;
  
  for (i = 0; i < 8; i++ ) {
    if (nChecksum & 0x80) {
      nChecksum = nChecksum << 1;
      nChecksum = nChecksum ^ ARP_CRC8_POLY_BITS;
    } else {
      nChecksum = nChecksum << 1;
    }
  }

  return nChecksum;
}

static uint8_t
CRC8Buffer(
  uint8_t nChecksumIn,
  uint8_t* pBuffer,
  unsigned int nLength)
{
  uint8_t nChecksum = nChecksumIn;
  unsigned int i;
  
  for (i = 0; i < nLength; i++) {
    nChecksum = CRC8Byte(nChecksum, pBuffer[i]);
  }
  
  return nChecksum;
}

AVR2IPMI_STATUS
avr2ipmiCloseSession(
  AVR2IPMI_SESSION hSession)
{
  if (hSession->Magic != SESSION_MAGIC) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_INVALID_SESSION);
  }

  switch (hSession->Backend) {
#if defined(INCLUDE_FREEIPMI)
  case AVR2IPMI_BACKEND_FREEIPMI:
    ipmi_ctx_close(hSession->Variant.FreeIPMI.hContext);
    ipmi_ctx_destroy(hSession->Variant.FreeIPMI.hContext);
    break;
#endif

  default:
    assert(FALSE);
    break;
  }

  free(hSession);

  return AVR2IPMI_SUCCESS;
}

AVR2IPMI_STATUS
avr2ipmiOpenSession(
  const AVR2IPMI_OPTIONS* pOptions,
  AVR2IPMI_SESSION* phSession)
{
  AVR2IPMI_STATUS status = AVR2IPMI_SUCCESS;
  AVR2IPMI_SESSION pSession = NULL;

  if (NULL == pOptions || NULL == phSession) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_NULL_POINTER);
  }

  pSession = (AVR2IPMI_SESSION)malloc(sizeof(*pSession));
  if (NULL == pSession) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_INSUFFICIENT_RESOURCES);
  }

  switch (pOptions->Backend) {
    case AVR2IPMI_BACKEND_FREEIPMI: {
#if defined(INCLUDE_FREEIPMI)
      ipmi_ctx_t hContext;
      int err;
      unsigned int flags = pOptions->Variant.FreeIPMI.EnableDebug ? IPMI_FLAGS_DEBUG_DUMP : 0;

      hContext = ipmi_ctx_create();
      if (!hContext) {
        status = SetFreeIPMIErrno(&_AVR2IPMILastErrorA, errno);

        goto done;
      }

      if (0 == strlen(pOptions->Hostname)) {
        err = ipmi_ctx_find_inband(
          hContext,                            /* ipmi_ctx_t ctx */
          NULL,                                /* ipmi_driver_type_t *driver_type */
          0,                                   /* int disable_auto_probe */
          0,                                   /* uint16_t driver_address */
          0,                                   /* uint8_t register_spacing */
          NULL,                                /* const char *driver_device */
          0,                                   /* unsigned int workaround_flags */
          0);                                  /* unsigned int flags */
        if (err < 0) {
          status = SetFreeIPMIInBandSessionError(&_AVR2IPMILastErrorA, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));

#if PRINT_SESSION_ERROR
          printf("ipmi_ctx_find_inband returned %d, errnum %d => %s\n", err, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));
#endif

          ipmi_ctx_destroy(hContext);

          goto done;
        } else if (0 == err) {
          /* No local IPMI device found */

#if PRINT_SESSION_ERROR
          printf("ipmi_ctx_find_inband returned %d, errnum %d => %s\n", err, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));
#endif

          status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_NO_LOCAL_IPMI_MC);

          goto done;
        }
      } else {
        err = ipmi_ctx_open_outofband(
          hContext,                            /* ipmi_ctx_t ctx */
          pOptions->Hostname,                  /* const char *hostname */
          pOptions->Username,                  /* const char *username */
          pOptions->Password,                  /* const char *password */
          pOptions->Authentication,            /* uint8_t authentication_type */
          IPMI_PRIVILEGE_LEVEL_OPERATOR,       /* uint8_t privilege_level */
          0,                                   /* unsigned int session_timeout */
          0,                                   /* unsigned int retransmission_timeout */
          0,                                   /* unsigned int workaround_flags */
          flags);                              /* unsigned int flags */
        if (err) {
          status = SetFreeIPMIOutOfBandSessionError(&_AVR2IPMILastErrorA, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));

#if PRINT_SESSION_ERROR
          printf("ipmi_ctx_open_outofband errnum %d => %s\n", ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));
#endif

          ipmi_ctx_destroy(hContext);

          goto done;
        }
      }
      
      pSession->Magic = SESSION_MAGIC;
      pSession->Variant.FreeIPMI.hContext = hContext;
#else
      status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_NOT_AVAILABLE);

      goto done;
#endif

      break;
    }

  default:
    assert(FALSE);
    break;
  }

  pSession->Backend = pOptions->Backend;
  pSession->BusID = pOptions->BusID;
  pSession->ChipAddress = pOptions->ChipAddress;

done:
  if (AVR2IPMI_SUCCESS != status) {
    if (NULL != pSession) {
      free(pSession);
    }
  } else {
    *phSession = pSession;
  }

  return status;
}

static AVR2IPMI_STATUS
RequestResponseRewind(
  AVR2IPMI_SESSION hSession,
  const struct timespec* pExpire)
{
  AVR2IPMI_STATUS status = AVR2IPMI_SUCCESS;
  int clkError;
  struct timespec now;
  uint8_t ipmiRequest[8];
  uint8_t ipmiResponse[2];
  uint8_t nChecksum, completion = 0;
  int ipmiResponseLength = 0;
  int bDone;

  ipmiRequest[0] = IPMI_CMD_MASTER_WRITE_READ;
  ipmiRequest[1] = hSession->BusID;
  ipmiRequest[2] = hSession->ChipAddress << 1;
  ipmiRequest[3] = 0; /* Nothing to read */
  ipmiRequest[4] = SMBUS_CMD_BOARDMAN2_REWIND;
  ipmiRequest[5] = 1; /* 1 byte to write */
  /* SMBUS payload */
  ipmiRequest[6] = 0; /* Reserved */
  /* Compute PEC (CRC8) */
  nChecksum = CRC8Byte(0, hSession->ChipAddress << 1);
  nChecksum = CRC8Buffer(nChecksum, &ipmiRequest[4], 3);
  ipmiRequest[7] = nChecksum;

#if TRACE
  DumpIPMIRequest(ipmiRequest, 8, "RequestResponseRewind");
#endif

  bDone = FALSE;
  do {
    memset(ipmiResponse, 0, ARRAY_LENGTH(ipmiResponse));
      
    switch (hSession->Backend) {
#if defined(INCLUDE_FREEIPMI)
      case AVR2IPMI_BACKEND_FREEIPMI: {
        ipmi_ctx_t hContext = hSession->Variant.FreeIPMI.hContext;

        ipmiResponseLength = ipmi_cmd_raw(
          hContext,           /* ipmi_ctx_t ctx */
          0,                  /* uint8_t lun */
          IPMI_NET_FN_APP_RQ, /* uint8_t net_fn */
          ipmiRequest,        /* const void *buf_rq */
          8,                  /* unsigned int buf_rq_len */
          ipmiResponse,       /* void *buf_rs */
          2);                 /* unsigned int buf_rs_len */
        if (ipmiResponseLength < 0) {
          status = SetFreeIPMIBackendError(&_AVR2IPMILastErrorA, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));

#if PRINT_BACKEND_ERROR
          printf("ipmi_cmd_raw (RequestResponseRewind) error %d => %s\n", ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));
#endif

          goto out;
        }
        break;
      }
#endif

      default:
        assert(FALSE);
        break;
    }

#if TRACE
    DumpIPMIResponse(ipmiResponse, ipmiResponseLength, "RequestResponseRewind");
#endif

    if (ipmiResponseLength < 2) {
      status = SetIPMIShortResponseError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, 2, ipmiResponseLength);

#if PRINT_IPMI_ERROR
      printf("ipmi_cmd_raw (RequestResponseRewind) response length too short (expected >= 2): %d\n", ipmiResponseLength);
#endif

      goto out;
    } else {
      completion = ipmiResponse[1];
      if (completion == 0) {
        bDone = TRUE;
      } else if (completion == 0x83) {
        /* NACKed; we will try again */
      } else {
        status = SetIPMICompletionError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, completion);

#if PRINT_IPMI_ERROR
        printf("ipmi_cmd_raw (RequestResponseRewind) returned error completion code: 0x%02X\n", completion);
#endif

        goto out;
      }
    }

    clkError = clock_gettime(CLOCK_REALTIME, &now);
    if (clkError) {
      status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_UNEXPECTED_ERROR);

      goto out;
    }

    /* If current real time >= expire time, then time out. */
    if (now.tv_sec >= pExpire->tv_sec) {
      if (now.tv_sec == pExpire->tv_sec) {
        if (now.tv_nsec >= pExpire->tv_nsec) {
          status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_TIMEOUT);

          goto out;
        }
      } else {
        status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_TIMEOUT);

        goto out;
      }
    }
  } while (!bDone);

out:
  return status;
}

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_Command(
  AVR2IPMI_SESSION hSession,
  _AVR2IPMI_UINT32 flags,
  _AVR2IPMI_UINT32 timeoutUs,
  _AVR2IPMI_UINT32 commandLength,
  const _AVR2IPMI_UINT8* pCommand,
  _AVR2IPMI_UINT8 responseAddrOverride,
  _AVR2IPMI_UINT32 responseLength,
  _AVR2IPMI_UINT8* pResponse,
  _AVR2IPMI_UINT32* pActualResponseLength)
{
  AVR2IPMI_STATUS status = AVR2IPMI_SUCCESS;
  int clkError;
  uint32_t position = 0;
  struct timespec start, expire, now;
  time_t seconds;
  long nanoseconds;
  uint8_t ipmiRequest[39];
  uint8_t ipmiResponse[36];
  uint8_t packetFlags, chunk, completion, nChecksum, nChecksumReceived, smbusByteCount, readPayloadLength;
  int ipmiResponseLength;
  int bDone;

  if (commandLength > 0 && NULL == pCommand) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_NULL_POINTER);
  }
  if (commandLength < 2) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_SHORT_COMMAND);
  }
  if (responseLength > 0 && NULL == pResponse) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_NULL_POINTER);
  }

  if (hSession->Magic != SESSION_MAGIC) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_INVALID_SESSION);
  }

  seconds = timeoutUs / 1000000;
  nanoseconds = timeoutUs * 1000;

  /* Get current real time. */
  clkError = clock_gettime(CLOCK_REALTIME, &start);
  if (clkError) {
    return SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_UNEXPECTED_ERROR);
  }

  /* Calculate real time at which we time out. */
  expire.tv_sec = start.tv_sec + seconds;
  expire.tv_nsec = start.tv_sec + nanoseconds;
  if (expire.tv_nsec > 1000000000) {
    expire.tv_sec++;
    expire.tv_nsec -= 1000000000;
  }

  position = 0;
  while (position < commandLength) {
    packetFlags = 0;

    if (0 == position) {
      packetFlags |= FLAG_FIRST_PACKET;
    }

    chunk = 31;
    if (position + chunk >= commandLength) {
      packetFlags |= FLAG_LAST_PACKET;
      chunk = commandLength - position;
    }

    ipmiRequest[0] = IPMI_CMD_MASTER_WRITE_READ;
    ipmiRequest[1] = hSession->BusID;
    ipmiRequest[2] = hSession->ChipAddress << 1;
    ipmiRequest[3] = 0; /* Nothing to to read */
    ipmiRequest[4] = SMBUS_CMD_BOARDMAN2_CMD;
    ipmiRequest[5] = chunk + 1; /* SMBUS write payload byte count */
    /* SMBUS payload */
    ipmiRequest[6] = packetFlags;
    memcpy(&ipmiRequest[7], pCommand + position, chunk);
    /* Compute PEC (CRC8) */
    nChecksum = CRC8Byte(0, hSession->ChipAddress << 1);
    nChecksum = CRC8Buffer(nChecksum, &ipmiRequest[4], chunk + 3);
    ipmiRequest[7 + chunk] = nChecksum;

#if TRACE
    DumpIPMIRequest(ipmiRequest, chunk + 8, "SMBUS write");
#endif

    bDone = FALSE;
    do {
      memset(ipmiResponse, 0, 2);
        
      switch (hSession->Backend) {
#if defined(INCLUDE_FREEIPMI)
        case AVR2IPMI_BACKEND_FREEIPMI: {
          ipmi_ctx_t hContext = hSession->Variant.FreeIPMI.hContext;

          ipmiResponseLength = ipmi_cmd_raw(
            hContext,           /* ipmi_ctx_t ctx */
            0,                  /* uint8_t lun */
            IPMI_NET_FN_APP_RQ, /* uint8_t net_fn */
            ipmiRequest,        /* const void *buf_rq */
            chunk + 8,          /* unsigned int buf_rq_len */
            ipmiResponse,       /* void *buf_rs */
            2);                 /* unsigned int buf_rs_len */
          if (ipmiResponseLength < 0) {
            status = SetFreeIPMIBackendError(&_AVR2IPMILastErrorA, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));

#if PRINT_BACKEND_ERROR
            printf("ipmi_cmd_raw (SMBUS write) error %d => %s\n", ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));
#endif

            goto out;
          }
          break;
        }
#endif

        default:
          assert(FALSE);
          break;
      }

#if TRACE
      DumpIPMIResponse(ipmiResponse, ipmiResponseLength, "SMBUS write");
#endif

      if (ipmiResponseLength < 2) {
        status = SetIPMIShortResponseError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, 2, ipmiResponseLength);

#if PRINT_IPMI_ERROR
        printf("ipmi_cmd_raw (SMBUS write) response length too short (expected >= 2): %d\n", ipmiResponseLength);
#endif

        goto out;
      } else {
        completion = ipmiResponse[1];
        if (completion == 0) {
          bDone = TRUE;
        } else if (completion == 0x83) {
          /* NACKed; we will try again */
        } else {
          status = SetIPMICompletionError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, completion);

#if PRINT_IPMI_ERROR
          printf("ipmi_cmd_raw (SMBUS write) returned error completion code: 0x%02X\n", completion);
#endif

          goto out;
        }
      }

      clkError = clock_gettime(CLOCK_REALTIME, &now);
      if (clkError) {
        status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_UNEXPECTED_ERROR);

        goto out;
      }

      /* If current real time >= expire time, then time out. */
      if (now.tv_sec >= expire.tv_sec) {
        if (now.tv_sec == expire.tv_sec) {
          if (now.tv_nsec >= expire.tv_nsec) {
            status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_TIMEOUT);

            goto out;
          }
        } else {
          status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_TIMEOUT);

          goto out;
        }
      }
    } while (!bDone);

    position += chunk;
  }

  /* Changing SMBUS chip address between command and response */
  /* Should only use be used when somebody has requested changing the uC's SMBUS chip address */
  if (0 != responseAddrOverride) {
    hSession->ChipAddress = responseAddrOverride;
  }

  position = 0;
  if (!(flags & AVR2IPMI_FLAG_SKIP_RESPONSE)) {
    while (position < responseLength) {
      ipmiRequest[0] = IPMI_CMD_MASTER_WRITE_READ;
      ipmiRequest[1] = hSession->BusID;
      ipmiRequest[2] = hSession->ChipAddress << 1;
      ipmiRequest[3] = 34; /* Number of bytes to read: large enough for (a) SMBUS byte count + (b) SMBUS payload of 32 bytes + (c) PEC */
      ipmiRequest[4] = SMBUS_CMD_BOARDMAN2_RESP;

#if TRACE
      DumpIPMIRequest(ipmiRequest, 5, "SMBUS read");
#endif

      bDone = FALSE;
      do {
        memset(ipmiResponse, 0, ARRAY_LENGTH(ipmiResponse));
          
        switch (hSession->Backend) {
#if defined(INCLUDE_FREEIPMI)
          case AVR2IPMI_BACKEND_FREEIPMI: {
            ipmi_ctx_t hContext = hSession->Variant.FreeIPMI.hContext;

            ipmiResponseLength = ipmi_cmd_raw(
              hContext,           /* ipmi_ctx_t ctx */
              0,                  /* uint8_t lun */
              IPMI_NET_FN_APP_RQ, /* uint8_t net_fn */
              ipmiRequest,        /* const void *buf_rq */
              5,                  /* unsigned int buf_rq_len */
              ipmiResponse,       /* void *buf_rs */
              36);                /* unsigned int buf_rs_len */
            if (ipmiResponseLength < 0) {
              status = SetFreeIPMIBackendError(&_AVR2IPMILastErrorA, ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));

#if PRINT_BACKEND_ERROR
              printf("ipmi_cmd_raw (SMBUS read) error %d => %s\n", ipmi_ctx_errnum(hContext), ipmi_ctx_errormsg(hContext));
#endif

              goto out;
            }
            break;
          }
#endif

        default:
          assert(FALSE);
          break;
        }

#if TRACE
        DumpIPMIResponse(ipmiResponse, ipmiResponseLength, "SMBUS read");
#endif

        if (ipmiResponseLength < 2) {
          status = SetIPMIShortResponseError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, 2, ipmiResponseLength);

#if PRINT_IPMI_ERROR
          printf("ipmi_cmd_raw (SMBUS read) response length too short (expected >= 2): %d\n", ipmiResponseLength);
#endif

          goto out;
        } else {
          completion = ipmiResponse[1];
          if (completion == 0) {
            bDone = TRUE;
          } else if (completion == 0x83) {
            /* NACKed; we will try again */
          } else {
            status = SetIPMICompletionError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, completion);

#if PRINT_IPMI_ERROR
            printf("ipmi_cmd_raw (SMBUS read) returned error completion code: 0x%02X\n", completion);
#endif

            goto out;
          }
        }

        clkError = clock_gettime(CLOCK_REALTIME, &now);
        if (clkError) {
          status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_UNEXPECTED_ERROR);

          goto out;
        }

        /* If current real time >= expire time, then time out. */
        if (now.tv_sec >= expire.tv_sec) {
          if (now.tv_sec == expire.tv_sec) {
            if (now.tv_nsec >= expire.tv_nsec) {
              status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_TIMEOUT);

              goto out;
            }
          } else {
            status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_TIMEOUT);

            goto out;
          }
        }
      } while (!bDone);

      if (ipmiResponseLength < 4) {
        status = SetIPMIShortResponseError(&_AVR2IPMILastErrorA, AVR2IPMI_BACKEND_FREEIPMI, 5, ipmiResponseLength);

#if PRINT_IPMI_ERROR
        printf("ipmi_cmd_raw (SMBUS read) response length too short (expected >= 5): %d\n", ipmiResponseLength);
#endif

        goto out;
      }

      smbusByteCount = ipmiResponse[2];
      if (smbusByteCount < 1 || smbusByteCount > 32) {
        /* Illegal SMBUS byte count */
        status = SetSimpleError(&_AVR2IPMILastErrorA, AVR2IPMI_UNEXPECTED_ERROR);

        goto out;
      }

      if (ipmiResponseLength >= smbusByteCount + 4) {
        /* Compute expected PEC (CRC8) */
        nChecksum = CRC8Byte(0, hSession->ChipAddress << 1);
        nChecksum = CRC8Byte(nChecksum, 0xE1);
        nChecksum = CRC8Byte(nChecksum, (hSession->ChipAddress << 1) | 0x1);
        nChecksum = CRC8Buffer(nChecksum, &ipmiResponse[2], smbusByteCount + 1);

        nChecksumReceived = ipmiResponse[3 + smbusByteCount];
        if (nChecksumReceived != nChecksum) {
#if PRINT_PEC_ERROR
          printf("Bad PEC received: expecting 0x%02X actual 0x%02X\n", nChecksum, nChecksumReceived);
#endif

          /* Request that uC rewinds its response pointer to the beginning of the last response packet */
          status = RequestResponseRewind(hSession, &expire);
          if (AVR2IPMI_SUCCESS != status) {
            goto out;
          }

          continue;
        }
      }

      packetFlags = ipmiResponse[3];

      if (packetFlags & FLAG_FIRST_PACKET) {
        position = 0;
      }

      readPayloadLength = smbusByteCount - 1;

      chunk = readPayloadLength;
      if (position + chunk > responseLength) {
        chunk = responseLength - position;
      }
      memcpy(pResponse + position, &ipmiResponse[4], chunk);

      position += readPayloadLength;

      if (packetFlags & FLAG_LAST_PACKET) {
        break;
      }
    }
  }

out:
  if (AVR2IPMI_SUCCESS == status) {
    *pActualResponseLength = position;
  }

  return status;
}
