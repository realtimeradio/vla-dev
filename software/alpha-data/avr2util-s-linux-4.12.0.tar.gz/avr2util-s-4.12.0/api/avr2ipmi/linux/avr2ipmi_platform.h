#if !defined(_ADATA_AVR2IPMI_API_PLATFORM_H)
#define _ADATA_AVR2IPMI_API_PLATFORM_H

/*
** File: avr2ipmi_platform.h  
** Project: AVR2 IPMI API module library
** Purpose: Interface to Linux-specific functions for AVR2 IPMI API library
**
** (C) Copyright Alpha Data 2017
*/

#include <avr2ipmi/platform.h>

extern AVR2IPMI_STATUS
avr2ipmiOpenSession(
  const AVR2IPMI_OPTIONS* pOptions,
  AVR2IPMI_SESSION* phDevice);

extern AVR2IPMI_STATUS
avr2ipmiCloseSession(
  AVR2IPMI_SESSION hSession);

#endif
