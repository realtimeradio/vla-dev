/*
** File: avr2ipmi.c  
** Project: AVR2 IPMI API library
** Purpose: OS-independent code for AVR2 IPMI API library
**
** (C) Copyright Alpha Data 2017
*/

#include <string.h>
#include <ctype.h>
#include <limits.h>

#include <avr2ipmi.h>
#include <portability.h>
#include <avr2ipmi_platform.h>

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

__thread AVR2IPMI_ERROR_DETAILA _AVR2IPMILastErrorA;
#if defined(_WIN32) || defined(_MSC_VER)
__thread AVR2IPMI_ERROR_DETAILW _AVR2IPMILastErrorW;
#endif

static const char g_pszBackendFreeIPMI[] = "freeipmi";

/* Default IPMI Bus ID where we expect to find the uC */
#define DEFAULT_IPMI_BUS_ID (0x01)

/* Default I2C chip address where we expect to find the uC */
#define DEFAULT_UC_SMBUS_CHIP_ADDR (0x48)

static const char* g_ppszAvailableBackendsA[] = {
#ifdef INCLUDE_FREEIPMI
  "freeipmi",
#endif
  NULL
};

#if defined(_WIN32) || defined(_MSC_VER)
static const char* g_ppszAvailableBackendsW[] = {
# ifdef INCLUDE_FREEIPMI
  L"freeipmi",
# endif
  NULL
};
#endif

static int
ParseUIntHex(
  const char* pString,
  size_t nLength,
  unsigned int* pValue)
{
  const unsigned int maxdiv16 = UINT_MAX / 16;
  size_t i;
  unsigned int val = 0;

  for (i = 0; i < nLength; i++) {
    char c = tolower(pString[i]);

    if (val >= maxdiv16) {
      return FALSE; /* Out of range 0 .. UINT_MAX */
    }

    val = val << 4;
    if (c >= '0' && c <= '9') {
      val += (unsigned int)(c - '0');
    } else if (c >= 'a' && c <= 'f') {
      val += (unsigned int)(c - 'f') + 10;
    } else {
      return FALSE;
    }
  }

  *pValue = val;

  return TRUE;
}

static int
ParseUIntDec(
  const char* pString,
  size_t nLength,
  unsigned int* pValue)
{
  const unsigned int maxdiv10 = UINT_MAX / 10;
  size_t i;
  unsigned int increment, val = 0;

  for (i = 0; i < nLength; i++) {
    char c = tolower(pString[i]);

    if (val > maxdiv10) {
      return FALSE; /* Out of range 0 .. UINT_MAX */
    }

    val = val * 10;

    if (c >= '0' && c <= '9') {
      increment = (unsigned int)(c - '0');
    } else {
      return FALSE;
    }

    if (val > (UINT_MAX - increment)) {
      return FALSE; /* Out of range 0 .. UINT_MAX */
    }

    val += increment;
  }

  *pValue = val;

  return TRUE;
}

static int
ParseUInt(
  const char* pString,
  size_t nLength,
  unsigned int* pValue)
{
  if (nLength >= 2 && pString[0] == '0' && pString[1] == 'x') {
    return ParseUIntHex(pString + 2, nLength - 2, pValue);
  } else {
    return ParseUIntDec(pString, nLength, pValue);
  }
}

static void
CopyValue(
  char* pszDst,
  const char* pszSrc,
  size_t nDstSize,
  size_t nSrcSize)
{
  while (nDstSize > 1 && nSrcSize) {
    char c = *pszSrc++;

    if (c == '\0') {
      break;
    }

    *pszDst++ = c;

    nDstSize--;
    nSrcSize--;
  }

  *pszDst = '\0';
}

static const char*
TrimWhitespaceA(
  const char* pszString)
{
  while (1) {
    char c = *pszString;

    if (c == '\0' || !isspace(c)) {
      break;
    }

    pszString++;
  }

  return pszString;
}

static size_t
IsolateWordA(
  const char* pszString)
{
  size_t i = 0;

  while (1) {
    char c = pszString[i];

    if (c == '\0' || isspace(c)) {
      break;
    }

    i++;
  }

  return i;
}

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_CloseSession(
  AVR2IPMI_SESSION hSession)
{
  if (AVR2IPMI_SESSION_INVALID_VALUE == hSession) {
    return AVR2IPMI_INVALID_SESSION;
  }
  
  return avr2ipmiCloseSession(hSession);
}

AVR2IPMI_EXPORT const char**
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetBackendsA(
  void)
{
  return g_ppszAvailableBackendsA;
}

#if defined(_WIN32) || defined(_MSC_VER)

AVR2IPMI_EXPORT const wchar_t**
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetBackendsW(
  void)
{
  return g_ppszAvailableBackendsW;
}

#endif


AVR2IPMI_EXPORT void
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetErrorDetailA(
  AVR2IPMI_ERROR_DETAILA* pErrorDetail)
{
  memcpy(pErrorDetail, &_AVR2IPMILastErrorA, sizeof(*pErrorDetail));
}

#if defined(_WIN32) || defined(_MSC_VER)

AVR2IPMI_EXPORT void
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetErrorDetailW(
  AVR2IPMI_ERROR_DETAILW* pErrorDetail)
{
  /* Take non-string fields from ANSI version */
  pErrorDetail->Status = _AVR2IPMILastErrorA.Status;
  pErrorDetail->Backend = _AVR2IPMILastErrorA.Backend;
  pErrorDetail->Completion = _AVR2IPMILastErrorA.Completion;
  pErrorDetail->ResponseLength = _AVR2IPMILastErrorA.ResponseLength;
  pErrorDetail->Variant = _AVR2IPMILastErrorA.Variant;

  /* Only take description field from Unicode version */
  memcpy(pErrorDetail->Description, _AVR2IPMILastErrorW.Description, sizeof(pErrorDetail->Description));
}

#endif

AVR2IPMI_EXPORT const char*
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetStatusStringA(
  AVR2IPMI_STATUS code,
  _AVR2IPMI_BOOL bShort)
{
  if (bShort) {
    switch (code) {
    case AVR2IPMI_SUCCESS:
      return "AVR2IPMI_SUCCESS";

    case AVR2IPMI_INTERNAL_ERROR:
      return "AVR2IPMI_INTERNAL_ERROR";

    case AVR2IPMI_UNEXPECTED_ERROR:
      return "AVR2IPMI_UNEXPECTED_ERROR";

    case AVR2IPMI_INVALID_SESSION:
      return "AVR2IPMI_INVALID_SESSION";

    case AVR2IPMI_NULL_POINTER:
      return "AVR2IPMI_NULL_POINTER";
      
    case AVR2IPMI_INSUFFICIENT_RESOURCES:
      return "AVR2IPMI_INSUFFICIENT_RESOURCES";

    case AVR2IPMI_BAD_OPTIONS_FORMAT:
      return "AVR2IPMI_BAD_OPTIONS_FORMAT";

    case AVR2IPMI_OPTION_NAME_MISSING:
      return "AVR2IPMI_OPTION_NAME_MISSING";

    case AVR2IPMI_OPTION_VALUE_MISSING:
      return "AVR2IPMI_OPTION_VALUE_MISSING";

    case AVR2IPMI_OPTION_UNRECOGNIZED:
      return "AVR2IPMI_OPTION_UNRECOGNIZED";

    case AVR2IPMI_BACKEND_UNRECOGNIZED:
      return "AVR2IPMI_BACKEND_UNRECOGNIZED";

    case AVR2IPMI_AUTHENTICATION_UNRECOGNIZED:
      return "AVR2IPMI_AUTHENTICATION_UNRECOGNIZED";

    case AVR2IPMI_BACKEND_NOT_AVAILABLE:
      return "AVR2IPMI_BACKEND_NOT_AVAILABLE";

    case AVR2IPMI_BACKEND_ERROR:
      return "AVR2IPMI_BACKEND_ERROR";

    case AVR2IPMI_BAD_IPMI_BUS_ID:
      return "AVR2IPMI_BAD_IPMI_BUS_ID";

    case AVR2IPMI_BAD_IPMI_CHIP_ADDR:
      return "AVR2IPMI_BAD_IPMI_CHIP_ADDR";

    case AVR2IPMI_SESSION_ERROR:
      return "AVR2IPMI_SESSION_ERROR";

    case AVR2IPMI_NO_LOCAL_IPMI_MC:
      return "AVR2IPMI_NO_LOCAL_IPMI_MC";

    case AVR2IPMI_BACKEND_INIT_FAILED:
      return "AVR2IPMI_BACKEND_INIT_FAILED";

    case AVR2IPMI_IPMI_SHORT_RESPONSE:
      return "AVR2IPMI_IPMI_SHORT_RESPONSE";

    case AVR2IPMI_IPMI_COMPLETION_ERROR:
      return "AVR2IPMI_IPMI_COMPLETION_ERROR";

    case AVR2IPMI_INVALID_PARAMETER:
      return "AVR2IPMI_INVALID_PARAMETER";

    case AVR2IPMI_TIMEOUT:
      return "AVR2IPMI_TIMEOUT";

    case AVR2IPMI_SHORT_COMMAND:
      return "AVR2IPMI_SHORT_COMMAND";

    default:
      return "AVR2IPMI_?";
    }
  } else {
    switch (code) {
    case AVR2IPMI_SUCCESS:
      return "No error";

    case AVR2IPMI_INTERNAL_ERROR:
      return "An error in the API logic was detected";

    case AVR2IPMI_UNEXPECTED_ERROR:
      return "An unexpected error caused the operation to fail";

    case AVR2IPMI_INVALID_SESSION:
      return "An invalid session handle was passed";
      
    case AVR2IPMI_NULL_POINTER:
      return "A NULL pointer was passed where a non-NULL pointer was required";
      
    case AVR2IPMI_INSUFFICIENT_RESOURCES:
      return "An allocation failed";

    case AVR2IPMI_BAD_OPTIONS_FORMAT:
      return "The options string was not in the form \"<backend> [option ...]\"";

    case AVR2IPMI_OPTION_NAME_MISSING:
      return "The name of an option was missing";

    case AVR2IPMI_OPTION_UNRECOGNIZED:
      return "An option was not recognized";

    case AVR2IPMI_OPTION_VALUE_MISSING:
      return "An option value was missing";

    case AVR2IPMI_BACKEND_UNRECOGNIZED:
      return "The backend IPMI library name (freeipmi, openipmi etc.) was not recognized";

    case AVR2IPMI_AUTHENTICATION_UNRECOGNIZED:
      return "The requested authentication type was not recognized";

    case AVR2IPMI_BACKEND_NOT_AVAILABLE:
      return "The requested backend IPMI library (freeipmi, openipmi etc.) is not available in this system";

    case AVR2IPMI_BAD_IPMI_BUS_ID:
      return "The specified IPMI Bus ID was not a number in the range 0 to 0xFF";

    case AVR2IPMI_BAD_IPMI_CHIP_ADDR:
      return "The specified SMBUS chip address was not a number in the range 0 to 0x7F";

    case AVR2IPMI_BACKEND_ERROR:
      return "The backend IPMI library reported that opening a session failed for an unexpected reason";

    case AVR2IPMI_SESSION_ERROR:
      return "The backend IPMI library reported that opening a session failed for an unexpected reason";

    case AVR2IPMI_NO_LOCAL_IPMI_MC:
      return "The backend IPMI library did not find a local IPMI MC";

    case AVR2IPMI_BACKEND_INIT_FAILED:
      return "Initialization of the backend IPMI library failed for an unexpected reason";

    case AVR2IPMI_IPMI_SHORT_RESPONSE:
      return "MC returned a response that was too short to be valid (< 2 bytes)";

    case AVR2IPMI_IPMI_COMPLETION_ERROR:
      return "MC returned an error (nonzero) completion code that was not one of the expected values";

    case AVR2IPMI_INVALID_PARAMETER:
      return "A parameter had an illegal value";

    case AVR2IPMI_TIMEOUT:
      return "The operation did not complete within the timeout period";

    case AVR2IPMI_SHORT_COMMAND:
      return "The length of the command was less than 2 bytes";

    default:
      return "Unrecognized AVR2IPMI_STATUS code";
    }
  }
}

#if defined(_WIN32) || defined(_MSC_VER)

AVR2IPMI_EXPORT const wchar_t*
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_GetStatusStringW(
  AVR2IPMI_STATUS code,
  _AVR2IPMI_BOOL bShort)
{
  if (bShort) {
    switch (code) {
    case AVR2IPMI_SUCCESS:
      return L"AVR2IPMI_SUCCESS";

    case AVR2IPMI_INTERNAL_ERROR:
      return L"AVR2IPMI_INTERNAL_ERROR";

    case AVR2IPMI_UNEXPECTED_ERROR:
      return L"AVR2IPMI_UNEXPECTED_ERROR";

    case AVR2IPMI_INVALID_SESSION:
      return L"AVR2IPMI_INVALID_SESSION";

    case AVR2IPMI_NULL_POINTER:
      return L"AVR2IPMI_NULL_POINTER";
      
    case AVR2IPMI_INSUFFICIENT_RESOURCES:
      return L"AVR2IPMI_INSUFFICIENT_RESOURCES";

    case AVR2IPMI_BAD_OPTIONS_FORMAT:
      return L"AVR2IPMI_BAD_OPTIONS_FORMAT";

    case AVR2IPMI_OPTION_NAME_MISSING:
      return L"AVR2IPMI_OPTION_NAME_MISSING";

    case AVR2IPMI_OPTION_VALUE_MISSING:
      return L"AVR2IPMI_OPTION_VALUE_MISSING";

    case AVR2IPMI_OPTION_UNRECOGNIZED:
      return L"AVR2IPMI_OPTION_UNRECOGNIZED";

    case AVR2IPMI_BACKEND_UNRECOGNIZED:
      return L"AVR2IPMI_BACKEND_UNRECOGNIZED";

    case AVR2IPMI_AUTHENTICATION_UNRECOGNIZED:
      return L"AVR2IPMI_AUTHENTICATION_UNRECOGNIZED";

    case AVR2IPMI_BACKEND_NOT_AVAILABLE:
      return L"AVR2IPMI_BACKEND_NOT_AVAILABLE";

    case AVR2IPMI_BAD_IPMI_BUS_ID:
      return L"AVR2IPMI_BAD_IPMI_BUS_ID";

    case AVR2IPMI_BAD_IPMI_CHIP_ADDR:
      return L"AVR2IPMI_BAD_IPMI_CHIP_ADDR";

    case AVR2IPMI_BACKEND_ERROR:
      return L"AVR2IPMI_BACKEND_ERROR";

    case AVR2IPMI_SESSION_ERROR:
      return L"AVR2IPMI_SESSION_ERROR";

    case AVR2IPMI_NO_LOCAL_IPMI_MC:
      return L"AVR2IPMI_NO_LOCAL_IPMI_MC";

    case AVR2IPMI_BACKEND_INIT_FAILED:
      return L"AVR2IPMI_BACKEND_INIT_FAILED";

    case AVR2IPMI_IPMI_SHORT_RESPONSE:
      return L"AVR2IPMI_IPMI_SHORT_RESPONSE";

    case AVR2IPMI_IPMI_COMPLETION_ERROR:
      return L"AVR2IPMI_IPMI_COMPLETION_ERROR";

    case AVR2IPMI_INVALID_PARAMETER:
      return L"AVR2IPMI_INVALID_PARAMETER";

    case AVR2IPMI_TIMEOUT:
      return L"AVR2IPMI_TIMEOUT";

    case AVR2IPMI_SHORT_COMMAND:
      return L"AVR2IPMI_SHORT_COMMAND";

    default:
      return L"AVR2IPMI_?";
    }
  } else {
    switch (code) {
    case AVR2IPMI_SUCCESS:
      return L"No error";

    case AVR2IPMI_INTERNAL_ERROR:
      return L"An error in the API logic was detected";

    case AVR2IPMI_UNEXPECTED_ERROR:
      return L"An unexpected error caused the operation to fail";

    case AVR2IPMI_INVALID_SESSION:
      return L"An invalid session handle was passed";
      
    case AVR2IPMI_NULL_POINTER:
      return L"A NULL pointer was passed where a non-NULL pointer was required";
      
    case AVR2IPMI_INSUFFICIENT_RESOURCES:
      return L"An allocation failed";

    case AVR2IPMI_BAD_OPTIONS_FORMAT:
      return L"The options string was not in the form \"<backend> [option ...]\"";

    case AVR2IPMI_OPTION_NAME_MISSING:
      return L"The name of an option was missing";

    case AVR2IPMI_OPTION_UNRECOGNIZED:
      return L"An option was not recognized";

    case AVR2IPMI_OPTION_VALUE_MISSING:
      return L"An option value was missing";

    case AVR2IPMI_BACKEND_UNRECOGNIZED:
      return L"The backend IPMI library name (freeipmi, openipmi etc.) was not recognized";

    case AVR2IPMI_AUTHENTICATION_UNRECOGNIZED:
      return L"The requested authentication type was not recognized";

    case AVR2IPMI_BACKEND_NOT_AVAILABLE:
      return L"The requested backend IPMI library (freeipmi, openipmi etc.) is not available in this system";

    case AVR2IPMI_BAD_IPMI_BUS_ID:
      return L"The specified IPMI Bus ID was not a number in the range 0 to 0xFF";

    case AVR2IPMI_BAD_IPMI_CHIP_ADDR:
      return L"The specified SMBUS chip address was not a number in the range 0 to 0x7F";

    case AVR2IPMI_BACKEND_ERROR:
      return L"The backend IPMI library reported that opening a session failed for an unexpected reason";

    case AVR2IPMI_SESSION_ERROR:
      return L"The backend IPMI library reported that opening a session failed for an unexpected reason";

    case AVR2IPMI_NO_LOCAL_IPMI_MC:
      return L"The backend IPMI library did not find a local IPMI MC";

    case AVR2IPMI_BACKEND_INIT_FAILED:
      return L"Initialization of the backend IPMI library failed for an unexpected reason";

    case AVR2IPMI_IPMI_SHORT_RESPONSE:
      return L"MC returned a response that was too short to be valid (< 2 bytes)";

    case AVR2IPMI_IPMI_COMPLETION_ERROR:
      return L"MC returned an error (nonzero) completion code that was not one of the expected values";

    case AVR2IPMI_INVALID_PARAMETER:
      return L"A parameter had an illegal value";

    case AVR2IPMI_TIMEOUT:
      return L"The operation did not complete within the timeout period";

    case AVR2IPMI_SHORT_COMMAND:
      return L"The length of the command was less than 2 bytes";

    default:
      return L"Unrecognized AVR2IPMI_STATUS code";
    }
  }
}

#endif

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_OpenSession(
  const AVR2IPMI_OPTIONS* pOptions,
  AVR2IPMI_SESSION* phSession)
{
  return avr2ipmiOpenSession(pOptions, phSession);
}

AVR2IPMI_EXPORT AVR2IPMI_STATUS
AVR2IPMI_CALLING_CONVENTION
AVR2IPMI_ParseOptionsA(
  const char* pszOptionsString,
  AVR2IPMI_OPTIONS* pOptions)
{
  AVR2IPMI_BACKEND_TYPE nBackend;
  AVR2IPMI_AUTHENTICATION_TYPE nAuthenticationType = AVR2IPMI_AUTHENTICATION_MD5;
  char szHostname[256];
  char szUsername[256];
  char szPassword[256];
  unsigned int nBusID = DEFAULT_IPMI_BUS_ID;
  unsigned int nChipAddress = DEFAULT_UC_SMBUS_CHIP_ADDR;
  int bEnableDebug = FALSE;
  size_t nWordLength;

  if (NULL == pszOptionsString || NULL == pOptions) {
    return AVR2IPMI_NULL_POINTER;
  }

  strcpy(szHostname, "");
  szUsername[0] = '\0';
  szPassword[0] = '\0';

  /* Trim whitespace from beginning of options string */
  pszOptionsString = TrimWhitespaceA(pszOptionsString);

  /* Isolate first word, which is the backend to use (FreeIPMI, OpenIPMI etc.) */
  nWordLength = IsolateWordA(pszOptionsString);
  if (0 == nWordLength) {
    return AVR2IPMI_BAD_OPTIONS_FORMAT;
  }

  /* Check for FreeIPMI backend name */
  if (0 == strncasecmp(pszOptionsString, g_pszBackendFreeIPMI, nWordLength)) {
    nBackend = AVR2IPMI_BACKEND_FREEIPMI;
  } else {
    /* No other backends implemented at the moment */

    return AVR2IPMI_BACKEND_UNRECOGNIZED;
  }

  /* Parse the options */

  /* Move to next word and trim whitespace */
  pszOptionsString += nWordLength;
  pszOptionsString = TrimWhitespaceA(pszOptionsString);

  nWordLength = IsolateWordA(pszOptionsString);

  while (TRUE) {
    int bGNUStyleOption, bHasValue, bConsumeValue = FALSE;
    const char* pszOption = NULL;
    size_t nOptionLength = 0;
    const char* pszValue = NULL;
    size_t nValueLength = 0;

    if (0 == nWordLength) {
      break;
    }

    if (pszOptionsString[0] == '-') {
      if (nWordLength >= 2 && pszOptionsString[1] == '-') {
        char* p;

        /*
        ** Legal forms are:
        **
        **   --option
        **   --option=value
        */

        bGNUStyleOption = TRUE;

        /* Assume doesn't have a value, will correct below */
        bHasValue = FALSE;

        pszOption = pszOptionsString + 2;
        nOptionLength = nWordLength - 2;
        if (0 == nOptionLength) {
          return AVR2IPMI_OPTION_NAME_MISSING;
        }

        p = strchr(pszOption, '=');
        if (NULL != p) {
          bHasValue = TRUE;

          nOptionLength = p - pszOption;
          if (0 == nOptionLength) {
            return AVR2IPMI_OPTION_NAME_MISSING;
          }

          pszValue = p + 1;
          nValueLength = nWordLength - (nOptionLength + 3);
          if (0 == nValueLength) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }
        }
      } else {
        /*
        ** Legal forms are:
        **
        **   -option
        **   -option value
        */

        bGNUStyleOption = FALSE;

        /* Assume doesn't have a value, will correct below */
        bHasValue = FALSE;

        pszOption = pszOptionsString + 1;
        nOptionLength = nWordLength - 1;
        if (0 == nOptionLength) {
          return AVR2IPMI_OPTION_NAME_MISSING;
        }

        /* Move to next word and trim whitespace */
        pszOptionsString += nWordLength;
        pszOptionsString = TrimWhitespaceA(pszOptionsString);

        nWordLength = IsolateWordA(pszOptionsString);
        if (nWordLength > 0 && pszOptionsString[0] != '-') {
          bHasValue = TRUE;

          pszValue = pszOptionsString;
          nValueLength = nWordLength;
        }
      }
    } else {
      return AVR2IPMI_BAD_OPTIONS_FORMAT;
    }

    switch (nBackend) {
    case AVR2IPMI_BACKEND_FREEIPMI:
      if (bGNUStyleOption) {
        if (0 == strncmp("authentication-type", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          if (0 == strncasecmp(pszValue, "none", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_NONE;
          } else if (0 == strncasecmp(pszValue, "md2", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_MD2;
          } else if (0 == strncasecmp(pszValue, "md5", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_MD5;
          } else if (0 == strncasecmp(pszValue, "straight_password_key", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_STRAIGHT_PASSWORD;
          } else {
            return AVR2IPMI_AUTHENTICATION_UNRECOGNIZED;
          }
        } else if (0 == strncmp("busid", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          if (!ParseUInt(pszValue, nValueLength, &nBusID)) {
            return AVR2IPMI_BAD_IPMI_BUS_ID;
          }
          if (nBusID > 0xFF) {
            return AVR2IPMI_BAD_IPMI_BUS_ID;
          }
        } else if (0 == strncmp("chipaddr", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          if (!ParseUInt(pszValue, nValueLength, &nChipAddress)) {
            return AVR2IPMI_BAD_IPMI_CHIP_ADDR;
          }
          if (nChipAddress > 0x7F) {
            return AVR2IPMI_BAD_IPMI_CHIP_ADDR;
          }
        } else if (0 == strncmp("debug", pszOption, nOptionLength)) {
          bEnableDebug = TRUE;
        } else if (0 == strncmp("hostname", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          CopyValue(szHostname, pszValue, ARRAY_LENGTH(szHostname), nValueLength);
        } else if (0 == strncmp("password", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          CopyValue(szPassword, pszValue, ARRAY_LENGTH(szPassword), nValueLength);
        } else if (0 == strncmp("username", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          CopyValue(szUsername, pszValue, ARRAY_LENGTH(szUsername), nValueLength);
        } else {
          return AVR2IPMI_OPTION_UNRECOGNIZED;
        }

        bConsumeValue = TRUE;
      } else {
        if (0 == strncmp("a", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          if (0 == strncasecmp(pszValue, "none", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_NONE;
          } else if (0 == strncasecmp(pszValue, "md2", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_MD2;
          } else if (0 == strncasecmp(pszValue, "md5", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_MD5;
          } else if (0 == strncasecmp(pszValue, "straight_password_key", nValueLength)) {
            nAuthenticationType = AVR2IPMI_AUTHENTICATION_STRAIGHT_PASSWORD;
          } else {
            return AVR2IPMI_AUTHENTICATION_UNRECOGNIZED;
          }

          bConsumeValue = TRUE;
        } else if (0 == strncmp("busid", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          if (!ParseUInt(pszValue, nValueLength, &nBusID)) {
            return AVR2IPMI_BAD_IPMI_BUS_ID;
          }
          if (nBusID > 0xFF) {
            return AVR2IPMI_BAD_IPMI_BUS_ID;
          }

          bConsumeValue = TRUE;
        } else if (0 == strncmp("chipaddr", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          if (!ParseUInt(pszValue, nValueLength, &nChipAddress)) {
            return AVR2IPMI_BAD_IPMI_CHIP_ADDR;
          }
          if (nChipAddress > 0x7F) {
            return AVR2IPMI_BAD_IPMI_CHIP_ADDR;
          }

          bConsumeValue = TRUE;
        } else if (0 == strncmp("h", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          CopyValue(szHostname, pszValue, ARRAY_LENGTH(szHostname), nValueLength);

          bConsumeValue = TRUE;
        } else if (0 == strncmp("p", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          CopyValue(szPassword, pszValue, ARRAY_LENGTH(szPassword), nValueLength);

          bConsumeValue = TRUE;
        } else if (0 == strncmp("u", pszOption, nOptionLength)) {
          if (!bHasValue) {
            return AVR2IPMI_OPTION_VALUE_MISSING;
          }

          CopyValue(szUsername, pszValue, ARRAY_LENGTH(szUsername), nValueLength);

          bConsumeValue = TRUE;
        } else {
          return AVR2IPMI_OPTION_UNRECOGNIZED;
        }
      }
      break;

    default:
      return AVR2IPMI_INTERNAL_ERROR;
    }

    if (bConsumeValue) {
      /* Move to next word and trim whitespace */
      pszOptionsString += nWordLength;
      pszOptionsString = TrimWhitespaceA(pszOptionsString);

      nWordLength = IsolateWordA(pszOptionsString);
    }
  }

  pOptions->Backend = nBackend;
  
  pOptions->Authentication = nAuthenticationType;
  
  strncpy(pOptions->Hostname, szHostname, ARRAY_LENGTH(pOptions->Hostname));
  pOptions->Hostname[ARRAY_LENGTH(pOptions->Hostname) - 1] = '0';
  
  strncpy(pOptions->Username, szUsername, ARRAY_LENGTH(pOptions->Username));
  pOptions->Username[ARRAY_LENGTH(pOptions->Username) - 1] = '0';
  
  strncpy(pOptions->Password, szPassword, ARRAY_LENGTH(pOptions->Password));
  pOptions->Password[ARRAY_LENGTH(pOptions->Password) - 1] = '0';
  
  pOptions->BusID = (uint8_t)nBusID;

  pOptions->ChipAddress = (uint8_t)nChipAddress;

  pOptions->Variant.FreeIPMI.EnableDebug = bEnableDebug ? TRUE : FALSE;

  return AVR2IPMI_SUCCESS;
}
