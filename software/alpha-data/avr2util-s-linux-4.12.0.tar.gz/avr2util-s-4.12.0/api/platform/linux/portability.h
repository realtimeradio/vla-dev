#if !defined(_ADATA_PORTABILITY_H)
#define _ADATA_PORTABILITY_H

/*
** File: portability.h  
** Project: API libraries
** Purpose: Linux-specific definitions for abstracting the platform
**
** (C) Copyright Alpha Data 2011
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#include <ctype.h>

#ifndef TRUE
# define TRUE (1)
#endif
#ifndef FALSE
# define FALSE (0)
#endif

typedef int bool_t;
typedef FILE* portable_file_t;
#define PORTABLE_INVALID_FILE (NULL)
#define PORTABLE_HAS_USER_EVENT_HANDLE (0)
#define PORTABLE_HAS_WCHAR_SUPPORT (1)

#define portableFormatStringA1 snprintf
#define portableFormatStringA2 snprintf
#define portableFormatStringA3 snprintf
#define portableFormatStringA4 snprintf

#endif
