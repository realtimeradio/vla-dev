#if !defined(_ADATA_AVR2_API_PROTOCOL_H)
#define _ADATA_AVR2_API_PROTOCOL_H

#define SOH    (0x01) /* Start of packet character */
#define EOT    (0x04) /* End of packet character */
#define ESCAPE (0x10) /* Escape character */

typedef struct _RxEscapeState {
  bool_t bSOHDetected;
  bool_t bLastWasEscape;
  unsigned int position;
  uint8_t rawCh;
  uint8_t unescapedCh;
  uint8_t expectedResponse[2];
} RxEscapeState;

typedef struct _TxEscapeState {
  unsigned int nOccupied;
  bool_t bLastWasEscape;
  uint8_t buffer[32];
} TxEscapeState;

extern void
avr2ProtocolStartRxPacket(
  RxEscapeState* pRxEscapeState,
  const uint8_t* pCommand);

extern bool_t /* TRUE => packet has been completed */
avr2ProtocolUnescapeRxCharacter(
  RxEscapeState* pRxEscapeState,
  uint8_t rawCh,
  bool_t* pbValid,
  uint32_t* pPosition);

extern void
avr2ProtocolStartTxPacket(
  TxEscapeState* pTxEscapeState);

extern bool_t /* success => buffer full or buffer needs transmitted */
avr2ProtocolEscapeTxCharacter(
  TxEscapeState* pTxEscapeState,
  uint8_t character,
  bool_t *pbConsumed);

extern void
avr2ProtocolEndTxPacket(
  TxEscapeState* pTxEscapeState);


#endif
