/*
** File: avr2_platform.c  
** Project: AVR2 API library
** Purpose: Linux-specific code for AVR2 API library
**
** (C) Copyright Alpha Data 2016, 2020
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/timerfd.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>

#include <avr2.h>
#include <portability.h>
#include "../protocol.h"

/* In this routine, we attempt to suck out any stale data from the AVR2's
** TX buffers, including data in the USB serial port's RX buffers.
**
** Set communication event mask to only receive-type events.
** Repeat {
**   Purge serial port buffers.
**   Wait until a 50 ms timeout elapses OR a byte arrives in the serial port's receive buffer.
**   If timeout, cancel I/O and then break from loop.
** }
**
** In other words, we keep sucking out data until no more data arrives within 50 ms.
*/
#define PURGE_TIMEOUT (50)
static void
purgePortBuffers(
  int fd)
{
  while (1) {
    struct pollfd fds[1];
    int pollResult;
    
    if (tcflush(fd, TCIOFLUSH) < 0) {
      /* Flush failed; just return. */
      printf("var\n");
      return;
    }
    
    fds[0].fd = fd;
    fds[0].events = POLLIN;
    fds[0].revents = 0;
    pollResult = poll(fds, 1, PURGE_TIMEOUT);
    if (pollResult < 0) {
      printf("foo\n");
      /* poll() failed, just return. */
      return;
    }
    if (pollResult > 0) {
      /* Got some data, so go around the loop again. */
      continue;
    }
    
    break;
  }
  
  return;
}

AVR2_STATUS
avr2Close(
  AVR2_HANDLE hDevice)
{
  if (close(hDevice)) {
    switch (errno) {
    case EBADF:
      return AVR2_INVALID_HANDLE;
      
    /* What action is needed if EINTR occurs is a controversial topic.
    ** In Linux, it seems that the recommended course of action is not to
    ** retry the close(). */
    case EINTR:
    case EIO:
    default:
      return AVR2_UNEXPECTED_ERROR;
    }
  }
  
  return AVR2_SUCCESS;
}

AVR2_STATUS
avr2OpenPortA(
  const char* pPortName,
  AVR2_HANDLE* phDevice)
{
  int fd = -1;
  AVR2_STATUS status = AVR2_SUCCESS;
  struct termios options;    

  if (NULL == phDevice) {
    return AVR2_NULL_POINTER;
  }
  if (NULL == pPortName) {
    return AVR2_NULL_POINTER;
  }

  fd = open(pPortName, O_RDWR | O_NOCTTY | O_SYNC);
  if (fd < 0) {
    switch (errno) {
    case EACCES:
      status = AVR2_ACCESS_DENIED;
      break;
    
    case EISDIR:
    case EFAULT:
      status = AVR2_INVALID_PARAMETER;
      break;
    
    case EMFILE:
    case ENFILE:
      status = AVR2_RESOURCE_LIMIT;
      break;
    
    case ENODEV:
    case ENXIO:
    case ENOENT:
      status = AVR2_DEVICE_NOT_FOUND;
      break;
    
    case ENOMEM:
      status = AVR2_NO_MEMORY;
      break;
    
    default:
      status = AVR2_UNEXPECTED_ERROR;
      break;    
    }
    goto done;
  }

  /* Set tty options; should not be necessary for ttyACM<n>, but we do it just in case. */
  if (tcgetattr(fd, &options) < 0) {
    status = AVR2_UNEXPECTED_ERROR;
    goto done;
  }
  cfmakeraw(&options);
  options.c_cflag |= CLOCAL | CREAD;
  options.c_cflag &= ~CSTOPB;
  options.c_cflag |= CS8;
  if (tcsetattr(fd, TCSANOW, &options) < 0) {
    status = AVR2_UNEXPECTED_ERROR;
    goto done;
  }

  /* Attempt to purge serial port buffers */
  purgePortBuffers(fd);
  
done:
  if (AVR2_SUCCESS != status) {
    if (AVR2_HANDLE_INVALID_VALUE != fd) {
      close(fd);
    }
  } else {
    *phDevice = fd;
  }
  return status;
}

static AVR2_STATUS
transmitBuffer(
  int hDevice,
  int hTimer,
  uint8_t* pBuffer,
  uint32_t nCount)
{
  AVR2_STATUS status = AVR2_SUCCESS;
  struct pollfd fds[2];
  int n = 1;
  
  fds[0].fd = hDevice;
  fds[0].events = POLLOUT;
  if (hTimer > 0) {
    fds[1].fd = hTimer;
    fds[1].events = POLLIN;
    n++;
  }
  while (nCount > 0) {
    int pollResult;
    
    fds[0].revents = 0;
    fds[1].revents = 0;
    pollResult = poll(fds, n, -1);
    if (pollResult < 0) {
      switch (errno) {
      case EINTR:
        /* poll() does not automatically restart after a signal handler returns, so try again. */
        continue;
        
      case EBADF:
      case EINVAL:
        status = AVR2_INVALID_HANDLE;
        goto out;
          
      default:
        status = AVR2_UNEXPECTED_ERROR;
      }
    }
    
    if (fds[0].revents & POLLOUT) {
      ssize_t nWritten;
      
      nWritten = write(hDevice, pBuffer, nCount);
      if (nWritten < 0) {
        switch (errno) {
        case EWOULDBLOCK:
          break;
          
        case EBADF:
        case EINVAL:
          status = AVR2_INVALID_HANDLE;
          goto out;
          
        case EINTR:
          /* write() normally automatically restarts after a signal handler returns, so this indicates an error */
          status = AVR2_CANCELLED;
          goto out;
          
        default:
          status = AVR2_UNEXPECTED_ERROR;
          goto out;
        }
      } else {
        assert(nWritten <= nCount);
        nCount -= (uint32_t)nWritten; /* Cast is safe because nWritten must be less than nCount */
        pBuffer += nWritten;
      }
    }
    
    if (n >= 1 && (fds[1].revents & POLLIN)) {
      status = AVR2_TIMEOUT;
      goto out;
    }
  }
  
out:
  return status;
}

static AVR2_STATUS
receiveCharacter(
  int hDevice,
  int hTimer,
  uint8_t* pCharacter)
{
  AVR2_STATUS status = AVR2_SUCCESS;
  struct pollfd fds[2];
  int n = 1;
  ssize_t nCount = 1;
  
  fds[0].fd = hDevice;
  fds[0].events = POLLIN;
  if (hTimer > 0) {
    fds[1].fd = hTimer;
    fds[1].events = POLLIN;
    n++;
  }

  while (nCount) {
    int pollResult;
    
    fds[0].revents = 0;
    fds[1].revents = 0;
    pollResult = poll(fds, n, -1);
    if (pollResult < 0) {
      switch (errno) {
      case EINTR:
        /* poll() does not automatically restart after a signal handler returns, so try again. */
        continue;
        
      case EBADF:
      case EINVAL:
        status = AVR2_INVALID_HANDLE;
        goto out;
          
      default:
        status = AVR2_UNEXPECTED_ERROR;
      }
    }
    
    if (fds[0].revents & POLLIN) {
      ssize_t nRead;
      
      nRead = read(hDevice, pCharacter, nCount);
      if (nRead < 0) {
        switch (errno) {
        case EWOULDBLOCK:
          break;
          
        case EBADF:
        case EINVAL:
          status = AVR2_INVALID_HANDLE;
          goto out;
          
        case EINTR:
          /* read() normally automatically restarts after a signal handler returns, so this indicates an error */
          status = AVR2_CANCELLED;
          goto out;
          
        default:
          status = AVR2_UNEXPECTED_ERROR;
          goto out;
        }
      } else {
        assert(nRead <= 1);
        nCount -= nRead; /* Cast is safe because nWritten must be less than nCount */
      }
    }
    
    if (n >= 1 && (fds[1].revents & POLLIN)) {
      status = AVR2_TIMEOUT;
      goto out;
    }
  }

out:
  return status;
}

AVR2_EXPORT AVR2_STATUS
AVR2_CALLING_CONVENTION
AVR2_Command(
  AVR2_HANDLE hDevice,
  _AVR2_UINT32 flags,
  _AVR2_UINT32 timeoutUs,
  _AVR2_UINT32 commandLength,
  const _AVR2_UINT8* pCommand,
  _AVR2_UINT32 responseLength,
  _AVR2_UINT8* pResponse,
  _AVR2_UINT32* pActualResponseLength)
{
  AVR2_STATUS status = AVR2_SUCCESS;
  int hTimer = -1;
  RxEscapeState rxEscapeState;
  TxEscapeState txEscapeState;
  uint32_t position;

  if (commandLength > 0 && NULL == pCommand) {
    return AVR2_NULL_POINTER;
  }
  if (commandLength < 2) {
    return AVR2_SHORT_COMMAND;
  }
  if (responseLength > 0 && NULL == pResponse) {
    return AVR2_NULL_POINTER;
  }

  if (timeoutUs > 0) {
    hTimer = timerfd_create(CLOCK_REALTIME, 0);
    if (hTimer < 0) {
      status = AVR2_RESOURCE_LIMIT;
      goto out;
    }
  }

  if (hTimer >= 0) {
    struct itimerspec timeout = {
      { 0, 0}, /* No repetition */
      { timeoutUs / 1000000, 1000 * (timeoutUs % 1000000) } /* Initial expiry */
    };
    
    if (timerfd_settime(hTimer, 0, &timeout, NULL) < 0) {
      status = AVR2_UNEXPECTED_ERROR;
      goto out;
    }
  }

  position = 0;
  avr2ProtocolStartTxPacket(&txEscapeState);
  while (position <= commandLength) {
    bool_t bCharacterConsumed, bBufferReadyForTx;

    if (position == commandLength) {
      avr2ProtocolEndTxPacket(&txEscapeState);
      bBufferReadyForTx = TRUE;
      bCharacterConsumed = TRUE;
    } else {
      bBufferReadyForTx = avr2ProtocolEscapeTxCharacter(&txEscapeState, pCommand[position], &bCharacterConsumed);
    }
    if (bBufferReadyForTx) {
      status = transmitBuffer(hDevice, hTimer, txEscapeState.buffer, txEscapeState.nOccupied);
      if (status != AVR2_SUCCESS) {
        goto out;
      }
      txEscapeState.nOccupied = 0;
    }
    if (bCharacterConsumed) {
      position++;
    }
  }

  avr2ProtocolStartRxPacket(&rxEscapeState, pCommand);
  if (responseLength > 0) {
    bool_t bCompleted;

    do {
      bool_t bValid;
      uint8_t rawCh;

      status = receiveCharacter(hDevice, hTimer, &rawCh);
      if (AVR2_SUCCESS != status) {
        goto out;
      }
      bCompleted = avr2ProtocolUnescapeRxCharacter(&rxEscapeState, rawCh, &bValid, &position);
      if (bValid && position < responseLength) {
        pResponse[position] = rxEscapeState.unescapedCh;
      }
    } while (!bCompleted);
  }

  *pActualResponseLength = rxEscapeState.position;

out:
  if (hTimer >= 0) {
    close(hTimer);
  }

  return status;
}

/* This has to be a separate file because of <asm/termbits.h> conflicts */
extern int avr2SetCustomBaudRate(int fd, int baud);

AVR2_EXPORT AVR2_STATUS
AVR2_CALLING_CONVENTION
AVR2_SetPortBaud(
  AVR2_HANDLE hDevice,
  _AVR2_UINT32 baudRate)
{
  if (avr2SetCustomBaudRate(hDevice, (int)baudRate) != 0) {
    return AVR2_SET_BAUD_FAILED;
  }

  return AVR2_SUCCESS;
}

