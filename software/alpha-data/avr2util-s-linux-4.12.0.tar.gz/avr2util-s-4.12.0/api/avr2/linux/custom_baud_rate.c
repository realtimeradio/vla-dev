/*
** File: custom_baud_rate.c  
** Project: AVR2 API library
** Purpose: Set custom baud rate on serial port
**
** (C) Copyright Alpha Data 2020
*/

#include <sys/ioctl.h>
#include <asm/termbits.h>

int avr2SetCustomBaudRate(int fd, int baud)
{
  /*
  ** The microcontroller uses a non-standard serial speed, and tcsetattr only
  ** allows standard speeds, so an alternative method is needed. The header
  ** files for using TCGETS2/TCSETS2 ioctl method seem to conflict with
  ** termios.h, so the speed setting is done in a separate file.
  */
  struct termios2 tio;
  
  if (ioctl(fd, TCGETS2, &tio) < 0) {
    return -1;
  }
  
  tio.c_cflag &= ~CBAUD;
  tio.c_cflag |= BOTHER| CLOCAL | CREAD;
  tio.c_cflag &= ~CSTOPB;
  tio.c_cflag |= CS8;
  tio.c_ispeed = baud;
  tio.c_ospeed = baud;
  
  if (ioctl(fd, TCSETS2, &tio) < 0) {
    return -2;
  }
 
  return 0;
}
