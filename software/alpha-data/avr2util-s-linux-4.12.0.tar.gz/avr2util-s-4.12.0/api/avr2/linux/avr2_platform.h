#if !defined(_ADATA_AVR2_API_PLATFORM_H)
#define _ADATA_AVR2_API_PLATFORM_H

/*
** File: avr2_platform.h  
** Project: AVR2 API module library
** Purpose: Interface to Linux-specific functions for AVR2 API library
**
** (C) Copyright Alpha Data 2016
*/

#include <avr2/platform.h>

extern AVR2_STATUS
avr2OpenPortA(
  const char* pPortName,
  AVR2_HANDLE* phDevice);

extern AVR2_STATUS
avr2OpenPortW(
  const wchar_t* pPortName,
  AVR2_HANDLE* phDevice);

extern AVR2_STATUS
avr2Close(
  AVR2_HANDLE hDevice);

#endif
