/*
** File: avr2s_platform.c  
** Project: AVR2 SMBUS API library
** Purpose: Win32-specific code for AVR2 API library
**
** (C) Copyright Alpha Data 2017
*/

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/timerfd.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>
#include <stdint.h>

#include <linux/i2c.h>
#include <linux/i2c-dev.h>

#include <avr2s.h>
#include <portability.h>

/* SMBUS command for sending a BoardMan2 command packet (Block Write) */
#define SMBUS_CMD_BOARDMAN2_CMD  (0xE0)
/* SMBUS command for receiving a BoardMan2 response packet (Block Read) */
#define SMBUS_CMD_BOARDMAN2_RESP (0xE1)

#define AVR2S_MAX_PAYLOAD_LENGTH (32)

/* Flags byte, which is first byte of a command or response packet */
#define FLAG_FIRST_PACKET     (0x1 << 0)
#define FLAG_LAST_PACKET      (0x1 << 1)

static int32_t
smbusPacket(
  int fd,
  int readOrWrite,
  uint8_t smbusCommand,
  int size,
  union i2c_smbus_data* pBuffer)
{
	struct i2c_smbus_ioctl_data ioctls;

	ioctls.read_write = readOrWrite;
	ioctls.command = smbusCommand;
	ioctls.size = size;
	ioctls.data = pBuffer;

	return ioctl(fd, I2C_SMBUS, &ioctls);
}

static int32_t
smbusBlockRead(
  int fd,
  uint8_t smbusCommand,
  uint8_t* pSmbusByteCount,
  uint8_t* pSmbusPayload)
{
	union i2c_smbus_data data;
  uint8_t smbusByteCount;
	unsigned int i;
  int32_t nResult;

  nResult = smbusPacket(fd, I2C_SMBUS_READ, smbusCommand, I2C_SMBUS_BLOCK_DATA, &data);
  if (nResult) {
    return nResult;
  }

	smbusByteCount = data.block[0];

  *pSmbusByteCount = smbusByteCount;

  for (i = 1; i <= smbusByteCount; i++) {
		pSmbusPayload[i - 1] = data.block[i];
  }

  return 0;
}

static int32_t
smbusBlockWrite(
  int fd,
  uint8_t smbusCommand,
  uint8_t smbusByteCount,
  const uint8_t* pSmbusPayload)
{
	union i2c_smbus_data data;
	unsigned int i;
  int32_t nResult;

	data.block[0] = smbusByteCount;

  for (i = 1; i <= smbusByteCount; i++) {
		data.block[i] = pSmbusPayload[i - 1];
  }

	nResult = smbusPacket(fd, I2C_SMBUS_WRITE, smbusCommand, I2C_SMBUS_BLOCK_DATA, &data);
  if (nResult) {
    return nResult;
  }

  return 0;
}

static AVR2S_STATUS
mapErrno(
  int error)
{
  return AVR2S_UNEXPECTED_ERROR;
}

AVR2S_STATUS
avr2sClose(
  AVR2S_HANDLE hDevice)
{
  if (close(hDevice)) {
    switch (errno) {
    case EBADF:
      return AVR2S_INVALID_HANDLE;
      
    /* What action is needed if EINTR occurs is a controversial topic.
    ** In Linux, it seems that the recommended course of action is not to
    ** retry the close(). */
    case EINTR:
    case EIO:
    default:
      return AVR2S_UNEXPECTED_ERROR;
    }
  }
  
  return AVR2S_SUCCESS;
}

AVR2S_STATUS
avr2sOpenSmbusA(
  const char* pDeviceName, /* e.g. /dev/i2c0 */
  _AVR2S_UINT8 chipAddress,  /* 7-bit chip address */
  AVR2S_HANDLE* phDevice)
{
  int fd = -1;
  AVR2S_STATUS status = AVR2S_SUCCESS;

  if (NULL == phDevice) {
    return AVR2S_NULL_POINTER;
  }
  if (NULL == pDeviceName) {
    return AVR2S_NULL_POINTER;
  }

  fd = open(pDeviceName, O_RDWR);
  if (fd < 0) {
    switch (errno) {
    case EACCES:
      status = AVR2S_ACCESS_DENIED;
      break;
    
    case EISDIR:
    case EFAULT:
      status = AVR2S_INVALID_PARAMETER;
      break;
    
    case EMFILE:
    case ENFILE:
      status = AVR2S_RESOURCE_LIMIT;
      break;
    
    case ENODEV:
    case ENXIO:
    case ENOENT:
      status = AVR2S_DEVICE_NOT_FOUND;
      break;
    
    case ENOMEM:
      status = AVR2S_NO_MEMORY;
      break;
    
    default:
      status = AVR2S_UNEXPECTED_ERROR;
      break;    
    }
    goto done;
  }

  if (ioctl(fd, I2C_SLAVE, chipAddress) < 0) {
    status = AVR2S_UNEXPECTED_ERROR;
    goto done;
  }

done:
  if (AVR2S_SUCCESS != status) {
    if (AVR2S_HANDLE_INVALID_VALUE != fd) {
      close(fd);
    }
  } else {
    *phDevice = fd;
  }
  return status;
}

AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_Command(
  AVR2S_HANDLE hDevice,
  _AVR2S_UINT32 flags,
  _AVR2S_UINT32 timeoutUs,
  _AVR2S_UINT32 commandLength,
  const _AVR2S_UINT8* pCommand,
  _AVR2S_UINT8 responseAddrOverride,
  _AVR2S_UINT32 responseLength,
  _AVR2S_UINT8* pResponse,
  _AVR2S_UINT32* pActualResponseLength)
{
  AVR2S_STATUS status = AVR2S_SUCCESS;
  int error = 0, clkError;
  uint32_t position = 0;
  struct timespec start, expire, now;
  time_t seconds;
  long nanoseconds;

  if (commandLength > 0 && NULL == pCommand) {
    return AVR2S_NULL_POINTER;
  }
  if (commandLength < 2) {
    return AVR2S_SHORT_COMMAND;
  }
  if (responseLength > 0 && NULL == pResponse) {
    return AVR2S_NULL_POINTER;
  }

  seconds = timeoutUs / 1000000;
  nanoseconds = timeoutUs * 1000;

  /* Get current real time. */
  clkError = clock_gettime(CLOCK_REALTIME, &start);
  if (clkError) {
    status = AVR2S_UNEXPECTED_ERROR;
    goto out;
  }

  /* Calculate real time at which we time out. */
  expire.tv_sec = start.tv_sec + seconds;
  expire.tv_nsec = start.tv_sec + nanoseconds;
  if (expire.tv_nsec > 1000000000) {
    expire.tv_sec++;
    expire.tv_nsec -= 1000000000;
  }

  position = 0;
  while (position < commandLength) {
    uint8_t payload[32];
    uint8_t chunk, packetFlags;

    packetFlags = 0;

    if (0 == position) {
      packetFlags |= FLAG_FIRST_PACKET;
    }

    chunk = 31;
    if (position + chunk >= commandLength) {
      packetFlags |= FLAG_LAST_PACKET;
      chunk = commandLength - position;
    }

    payload[0] = packetFlags;
    memcpy(&payload[1], pCommand + position, chunk);

    if (0 == smbusBlockWrite((int)hDevice, SMBUS_CMD_BOARDMAN2_CMD, chunk + 1, payload)) {
      position += chunk;
    } else {
      if (ENXIO != errno) {
        error = errno;

        goto out;
      }
    }

    clkError = clock_gettime(CLOCK_REALTIME, &now);
    if (clkError) {
      status = AVR2S_UNEXPECTED_ERROR;
      goto out;
    }

    /* If current real time >= expire time, then time out. */
    if (now.tv_sec >= expire.tv_sec) {
      if (now.tv_sec == expire.tv_sec) {
        if (now.tv_nsec >= expire.tv_nsec) {
          status = AVR2S_TIMEOUT;
          goto out;
        }
      } else {
        status = AVR2S_TIMEOUT;
        goto out;
      }
    }
  }

  /* Changing SMBUS chip address between command and response */
  /* Should only use be used when somebody has requested changing the uC's SMBUS chip address */
  if (0 != responseAddrOverride) {
    if (ioctl((int)hDevice, I2C_SLAVE, responseAddrOverride) < 0) {
      status = AVR2S_UNEXPECTED_ERROR;
      goto out;
    }
  }

  position = 0;
  if (!(flags & AVR2S_FLAG_SKIP_RESPONSE)) {
    while (TRUE) {
      uint8_t payload[32];
      uint8_t chunk, readPayloadLength, packetFlags;

      if (0 == smbusBlockRead((int)hDevice, SMBUS_CMD_BOARDMAN2_RESP, &readPayloadLength, payload)) {
        if (0 == readPayloadLength) {
          continue;
        }

        packetFlags = payload[0];
        readPayloadLength--;

        if (packetFlags & FLAG_FIRST_PACKET) {
          position = 0;
        }

        chunk = readPayloadLength;
        if (position + chunk > responseLength) {
          chunk = responseLength - position;
        }
        memcpy(pResponse + position, &payload[1], chunk);

        position += readPayloadLength;

        if (packetFlags & FLAG_LAST_PACKET) {
          break;
        }
      } else {
        if (ENXIO != errno) {
          error = errno;

          goto out;
        }
      }

      clkError = clock_gettime(CLOCK_REALTIME, &now);
      if (clkError) {
        status = AVR2S_UNEXPECTED_ERROR;
        goto out;
      }

      /* If current real time >= expire time, then time out. */
      if (now.tv_sec >= expire.tv_sec) {
        if (now.tv_sec == expire.tv_sec) {
          if (now.tv_nsec >= expire.tv_nsec) {
            status = AVR2S_TIMEOUT;
            goto out;
          }
        } else {
          status = AVR2S_TIMEOUT;
          goto out;
        }
      }
    }
  }

out:
  if (error) {
    status = mapErrno(error);
  } else {
    *pActualResponseLength = position;
  }

  return status;
}
