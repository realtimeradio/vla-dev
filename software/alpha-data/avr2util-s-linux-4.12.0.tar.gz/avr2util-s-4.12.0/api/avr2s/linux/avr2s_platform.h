#if !defined(_ADATA_AVR2S_API_PLATFORM_H)
#define _ADATA_AVR2S_API_PLATFORM_H

/*
** File: avr2s_platform.h  
** Project: AVR2 SMBUS API module library
** Purpose: Interface to Linux-specific functions for AVR2 SMBUS API library
**
** (C) Copyright Alpha Data 2017
*/

#include <avr2s/platform.h>

extern AVR2S_STATUS
avr2sOpenSmbusA(
  const char* pDeviceName,
  _AVR2S_UINT8 chipAddress, /* 7-bit chip address */
  AVR2S_HANDLE* phDevice);

extern AVR2S_STATUS
avr2sOpenSmbusW(
  const wchar_t* pPortName,
  _AVR2S_UINT8 chipAddress, /* 7-bit chip address */
  AVR2S_HANDLE* phDevice);

extern AVR2S_STATUS
avr2sClose(
  AVR2S_HANDLE hDevice);

#endif
