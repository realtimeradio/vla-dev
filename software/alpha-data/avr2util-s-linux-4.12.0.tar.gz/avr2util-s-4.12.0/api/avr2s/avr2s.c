/*
** File: avr2s.c  
** Project: AVR2 API library
** Purpose: OS-independent code for AVR2 SMBUS API library
**
** (C) Copyright Alpha Data 2017
*/

#include <avr2s.h>
#include <portability.h>
#include <avr2s_platform.h>

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_Close(
  AVR2S_HANDLE hDevice)
{
  return avr2sClose(hDevice);
}

AVR2S_EXPORT const char*
AVR2S_CALLING_CONVENTION
AVR2S_GetStatusStringA(
  AVR2S_STATUS code,
  _AVR2S_BOOL bShort)
{
  if (bShort) {
    switch (code) {
    case AVR2S_SUCCESS:
      return "AVR2S_SUCCESS";

    case AVR2S_INTERNAL_ERROR:
      return "AVR2S_INTERNAL_ERROR";

    case AVR2S_UNEXPECTED_ERROR:
      return "AVR2S_UNEXPECTED_ERROR";

    case AVR2S_BAD_DRIVER:
      return "AVR2S_BAD_DRIVER";

    case AVR2S_NO_MEMORY:
      return "AVR2S_NO_MEMORY";

    case AVR2S_ACCESS_DENIED:
      return "AVR2S_ACCESS_DENIED";

    case AVR2S_DEVICE_NOT_FOUND:
      return "AVR2S_DEVICE_NOT_FOUND";

    case AVR2S_HARDWARE_ERROR:
      return "AVR2S_HARDWARE_ERROR";

    case AVR2S_INVALID_BUFFER:
      return "AVR2S_INVALID_BUFFER";

    case AVR2S_INVALID_FLAG:
      return "AVR2S_INVALID_FLAG";

    case AVR2S_INVALID_HANDLE:
      return "AVR2S_INVALID_HANDLE";

    case AVR2S_INVALID_INDEX:
      return "AVR2S_INVALID_INDEX";

    case AVR2S_INVALID_REGION:
      return "AVR2S_INVALID_REGION";

    case AVR2S_NULL_POINTER:
      return "AVR2S_NULL_POINTER";

    case AVR2S_CANCELLED:
      return "AVR2S_CANCELLED";

    case AVR2S_RESOURCE_LIMIT:
      return "AVR2S_RESOURCE_LIMIT";

    case AVR2S_REGION_TOO_LARGE:
      return "AVR2S_REGION_TOO_LARGE";

    case AVR2S_WRONG_MODE:
      return "AVR2S_WRONG_MODE";

    case AVR2S_NOT_SUPPORTED:
      return "AVR2S_NOT_SUPPORTED";

    case AVR2S_INVALID_PARAMETER:
      return "AVR2S_INVALID_PARAMETER";

    case AVR2S_TIMEOUT:
      return "AVR2S_TIMEOUT";

    case AVR2S_SHORT_COMMAND:
      return "AVR2S_SHORT_COMMAND";

    default:
      return "AVR2S_?";
    }
  } else {
    switch (code) {
    case AVR2S_SUCCESS:
      return "No error";

    case AVR2S_INTERNAL_ERROR:
      return "An error in the API logic was detected";

    case AVR2S_UNEXPECTED_ERROR:
      return "An unexpected error caused the operation to fail";

    case AVR2S_BAD_DRIVER:
      return "The driver may not be correctly installed";

    case AVR2S_NO_MEMORY:
      return "Couldn't allocate memory required to complete operation";

    case AVR2S_ACCESS_DENIED:
      return "The calling process does not have permission to perform the operation";

    case AVR2S_DEVICE_NOT_FOUND:
      return "Failed to open the device with the specified index";

    case AVR2S_HARDWARE_ERROR:
      return "An error in the hardware was detected";

    case AVR2S_INVALID_BUFFER:
      return "The supplied buffer was invalid and could not be read/written";

    case AVR2S_INVALID_FLAG:
      return "A flag was invalid or not recognized";

    case AVR2S_INVALID_HANDLE:
      return "The device handle was invalid";

    case AVR2S_INVALID_INDEX:
      return "The index parameter was invalid";

    case AVR2S_INVALID_REGION:
      return "The offset and/or length parameters were invalid";

    case AVR2S_NULL_POINTER:
      return "A NULL pointer was passed where non-NULL was required";

    case AVR2S_CANCELLED:
      return "The operation was cancelled";

    case AVR2S_RESOURCE_LIMIT:
      return "A resource limit was reached";

    case AVR2S_REGION_TOO_LARGE:
      return "The specified region was too large for a single operation";

    case AVR2S_WRONG_MODE:
      return "The operation was attempted when the device was not in the proper mode";

    case AVR2S_NOT_SUPPORTED:
      return "The operation is not supported for this device";

    case AVR2S_INVALID_PARAMETER:
      return "A parameter had an illegal value";

    case AVR2S_TIMEOUT:
      return "The operation did not complete within the timeout period";

    case AVR2S_SHORT_COMMAND:
      return "The length of the command was less than 2 bytes";

    default:
      return "Unrecognized AVR2S_STATUS code";
    }
  }
}

AVR2S_EXPORT AVR2S_STATUS
AVR2S_CALLING_CONVENTION
AVR2S_OpenDeviceA(
  const char* pDeviceName,
  _AVR2S_UINT8 chipAddress,
  AVR2S_HANDLE* phDevice)
{
  return avr2sOpenSmbusA(pDeviceName, chipAddress, phDevice);
}
