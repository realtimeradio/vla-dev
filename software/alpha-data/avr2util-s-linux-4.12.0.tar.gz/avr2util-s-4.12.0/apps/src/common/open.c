/*
** open.c - Function to open a device according to index or serial number.
**
** (C) Copyright 2011-2012 Alpha Data
*/

#include <stdio.h>

#if defined(_WIN32)

/* Windows */
# include <windows.h>
# include <tchar.h>

#else

/* Linux or VxWorks */
# define _T(c) c
# define _tprintf printf

#endif

#include <admxrc3.h>

#if !defined(CHECK_DEVICE_STATUS_ON_OPEN)
# if defined(ADMXRC3_H_VERSION)
#   if (ADMXRC3_H_VERSION >= ADMXRC3_H_MAKE_VERSION(1, 6, 0))
#     define CHECK_DEVICE_STATUS_ON_OPEN (1)
#   else
#     define CHECK_DEVICE_STATUS_ON_OPEN (0)
#   endif
# else
#   define CHECK_DEVICE_STATUS_ON_OPEN (0)
# endif
#endif

#if defined(__linux) && CHECK_DEVICE_STATUS_ON_OPEN
# include <dlfcn.h>
#endif

#include "sdk_common.h"

#define MAX_NUM_DEVICES (256)

static ADMXRC3_STATUS
_sampleOpenCard(
  unsigned int index,
  bool_t bByIndex,
  unsigned int serial,
  bool_t bBySerial,
  bool_t bReadOnly,
  bool_t bClearErrors,
  ADMXRC3_HANDLE* phCard)
{
  ADMXRC3_STATUS status;
  ADMXRC3_HANDLE hCard = ADMXRC3_HANDLE_INVALID_VALUE;
  ADMXRC3_CARD_INFO cardInfo;
  unsigned int i;
#if CHECK_DEVICE_STATUS_ON_OPEN
# if defined(_WIN32)
  HMODULE hAdmxrc3Dll = NULL;
# elif defined(__linux)
  void* pAdmxrc3So = NULL;
# else
  /* VxWorks or other OS - no handle needed */
# endif
  typedef ADMXRC3_STATUS ADMXRC3_GETDEVICESTATUS(ADMXRC3_HANDLE hDevice, uint32_t flags, ADMXRC3_DEVICE_STATUS* pDeviceStatus, bool_t* pbAnyError);
  typedef ADMXRC3_STATUS ADMXRC3_CLEARDEVICEERRORS(ADMXRC3_HANDLE hDevice);
  ADMXRC3_GETDEVICESTATUS* pAdmxrc3GetDeviceStatus = NULL;
  ADMXRC3_CLEARDEVICEERRORS* pAdmxrc3ClearDeviceErrors = NULL;
  bool_t bFunctionalityAvailable = FALSE;
  ADMXRC3_DEVICE_STATUS devStatus;
  bool_t bAnyError;
#endif

  if (bByIndex && bBySerial) {
    /* Attempt to open device with specified index and serial number */
    if (bReadOnly) {
      status = ADMXRC3_OpenEx(index, TRUE, 0, &hCard);
    } else {
      status = ADMXRC3_Open(index, &hCard);
    }
    if (status != ADMXRC3_SUCCESS) {
      return status;
    }
    status = ADMXRC3_GetCardInfo(hCard, &cardInfo);
    if (status == ADMXRC3_SUCCESS && cardInfo.SerialNumber == serial) {
      goto found;
    }
    ADMXRC3_Close(hCard);
    return ADMXRC3_DEVICE_NOT_FOUND;
  } else if (bBySerial) {
    /* Attempt to open device with specified serial number */
    /* Enumerate devices */
    for (i = 0; i < MAX_NUM_DEVICES; i++) {
      /* Open in read-only mode while enumerating as this should never fail */
      status = ADMXRC3_OpenEx(i, TRUE, 0, &hCard);
      if (status != ADMXRC3_SUCCESS) {
        if (status == ADMXRC3_DEVICE_NOT_FOUND) {
          break;
        } else {
          continue;
        }
      }
      status = ADMXRC3_GetCardInfo(hCard, &cardInfo);
      if (status == ADMXRC3_SUCCESS) {
        if (cardInfo.SerialNumber == serial) {
          if (bReadOnly) {
            /* Requested opening in read-only mode, so can return the handle used for enumeration */
          } else {
            /* Requested opening in read-write mode, so need to close and re-open in read-write mode */
            ADMXRC3_Close(hCard);
            status = ADMXRC3_Open(i, &hCard);
            if (status != ADMXRC3_SUCCESS) {
              return status;
            }
          }
          goto found;
        }
      }
      ADMXRC3_Close(hCard);
    }
    /* Did not find the card with the specified serial number */
    return ADMXRC3_DEVICE_NOT_FOUND;
  } else {
    /* Attempt to open device with specified index */
    status = ADMXRC3_OpenEx(index, bReadOnly, 0, &hCard);
    if (ADMXRC3_SUCCESS != status) {
      return status;
    }
    status = ADMXRC3_GetCardInfo(hCard, &cardInfo);
    if (ADMXRC3_SUCCESS != status) {
      ADMXRC3_Close(hCard);
      return status;
    }
  }

found:
#if CHECK_DEVICE_STATUS_ON_OPEN
  /*
  ** We dynamically get the entry points for ADMXRC3_GetDeviceStatus and
  ** ADMXRC3_ClearDeviceErrors so that if the ADMXRC3 runtime installed on
  ** the system happens to predate the addition of these functions to the
  ** ADMXRC3 API, we can gracefully disable the corresponding functionality
  ** in this application.
  */
# if defined(_WIN32)
#   if _DEBUG
  hAdmxrc3Dll = GetModuleHandle(_T("admxrc3d"));
#   else
  hAdmxrc3Dll = GetModuleHandle(_T("admxrc3"));
#   endif
  if (NULL != hAdmxrc3Dll) {
    pAdmxrc3GetDeviceStatus = (ADMXRC3_GETDEVICESTATUS*)GetProcAddress(hAdmxrc3Dll, "ADMXRC3_GetDeviceStatus");
    pAdmxrc3ClearDeviceErrors = (ADMXRC3_CLEARDEVICEERRORS*)GetProcAddress(hAdmxrc3Dll, "ADMXRC3_ClearDeviceErrors");
    if (NULL != pAdmxrc3GetDeviceStatus && NULL != pAdmxrc3ClearDeviceErrors) {
      bFunctionalityAvailable = TRUE;
    }
  }
# elif defined(__linux)
  pAdmxrc3So = dlopen("libadmxrc3.so", RTLD_LAZY | RTLD_NOLOAD);
  if (NULL != pAdmxrc3So) {
    pAdmxrc3GetDeviceStatus = (ADMXRC3_GETDEVICESTATUS*)dlsym(pAdmxrc3So, "ADMXRC3_GetDeviceStatus");
    pAdmxrc3ClearDeviceErrors = (ADMXRC3_CLEARDEVICEERRORS*)dlsym(pAdmxrc3So, "ADMXRC3_ClearDeviceErrors");
    if (NULL != pAdmxrc3GetDeviceStatus && NULL != pAdmxrc3ClearDeviceErrors) {
      bFunctionalityAvailable = TRUE;
    } else {
      dlclose(pAdmxrc3So);
      pAdmxrc3So = NULL;
    }
  }
# else
  /* VxWorks or other OS - assume no dynamic loading and that required functions exist. */
  pAdmxrc3GetDeviceStatus = &ADMXRC3_GetDeviceStatus;
  pAdmxrc3ClearDeviceErrors = &ADMXRC3_ClearDeviceErrors;
  bFunctionalityAvailable = TRUE;
# endif

  if (bFunctionalityAvailable) {
    /* Check device status and attempt to clear errors (if any) */
    status = pAdmxrc3GetDeviceStatus(hCard, 0, &devStatus, &bAnyError);
    if (ADMXRC3_SUCCESS == status) {
      if (bAnyError) {
        _tprintf(_T("+++ Device is in error state:\n"));
        _tprintf(_T("+++ Window errors = 0x%08lx, DMA errors = 0x%08lx, Direct Master errors = 0x%08lx\n"),
          (unsigned long)devStatus.Window, (unsigned long)devStatus.DMA, (unsigned long)devStatus.DirectMaster);
        _tprintf(_T("+++ Model-specific errors = { low: 0x%08lx, high: 0x%08lx }\n"),
          (unsigned long)devStatus.ModelLow, (unsigned long)devStatus.ModelHigh);
        _tprintf(_T("+++ Decoded flags are:\n"));
        for (i = 0; i < cardInfo.NumWindow; i++) {
          if (devStatus.Window & ADMXRC3_DS_LOCAL_TIMEOUT(i)) {
            _tprintf(_T("+++   Window %u timeout detected\n"), i);
          }
        }
        for (i = 0; i < cardInfo.NumDmaChannel; i++) {
          if (devStatus.DMA & ADMXRC3_DMA_BUS_TIMEOUT(i)) {
            _tprintf(_T("+++   DMA engine %u I/O bus timeout detected\n"), i);
          }
        }
        if (devStatus.DirectMaster & ADMXRC3_DM_BUS_TIMEOUT) {
          _tprintf(_T("+++   Direct Master bus timeout detected\n"));
        }
        if (devStatus.DirectMaster & ADMXRC3_DM_BAD_TRANSACTION) {
          _tprintf(_T("+++   Direct Master bad transaction detected\n"));
        }

        if (!bReadOnly && bClearErrors) {
          _tprintf(_T("+++ Attempting to clear errors...\n"));
          status = pAdmxrc3ClearDeviceErrors(hCard);
          if (ADMXRC3_SUCCESS != status) {
            _tprintf(_T("+++ Failed to clear errors, status=0x%x(%s)\n"), status, ADMXRC3_GetStatusString(status, TRUE));
          }
        }
      }
    } else {
      _tprintf(_T("+++ Failed to check device, status=0x%x(%s)\n"), status, ADMXRC3_GetStatusString(status, TRUE));
    }
  }

# if defined(_WIN32)
  /* Windows - nothing to do. */
# elif defined(__linux)
  if (NULL != pAdmxrc3So) {
    dlclose(pAdmxrc3So);
  }
# endif
  /* VxWorks or other OS - nothing to do. */
#endif

  *phCard = hCard;

  return ADMXRC3_SUCCESS;
}

ADMXRC3_STATUS
sampleOpenCard(
  unsigned int index,
  bool_t bByIndex,
  unsigned int serial,
  bool_t bBySerial,
  bool_t bReadOnly,
  ADMXRC3_HANDLE* phCard)
{
  return _sampleOpenCard(index, bByIndex, serial, bBySerial, bReadOnly, TRUE, phCard);
}

ADMXRC3_STATUS
sampleOpenCardNoClearError(
  unsigned int index,
  bool_t bByIndex,
  unsigned int serial,
  bool_t bBySerial,
  bool_t bReadOnly,
  ADMXRC3_HANDLE* phCard)
{
  return _sampleOpenCard(index, bByIndex, serial, bBySerial, bReadOnly, FALSE, phCard);
}
