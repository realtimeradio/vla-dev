#ifndef _ADATA_COMMON_H
#define _ADATA_COMMON_H

#include <admxrc3.h>

#if defined(_WIN32)

/* Windows */
# if defined(_MSC_VER)
/* MSVC */
#   include "sdk_inttypes.h"
#   include "sdk_stdint.h"
# else
/* Non-MSVC, assume C99-compliant */
#   include <stdint.h>
#   include <inttypes.h>
# endif
typedef BOOL bool_t;

# include <tchar.h>

#else

/* Linux or VxWorks */

# if !(defined(__VXWORKS__) || defined(__vxworks))
/* Assume C99-compliant compiler */
#   include <stdint.h>
# endif

# if defined(__VXWORKS__) || defined(__vxworks)
typedef size_t uintptr_t; /* Works for ILP32, LP64, LLP64 & ILP64 type compilers, which covers almost all of them */
# endif

typedef int bool_t;
typedef char TCHAR;

#ifndef FALSE
# define FALSE (0)
#endif
#ifndef TRUE
# define TRUE (1)
#endif

#endif

typedef enum _OptionType {
	OptionFloat   = 0,
	OptionDouble  = 1,
	OptionInt     = 2,
	OptionUInt    = 3,
	OptionHex     = 4,
	OptionInt64   = 5,
	OptionUInt64  = 6,
	OptionHex64   = 7,
	OptionString  = 8,
	OptionBoolean = 9,
	OptionPath    = 10
} OptionType;

typedef union _Value {
	float floatVal;
	double doubleVal;
	int32_t intVal;
  uint32_t uintVal;
	uint32_t hexVal;
	int64_t int64Val;
	uint64_t uint64Val;
	uint64_t hex64Val;
	TCHAR* pStringVal;
	bool_t booleanVal;
	TCHAR* pPathVal;
} Value;

typedef struct _Option {
	/* Must be initialised before call */
	const TCHAR*  key;
	OptionType    type;
	const TCHAR*  meaning;
	Value         def;
	/* Filled in on return */
	bool_t        specified;
	Value         value;
} Option;

typedef struct _Arguments {
	/* Initialised before call */
	int           nOption;
	OptionType*   paramType;
	TCHAR**       paramInfo;
	TCHAR**       paramMeaning;
	int           nParamType;
	int           minNParam;
  bool_t        bNoStdOptions; /* TRUE => Suppress -sdk and -bitdir options */

	/* Partially initialised before call */
	Option*       option;

	/* Filled in on return */
	int           nParam;
	Value*        param;

	TCHAR*        appName;
	TCHAR*        sdkPath;
	TCHAR*        bitPath;

	TCHAR*        bitFile;
} Arguments;

static const Arguments g_initArguments = {
  0,     /* nOption */
  NULL,  /* paramType */
  NULL,  /* paramInfo */
  NULL,  /* paramMeaning */
  0,     /* nParamType */
  0,     /* minNParam */
  FALSE, /* bNoStdOptions */
  NULL,  /* option */
  0,     /* nParam */
  NULL,  /* param */
  NULL,  /* appName */
  NULL,  /* sdkPath */
  NULL,  /* bitPath */
  NULL   /* bitFile */
};

extern int
sampleParseCommandLine(
  TCHAR* pAppName,
  int argc,
  TCHAR* argv[],
  Arguments* pArgs);

extern void
sampleCleanupCommandLine(
  Arguments* pArgs);

/* Caller is responsible for freeing returned string */
extern TCHAR*
sampleGetSdkBitDir(
  void);
  
/* Caller is responsible for freeing returned string */
extern TCHAR*
sampleConstructBitFilename(
  ADMXRC3_HANDLE hCard,
  unsigned int targetIndex,
  const TCHAR* pDir,
  const TCHAR* pDesign,
  const TCHAR* pSdkBitDir,
  bool_t* pbShouldConfigure);
  
extern const TCHAR*
sampleGetFpgaFilename(
  ADMXRC3_HANDLE hCard,
  unsigned int targetIndex,
  const TCHAR* pDir,
  const TCHAR* pDesign,
  Arguments* pArgs,
  bool_t* pbShouldConfigure);

extern void
sampleDumpOptions(
  Arguments* pArgs);

extern void
sampleDumpCommandLine(
  Arguments* pArgs);

extern ADMXRC3_STATUS
sampleOpenCard(
  unsigned int index,
  bool_t bByIndex,
  unsigned int serial,
  bool_t bBySerial,
  bool_t bReadOnly,
  ADMXRC3_HANDLE* phCard);

extern ADMXRC3_STATUS
sampleOpenCardNoClearError(
  unsigned int index,
  bool_t bByIndex,
  unsigned int serial,
  bool_t bBySerial,
  bool_t bReadOnly,
  ADMXRC3_HANDLE* phCard);

#endif
