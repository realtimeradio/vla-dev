/*
** args.c - Infrastructure used by the Win32 sample applications for parsing
**          command-line arguments and generating filenames for .BIT files.
**
** (C) Copyright 2009-2011 Alpha Data
*/

#if defined(_WIN32)

/* Windows */
# include <windows.h>
# include <tchar.h>

# if !defined(_MSC_VER)
/* Non-MSVC - won't have secure strings library */
#   define _stscanf_s _stscanf
#   define _stprintf_s(buf, max, format, ...) _sntprintf(buf, max, format, __VA_ARGS__)
#   define _vstprintf_s(buf, max, format, ...) _vsntprintf(buf, max, format, __VA_ARGS__)
#   define memcpy_s(pDst, max, pSrc, n) memcpy(pDst, pSrc, n)
#   define _tcscpy_s(pDstStr, max, pSrcStr) _tcscpy(pDstStr, pSrcStr)
#   define _tcscat_s(pDstStr, max, pStr) _tcscat(pDstStr, pStr)
# endif

#else

/* Linux or VxWorks */
# define _T(c) c
# define _stscanf_s sscanf
# if (defined(__VXWORKS__) || defined(__vxworks)) && (_WRS_VXWORKS_MAJOR <= 5)
    /* VxWorks 5.x doesn't have snprintf() or vsnprintf() */
#   define _stprintf_s(buf, max, format, ...) sprintf(buf, format, __VA_ARGS__)
#   define _vstprintf_s(buf, max, format, ...) vsprintf(buf, format, __VA_ARGS__)
# else
#   define _stprintf_s(buf, max, format, ...) snprintf(buf, max, format, __VA_ARGS__)
#   define _vstprintf_s(buf, max, format, ...) vsnprintf(buf, max, format, __VA_ARGS__)
# endif
# define memcpy_s(pDst, max, pSrc, n) memcpy(pDst, pSrc, n)
# define _tcscat_s(pDstStr, max, pStr) strcat(pDstStr, pStr)
# define _tcscmp(pStr1, pStr2) strcmp(pStr1, pStr2)
# define _tcscpy_s(pDstStr, max, pSrcStr) strcpy(pDstStr, pSrcStr)
# define _tcslen(pStr) strlen(pStr)
# define _totlower(c) tolower(c)
# define _tprintf printf

#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

#include "sdk_common.h"

#define NUL _T('\0')

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

/*
** The environment variable that the sample applications
** attempt to pick up and use to find the base of the ADM-XRC
** SDK and hence the FPGA bitstream files.
*/
#define ENVIRONMENT_VARIABLE (_T("ADMXRC3_SDK"))

#if defined(_WIN32)
/* Windows */
static const TCHAR nativeSlash = _T('\\');
static const TCHAR nativeSlashStr[] = _T("\\");
static const TCHAR nonNativeSlash = _T('/');
static const TCHAR optionChar = _T('/');
#else
/* Linux or VxWorks */
static const TCHAR nativeSlash = _T('/');
static const TCHAR nativeSlashStr[] = _T("/");
static const TCHAR nonNativeSlash = _T('/');
static const TCHAR optionChar = _T('-');
#endif

static const TCHAR* typeString[] = {
  _T("float"),
  _T("double"),
  _T("int"),
  _T("uint"),
  _T("hex"),
  _T("int64"),
  _T("uint64"),
  _T("hex64"),
  _T("string"),
  _T("boolean"),
  _T("path")
};

#define SET_STRING(STRING, VALUE) { \
  if ((STRING) != NULL) { \
		free(STRING); \
    (STRING) = NULL; \
  } \
  if ((VALUE) != NULL) { \
    size_t n = _tcslen(VALUE) + 1; \
    (STRING) = (TCHAR*)malloc(sizeof(TCHAR) * n); \
    memcpy_s((STRING), sizeof(TCHAR) * n, VALUE, sizeof(TCHAR) * n); \
  } \
}

#if !defined(_WIN32)
static int
_tcsicmp(
  const char* pS1,
  const char* pS2)
{
  char c1, c2;

  while (1) {
    c1 = *pS1;
    c2 = *pS2;
    if (c1 == '\0' || tolower(c1) != tolower(c2)) {
      break;
    }
    pS1++;
    pS2++;
  }
  return tolower(c1) - tolower(c2);
}
#endif

static void
fatal(
  TCHAR* pFmt, ...)
{
  TCHAR buffer[1024];
  va_list ap;
  /* size_t n; */

  va_start(ap, pFmt);
  /* n = */ _vstprintf_s(buffer, ARRAY_LENGTH(buffer), pFmt, ap);
  va_end(ap);

  _tprintf(_T("%s"), buffer);
}

static void
convertSlashes(
  TCHAR* pStr)
{
  if (nativeSlash == nonNativeSlash) {
    return;
  }
  while (*pStr != NUL) {
    if (*pStr == nonNativeSlash) {
      *pStr = nativeSlash;
    }
    pStr++;
  }
}

static void
stripLeadingSpace(
  TCHAR* pStr)
{
  TCHAR* p;
  TCHAR* q;
  
  p = pStr;
  q = pStr;
  while (*p != NUL && isspace(*p)) {
    p++;
  }
  while (*p != NUL) {
    *q++ = *p++;
  }
  *q = NUL;
}

static void
stripTrailingSpace(
  TCHAR* pStr)
{
  size_t i, n;
  
  n = _tcslen(pStr);
  if (n == 0) {
    return;
  }

  i = n - 1;
  do {
    if (!isspace(pStr[i])) {
      i++;
      break;
    }
    i--;
  } while (i > 0);
  
  pStr[i] = NUL;
}

static void
stripTrailingSlash(
  TCHAR* pStr)
{
  size_t n;
  
  n = _tcslen(pStr);
  if (n) {
    if (pStr[n - 1] == nativeSlash) {
      if (n != 1) {
	pStr[n - 1] = NUL;
      }
    }
  }
}

#if !defined(_WIN32) || !defined(_MSC_VER)
static void
_tcslwr_s(
  TCHAR* pStr,
  size_t max)
{
  TCHAR c;

  while (max) {
    c = *pStr;
    if (c == NUL) {
      break;
    }
    *pStr++ = tolower(c);
    max--;
  }
}
#endif

#if !defined(_MSC_VER)
static void
_tgetenv_s(
  size_t* pRequiredLength,
  TCHAR* pBuffer,
  size_t max,
  const TCHAR* pVariableName)
{
  TCHAR* pTmp;
  size_t length;

  pTmp = getenv(pVariableName);
  if (NULL == pTmp) {
    length = 0;
  } else {
    length = strlen(pTmp);
  }
  if (NULL != pRequiredLength) {
    /* Not found */
    *pRequiredLength = length + 1;
  }
  if (NULL != pBuffer) {
    if (max) {
      max--; /* subtract 1 for NUL terminator */
      if (length > max) {
        length = max;
      }
      if (length) {
        memcpy(pBuffer, pTmp, length * sizeof(TCHAR));
      }
      pBuffer[length] = '\0';
    }
  }
}
#endif

static void
tidyPath(
  TCHAR* pStr)
{
  convertSlashes(pStr);
  stripLeadingSpace(pStr);
  stripTrailingSpace(pStr);
  stripTrailingSlash(pStr);
}

/*
**  0 => Value was parsed OK
** -1 => pString contained a string that was not a valid ASCII representation of the
**       datatype implied by 'type'
*/
static int
setValue(
  Value* pValue,
  OptionType type,
  TCHAR* pString)
{
  TCHAR buffer[5];
  int res;

  if (type == OptionFloat) {
    double tmp;
    
    res = _stscanf_s(pString, _T("%lf"), &tmp);
    if (0 == res) {
      /* pString was not a valid real number */
      return -1;
    }
    assert(res == 1);
    pValue->floatVal = (float)tmp;
  } else if (type == OptionDouble) {
    res = _stscanf_s(pString, _T("%lf"), &pValue->doubleVal);
    if (0 == res) {
      /* pString was not a valid real number */
      return -1;
    }
    assert(res == 1);
  } else if (type == OptionInt) {
    long tmp;
    
    res = _stscanf_s(pString, _T("%ld"), &tmp);
    if (0 == res) {
      /* pString was not a valid int */
      return -1;
    }
    assert(res == 1);
    pValue->intVal = (int32_t)tmp;
  } else if (type == OptionUInt) {
    unsigned long tmp;
    
    if (_tcslen(pString) >= 2 && pString[0] == _T('0') && _totlower(pString[1]) == _T('x')) {
      res = _stscanf_s(pString + 2, _T("%lX"), &tmp);
    } else {
      res = _stscanf_s(pString, _T("%lu"), &tmp);
    }
    if (0 == res) {
      /* pString was not a valid unsigned int (hex or base 10) */
      return -1;
    }
    assert(res == 1);
    pValue->uintVal = (uint32_t)tmp;
  } else if (type == OptionHex) {
    unsigned long tmp;
    
    res = _stscanf_s(pString, _T("%lX"), &tmp);
    if (0 == res) {
      /* pString was not a valid unsigned int (hex) */
      return -1;
    }
    assert(res == 1);
    pValue->hexVal = (uint32_t)tmp;
  } else if (type == OptionInt64) {
    long long tmp;

    res = _stscanf_s(pString, _T("%lld"), &tmp);
    if (0 == res) {
      /* pString was not a valid int64 */
      return -1;
    }
    assert(res == 1);
    pValue->int64Val = (int64_t)tmp;
  } else if (type == OptionUInt64) {
    unsigned long long tmp;

    if (_tcslen(pString) >= 2 && pString[0] == _T('0') && _totlower(pString[1]) == _T('x')) {      
      res = _stscanf_s(pString + 2, _T("%llx"), &tmp);
      if (0 == res) {
        /* pString was not a valid uint64 (hex) */
        return -1;
      }
      assert(res == 1);
      pValue->uint64Val = (uint64_t)tmp;
    } else {
      res = _stscanf_s(pString, _T("%llu"), &tmp);
      if (0 == res) {
        /* pString was not a valid uint64 (base 10) */
        return -1;
      }
      assert(res == 1);
      pValue->uint64Val = (uint64_t)tmp;
    }
  } else if (type == OptionHex64) {
    unsigned long long tmp;

    res = _stscanf_s(pString, _T("%llx"), &tmp);
    if (0 == res) {
      /* pString was not a valid uint64 (hex) */
      return -1;
    }
    assert(res == 1);
    pValue->uint64Val = (uint64_t)tmp;    
  } else if (type == OptionString) {
    SET_STRING(pValue->pStringVal, pString);
  } else if (type == OptionBoolean) {
    _tcscpy_s(buffer, ARRAY_LENGTH(buffer), pString);
    _tcslwr_s(buffer, ARRAY_LENGTH(buffer));
    if (_tcsicmp(buffer, _T("true")) == 0) {
      pValue->booleanVal = TRUE;
    } else if (_tcsicmp(buffer, _T("false")) == 0) {
      pValue->booleanVal = FALSE;
    } else {
      /* pString was not a valid boolean */
      return -1;
    }
  } else if (type == OptionPath) {
    SET_STRING(pValue->pPathVal, pString);
    tidyPath(pValue->pPathVal);
  } else {
    assert(FALSE);
  }
  
  return 0;
}

static TCHAR*
valueToString(
  Value* pValue,
  OptionType type)
{
  static TCHAR buffer[128];
  
  switch(type) {
  case OptionFloat:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%f"), (double)pValue->floatVal);
    break;
  case OptionDouble:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%f"), pValue->doubleVal);
    break;
  case OptionInt:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%ld"), (long)pValue->intVal);
    break;
  case OptionUInt:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%lu"), (unsigned long)pValue->uintVal);
    break;
  case OptionHex:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("0x%lX"), (unsigned long)pValue->hexVal);
    break;
  case OptionInt64:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%lld"), (long long)pValue->intVal);
    break;
  case OptionUInt64:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%llu"), (unsigned long long)pValue->uintVal);
    break;
  case OptionHex64:
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("0x%llx"), (unsigned long long)pValue->hexVal);
    break;
  case OptionString:
    if (pValue->pStringVal != NULL) {
      _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%s"), pValue->pStringVal);
    } else {
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T(""));
    }
    break;
  case OptionBoolean:
    if (pValue->booleanVal) {
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T("TRUE"));
    } else {
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T("FALSE"));
    }
    break;
  case OptionPath:
    if (pValue->pPathVal != NULL) {
      _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%s"), pValue->pPathVal);
    } else {
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T(""));
    }
    break;
  }
  
  return buffer;
}

static TCHAR*
defaultToString(
  Option* pOption)
{
  return valueToString(&pOption->def, pOption->type);
}

static TCHAR*
optionToString(
  Option* pOption)
{
  static TCHAR* pValueStr;
  static TCHAR buffer[128];
  
  pValueStr = valueToString(&pOption->value, pOption->type);
  if (pOption->type == OptionBoolean) {
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%c%s %s\n"), pOption->value.booleanVal ? _T('+') : _T('-'), pOption->key, pValueStr);
  } else {
    _stprintf_s(buffer, ARRAY_LENGTH(buffer), _T("%c%s %s"), optionChar, pOption->key, pValueStr);
  }
  
  return buffer;
}

static void
setOptionDefault(
  Option* pOption)
{
  switch (pOption->type) {
  case OptionFloat:
    pOption->value.floatVal = pOption->def.floatVal;
    break;
  case OptionDouble:
    pOption->value.doubleVal = pOption->def.doubleVal;
    break;
  case OptionInt:
    pOption->value.intVal = pOption->def.intVal;
    break;
  case OptionUInt:
    pOption->value.uintVal = pOption->def.uintVal;
    break;
  case OptionHex:
    pOption->value.hexVal = pOption->def.hexVal;
    break;
  case OptionInt64:
    pOption->value.int64Val = pOption->def.int64Val;
    break;
  case OptionUInt64:
    pOption->value.uint64Val = pOption->def.uint64Val;
    break;
  case OptionHex64:
    pOption->value.hex64Val = pOption->def.hex64Val;
    break;
  case OptionString:
    pOption->value.pStringVal = NULL;
    SET_STRING(pOption->value.pStringVal, pOption->def.pStringVal);
    break;
  case OptionBoolean:
    pOption->value.booleanVal = pOption->def.booleanVal;
    break;
  case OptionPath:
    pOption->value.pPathVal = NULL;
    SET_STRING(pOption->value.pPathVal, pOption->def.pPathVal);
    break;
  }
  pOption->specified = FALSE;
}

/*
**  0 => Option value was parsed OK
** -1 => pString contained a string that was not a valid ASCII representation of the
**       datatype implied by 'pOption->type'
*/
static int
setOption(
  Option* pOption,
  TCHAR* pString)
{
  int res;

  res = setValue(&pOption->value, pOption->type, pString);
  if (res) {
    return res; /* Error */
  }
  pOption->specified = TRUE;
  return 0; /* OK */
}

static Option*
findOption(
  TCHAR* pKeyName,
  Option* pOptions,
  int n)
{
  int i;
  
  for (i = 0; i < n; i++) {
    if (_tcscmp(pOptions[i].key, pKeyName) == 0) {
      return &pOptions[i];
    }
  }
  
  return NULL;
}

static void
showUsage(
  TCHAR* appName,
  Arguments* pArgs)
{
  int i;
  
  _tprintf(_T("Usage: %s [option ...]"), appName);
  for (i = 0; i < pArgs->nParamType; i++) {
    TCHAR* a, * b;
    
    if (i < pArgs->minNParam) {
      a = _T("");
      b = _T("");
    } else {
      a = _T("[");
      b = _T("]");
    }
    _tprintf(_T(" %s%s%s"), a, pArgs->paramInfo[i], b);
  }
  if (pArgs->nParamType) {
    _tprintf(_T("\n"));
  }
  _tprintf(_T("\n"));
  for (i = 0; i < pArgs->nParamType; i++) {
    _tprintf(_T("%10s = %s\n"), pArgs->paramInfo[i], pArgs->paramMeaning[i]);
  }
  _tprintf(_T("\n"));
  _tprintf(_T("%12s  %7s  %12s  %s\n\n"), _T("Option"), _T("Type"), _T("Default"), _T("Meaning"));
#if defined(_WIN32)
  _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("/h /? /help"), _T(""), _T(""), _T("Show this help"));
  if (!pArgs->bNoStdOptions) {
    _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("/sdk"), _T("string"), _T(""), _T("Specify base directory of ADM-XRC SDK"));
    _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("/bitdir"), _T("string"), _T(""), _T("Specify bitstream directory"));
    _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("/bitfile"), _T("string"), _T(""), _T("Specify bitstream file (.bit)"));
  }
#else
  _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("-h -? -help"), _T(""), _T(""), _T("Show this help"));
  if (!pArgs->bNoStdOptions) {
    _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("-sdk"), _T("string"), _T(""), _T("Specify base directory of ADM-XRC SDK"));
    _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("-bitdir"), _T("string"), _T(""), _T("Specify bitstream directory"));
    _tprintf(_T("%12s  %7s  %12s  %s\n"), _T("-bitfile"), _T("string"), _T(""), _T("Specify bitstream file (.bit)"));
  }
#endif
  for (i = 0; i < pArgs->nOption; i++) {
    TCHAR buffer[17];
    
    if (pArgs->option[i].type == OptionBoolean) {
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T("-/+"));
    } else {
#if defined(_WIN32)
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T("/"));
#else
      _tcscpy_s(buffer, ARRAY_LENGTH(buffer), _T("-"));
#endif
    }
    _tcscat_s(buffer, ARRAY_LENGTH(buffer), pArgs->option[i].key);
    _tprintf(_T("%12s  %7s  %12s  %s\n"),
	     buffer,
	     typeString[pArgs->option[i].type],
	     defaultToString(&pArgs->option[i]),
	     pArgs->option[i].meaning);
  }
}

void sampleDumpCommandLine(
  Arguments* pArgs)
{
  TCHAR* buffer;
  int	 i, j;
  
  _tprintf(_T("Command line: %s"), pArgs->appName);
  for (i = 0; i < pArgs->nOption; i++) {
    if (pArgs->option[i].specified) {
      buffer = optionToString(&pArgs->option[i]);
      _tprintf(_T(" %s"), buffer);
    }
  }
  j = pArgs->nParam;
  if (j > pArgs->nParamType) {
    j = pArgs->nParamType;
  }
  for (i = 0; i < j; i++) {
    buffer = valueToString(&pArgs->param[i], pArgs->paramType[i]);
    _tprintf(_T(" %s"), buffer);
  }
  for (; i < pArgs->nParam; i++) {
    buffer = valueToString(&pArgs->param[i], OptionString);
    _tprintf(_T(" %s"), buffer);
  }
  _tprintf(_T("\n"));
}

void
sampleDumpOptions(
  Arguments* pArgs)
{
  int i;
  
  _tprintf(_T("Dump of all options:\n"));
  for (i = 0; i < pArgs->nOption; i++) {
    TCHAR* pBuffer;
    
    pBuffer = valueToString(&pArgs->option[i].value, pArgs->option[i].type);
    _tprintf(_T("%12s %8s %8s\n"), pArgs->option[i].key, typeString[pArgs->option[i].type], pBuffer);
  }
}

void
sampleCleanupCommandLine(
  Arguments* pArguments)
{
  int i;

  if (NULL != pArguments->option) {
    for (i = 0; i < pArguments->nOption; i++) {
      if (pArguments->option[i].type == OptionString) {
        free(pArguments->option[i].value.pStringVal);
        pArguments->option[i].value.pStringVal = NULL;
      } else if (pArguments->option[i].type == OptionPath) {
        free(pArguments->option[i].value.pPathVal);
        pArguments->option[i].value.pPathVal = NULL;
      }
    }
  }
  if (NULL != pArguments->param) {
    for (i = 0; i < pArguments->nParam; i++) {
      if (i < pArguments->nParamType) {
        if (pArguments->paramType[i] == OptionString) {
          free(pArguments->param[i].pStringVal);
          pArguments->param[i].pStringVal = NULL;
        } else if (pArguments->paramType[i] == OptionPath) {
          free(pArguments->param[i].pPathVal);
          pArguments->param[i].pPathVal = NULL;
        }
      } else {
        free(pArguments->param[i].pStringVal);
        pArguments->param[i].pStringVal = NULL;
      }
    }
    free(pArguments->param);
    pArguments->param = NULL;
  }
  if (NULL != pArguments->appName) {
    free(pArguments->appName);
    pArguments->appName = NULL;
  }
  if (NULL != pArguments->sdkPath) {
    free(pArguments->sdkPath);
    pArguments->sdkPath = NULL;
  }
  if (NULL != pArguments->bitPath) {
    free(pArguments->bitPath);
    pArguments->bitPath = NULL;
  }
  if (NULL != pArguments->bitFile) {
    free(pArguments->bitFile);
    pArguments->bitFile = NULL;
  }
}

int
sampleParseCommandLine(
  TCHAR* appName,
  int argc,
  TCHAR* argv[],
  Arguments* pArgs)
{
  TCHAR* pAdmxrcSdk;
  size_t dummy, admxrcSdkLen;
  int i, j;

  if (pArgs == NULL) {
    fatal(_T("sampleParseCommandLine(): argument 'pArgs' is NULL (must not be NULL)\n"));
    return -1;
  }

  pArgs->appName = NULL;
  pArgs->sdkPath = NULL;
  pArgs->bitPath = NULL;
  pArgs->bitFile = NULL;
  pArgs->param = NULL;
  pArgs->nParam = 0;

  if (appName == NULL) {
    fatal(_T("sampleParseCommandLine(): argument 'appName' is NULL (must not be NULL)\n"));
    return -1;
  }
  SET_STRING(pArgs->appName, appName);

  for (i = 0; i < pArgs->nOption; i++) {
    setOptionDefault(&pArgs->option[i]);
  }

  _tgetenv_s(&admxrcSdkLen, NULL, 0, ENVIRONMENT_VARIABLE);
  if (0 != admxrcSdkLen) {
    pAdmxrcSdk = (TCHAR*)malloc(admxrcSdkLen * sizeof(TCHAR));
    if (NULL != pAdmxrcSdk) {
      _tgetenv_s(&dummy, pAdmxrcSdk, admxrcSdkLen, ENVIRONMENT_VARIABLE);
      if (0 != admxrcSdkLen) {
        SET_STRING(pArgs->sdkPath, pAdmxrcSdk);
        tidyPath(pArgs->sdkPath);
      }
      free(pAdmxrcSdk);
    } else {
      fatal(_T("sampleParseCommandLine(): failed to allocate string storage for getting %s environment variable\n"), ENVIRONMENT_VARIABLE);
      return -1;
    }
  }

  /* Parse the options */
  for (i = 1; i < argc; i++) {
    TCHAR tag = argv[i][0];

#if defined(_WIN32)
    if (tag == _T('-') || tag == _T('/') || tag == _T('+')) {
#else
    if (tag == _T('-') || tag == _T('+')) {
#endif
      if (argv[i][1] == _T('\0')) {
        i++;
        break;
      } else if ((_tcscmp(argv[i] + 1, _T("h")) == 0) ||
        (_tcscmp(argv[i] + 1, _T("help")) == 0) ||
        (_tcscmp(argv[i] + 1, _T("?")) == 0)) {
          showUsage(appName, pArgs);
          return -1;
      } else if (!pArgs->bNoStdOptions && _tcscmp(argv[i] + 1, _T("sdk")) == 0) {
        i++;
        if (i == argc) {
          fatal(_T("%csdk option requires parameter: path to ADM-XRC SDK root\n"), optionChar);
          return -1;
        }
        SET_STRING(pArgs->sdkPath, argv[i]);
        tidyPath(pArgs->sdkPath);
      } else if (!pArgs->bNoStdOptions && _tcscmp(argv[i] + 1, _T("bitdir")) == 0) {
        i++;
        if (i == argc) {
          fatal(_T("%cbitdir option requires parameter: path to bitstream directory\n"), optionChar);
          return -1;
        }
        SET_STRING(pArgs->bitPath, argv[i]);
        tidyPath(pArgs->bitPath);
      } else if (!pArgs->bNoStdOptions && _tcscmp(argv[i] + 1, _T("bitfile")) == 0) {
        i++;
        if (i == argc) {
          fatal(_T("%cbitfile option requires parameter: path to bitstream file (.bit)\n"), optionChar);
          return -1;
        }
        SET_STRING(pArgs->bitFile, argv[i]);
        tidyPath(pArgs->bitFile);
      } else {
        int narg;
        Option* pOption;

        pOption = findOption(argv[i] + 1, pArgs->option, pArgs->nOption);
        if (pOption == NULL) {
          fatal(_T("Unknown option: %s\n"), argv[i]);
          return -1;
        } else {
          narg = (pOption->type == OptionBoolean) ? 0 : 1;
          if (i + narg + 1 > argc) {
            fatal(_T("%s option requires parameter: %s\n"), argv[i], pOption->meaning);
            return -1;
          }
          if (pOption->type == OptionBoolean) {
            if (tag == _T('-')) {
              pOption->value.booleanVal = FALSE;
            } else if (tag == _T('+')) {
              pOption->value.booleanVal = TRUE;
            } else {
              fatal(_T("Boolean option %s should be specified as -%s or +%s\n"),
                pOption->key, pOption->key, pOption->key);
              return -1;
            }
          } else {
            i++;
            if (setOption(pOption, argv[i])) {
              fatal(_T("Value of %s option %s is invalid: %s\n"),
                typeString[pOption->type], pOption->key, argv[i]);
              return -1;
            }
          }
        }
      }
    } else {
      break;
    }
  }

  pArgs->nParam = argc - i;
  if (pArgs->nParam <= 0) {
    pArgs->nParam = 0;
    pArgs->param = NULL;
  } else {
    pArgs->param = (Value*)malloc(sizeof(Value) * pArgs->nParam);
    for (j = 0; j < pArgs->nParam; j++) {
      pArgs->param[j].pStringVal = NULL;
    }
    j = 0;
    for (; i < argc; i++) {
      if (j < pArgs->nParamType) {
        if (pArgs->paramType[j] == OptionString) {
          pArgs->param[j].pStringVal = NULL;
        } else if (pArgs->paramType[j] == OptionPath) {
          pArgs->param[j].pPathVal = NULL;
        }

        if (setValue(&pArgs->param[j], pArgs->paramType[j], argv[i])) {
          fatal(_T("Value of %s parameter %d is invalid: %s\n"),
            typeString[pArgs->paramType[j]], j + 1, argv[i]);
          return -1;
        }
      } else {
        if (setValue(&pArgs->param[j], OptionString, argv[i])) {
          fatal(_T("Value of parameter %d is invalid: %s\n"), j + 1, argv[i]);
          return -1;
        }
      }
      j++;
    }
  }

  if (pArgs->minNParam > pArgs->nParam) {
    _tprintf(_T("Too few parameters supplied. Use %s %c? to get help.\n"), pArgs->appName, optionChar);
    return -1;
  }

  if (pArgs->bitPath == NULL && pArgs->sdkPath != NULL) {
    const TCHAR* pBitDir = _T("bit");
    TCHAR* pBitPath;
    size_t n = _tcslen(pArgs->sdkPath) + 1 + _tcslen(pBitDir) + 1;

    pBitPath = (TCHAR*)malloc(n * sizeof(TCHAR));
    if (NULL == pBitPath) {
      fatal(_T("*** parse_command_line(): failed to allocate 'pBitPath'\n"));
      return -1;
    }
    _tcscpy_s(pBitPath, n, pArgs->sdkPath);
    _tcscat_s(pBitPath, n, nativeSlashStr);
    _tcscat_s(pBitPath, n, pBitDir);
    SET_STRING(pArgs->bitPath, pBitPath);
    free(pBitPath);
  }

  return 0;
}
