#ifndef _ADATA_COMMONTIME_H
#define _ADATA_COMMONTIME_H

#include <sys/time.h>

typedef struct timeval admxrc3_time_t;

static const struct timeval timeZero = {
  0, 0
};

admxrc3_time_t
timeGet(void);

admxrc3_time_t
timeMake(
  long sec,
  long usec,
  int bRoundup);

int
timeAfter(
  admxrc3_time_t t1,
  admxrc3_time_t t2);

int
timeBefore(
  admxrc3_time_t t1,
  admxrc3_time_t t2);

int
timeEqual(
  admxrc3_time_t t1,
  admxrc3_time_t t2);

admxrc3_time_t
timeAdd(
  admxrc3_time_t t1,
  admxrc3_time_t t2);

admxrc3_time_t
timeSubtract(
  admxrc3_time_t t1,
  admxrc3_time_t t2);

double
timeToDouble(
  admxrc3_time_t t1);

float
timeToFloat(
  admxrc3_time_t t1);

admxrc3_time_t
doubleToTime(
  double t1);

admxrc3_time_t
floatToTime(
  float t1);

int
sleepMs(
  unsigned long ms);

#if defined(ADMXRC3_IMPORT_DELAY_US)

# include <unistd.h>

# define initDelayUs() /* Do nothing */

static inline void
delayUs(
  unsigned long us)
{
  usleep(us);
}

#endif /* defined(ADMXRC3_IMPORT_DELAY_US) */

#endif
