/*
** time.c - Utility functions for handling variables of type "timeval"
**
**          Used by the example applications.
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include "platform_time.h"

struct timeval
timeGet(
  void)
{
  struct timeval t;
  int err;

  err = gettimeofday(&t, NULL);
  if (err) {
    printf("*** get_time: gettimeofday failed\n");
    exit(-1);
  }

  return t;
}

struct timeval
timeMake(
  long seconds,
  long us,
  int bRoundUp /* ignored */)
{
  struct timeval t;

  t.tv_sec = seconds;
  t.tv_usec = us;

  return t;
}

double
timeToDouble(
  struct timeval t1)
{
  return (double)t1.tv_usec / 1000000.0 + (double)t1.tv_sec;
}

float
timeToFloat(
  struct timeval t1)
{
  return (float)t1.tv_usec / 1000000.0f + (float)t1.tv_sec;
}

struct timeval
doubleToTime(
  double t1)
{
  struct timeval t;

  t.tv_sec = (long)t1;
  t.tv_usec = (long)((t1 - (double)t.tv_sec) * 1000000.0);

  return t;
}

struct timeval
floatToTime(
  float t1)
{
  struct timeval t;

  t.tv_sec = (long)t1;
  t.tv_usec = (long)((t1 - (float)t.tv_sec) * 1000000.0f);

  return t;
}

int
timeAfter(
  struct timeval t1,
  struct timeval t2)
{
  if (t1.tv_sec > t2.tv_sec) {
    return 1;
  } else {
    if (t1.tv_sec == t2.tv_sec) {
      return (t1.tv_usec > t2.tv_usec);
    } else {
      return 0;
    }
  }
}

int
timeEqual(
  struct timeval t1,
  struct timeval t2)
{
  return (t1.tv_sec == t2.tv_sec && t1.tv_usec == t2.tv_usec);
}

int
timeBefore(
  struct timeval t1,
  struct timeval t2)
{
  if (t1.tv_sec < t2.tv_sec) {
    return 1;
  } else {
    if (t1.tv_sec == t2.tv_sec) {
      return (t1.tv_usec < t2.tv_usec);
    } else {
      return 0;
    }
  }
}

struct timeval
timeAdd(
  struct timeval t1,
  struct timeval t2)
{
  struct timeval t;

  t.tv_usec = t1.tv_usec + t2.tv_usec;
  t.tv_sec = t1.tv_sec + t2.tv_sec;
  if (t.tv_usec >= 1000000) {
    t.tv_usec -= 1000000;
    t.tv_sec++;
  }

  return t;
}

struct timeval
timeSubtract(
  struct timeval t1,
  struct timeval t2)
{
  struct timeval t;

  t.tv_usec = t1.tv_usec - t2.tv_usec;
  t.tv_sec = t1.tv_sec - t2.tv_sec;
  if (t.tv_usec < 0) {
    t.tv_usec += 1000000;
    t.tv_sec--;
  }

  return t;
}

int
sleepMs(
  unsigned long ms)
{
  struct timeval to;

  to.tv_sec = ms / 1000;
  to.tv_usec = (ms % 1000) * 1000;
  return select(0, NULL, NULL, NULL, &to) == 0;
}
