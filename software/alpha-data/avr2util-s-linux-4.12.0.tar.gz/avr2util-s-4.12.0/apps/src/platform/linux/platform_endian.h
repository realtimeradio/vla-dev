#ifndef _ADATA_COMMONENDIAN_H
#define _ADATA_COMMONENDIAN_H

#include <asm/byteorder.h>

#define cpu_to_be8(x) x
#define cpu_to_be16(x) __cpu_to_be16(x)
#define cpu_to_be32(x) __cpu_to_be32(x)
#define cpu_to_be64(x) __cpu_to_be64(x)
#define cpu_to_le8(x) x
#define cpu_to_le16(x) __cpu_to_le16(x)
#define cpu_to_le32(x) __cpu_to_le32(x)
#define cpu_to_le64(x) __cpu_to_le64(x)

#define be8_to_cpu(x) x
#define be16_to_cpu(x) __be16_to_cpu(x)
#define be32_to_cpu(x) __be32_to_cpu(x)
#define be64_to_cpu(x) __be64_to_cpu(x)
#define le8_to_cpu(x) x
#define le16_to_cpu(x) __le16_to_cpu(x)
#define le32_to_cpu(x) __le32_to_cpu(x)
#define le64_to_cpu(x) __le64_to_cpu(x)

#endif
