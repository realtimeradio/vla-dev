static const TCHAR*
getFpgaDeviceString(
  uint16_t deviceCode)
{
  static struct _FpgaDeviceKeyValue {
    unsigned int key;
    const TCHAR* pValue;
  } table[] = {
    { ADMXRC3_FPGA_KU035,  _T("KU035")  },
    { ADMXRC3_FPGA_KU040,  _T("KU040")  },
    { ADMXRC3_FPGA_KU060,  _T("KU060")  },
    { ADMXRC3_FPGA_KU115,  _T("KU115")  },
    { ADMXRC3_FPGA_KU025,  _T("KU025")  },
    { ADMXRC3_FPGA_KU085,  _T("KU085")  },
    { ADMXRC3_FPGA_KU095,  _T("KU095")  },
    { ADMXRC3_FPGA_VU065,  _T("VU065")  },
    { ADMXRC3_FPGA_VU080,  _T("VU080")  },
    { ADMXRC3_FPGA_VU095,  _T("VU095")  },
    { ADMXRC3_FPGA_VU125,  _T("VU125")  },
    { ADMXRC3_FPGA_VU160,  _T("VU160")  },
    { ADMXRC3_FPGA_VU440,  _T("VU440")  },
    { ADMXRC3_FPGA_VU190,  _T("VU190")  },
    { ADMXRC3_FPGA_KU3P,   _T("KU3P")   },
    { ADMXRC3_FPGA_KU5P,   _T("KU5P")   },
    { ADMXRC3_FPGA_KU9P,   _T("KU9P")   },
    { ADMXRC3_FPGA_KU11P,  _T("KU11P")  },
    { ADMXRC3_FPGA_KU13P,  _T("KU13P")  },
    { ADMXRC3_FPGA_KU15P,  _T("KU15P")  },
    { ADMXRC3_FPGA_VU3P,   _T("VU3P")   },
    { ADMXRC3_FPGA_VU5P,   _T("VU5P")   },
    { ADMXRC3_FPGA_VU7P,   _T("VU7P")   },
    { ADMXRC3_FPGA_VU9P,   _T("VU9P")   },
    { ADMXRC3_FPGA_VU11P,  _T("VU11P")  },
    { ADMXRC3_FPGA_VU13P,  _T("VU13P")  },
    { ADMXRC3_FPGA_VU27P,  _T("VU27P")  },
    { ADMXRC3_FPGA_VU29P,  _T("VU29P")  },
    { ADMXRC3_FPGA_VU31P,  _T("VU31P")  },
    { ADMXRC3_FPGA_VU33P,  _T("VU33P")  },
    { ADMXRC3_FPGA_VU35P,  _T("VU35P")  },
    { ADMXRC3_FPGA_VU37P,  _T("VU37P")  },
    { ADMXRC3_FPGA_ZU2EG,  _T("ZU2EG")  },
    { ADMXRC3_FPGA_ZU3EG,  _T("ZU3EG")  },
    { ADMXRC3_FPGA_ZU4EV,  _T("ZU4EV")  },
    { ADMXRC3_FPGA_ZU5EV,  _T("ZU5EV")  },
    { ADMXRC3_FPGA_ZU6EG,  _T("ZU6EG")  },
    { ADMXRC3_FPGA_ZU7EV,  _T("ZU7EV")  },
    { ADMXRC3_FPGA_ZU9EG,  _T("ZU9EG")  },
    { ADMXRC3_FPGA_ZU11EG, _T("ZU11EG") },
    { ADMXRC3_FPGA_ZU15EG, _T("ZU15EG") },
    { ADMXRC3_FPGA_ZU17EG, _T("ZU17EG") },
    { ADMXRC3_FPGA_ZU19EG, _T("ZU19EG") },
    { ADMXRC3_FPGA_ZU21DR, _T("ZU21DR") },
    { ADMXRC3_FPGA_ZU25DR, _T("ZU25DR") },
    { ADMXRC3_FPGA_ZU27DR, _T("ZU27DR") },
    { ADMXRC3_FPGA_ZU28DR, _T("ZU28DR") },
    { ADMXRC3_FPGA_ZU29DR, _T("ZU29DR") },
    { ADMXRC3_FPGA_ZU39DR, _T("ZU39DR") },
    { ADMXRC3_FPGA_ZU46DR, _T("ZU46DR") },
    { ADMXRC3_FPGA_ZU47DR, _T("ZU47DR") },
    { ADMXRC3_FPGA_ZU48DR, _T("ZU48DR") },
    { ADMXRC3_FPGA_ZU49DR, _T("ZU49DR") },
    { ADMXRC3_FPGA_VC1352, _T("VC1352") },
    { ADMXRC3_FPGA_VC1502, _T("VC1502") },
    { ADMXRC3_FPGA_VC1702, _T("VC1702") },
    { ADMXRC3_FPGA_VC1802, _T("VC1802") },
	{ ADMXRC3_FPGA_VC1902, _T("VC1902") },
    { ADMXRC3_FPGA_VM1102, _T("VM1102") },
    { ADMXRC3_FPGA_VM1302, _T("VM1302") },
    { ADMXRC3_FPGA_VM1402, _T("VM1402") },
    { ADMXRC3_FPGA_VM1502, _T("VM1502") },
    { ADMXRC3_FPGA_VM1802, _T("VM1802") },
    { ADMXRC3_FPGA_VM2302, _T("VM2302") },
    { ADMXRC3_FPGA_VM2502, _T("VM2502") },
    { ADMXRC3_FPGA_VM2902, _T("VM2902") },
    { ADMXRC3_FPGA_VP1102, _T("VP1102") },
    { ADMXRC3_FPGA_VP1202, _T("VP1202") },
    { ADMXRC3_FPGA_VP1402, _T("VP1402") },
    { ADMXRC3_FPGA_VP1502, _T("VP1502") },
    { ADMXRC3_FPGA_VP1552, _T("VP1552") },
    { ADMXRC3_FPGA_VP1702, _T("VP1702") },
	{ ADMXRC3_FPGA_VP1802, _T("VP1802") }
  };
  unsigned int i;

  for (i = 0; i < ARRAY_LENGTH(table); i++) {
    if (deviceCode == table[i].key) {
      return table[i].pValue;
    }
  }

  return _T("UNRECOGNIZED");
}

static const TCHAR*
getFpgaTempGradeString(
  uint8_t tempGrade)
{
  switch (tempGrade) {
  case 0U:
    return _T("C (Commercial)");

  case 1U:
    return _T("I (Industrial)");

  case 2U:
    return _T("E (Extended)");

  default:
    return _T("UNRECOGNIZED");
  }
}

static const TCHAR*
getFpgaSpaceGradeString(
  uint8_t spaceGrade)
{
  switch (spaceGrade) {
  case 0U:
    return _T("Not space grade");

  case 1U:
    return _T("Space grade");

  default:
    return _T("UNRECOGNIZED");
  }
}
