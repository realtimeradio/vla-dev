/*
** intel_hex.c - Functions for reading and writing Intel Hex (.mcs) files.
**
** (C) Copyright 2017 Alpha Data
**
** Note:
** 1. Record type 2 (Extended Segment Address) is not supported and is ignored.
** 2. Record type 3 (Start Segment Address) is not supported and is ignored.
** 3. Empty lines and lines not beginning with a colon are ignored and are not considered to be errors.
** 4. Nonprintable characters other than '\r' and '\n' are skipped, setting the INTEL_HEX_ERROR_BAD_CHARACTER flag.
** 5. Any line with a byte that is not a valid hexadecimal number is skipped, setting the INTEL_HEX_ERROR_BAD_RECORD flag.
*/

#if defined(_WIN32)

/* Windows */
# include <windows.h>
# include <tchar.h>

#else

/* Linux or VxWorks */
# define _T(x) x
# define _tprintf printf
# define _ftprintf fprintf
# define FALSE (0)
# define TRUE (1)

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <ctype.h>

#include <sdk_common.h>
#include <platform_endian.h>

#include "intel_hex.h"

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

#define MAX_LINE_LENGTH ((255 + 5) * 2 + 1) /* Maximum line length excluding CR / LF, excluding NUL terminator but including colon */

static IntelHexError
readIntelHexLine(
  FILE* pFile,
  char* pLineBuffer,
  unsigned int* pLength,
  bool_t *pbBadCharacter)
{
  unsigned int pos = 0;
  IntelHexError ret = IntelHexErrorOk;
  bool_t bBadCharacter = FALSE;

  while (!feof(pFile)) {
    int c = fgetc(pFile);

    if (c == EOF) {
      if (ferror(pFile)) {
        ret = IntelHexErrorReadError;
      }
      break;
    } else if (c == '\n') {
      break;
    } else if (c == '\r') {
      /* Skip CR characters */
    } else {
      if (isprint(c)) {
        if (pos < MAX_LINE_LENGTH) {
          pLineBuffer[pos++] = (char)c;
        }
      } else {
        /* Skip other nonprintable characters and record as warning */
        bBadCharacter = TRUE;
      }
    }
  }

  pLineBuffer[pos] = '\0';

  *pLength = pos;
  *pbBadCharacter = bBadCharacter;

  return ret;
}

static bool_t
hexToByte(
  const char* pCharacters,
  uint8_t* pByte)
{
  unsigned int i;
  int shift = 4;
  uint8_t byte = 0;

  for (i = 0; i < 2; i++) {
    char c = pCharacters[i];

    if (c >= '0' && c <= '9') {
      byte = (uint8_t)(byte | ((c - '0') << shift));
    } else if (c >= 'A' && c <= 'F') {
      byte = (uint8_t)(byte | ((c - 'A' + 10) << shift));
    } else if (c >= 'a' && c <= 'f') {
      byte = (uint8_t)(byte | ((c - 'a' + 10) << shift));
    } else {
      return FALSE;
    }

    shift -= 4;
  }

  *pByte = byte;

  return TRUE; /* OK */
}

static void
logError(
  IntelHexFile* pIntelHexFile,
  unsigned int pass,
  unsigned int code,
  unsigned int line)
{
  size_t errorCount;

  if (pass != 2) {
    return;
  }

  errorCount = pIntelHexFile->errorCount;
  if (errorCount < INTEL_HEX_FILE_MAX_ERROR) {
    pIntelHexFile->errors[errorCount].code = code;
    pIntelHexFile->errors[errorCount].line = line;
  }
  errorCount++;
  pIntelHexFile->errorCount = errorCount;
}

IntelHexError
avr2utilReadIntelHex(
  const TCHAR* pFilename,
  IntelHexFile** ppIntelHexFile)
{
  IntelHexFile* pIntelHexFile = NULL;
  FILE* pFile = NULL;
  unsigned int pass;
  uint32_t baseAddress = 0;
  size_t sectionCount = 0;
  int err;
  IntelHexError ret = IntelHexErrorOk;

#ifdef _MSC_VER
  err = _tfopen_s(&pFile, pFilename, _T("rb"));
#else
# ifdef _WIN32
  pFile = _tfopen(pFilename, "rb");
# else
  pFile = fopen(pFilename, "r");
# endif
  err = (NULL == pFile) ? errno : 0;
#endif
  if (err) {
    switch (err) {
    case EACCES:
      ret = IntelHexErrorPermissionDenied;
      break;

    case ENOENT:
      ret = IntelHexErrorNotFound;
      break;

    default:
      ret = IntelHexErrorOpenFailed;
      break;
    }

    goto done;
  }

  /* Pass 0: Count number of sections and allocate IntelHexFile data structure */
  /* Pass 1: Measure sections & allocate pData buffer for each IntelHexFileSection element */
  /* Pass 2: Populate pData buffer for each IntelHexFileSection element with data */
  for (pass = 0; pass < 3; pass++) {
    char line[MAX_LINE_LENGTH];
    uint8_t data[255];
    unsigned int lineLength, linePos, dataPos;
    unsigned int sectionIndex = 0;
    uint32_t address, nextAddress = 0, sectionLength = 0;
    uint8_t sum, lengthField = 0, addrFieldLo, addrFieldHi, typeField, checksumField, dataByte;
    uint16_t addrField;
    bool_t bTypeRecognized, bDiscardRecord, bEOFRecordFound = FALSE;
    IntelHexFileSection* pSection = NULL;
    unsigned int lineNumber = 0;
    bool_t bBadCharacter = FALSE;

    err = fseek(pFile, 0, SEEK_SET);
    if (err) {
      ret = IntelHexErrorSeekError;
      goto done;
    }

    if (pass >= 1) {
      pSection = &pIntelHexFile->sections[0];
    }

    while (!feof(pFile)) {
      lineNumber++;

      ret = readIntelHexLine(pFile, line, &lineLength, &bBadCharacter);
      if (ret) {
        goto done;
      }

      if (0 == lineLength || line[0] != ':') {
        /* Skip zero-length lines and lines that don't begin with a colon. */
        /* We don't flag such lines as an error so that we can allow have some kind of comment in an Intel Hex file. */
        continue;
      }

      if (lineLength < 11) {
        /* A line less than 11 characters in length cannot be valid */
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_RECORD, lineNumber);
        continue;
      }

      sum = 0;

      if (!hexToByte(&line[1], &lengthField)) {
        /* Not a valid hexadecimal value for length field */
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_RECORD, lineNumber);
        continue;
      }
      sum = (uint8_t)(sum + lengthField);

      if (!hexToByte(&line[3], &addrFieldHi) || !hexToByte(&line[5], &addrFieldLo)) {
        /* Not a valid hexadecimal value for address field */
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_RECORD, lineNumber);
        continue;
      }
      sum = (uint8_t)(sum + addrFieldHi);
      sum = (uint8_t)(sum + addrFieldLo);
      addrField = (uint16_t)(((uint16_t)addrFieldHi << 8) | ((uint16_t)addrFieldLo));

      if (!hexToByte(&line[7], &typeField)) {
        /* Not a valid hexadecimal value for address field */
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_RECORD, lineNumber);
        continue;
      }
      sum = (uint8_t)(sum + typeField);

      if (lineLength < (2U * (lengthField + 5U) + 1U)) {
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_SHORT_RECORD, lineNumber);
      }
      if (lineLength > (2U * (lengthField + 5U) + 1U)) {
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_LONG_RECORD, lineNumber);
      }

      linePos = 9;
      dataPos = 0;
      while (linePos + 1 < lineLength - 2 && dataPos < lengthField) {
        if (!hexToByte(&line[linePos], &dataByte)) {
          /* Not a valid hexadecimal value for data byte */
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_RECORD, lineNumber);
          continue;
        }

        data[dataPos++] = dataByte;
        linePos += 2;
        sum = (uint8_t)(sum + dataByte);
      }

      bTypeRecognized = TRUE;
      bDiscardRecord = FALSE;

      switch (typeField) {
      case INTEL_HEX_RECORD_DATA:
        address = baseAddress + addrField;

        if (address != nextAddress) {
          if (sectionLength) {
            /* Begin a new section */
            sectionIndex = sectionIndex + 1;
            sectionLength = 0;
            if (pass >= 1) {
              pSection++;
            }
          }
          if (pass == 1) {
            pSection->address = address;
            pSection->length = 0;
          }
        }

        if (pass == 2) {
          assert(sectionLength + dataPos >= sectionLength);
          assert(sectionLength + dataPos <= pSection->length);
          memcpy(pSection->pData + sectionLength, data, dataPos);
        }

        sectionLength += dataPos;
        if (pass == 1) {
          pSection->length = sectionLength;
        }
        nextAddress = address + dataPos;
        break;

      case INTEL_HEX_RECORD_EOF:
        if (lengthField) {
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_EOF_NOT_EMPTY, lineNumber);
        }
        bEOFRecordFound = TRUE;
        break;

      case INTEL_HEX_RECORD_EXT_SEG_ADDR:
        if (lengthField != 2) {
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_ADDR_LEN, lineNumber);
          bDiscardRecord = TRUE;
        } else {
          /* We don't support this type of record; it is specific to files that contain x86 processor machine code */
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_UNSUPP_RECORD, lineNumber);
          bDiscardRecord = TRUE;
        }
        break;

      case INTEL_HEX_RECORD_SEG_ADDR:
        if (lengthField != 4) {
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_ADDR_LEN, lineNumber);
          bDiscardRecord = TRUE;
        } else {
          /* We don't support this type of record; it is specific to files that contain x86 processor machine code */
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_UNSUPP_RECORD, lineNumber);
          bDiscardRecord = TRUE;
        }
        break;

      case INTEL_HEX_RECORD_EXT_LIN_ADDR:
        if (lengthField != 2) {
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_ADDR_LEN, lineNumber);
          bDiscardRecord = TRUE;
        } else {
          baseAddress = (uint32_t)((baseAddress & 0xFFFF) | (uint32_t)(data[0] << 24) | (uint32_t)(data[1] << 16));
        }
        break;

      case INTEL_HEX_RECORD_LIN_ADDR:
        if (lengthField != 4) {
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_ADDR_LEN, lineNumber);
          bDiscardRecord = TRUE;
        } else {
          baseAddress = (uint32_t)((uint32_t)(data[0] << 24) | (uint32_t)(data[1] << 16) | (uint32_t)(data[2] << 8) | (uint32_t)(data[3] << 0));
        }
        break;

      default:
        bTypeRecognized = FALSE;
        break;
      }

      if (bDiscardRecord) {
        continue;
      }

      /* Take 2's complement of sum so far */
      sum = (uint8_t)(~sum + 1);

      if (!hexToByte(&line[linePos], &checksumField)) {
        /* Not a valid hexadecimal value for checksum byte */
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_BAD_RECORD, lineNumber);
      } else {
        if (checksumField != sum) {
          /* Checksum mismatch */
          logError(pIntelHexFile, pass, INTEL_HEX_ERROR_CSUM_ERROR, lineNumber);
        }
      }

      if (!bTypeRecognized) {
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_UNSUPP_RECORD, lineNumber);
      } else {
        if (pass == 2) {
          if (bEOFRecordFound && (typeField != INTEL_HEX_RECORD_EOF)) {
            /* EOF record already encountered, but we just processed another record */
            logError(pIntelHexFile, pass, INTEL_HEX_ERROR_EOF_EXTRA, lineNumber);
          }
        }
      }
    }

    if (sectionLength > 0) {
      sectionIndex++;
    }

    if (0 == pass) {
      size_t allocSize;

      sectionCount = sectionIndex;

      allocSize = sizeof(IntelHexFile) + sizeof(pIntelHexFile->sections) * (sectionCount - 1);
      pIntelHexFile = (IntelHexFile*)malloc(allocSize);
      if (NULL == pIntelHexFile) {
        ret = IntelHexErrorAllocationError;
        goto done;
      }
      memset(pIntelHexFile, 0, allocSize);
      pIntelHexFile->sectionCount = sectionCount;
    } else if (1 == pass) {
      size_t i;

      for (i = 0; i < sectionCount; i++) {
        pSection = &pIntelHexFile->sections[i];
        pSection->pData = (uint8_t*)malloc(pSection->length);
        if (NULL == pSection->pData) {
          ret = IntelHexErrorAllocationError;
          goto done;
        }
      }
    } else if (2 == pass) {
      if (!bEOFRecordFound) {
        logError(pIntelHexFile, pass, INTEL_HEX_ERROR_NO_EOF_RECORD, lineNumber);
      }
    }
  }

done:
  if (NULL != pFile) {
    fclose(pFile);
  }

  if (ret) {
    if (NULL != pIntelHexFile) {
      avr2utilDisposeIntelHex(pIntelHexFile);
    }
  } else {
    *ppIntelHexFile = pIntelHexFile;
  }

  return ret;
}

static IntelHexError
writeSection(
  FILE* pFile,
  const IntelHexFileSection* pSection,
  uint8_t maxBytesPerRecord)
{
  IntelHexError ret = IntelHexErrorOk;
  uint32_t remaining, address, addressLow, addressHigh, prevAddressHigh;
  uint8_t* p;
  uint8_t offset, chunk, sum, csum, byte, addrMSB, addrLSB;
  unsigned int i;

  address = pSection->address;
  remaining = pSection->length;
  p = pSection->pData;
  prevAddressHigh = 0xFFFFFFFF; /* Not a value segment value */
  while (remaining) {
    addressHigh = (address & 0xFFFF0000U) >> 16;
    addressLow = (address & 0xFFFFU);
    offset = (uint8_t)(addressLow % maxBytesPerRecord);
    chunk = (uint8_t)(maxBytesPerRecord - offset);
    if (chunk > remaining) {
      chunk = (uint8_t)remaining;
    }

    /* Write an Extended Linear Address record */
    if (addressHigh != prevAddressHigh) {
      addrMSB = (uint8_t)((addressHigh >> 8) & 0xFF);
      addrLSB = (uint8_t)((addressHigh >> 0) & 0xFF);
      sum = 0x02;
      sum = (uint8_t)(sum + addrMSB);
      sum = (uint8_t)(sum + addrLSB);
      sum = (uint8_t)(sum + 0x04);
      csum = (uint8_t)(~sum + 1);
      _ftprintf(pFile, _T(":02000004%02X%02X%02X\n"), addrMSB, addrLSB, csum);
    }

    /* Write a Data record */
    addrMSB = (uint8_t)((addressLow >> 8) & 0xFF);
    addrLSB = (uint8_t)((addressLow >> 0) & 0xFF);
    _ftprintf(pFile, _T(":%02X%02X%02X00"), chunk, addrMSB, addrLSB);
    sum = chunk;
    sum = (uint8_t)(sum + addrMSB);
    sum = (uint8_t)(sum + addrLSB);
    for (i = 0; i < chunk; i++) {
      byte = p[i];
      _ftprintf(pFile, _T("%02X"), byte);
      sum = (uint8_t)(sum + byte);
    }
    csum = (uint8_t)(~sum + 1);
    _ftprintf(pFile, _T("%02X\n"), csum);

    address += chunk;
    remaining -= chunk;
    p += chunk;

    prevAddressHigh = addressHigh;
  }

  return ret;
}

extern IntelHexError
avr2utilWriteIntelHex(
  const TCHAR* pFilename,
  const IntelHexFile* pIntelHexFile,
  uint8_t maxBytesPerRecord)
{
  IntelHexError ret = IntelHexErrorOk;
  FILE* pFile = NULL;
  int err;
  size_t i;

#ifdef _MSC_VER
  err = _tfopen_s(&pFile, pFilename, _T("wt"));
#else
# ifdef _WIN32
  pFile = _tfopen(pFilename, "wt");
# else
  pFile = fopen(pFilename, "w");
# endif
  err = (NULL == pFile) ? errno : 0;
#endif
  if (err) {
    switch (err) {
    case EACCES:
      ret = IntelHexErrorPermissionDenied;
      break;

    case ENOENT:
      ret = IntelHexErrorNotFound;
      break;

    default:
      printf("%d\n", err);
      ret = IntelHexErrorOpenFailed;
      break;
    }

    goto done;
  }

  for (i = 0; i < pIntelHexFile->sectionCount; i++) {
    ret = writeSection(pFile, &pIntelHexFile->sections[i], maxBytesPerRecord);
    if (IntelHexErrorOk != ret) {
      goto done;
    }
  }

  /* Deposit end-of-file record */
  _ftprintf(pFile, _T(":00000001FF\n"));

done:
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

void
avr2utilDisposeIntelHex(
  IntelHexFile* pIntelHexFile)
{
  size_t i;

  for (i = 0; i < pIntelHexFile->sectionCount; i++) {
    IntelHexFileSection* pSection = &pIntelHexFile->sections[i];

    if (NULL != pSection->pData) {
      free(pSection->pData);
    }
  }

  free(pIntelHexFile);
}

extern void
avr2utilDisplayIntelHexInfo(
  const IntelHexFile* pIntelHexFile,
  const TCHAR* pIndent)
{
  size_t i;

  _tprintf(_T("%sNumber of sections .. %llu\n"),
    pIndent, (unsigned long long)pIntelHexFile->sectionCount);
  for (i = 0; i < pIntelHexFile->sectionCount; i++) {
    _tprintf(_T("%sSection %-9llu ... Address 0x%08X, length 0x%X\n"),
      pIndent, (unsigned long long)i, pIntelHexFile->sections[i].address, pIntelHexFile->sections[i].length);
  }
  _tprintf(_T("%sNumber of errors .... %llu\n"),
    pIndent, (unsigned long long)pIntelHexFile->errorCount);
  for (i = 0; i < pIntelHexFile->errorCount && i < INTEL_HEX_FILE_MAX_ERROR ; i++) {
    const TCHAR* pDescription = _T("?");

    switch (pIntelHexFile->errors[i].code) {
    case INTEL_HEX_ERROR_CSUM_ERROR:
      pDescription = _T("Bad checksum for record");
      break;

    case INTEL_HEX_ERROR_UNSUPP_RECORD:
      pDescription = _T("Record type not supported");
      break;

    case INTEL_HEX_ERROR_NO_EOF_RECORD:
      pDescription = _T("No end-of-file record was found");
      break;

    case INTEL_HEX_ERROR_EOF_EXTRA:
      pDescription = _T("At least one more record after end-of-file record");
      break;

    case INTEL_HEX_ERROR_BAD_RECORD:
      pDescription = _T("Malformed record");
      break;

    case INTEL_HEX_ERROR_SHORT_RECORD:
      pDescription = _T("Record ended prematurely");
      break;

    case INTEL_HEX_ERROR_LONG_RECORD:
      pDescription = _T("Extra characters after record");
      break;

    case INTEL_HEX_ERROR_BAD_CHARACTER:
      pDescription = _T("Unexpected nonprinting characters encountered in record");
      break;

    case INTEL_HEX_ERROR_EOF_NOT_EMPTY:
      pDescription = _T("EOF record with nonzero length field");
      break;

    case INTEL_HEX_ERROR_BAD_ADDR_LEN:
      pDescription = _T("Length field was not the expected value for given record type");
      break;

    default:
      pDescription = _T("Unknown error code!");
      break;
    }

    _tprintf(_T("%sError %-9llu ..... Line %u, code %u => %s\n"),
      pIndent, (unsigned long long)i, pIntelHexFile->errors[i].line, pIntelHexFile->errors[i].code, pDescription);
  }
}
