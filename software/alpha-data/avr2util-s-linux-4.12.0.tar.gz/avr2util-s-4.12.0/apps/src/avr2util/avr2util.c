/*
** avr2util.c - utility to manipulate AVR2 microcontroller on certain reconfigurable
**              computing cards, at a low level.
**
** (C) Copyright 2016 - 2020 Alpha Data
**
** Supported models:
**
**   o ADM-XRC-KU1
**   o ADM-PCIE-8V3
**   o ADM-PCIE-8K5 / ADM-PCIE-8K5-FH / ADM-PCIE-UCC
**   o ADM-PCIE-9V3 / ADM-PCIE-9V3G
**   o ADM-PCIE-9V5
**   o ADM-PCIE-9H3
**   o ADM-PCIE-9H7
**   o ADM-SDEV-BASE
**   o ADM-VPX3-9Z2
**   o ADM-XRC-9R1
**   o ADM-VPX3-9V2
**   o ADM-PA100 / ADM-PA101
**
** Exit codes: see EXIT_* #defines below.
*/

#if defined(_WIN32)

/* Windows */
# include <windows.h>
# include <tchar.h>
# define AVR2_VIA_USB_SUPPORTED
# define AVR2_VIA_ADXDMA_SUPPORTED

#else

/* Linux or VxWorks */
# define _T(x) x
# define _stprintf_s snprintf
# define _tscanf_s scanf
# define _tcschr(s, c) strchr(s, c)
# define _tcslen(s) strlen(s)
# define _tcscpy_s(x, n, y) do { strncpy(x, y, n); (x)[(n) - 1] = '\0'; } while (0)
# define _tcsicmp(pStr1, pStr2) strcasecmp(pStr1, pStr2)
# define _tcsstr(x, y) strstr(x, y)
# define _tmain main
# define _tprintf printf
# define _stscanf_s sscanf
# define FALSE (0)
# define TRUE (1)

# if defined(__VXWORKS__) || defined(__vxworks)
#   define ADB3_LIBRARY_STATIC
# else
#   define AVR2_VIA_USB_SUPPORTED
#   define AVR2_VIA_SMBUS_SUPPORTED
/* NOTE: Makefile defines AVR2_VIA_ADXDMA_SUPPORTED */
/* NOTE: Makefile may or may not define AVR2_VIA_IPMI_SUPPORTED */
#   if !defined(AVR2_LIBRARY_STATIC) || !defined(AVR2S_LIBRARY_STATIC) || !defined(AVR2IPMI_LIBRARY_STATIC) || !defined(ADB3_LIBRARY_STATIC)
/* Needed for dlopen() */
#     include <dlfcn.h>
#   endif
# endif

#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>

#include <sdk_common.h>
#include <platform_endian.h>
#include <platform_time.h>

#if defined(__INTEL_COMPILER)
/* Prevent warnings from ICC compiler of the form "external function definition with no prior declaration" */
# pragma warning(disable:1418)
#endif

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

#include "avr2util.h"
#include "avr2util_fpga.h"
#include "avr2util_model.h"
#include "avr2util_sensor.h"
#include "avr2util_version.h"
#include "intel_hex.h"
#include "sfdp.h"
#include "spi_flash.h"
#if defined(UPDATE_9V3G_U32)
# include "../update_9v3g_u32/update_9v3g_u32.h"
#endif

#define FIRMWARE_BASE_ADDR     (0x0U) /* Address in Application Flash where firmware code lives */
#define FIRMWARE_LENGTH_LIMIT  (0x1FC00U) /* Maximum possible size of firmware code */

#define BOARD_CONFIG_BASE_ADDR    (0x1FC00U) /* Address in Application Flash where board configuration block lives */
#define BOARD_CONFIG_LENGTH_LIMIT (512U)     /* Maximum possible size of board configuration block */

#define VPD_BASE_ADDR    (0x1FF00U) /* Address in Application Flash where VPD lives */
#define VPD_LENGTH_LIMIT (128U)     /* Maximum possible size of VPD block */

#define SENSOR_PAGE_LENGTH_LIMIT (64U) /* Maximum possible size of sensor data page */

/* Black box pages 0 - 23 are for clobber records */
/* Black box pages 24 - 30 are for noclobber reords */
#define BLACK_BOX_NUM_CLOBBER_RECORD   (24U) /* Number of black box sensor data pages reserved for clobber records */
#define BLACK_BOX_NUM_NOCLOBBER_RECORD  (7U) /* Number of black box sensor data pages reserved for noclobber records */

#define DRAWING_NUM_BOOTMAN2           (1320) /* Drawing number for AVR2 boot manager */
#define DRAWING_NUM_BOOTMAN2_ALT1       (720) /* Alternative drawing number for AVR2 boot manager */
#define DRAWING_NUM_BOOTMAN2_ALT2   (0x2D000) /* Alternative drawing number for AVR2 boot manager */
#define DRAWING_NUM_BOARDMAN2          (1321) /* Drawing number for AVR2 board manager */
#define DRAWING_NUM_BOARDMAN2_ALT1      (721) /* Alternative drawing number for AVR2 board manager */
#define DRAWING_NUM_BOARDMAN2_ALT2  (0x2D100) /* Alternative drawing number for AVR2 board manager */

#define UC_ADB3_REBOOT_DELAY_MS   (1000) /* Time allowed for uC to reboot itself when entering/exiting Service Mode when communicating via ADB3 Driver (PCIe) */
#define UC_ADXDMA_REBOOT_DELAY_MS (1000) /* Time allowed for uC to reboot itself when entering/exiting Service Mode when communicating via ADXDMA Driver (PCIe) */
#define UC_PSUART_REBOOT_DELAY_MS (1000) /* Time allowed for uC to reboot itself when entering/exiting Service Mode when communicating via PS UART */
#define UC_USBCOM_REBOOT_DELAY_MS (5000) /* Time allowed for uC to reboot itself when entering/exiting Service Mode when communicating via USB */
#define UC_SMBUS_REBOOT_DELAY_MS  (1000) /* Time allowed for uC to reboot itself when entering/exiting Service Mode when communicating via SMBUS */
#define UC_IPMI_REBOOT_DELAY_MS   (1000) /* Time allowed for uC to reboot itself when entering/exiting Service Mode when communicating via IPMI+SMBUS*/

/* Default timeout for a single microcontroller command (microseconds) */
#define DEFAULT_COMMAND_TIMEOUT_US (1000000)

/* Default I2C chip address where we expect to find the uC */
#define UC_SMBUS_CHIP_ADDR (0x48)

#if !defined(PROGRAM_NAME)
# ifdef _WIN32
#   define PROGRAM_NAME _T("avr2util.exe")
# else
#   if defined(AVR2_LIBRARY_STATIC)
#     define PROGRAM_NAME _T("avr2util-s")
#   else
#     define PROGRAM_NAME _T("avr2util")
#   endif /* defined(ADB3_LIBRARY_STATIC) */
# endif
#endif

/* Models that this utility knows about */
struct _SupportedModels {
  const TCHAR* pszModelName;
} g_supportedModels[] = {
  { _T("ADM-XRC-KU1") },
  { _T("ADM-PCIE-8V3") },
  { _T("ADM-PCIE-8K5") },
  { _T("ADM-PCIE-8K5-FH") },
  { _T("ADM-PCIE-UCC") },
  { _T("ADM-PCIE-9V3") },
  { _T("ADM-PCIE-9V5") },
  { _T("ADM-PCIE-9V3G") },
  { _T("ADM-PCIE-9H3") },
  { _T("ADM-PCIE-9H7") },
  { _T("ADM-SDEV-BASE") },
  { _T("ADM-VPX3-9Z2") },
  { _T("ADM-XRC-9R1") },
  { _T("ADM-VPX3-9V2") },
  { _T("ADM-PA100") },
  { _T("ADM-PA101") }
};

/* Models that this utility can communicate with via PCIe */
struct _ADB3SupportedModels {
  ADMXRC3_MODEL_TYPE modelType;
  const TCHAR* pszModelName;
} g_adb3SupportedModels[] = {
  { ADMXRC3_MODEL_ADMXRCKU1,  _T("ADM-XRC-KU1")  },
  { ADMXRC3_MODEL_ADMPCIE8V3, _T("ADM-PCIE-8V3") },
  { ADMXRC3_MODEL_ADMPCIE8K5, _T("ADM-PCIE-8K5(-FH) / ADM-PCIE-UCC") }
};


#if !defined(_MSC_VER)
/* Emulate _tfopen_s ("secure file open") from MSVC++ */
static int
_tfopen_s(
  FILE** ppFile,
  const TCHAR* pFilename,
  const TCHAR* pMode)
{
  FILE* pFile;

  pFile = fopen(pFilename, pMode);
  if (NULL == pFile) {
    return -1;
  }
  *ppFile = pFile;
  return 0;
}
#endif

#if !defined(_MSC_VER) && defined(__linux)
/* Emulate _tgetenv_s ("secure getenv") from MSVC++ */
static void
_tgetenv_s(
  size_t* pRequiredLength,
  TCHAR* pBuffer,
  size_t max,
  const TCHAR* pVariableName)
{
  TCHAR* pTmp;
  size_t length;

  pTmp = getenv(pVariableName);
  if (NULL == pTmp) {
    length = 0;
  } else {
    length = strlen(pTmp) + 1;
  }
  if (NULL != pRequiredLength) {
    /* Not found */
    *pRequiredLength = length;
  }
  if (NULL != pBuffer) {
    if (max) {
      max--; /* subtract 1 for NUL terminator */
      if (length > max) {
        length = max;
      }
      if (length) {
        memcpy(pBuffer, pTmp, length * sizeof(TCHAR));
      }
      pBuffer[length] = '\0';
    }
  }
}
#endif

#if !(defined(__VXWORKS__) || defined(__vxworks))

static int stringToUInt(
  const TCHAR* pString,
  unsigned int* pValue)
{
  if (_tcslen(pString) >= 2 && pString[0] == _T('0') && pString[1] == _T('x')) {
    return _stscanf_s(pString + 2, _T("%x"), pValue);
  } else {
    return _stscanf_s(pString, _T("%u"), pValue);
  }
}

static int
stringToInt(
  const TCHAR* pString,
  int* pValue)
{
  bool_t bNegate = FALSE;
  unsigned int value;
  int nConverted;

  if (_tcslen(pString) >= 1) {
    if (pString[0] == _T('-')) {
      bNegate = TRUE;
      pString++;
    } else if (pString[0] == _T('+')) {
      pString++;
    } 
  }
  if (_tcslen(pString) >= 2 && pString[0] == _T('0') && pString[1] == _T('x')) {
    nConverted = _stscanf_s(pString + 2, _T("%x"), &value);
  } else {
    nConverted = _stscanf_s(pString, _T("%u"), &value);
  }
  if (nConverted >= 1) {
    if (bNegate) {
      *pValue = -(int)value;
    } else {
      *pValue = (int)value;
    }
  }
  return nConverted;
}

static int
stringToULong(
  const TCHAR* pString,
  unsigned long* pValue)
{
  if (_tcslen(pString) >= 2 && pString[0] == _T('0') && pString[1] == _T('x')) {
    return _stscanf_s(pString + 2, _T("%lx"), pValue);
  } else {
    return _stscanf_s(pString, _T("%lu"), pValue);
  }
}

#endif

#if defined(AVR2_VIA_USB_SUPPORTED)

# if defined(AVR2_LIBRARY_STATIC)

/* AVR2 API library was statically linked, so no need to check for its presence. */
static int
LoadAVR2Library(
  API_AVR2* pApi)
{
  pApi->pfnAVR2_Close = &AVR2_Close;
  pApi->pfnAVR2_Command = &AVR2_Command;
  pApi->pfnAVR2_GetStatusString = &AVR2_GetStatusString;
  pApi->pfnAVR2_OpenPort = &AVR2_OpenPort;
  pApi->pfnAVR2_SetPortBaud = &AVR2_SetPortBaud;

  return EXIT_OK;
}

# else

static const char* g_pszAVR2APIFunctions[] = {
  "AVR2_Close",
  "AVR2_Command",
#   if defined(_UNICODE)
  "AVR2_GetStatusStringW",
  "AVR2_OpenPortW",
#   else
  "AVR2_GetStatusStringA",
  "AVR2_OpenPortA",
#   endif
  "AVR2_SetPortBaud"
};

#   if defined(_WIN32)
/* Windows - check for adavr2[d].dll using LoadLibrary(). If we can load it,
** we assume that subsequent delayed-loading of the DLL will succeed.
** This check is performance for Windows because if a delay-loaded DLL can't
** be found, the program crashes in a very unhelpful way, with no error
** message given to the user about why it crashed. */
static int
LoadAVR2Library(
  API_AVR2* pApi)
{
#     if defined(_DEBUG)
  static const char* pDLLName = "adavr2d.dll";
#     else
  static const char* pDLLName = "adavr2.dll";
#     endif
  HANDLE hModule;
  int i;
  FARPROC* ppFunctions;

  hModule = LoadLibraryA(pDLLName);
  if (NULL == hModule) {
    printf("*** Cannot find DLL '%s'. This can be corrected by installing the AVR2 System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pDLLName, pDLLName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (FARPROC*)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszAVR2APIFunctions); i++) {
    FARPROC pEntryPoint = GetProcAddress(hModule, g_pszAVR2APIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in DLL '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszAVR2APIFunctions[i], pDLLName);
      FreeLibrary(hModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   else
/* In Linux, we assume the shared object is available (we would not have even
** got this far if not). Linux gives a helpful error message when attempting
** to run a dynamically linked program for which one or more of its shared
** object references can't be resolved. */
static int
LoadAVR2Library(
  API_AVR2* pApi)
{
  static const char* pSoName = "libadavr2.so";
  void* pModule = NULL;
  int i;
  void** ppFunctions;

  pModule = dlopen("libadavr2.so", RTLD_NOW);
  if (NULL == pModule) {
    printf("*** Cannot find shared library '%s'. This can be corrected by installing the AVR2 System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pSoName, pSoName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (void**)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszAVR2APIFunctions); i++) {
    void* pEntryPoint = dlsym(pModule, g_pszAVR2APIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in shared library '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszAVR2APIFunctions[i], pSoName);
      dlclose(pModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   endif

# endif

#endif


#if defined(AVR2_VIA_SMBUS_SUPPORTED)

# if defined(AVR2S_LIBRARY_STATIC)

/* AVR2S API library was statically linked, so no need to check for its presence. */
static int
LoadAVR2SLibrary(
  API_AVR2S* pApi)
{
  pApi->pfnAVR2S_Close = &AVR2S_Close;
  pApi->pfnAVR2S_Command = &AVR2S_Command;
  pApi->pfnAVR2S_GetStatusString = &AVR2S_GetStatusString;
  pApi->pfnAVR2S_OpenDevice = &AVR2S_OpenDevice;

  return EXIT_OK;
}

# else

static const char* g_pszAVR2SAPIFunctions[] = {
  "AVR2S_Close",
  "AVR2S_Command",
#   if defined(_UNICODE)
  "AVR2S_GetStatusStringW",
  "AVR2S_OpenDeviceW"
#   else
  "AVR2S_GetStatusStringA",
  "AVR2S_OpenDeviceA"
#   endif
};

#   if defined(_WIN32)
/* Windows - check for adavr2[d].dll using LoadLibrary(). If we can load it,
** we assume that subsequent delayed-loading of the DLL will succeed.
** This check is performance for Windows because if a delay-loaded DLL can't
** be found, the program crashes in a very unhelpful way, with no error
** message given to the user about why it crashed. */
static int
LoadAVR2SLibrary(
  API_AVR2S* pApi)
{
#     if defined(_DEBUG)
  static const char* pDLLName = "adavr2sd.dll";
#     else
  static const char* pDLLName = "adavr2s.dll";
#     endif
  HANDLE hModule;
  int i;
  FARPROC* ppFunctions;

  hModule = LoadLibraryA(pDLLName);
  if (NULL == hModule) {
    printf("*** Cannot find DLL '%s'. This can be corrected by installing the AVR2S System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pDLLName, pDLLName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (FARPROC*)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszAVR2SAPIFunctions); i++) {
    FARPROC pEntryPoint = GetProcAddress(hModule, g_pszAVR2SAPIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in DLL '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszAVR2SAPIFunctions[i], pDLLName);
      FreeLibrary(hModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   else
/* In Linux, we assume the shared object is available (we would not have even
** got this far if not). Linux gives a helpful error message when attempting
** to run a dynamically linked program for which one or more of its shared
** object references can't be resolved. */
static int
LoadAVR2SLibrary(
  API_AVR2S* pApi)
{
  static const char* pSoName = "libadavr2s.so";
  void* pModule = NULL;
  int i;
  void** ppFunctions;

  pModule = dlopen("libadavr2s.so", RTLD_NOW);
  if (NULL == pModule) {
    printf("*** Cannot find shared library '%s'. This can be corrected by installing the AVR2S System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pSoName, pSoName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (void**)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszAVR2SAPIFunctions); i++) {
    void* pEntryPoint = dlsym(pModule, g_pszAVR2SAPIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in shared library '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszAVR2SAPIFunctions[i], pSoName);
      dlclose(pModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   endif

# endif

#endif


#if defined(AVR2_VIA_IPMI_SUPPORTED)

# if defined(AVR2IPMI_LIBRARY_STATIC)

/* AVR2 IPMI library was statically linked, so no need to check for its presence. */
static int
LoadAVR2IPMILibrary(
  API_AVR2IPMI* pApi)
{
  pApi->pfnAVR2IPMI_CloseSession = &AVR2IPMI_CloseSession;
  pApi->pfnAVR2IPMI_Command = &AVR2IPMI_Command;
  pApi->pfnAVR2IPMI_GetBackends = &AVR2IPMI_GetBackends;
  pApi->pfnAVR2IPMI_GetErrorDetail = &AVR2IPMI_GetErrorDetail;
  pApi->pfnAVR2IPMI_GetStatusString = &AVR2IPMI_GetStatusString;
  pApi->pfnAVR2IPMI_OpenSession = &AVR2IPMI_OpenSession;
  pApi->pfnAVR2IPMI_ParseOptions = &AVR2IPMI_ParseOptions;

  return EXIT_OK;
}

# else

static const char* g_pszAVR2IPMIAPIFunctions[] = {
  "AVR2IPMI_CloseSession",
  "AVR2IPMI_Command",
  "AVR2IPMI_OpenSession",
#   if defined(_UNICODE)
  "AVR2IPMI_GetBackendsW",
  "AVR2IPMI_GetErrorDetailW",
  "AVR2IPMI_GetStatusStringW",
  "AVR2IPMI_ParseOptionsW"
#   else
  "AVR2IPMI_GetBackendsA",
  "AVR2IPMI_GetErrorDetailA",
  "AVR2IPMI_GetStatusStringA",
  "AVR2IPMI_ParseOptionsA"
#   endif
};

#   if defined(_WIN32)
/* Windows - check for adavripmi[d].dll using LoadLibrary(). If we can load it,
** we assume that subsequent delayed-loading of the DLL will succeed.
** This check is performance for Windows because if a delay-loaded DLL can't
** be found, the program crashes in a very unhelpful way, with no error
** message given to the user about why it crashed. */
static int
LoadAVR2IPMILibrary(
  API_AVR2IPMI* pApi)
{
#     if defined(_DEBUG)
  static const char* pDLLName = "adavr2ipmid.dll";
#     else
  static const char* pDLLName = "adavr2ipmi.dll";
#     endif
  HANDLE hModule;
  int i;
  FARPROC* ppFunctions;

  hModule = LoadLibraryA(pDLLName);
  if (NULL == hModule) {
    printf("*** Cannot find DLL '%s'. This can be corrected by installing the AVR2IPMI System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pDLLName, pDLLName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (FARPROC*)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszAVR2IPMIAPIFunctions); i++) {
    FARPROC pEntryPoint = GetProcAddress(hModule, g_pszAVR2IPMIAPIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in DLL '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszAVR2IPMIAPIFunctions[i], pDLLName);
      FreeLibrary(hModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   else
/* In Linux, we assume the shared object is available (we would not have even
** got this far if not). Linux gives a helpful error message when attempting
** to run a dynamically linked program for which one or more of its shared
** object references can't be resolved. */
static int
LoadAVR2IPMILibrary(
  API_AVR2IPMI* pApi)
{
  static const char* pSoName = "libadavr2ipmi.so";
  void* pModule = NULL;
  int i;
  void** ppFunctions;

  pModule = dlopen("libadavr2s.so", RTLD_NOW);
  if (NULL == pModule) {
    printf("*** Cannot find shared library '%s'. This can be corrected by installing the AVR2S System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pSoName, pSoName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (void**)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszAVR2IPMIAPIFunctions); i++) {
    void* pEntryPoint = dlsym(pModule, g_pszAVR2IPMIAPIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in shared library '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszAVR2IPMIAPIFunctions[i], pSoName);
      dlclose(pModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   endif

# endif

#endif


#if defined(AVR2_VIA_ADXDMA_SUPPORTED)

# if defined(ADXDMA_LIBRARY_STATIC)

/* AVR2 IPMI library was statically linked, so no need to check for its presence. */
static int
LoadADXDMALibrary(
  API_ADXDMA* pApi)
{
  pApi->pfnADXDMA_CloseBC = &ADXDMA_CloseBC;
  pApi->pfnADXDMA_CommandUC = &ADXDMA_CommandUC;
  pApi->pfnADXDMA_GetStatusString = &ADXDMA_GetStatusString;
  pApi->pfnADXDMA_GetUCStatus = &ADXDMA_GetUCStatus;
  pApi->pfnADXDMA_OpenBC = &ADXDMA_OpenBC;

  return EXIT_OK;
}

# else

static const char* g_pszADXDMAAPIFunctions[] = {
  "ADXDMA_CloseBC",
  "ADXDMA_CommandUC",
#   if defined(_UNICODE)
  "ADXDMA_GetStatusStringW",
#   else
  "ADXDMA_GetStatusStringA",
#   endif
  "ADXDMA_GetUCStatus",
  "ADXDMA_OpenBC"
};

#   if defined(_WIN32)
/* Windows - check for adxdma[d].dll using LoadLibrary(). If we can load it,
** we assume that subsequent delayed-loading of the DLL will succeed.
** This check is performance for Windows because if a delay-loaded DLL can't
** be found, the program crashes in a very unhelpful way, with no error
** message given to the user about why it crashed. */
static int
LoadADXDMALibrary(
  API_ADXDMA* pApi)
{
#     if defined(_DEBUG)
  static const char* pDLLName = "adxdmad.dll";
#     else
  static const char* pDLLName = "adxdma.dll";
#     endif
  HANDLE hModule;
  int i;
  FARPROC* ppFunctions;

  hModule = LoadLibraryA(pDLLName);
  if (NULL == hModule) {
    printf("*** Cannot find DLL '%s'. This can be corrected by installing the ADXDMA Driver, or copying '%s' to the same folder as this program.\n",
      pDLLName, pDLLName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (FARPROC*)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszADXDMAAPIFunctions); i++) {
    FARPROC pEntryPoint = GetProcAddress(hModule, g_pszADXDMAAPIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in DLL '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszADXDMAAPIFunctions[i], pDLLName);
      FreeLibrary(hModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   else
/* In Linux, we assume the shared object is available (we would not have even
** got this far if not). Linux gives a helpful error message when attempting
** to run a dynamically linked program for which one or more of its shared
** object references can't be resolved. */
static int
LoadADXDMALibrary(
  API_ADXDMA* pApi)
{
  static const char* pSoName = "libadxdma.so";
  void* pModule = NULL;
  int i;
  void** ppFunctions;

  pModule = dlopen(pSoName, RTLD_NOW);
  if (NULL == pModule) {
    printf("*** Cannot find shared library '%s'. This can be corrected by installing the AVR2S System Monitor Driver, or copying '%s' to the same folder as this program.\n",
      pSoName, pSoName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (void**)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszADXDMAAPIFunctions); i++) {
    void* pEntryPoint = dlsym(pModule, g_pszADXDMAAPIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in shared library '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszADXDMAAPIFunctions[i], pSoName);
      dlclose(pModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}
#   endif

# endif

#endif


# if defined(ADB3_LIBRARY_STATIC)

/* AVR2 API library was statically linked, so no need to check for its presence. */
static int
LoadADB3Library(
  API_ADB3* pApi)
{
  pApi->pfnADB3_Close = &ADB3_Close;
  pApi->pfnADB3_CommandAVR2 = &ADB3_CommandAVR2;
  pApi->pfnADB3_GetAVR2Status = &ADB3_GetAVR2Status;
  pApi->pfnADB3_GetStatusString = &ADB3_GetStatusString;
  pApi->pfnADB3_GetUniqueId = &ADB3_GetUniqueId;
  pApi->pfnADB3_Open = &ADB3_Open;

  return EXIT_OK;
}

#else

static const char* g_pszADB3APIFunctions[] = {
  "ADB3_Close",
  "ADB3_CommandAVR2",
  "ADB3_GetAVR2Status",
# if defined(_UNICODE)
  "ADB3_GetStatusStringW",
# else
  "ADB3_GetStatusStringA",
# endif
  "ADB3_GetUniqueId",
  "ADB3_Open"
};

# if defined(_WIN32)

/* Windows - check for adb3[d].dll using LoadLibrary(). If we can load it,
** we assume that subsequent delayed-loading of the DLL will succeed.
** This check is performance for Windows because if a delay-loaded DLL can't
** be found, the program crashes in a very unhelpful way, with no error
** message given to the user about why it crashed. */
static int
LoadADB3Library(
  API_ADB3* pApi)
{
#   if defined(_DEBUG)
  static const char* pDLLName = "adb3d.dll";
#   else
  static const char* pDLLName = "adb3.dll";
#   endif
  HANDLE hModule;
  FARPROC* ppFunctions;
  int i;

  hModule = LoadLibraryA(pDLLName);
  if (NULL == hModule) {
    printf("*** Cannot find DLL '%s'. This can be corrected by installing the ADB3 Driver.\n", pDLLName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (FARPROC*)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszADB3APIFunctions); i++) {
    FARPROC pEntryPoint = GetProcAddress(hModule, g_pszADB3APIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in DLL '%s'. This may indicate that the DLL version is too old to run this program.\n",
        g_pszADB3APIFunctions[i], pDLLName);
      FreeLibrary(hModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}

# else

/* In Linux, we assume the shared object is available (we would not have even
** got this far if not). Linux gives a helpful error message when attempting
** to run a dynamically linked program for which one or more of its shared
** object references can't be resolved. */
static int
LoadADB3Library(
  API_ADB3* pApi)
{
  static const char* pSoName = "libadb3.so";
  void* pModule = NULL;
  int i;
  void** ppFunctions;

  pModule = dlopen("libadb3.so", RTLD_NOW);
  if (NULL == pModule) {
    printf("*** Cannot find shared library '%s'. This can be corrected by installing the ADB3 Driver.\n",
      pSoName);
    return EXIT_LIBRARY_NOT_FOUND;
  }

  ppFunctions = (void**)pApi;
  for (i = 0; i < ARRAY_LENGTH(g_pszADB3APIFunctions); i++) {
    void* pEntryPoint = dlsym(pModule, g_pszADB3APIFunctions[i]);
    if (NULL == pEntryPoint) {
      printf("*** Cannot find entry point '%s' in shared library '%s'. This may indicate that the shared library version is too old to run this program.\n",
        g_pszADB3APIFunctions[i], pSoName);
      dlclose(pModule);
      return EXIT_LIBRARY_NOT_FOUND;
    }
    *ppFunctions++ = pEntryPoint;
  }

  return EXIT_OK;
}

# endif

#endif


static ADB3_STATUS
sampleAdb3OpenCard(
  unsigned int index,
  bool_t bByIndex,
  unsigned int serial,
  bool_t bBySerial,
  bool_t bReadOnly,
  ADB3_HANDLE* phDevice,
  API_ADB3* pApi)
{
  ADB3_STATUS status;
  ADB3_HANDLE hDevice;
  ADB3_UNIQUE_ID id;
  unsigned int i;

  if (bByIndex && bBySerial) {
    /* Attempt to open card with specified index and serial number */
    status = pApi->pfnADB3_Open(index, bReadOnly, 0, &hDevice);
    if (status != ADB3_SUCCESS) {
      return status;
    }
    status = pApi->pfnADB3_GetUniqueId(hDevice, &id);
    if (status != ADB3_SUCCESS) {
      return status;
    }
    if (id.SerialNumber == serial) {
      *phDevice = hDevice;
      return ADB3_SUCCESS;
    }
    return ADB3_DEVICE_NOT_FOUND;
  }

  if (bBySerial) {
    /* Attempt to open card with specified serial number */
    for (i = 0; i < 256; i++) {
      status = pApi->pfnADB3_Open(i, bReadOnly, 0, &hDevice);
      if (status != ADB3_SUCCESS) {
        if (status == ADB3_DEVICE_NOT_FOUND) {
          return status;
        }
        continue;
      }
      status = pApi->pfnADB3_GetUniqueId(hDevice, &id);
      if (status != ADB3_SUCCESS) {
        continue;
      }
      if (id.SerialNumber == serial) {
        *phDevice = hDevice;
        return ADB3_SUCCESS;
      }
      pApi->pfnADB3_Close(hDevice);
    }
    return ADB3_DEVICE_NOT_FOUND;
  } else {
    /* Attempt to open card with specified index */
    return pApi->pfnADB3_Open(index, bReadOnly, 0, phDevice);
  }
}

static void
dumpAvr2Command(
  const uint8_t* pBuffer,
  uint32_t length)
{
  uint32_t i;

  _tprintf(_T("DEBUG: AVR2 command[%lu] = { "), (unsigned long)length);
  for (i = 0; i < length; i++) {
    _tprintf(_T("%02X "), (unsigned int)pBuffer[i]);
  }
  _tprintf(_T("}\n"));
}

static void
dumpAvr2Response(
  const uint8_t* pBuffer,
  uint32_t expectedLength,
  uint32_t actualLength)
{
  uint32_t i, length;

  length = (actualLength < expectedLength) ? actualLength : expectedLength;
  _tprintf(_T("DEBUG: AVR2 response[%lu] = { "), (unsigned long)length);
  for (i = 0; i < length; i++) {
    _tprintf(_T("%02X "), (unsigned int)pBuffer[i]);
  }
  _tprintf(_T("}\n"));
  if (actualLength > expectedLength) {
    _tprintf(_T("DEBUG: %lu extra unexpected characters of actual AVR2 response were discarded.\n"),
      (unsigned long)(actualLength - expectedLength));
  }
}

int
avr2utilSendAvr2CommandEx(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t timeoutUs,
  const uint8_t* pCommand,
  uint32_t commandLength,
   /* If nonzero, changes SMBUS chip address between command and response */
   /* Ignored if not communicating with uC via SMBUS or IPMI+SMBUS */
  uint8_t chipAddrOverride,
  const uint8_t expResponse[2],
  uint8_t* pResponse,
  uint32_t responseLength, /* 0 => Skip receiving response (SMBUS / IPMI+SMBUS only) */
  uint32_t* pActualLength)
{
  if (bVerbose) {
    dumpAvr2Command(pCommand, commandLength);
  }

  /* Prevent compiler whining about unused parameter when neither SMBUS nor IPMI+SMBUS compiled in */
  (void)chipAddrOverride;

  switch (pDevice->nInterfaceType) {
#if defined(AVR2_VIA_USB_SUPPORTED)
  case Avr2utilInterfaceAVR2: {
    AVR2_STATUS status;

    status = pDevice->variant.avr2.api.pfnAVR2_Command(
      pDevice->variant.avr2.hDevice, 0, timeoutUs, commandLength, pCommand, responseLength, pResponse, pActualLength);
    if (AVR2_SUCCESS != status) {
      _tprintf(_T("*** Failed to send command to AVR2 uC via USB: %s\n"), pDevice->variant.avr2.api.pfnAVR2_GetStatusString(status, TRUE));
      return EXIT_AVR2_COMMAND_ERROR;
    }

    break;
  }
#endif

#if defined(AVR2_VIA_SMBUS_SUPPORTED)
  case Avr2utilInterfaceAVR2S: {
    AVR2S_STATUS status;
    uint32_t flags = 0;

    status = pDevice->variant.avr2s.api.pfnAVR2S_Command(
      pDevice->variant.avr2s.hDevice, flags, timeoutUs, commandLength, pCommand, chipAddrOverride, responseLength, pResponse, pActualLength);
    if (AVR2S_SUCCESS != status) {
      _tprintf(_T("*** Failed to send command to AVR2 uC via SMBUS: %s\n"), pDevice->variant.avr2s.api.pfnAVR2S_GetStatusString(status, TRUE));
      return EXIT_AVR2_COMMAND_ERROR;
    }

    break;
  }
#endif

#if defined(AVR2_VIA_IPMI_SUPPORTED)
  case Avr2utilInterfaceAVR2IPMI: {
    AVR2IPMI_STATUS status;
    uint32_t flags = 0;

    status = pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_Command(
      pDevice->variant.avr2ipmi.hSession, flags, timeoutUs, commandLength, pCommand, chipAddrOverride, responseLength, pResponse, pActualLength);
    if (AVR2IPMI_SUCCESS != status) {
      _tprintf(_T("*** Failed to send command to AVR2 uC via IPMI: %s\n"), pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_GetStatusString(status, TRUE));
      return EXIT_AVR2_COMMAND_ERROR;
    }

    break;
  }
#endif

#if defined(AVR2_VIA_ADXDMA_SUPPORTED)
  case Avr2utilInterfaceADXDMA: {
    ADB3_STATUS status;

    status = pDevice->variant.adxdma.api.pfnADXDMA_CommandUC(
      pDevice->variant.adxdma.hBC, 0, timeoutUs, commandLength, pCommand, responseLength, pResponse, pActualLength);
    if (ADB3_SUCCESS != status) {
      _tprintf(_T("*** Failed to send command to uC: %s\n"), pDevice->variant.adxdma.api.pfnADXDMA_GetStatusString(status, TRUE));
      return EXIT_AVR2_COMMAND_ERROR;
    }

    break;
  }
#endif

  case Avr2utilInterfaceADB3: {
    ADB3_STATUS status;

    status = pDevice->variant.adb3.api.pfnADB3_CommandAVR2(
      pDevice->variant.adb3.hDevice, 0, timeoutUs, commandLength, pCommand, responseLength, pResponse, pActualLength);
    if (ADB3_SUCCESS != status) {
      _tprintf(_T("*** Failed to send command to AVR2 uC: %s\n"), pDevice->variant.adb3.api.pfnADB3_GetStatusString(status, TRUE));
      return EXIT_AVR2_COMMAND_ERROR;
    }

    break;
  }

  default:
    /* Should never get here */
    assert(FALSE);
    break;
  }

  if (bVerbose) {
    dumpAvr2Response(pResponse, responseLength, *pActualLength);
  }

  if (*pActualLength != responseLength) {
    _tprintf(_T("+++ Unexpected AVR2 response length %lu bytes; expected %lu bytes.\n"),
      (unsigned long)*pActualLength, (unsigned long)responseLength);
  }

  if (*pActualLength < 2) {
    _tprintf(_T("+++ AVR2 response too short to be valid.\n"));
    return EXIT_AVR2_SHORT_RESPONSE;
  } else {
    if (pResponse[0] != expResponse[0] || pResponse[1] != expResponse[1]) {
      _tprintf(_T("+++ Unexpected AVR2 response code { 0x%02X, 0x%02X }; expected { 0x%02X, 0x%02X }.\n"),
        (unsigned int)pResponse[0], (unsigned int)pResponse[1],
        (unsigned int)expResponse[0], (unsigned int)expResponse[1]);
    }
  }

  return EXIT_OK;
}

int
avr2utilSendAvr2Command(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t timeoutUs,
  const uint8_t* pCommand,
  uint32_t commandLength,
  const uint8_t expResponse[2],
  uint8_t* pResponse,
  uint32_t responseLength, /* 0 => Skip receiving response (SMBUS / IPMI+SMBUS only) */
  uint32_t* pActualLength)
{
  return avr2utilSendAvr2CommandEx(
    pDevice,
    bVerbose,
    timeoutUs,
    pCommand,
    commandLength,
    0,
    expResponse,
    pResponse,
    responseLength,
    pActualLength);
}

static int
productIdCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bNoDisplay,
  uint32_t* pProductId)
{
  uint8_t command[2];
  uint8_t response[6];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint32_t productId;
  int ret = EXIT_OK;

  command[0] = 0x03; /* User command group */
  command[1] = 0x86; /* Product ID query */
  expResponse[0] = 0x03; /* User command group */
  expResponse[1] = 0x06; /* Product ID response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  productId = (uint32_t)(((uint32_t)response[2] <<  0) | ((uint32_t)response[3] <<  8) |
                         ((uint32_t)response[4] << 16) | ((uint32_t)response[5] << 24));
  if (!bNoDisplay) {
    _tprintf(_T("AVR2 firmware Product ID is %lu(0x%lX)\n"), (unsigned long)productId, (unsigned long)productId);
  }

  if (NULL != pProductId) {
    *pProductId = productId;
  }

  return EXIT_OK;
}

static int
commTestCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  const unsigned int testDurationMs = 2000;
  const unsigned int payloadLength = 32;
  const unsigned int maxErrorsDisplayed = 10;
  admxrc3_time_t duration, start, now, expire;
  uint8_t command[34];
  uint8_t response[34];
  uint8_t expResponse[2];
  uint32_t responseLength;
  size_t nLinkSent = 0, nLinkReceived = 0, nPayloadSent = 0, nPayloadReceived = 0;
  unsigned int i, errorCount = 0;
  uint8_t expected, actual, sequenceNumber;
  double elapsedSec;
  int ret = EXIT_OK;

  duration = doubleToTime((double)testDurationMs * 0.001);
  start = now = timeGet();
  expire = timeAdd(start, duration);

  memset(command, 0, sizeof(command));
  command[0] = 0x03; /* User command group */
  command[1] = 0x84; /* Loopback32 command */

  expResponse[0] = 0x03; /* User command group */
  expResponse[1] = 0x04; /* Loopback32 response */

  _tprintf(_T("Measuring data rate for %u ms using Loopback32 command...\n"), testDurationMs);

  sequenceNumber = 1;

  do {
    /* Set up loopback32 data. */
    for (i = 0; i < payloadLength; i++) {
      command[i + 2] = (uint8_t)(i + sequenceNumber);
    }

    /* Zero-out the response buffer. */
    memset(response, 0, sizeof(response));

    ret = avr2utilSendAvr2Command(
      pDevice,
      bVerbose,
      pDevice->nCommandTimeoutUs,
      command,
      sizeof(command),
      expResponse,
      response,
      sizeof(response),
      &responseLength);
    if (EXIT_OK != ret) {
      return ret;
    }

    /* Verify loopback32 response data; should be the same as the command data. */
    for (i = 0; i < payloadLength; i++) {
      expected = (uint8_t)(i + sequenceNumber);
      actual = response[i + 2];
      if (actual != expected) {
        if (errorCount < maxErrorsDisplayed) {
          _tprintf(_T("*** Error in loopback32 response data byte %u: expected=0x%02X actual=0x%02X\n"),
            i, expected, actual);
        } else if (errorCount == maxErrorsDisplayed) {
          _tprintf(_T("*** More errors in loopback32 response data.\n"));
        }
        errorCount++;
      }
    }

    nLinkSent += sizeof(command);
    nLinkReceived += sizeof(response);
    nPayloadSent += sizeof(command) - 2;
    nPayloadReceived += sizeof(response) - 2;

    if (errorCount) {
      break;
    }

    /* sequenceNumber is always in the range 1 .. 255 */
    if (0xFF == sequenceNumber) {
      sequenceNumber = 1;
    } else {
      sequenceNumber++;
    }

    now = timeGet();
  } while (timeBefore(now, expire));

  elapsedSec = timeToDouble(timeSubtract(now, start));

  if (elapsedSec >= 0.01) {
    _tprintf(_T("Link sent / received rate = %.1f / %.1f B/s\n"),
      (double)nLinkSent / (double)elapsedSec, (double)nLinkReceived / (double)elapsedSec);
    _tprintf(_T("Payload sent / received rate = %.1f / %.1f B/s\n"),
      (double)nPayloadSent / (double)elapsedSec, (double)nPayloadReceived / (double)elapsedSec);

    if (errorCount) {
      _tprintf(_T("*** NOTE: The computed data rates are not reliable because at least one error was detected in a loopback32 response payload.\n"));
    }
  } else {
    _tprintf(_T("*** Data rates not computed because the test did not run for long enough.\n"));
  }

  return EXIT_OK;
}

static int
enterExitServiceMode(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bEnterNotExit,
  bool_t bTestOnly)
{
  const TCHAR* pDescription = bEnterNotExit ? _T("Enter Service Mode") : _T("Exit Service Mode");
  uint8_t command[2];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  bool_t bNowInServiceMode;
  int ret = EXIT_OK;

  if ((bEnterNotExit && !pDevice->bEnterServiceModeRequestAllowed) || (!bEnterNotExit && !pDevice->bExitServiceModeRequestAllowed)) {
    _tprintf(_T("*** %s via %s is not supported.\n"), pDescription, pDevice->pszInterfaceName);
    return EXIT_MODE_CHANGE_FAILED;
  }

  if (bTestOnly) {
    /* Caller just wants to know if mode change will be allowed */
    return EXIT_OK;
  }

  if (bEnterNotExit) {
    _tprintf(_T("Entering service mode: "));
  } else {
    _tprintf(_T("Exiting service mode: "));
  }
  fflush(stdout);

  command[0] = 0x03; /* User command group */
  expResponse[0] = 0x03; /* User command group */
  if (bEnterNotExit) {
    command[1] = 0x80; /* ServiceMode command */
    expResponse[1] = 0x00; /* ServiceMode acknowledge response */
  } else {
    command[1] = 0x82; /* ApplicationMode command */
    expResponse[1] = 0x02; /* ApplicationMode acknowledge response */
  }

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    _tprintf(_T("*** AVR2 returned status 0x%02X for %s command\n"),
      (unsigned int)avr2Status, pDescription);
    return EXIT_AVR2_COMMAND_ERROR;
  }

  /* Verify that the uC has switched to the opposite mode */
  switch (pDevice->nInterfaceType) {
  case Avr2utilInterfaceAVR2:
  case Avr2utilInterfaceAVR2S:
  case Avr2utilInterfaceAVR2IPMI: {
    uint32_t productId;

    /* Give the uC enough time to reboot itself */
    sleepMs(pDevice->nRebootDelayMs);

    ret = productIdCommand(pDevice, bVerbose, TRUE, &productId);
    if (0 != ret) {
      _tprintf(_T("*** Failed to get AVR2 firmware Product ID after %s command.\n"), pDescription);
      return ret;
    }
    if (productId == DRAWING_NUM_BOOTMAN2 || productId == DRAWING_NUM_BOOTMAN2_ALT1 || productId == DRAWING_NUM_BOOTMAN2_ALT2) {
      bNowInServiceMode = TRUE;
    } else {
      bNowInServiceMode = FALSE;
    }

    if (bEnterNotExit) {
      if (!bNowInServiceMode) {
        _tprintf(_T("*** uC did not enter Service Mode as requested. This probably indicates that the BootMan2 version in the AVR2 uC does not support SMBUS communication and immediately exited Service Mode.\n"));
        return EXIT_MODE_CHANGE_FAILED;
      }
    } else {
      if (bNowInServiceMode) {
        _tprintf(_T("*** uC did not exit Service Mode as requested.\n"));
        return EXIT_MODE_CHANGE_FAILED;
      }
    }

    break;
  }

#if defined(AVR2_VIA_ADXDMA_SUPPORTED)
  case Avr2utilInterfaceADXDMA: {
    ADXDMA_STATUS status;
    ADXDMA_UC_STATUS avr2UcStatus;

    /* Give the uC enough time to reboot itself */
    sleepMs(pDevice->nRebootDelayMs);

    status = pDevice->variant.adxdma.api.pfnADXDMA_GetUCStatus(pDevice->variant.adxdma.hBC, &avr2UcStatus);
    if (status != ADXDMA_SUCCESS) {
      _tprintf(_T("*** Failed to get AVR2 status after %s command: %s\n"),
        pDescription, pDevice->variant.adxdma.api.pfnADXDMA_GetStatusString(status, TRUE));
      return EXIT_AVR2_STATUS_ERROR;
    }

    bNowInServiceMode = avr2UcStatus.Flags.ServiceMode ? TRUE : FALSE;
    if (bEnterNotExit) {
      if (!bNowInServiceMode) {
        _tprintf(_T("*** uC did not enter Service Mode as requested.\n"));
        return EXIT_MODE_CHANGE_FAILED;
      }
    } else {
      if (bNowInServiceMode) {
        _tprintf(_T("*** uC did not exit Service Mode as requested.\n"));
        return EXIT_MODE_CHANGE_FAILED;
      }
    }

    break;
  }
#endif

  case Avr2utilInterfaceADB3: {
    ADB3_STATUS status;
    ADB3_AVR2_STATUS avr2Status;

    /* Give the uC enough time to reboot itself */
    sleepMs(pDevice->nRebootDelayMs);

    status = pDevice->variant.adb3.api.pfnADB3_GetAVR2Status(pDevice->variant.adb3.hDevice, &avr2Status);
    if (status != ADB3_SUCCESS) {
      _tprintf(_T("*** Failed to get AVR2 status after %s command: %s\n"),
        pDescription, pDevice->variant.adb3.api.pfnADB3_GetStatusString(status, TRUE));
      return EXIT_AVR2_STATUS_ERROR;
    }

    bNowInServiceMode = avr2Status.Flags.ServiceMode ? TRUE : FALSE;
    if (bEnterNotExit) {
      if (!bNowInServiceMode) {
        _tprintf(_T("*** uC did not enter Service Mode as requested.\n"));
        return EXIT_MODE_CHANGE_FAILED;
      }
    } else {
      if (bNowInServiceMode) {
        _tprintf(_T("*** uC did not exit Service Mode as requested.\n"));
        return EXIT_MODE_CHANGE_FAILED;
      }
    }

    break;
  }

  default:
    bNowInServiceMode = bEnterNotExit;
    break;
  }

  pDevice->bInServiceMode = bNowInServiceMode;

  _tprintf(_T("OK\n"));
  if (pDevice->nInterfaceType == Avr2utilInterfaceAVR2) {
    _tprintf(_T("NOTE: If BootMan2 firmware does not support USB communication, it will exit Service Mode immediately.\n"));
  }

  return EXIT_OK;
}

static int
autoEnterExitServiceMode(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bEnterNotExit,
  bool_t bTestOnly)
{
  if (pDevice->bInServiceMode == bEnterNotExit) {
    return EXIT_OK;
  }

  if (!pDevice->bAutoEnterServiceMode) {
    _tprintf(_T("*** Automatically %s Service Mode via %s is not supported.\n"),
      bEnterNotExit ? _T("entering") : _T("exiting"), pDevice->pszInterfaceName);
    return EXIT_MODE_CHANGE_FAILED;
  }

  return enterExitServiceMode(pDevice, bVerbose, bEnterNotExit, bTestOnly);
}

static int
versionCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bNoDisplay,
  uint16_t* pVersion)
{
  uint8_t command[2];
  uint8_t response[10];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint16_t version[4];
  int ret = EXIT_OK;

  command[0] = 0x03; /* User command group */
  command[1] = 0x83; /* Version query */
  expResponse[0] = 0x03; /* User command group */
  expResponse[1] = 0x03; /* Version response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  version[0] = (uint16_t)(((uint16_t)response[2] << 0) | ((uint16_t)response[3] << 8));
  version[1] = (uint16_t)(((uint16_t)response[4] << 0) | ((uint16_t)response[5] << 8));
  version[2] = (uint16_t)(((uint16_t)response[6] << 0) | ((uint16_t)response[7] << 8));
  version[3] = (uint16_t)(((uint16_t)response[8] << 0) | ((uint16_t)response[9] << 8));
  if (!bNoDisplay) {
    _tprintf(_T("AVR2 %s version is %u.%u.%u.%u\n"),
      pDevice->bInServiceMode ? _T("BootMan2") : _T("BoardMan2"),
      (unsigned int)version[0], (unsigned int)version[1], (unsigned int)version[2], (unsigned int)version[3]);
  }

  if (NULL != pVersion) {
    pVersion[0] = version[0];
    pVersion[1] = version[1];
    pVersion[2] = version[2];
    pVersion[3] = version[3];
  }

  return EXIT_OK;
}

static int
getSMBUSChipAddrCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bGetNonvolatile)
{
  uint8_t command[4];
  uint8_t response[4];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  uint8_t nChipAddr;
  int ret = EXIT_OK;

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x93; /* Get SMBUS chip address command */
  command[2] = (uint8_t)(bGetNonvolatile ? 0x2 : 0x1); /* 0x1 => get address volatile, 0x2 => get address nonvolatile */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x13; /* Set SMBUS chip address response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned error status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  nChipAddr = response[3];

  if (bGetNonvolatile) {
    if (0 == nChipAddr) {
      _tprintf(_T("Nonvolatile SMBUS chip address is 0.\n"));
      _tprintf(_T("The microcontroller will disable its SMBUS interface when it next reboots.\n"));
    } else {
      _tprintf(_T("Nonvolatile SMBUS chip address is 0x%02X.\n"), nChipAddr);
      _tprintf(_T("The microcontroller will enable its SMBUS interface when it next reboots.\n"));
    }
  } else {
    if (0 == nChipAddr) {
      _tprintf(_T("Current SMBUS chip address is 0.\n"));
      _tprintf(_T("The microcontroller's SMBUS interface is currently disabled.\n"));
    } else {
      _tprintf(_T("Current SMBUS chip address is 0x%02X.\n"), nChipAddr);
      _tprintf(_T("The microcontroller's SMBUS interface is currently enabled.\n"));
    }
  }

done:
  return ret;
}

static int
setSMBUSChipAddrCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bSetNonvolatile,
  unsigned int nChipAddr)
{
  uint8_t command[4];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  if (nChipAddr > 0x7FU) {
    _tprintf(_T("*** SMBUS chip address be in the range 0 to 127(0x7F).\n"));
    return EXIT_INVALID_INDEX;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x92; /* Set SMBUS chip address command */
  command[2] = (uint8_t)(bSetNonvolatile ? 0x2 : 0x1); /* 0x1 => set address volatile, 0x2 => set address nonvolatile */
  command[3] = (uint8_t)nChipAddr; /* 7-bit SMBUS chip address; cast safe due to above range check */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x12; /* Set SMBUS chip address response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2CommandEx(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    /* If changing volatile SMBUS chip address, need to change address that we use between command and response... */
    (uint8_t)(bSetNonvolatile ? 0 : nChipAddr), /* Cast safe due to above range check */
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid SMBUS chip address");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned error status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  if (bSetNonvolatile) {
    if (0 == nChipAddr) {
      _tprintf(_T("The microcontroller's nonvolatile SMBUS chip address has been set to 0.\n"));
      _tprintf(_T("The microcontroller will disable its SMBUS interface when it next reboots.\n"));
    } else {
      _tprintf(_T("The microcontroller's nonvolatile SMBUS chip address has been set to 0x%02X.\n"), nChipAddr);
      _tprintf(_T("The microcontroller will enable its SMBUS interface when it next reboots.\n"));
    }

  } else {
    if (0 == nChipAddr) {
      _tprintf(_T("The microcontroller's volatile SMBUS chip address has been set to 0.\n"));
      _tprintf(_T("This has disabled the microcontroller's SMBUS interface.\n"));
    } else {
      _tprintf(_T("The microcontroller's volatile SMBUS chip address has been set to 0x%02X.\n"), nChipAddr);
      _tprintf(_T("This has enabled the microcontroller's SMBUS interface.\n"));
    }
    _tprintf(_T("This condition will persist until the microcontroller next reboots.\n"));
  }

  _tprintf(_T("The microcontroller can be made to reboot by either (a) removing and then\n"));
  _tprintf(_T("restoring all power including standby power, or (b) entering and exiting Service\n"));
  _tprintf(_T("Mode.\n"));

done:
  return ret;
}

static int
getClkCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int clockIndex)
{
  uint8_t command[3];
  uint8_t response[7];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  uint32_t frequency;
  int ret = EXIT_OK;

  if (clockIndex > 0xFFU) {
    _tprintf(_T("*** Clock generator index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The getclk command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x8F; /* GetFrequency query */
  command[2] = (uint8_t)clockIndex; /* Clock generator index; cast safe due to above range check. */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x0F; /* GetFrequency response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid clock generator index");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned error status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  frequency = ((uint32_t)response[3] << 0) | ((uint32_t)response[4] << 8) | ((uint32_t)response[5] << 16) | ((uint32_t)response[6] << 24);
  _tprintf(_T("Frequency of clock generator %u is %lu Hz\n"),
    clockIndex, (unsigned long)frequency);

done:
  return ret;
}

static int
setClkCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int clockIndex,
  uint32_t frequency)
{
  uint8_t command[7];
  uint8_t response[7];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  if (clockIndex > 0xFFU) {
    _tprintf(_T("*** Clock generator index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The setclk command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x8E; /* SetFrequency query */
  command[2] = (uint8_t)clockIndex; /* Clock generator index; cast safe due to above range check. */
  command[3] = (uint8_t)((frequency >> 0) & 0xFFU); /* Frequency bits [7:0] */
  command[4] = (uint8_t)((frequency >> 8) & 0xFFU); /* Frequency bits [15:8] */
  command[5] = (uint8_t)((frequency >> 16) & 0xFFU); /* Frequency bits [23:16] */
  command[6] = (uint8_t)((frequency >> 24) & 0xFFU); /* Frequency bits [31:24] */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x0E; /* SetFrequency response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid clock generator index");
      break;

    case 17:
      pReason = _T("Requested frequency is out of range");
      break;

    case 33:
      pReason = _T("Microcontroller failed to communicate with SI5338");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  _tprintf(_T("Frequency for clock generator %u set to %lu Hz\n"), clockIndex, (unsigned long)frequency);

done:
  return ret;
}
static int
getClkNvCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int clockIndex)
{
  uint8_t command[4];
  uint8_t response[7];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  uint32_t frequency;
  bool_t bIsOverridden;
  int ret = EXIT_OK;

  if (clockIndex > 0xFFU) {
    _tprintf(_T("*** Clock generator index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The getclknv command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x84; /* GetFrequencyEx query */
  command[2] = (uint8_t)clockIndex; /* Clock generator index; cast safe due to above range check. */
  command[3] = 0x1; /* Flags: 0x1 => Get NV frequency value */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x04; /* GetFrequencyEx response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid clock generator index");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned error status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  frequency = ((uint32_t)response[3] << 0) | ((uint32_t)response[4] << 8) | ((uint32_t)response[5] << 16) | ((uint32_t)response[6] << 24);
  bIsOverridden = (frequency != 0U && frequency != 0xFFFFFFFFU);
  if (bIsOverridden) {
    _tprintf(_T("NV override frequency for clock generator %u is %lu Hz\n"),
      clockIndex, (unsigned long)frequency);
  } else {
    _tprintf(_T("NV override frequency for clock generator %u is %lu(0x%lX), which will not result in programming at power-up.\n"),
      clockIndex, (unsigned long)frequency, (unsigned long)frequency);
  }

done:
  return ret;
}

static int
setClkNvCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int clockIndex,
  uint32_t frequency)
{
  uint8_t command[8];
  uint8_t response[7];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  bool_t bIsOverridden;
  int ret = EXIT_OK;

  if (clockIndex > 0xFFU) {
    _tprintf(_T("*** Clock generator index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The setclknv command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x83; /* SetFrequencyEx query */
  command[2] = (uint8_t)clockIndex; /* Clock generator index; cast safe due to above range check. */
  command[3] = (uint8_t)((frequency >> 0) & 0xFFU); /* Frequency bits [7:0] */
  command[4] = (uint8_t)((frequency >> 8) & 0xFFU); /* Frequency bits [15:8] */
  command[5] = (uint8_t)((frequency >> 16) & 0xFFU); /* Frequency bits [23:16] */
  command[6] = (uint8_t)((frequency >> 24) & 0xFFU); /* Frequency bits [31:24] */
  command[7] = 0x3; /* Flags: 0x1 => Set NV frequency value, 0x2 => Don't program clock generator now */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x03; /* SetFrequencyEx response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid clock generator index");
      break;

    case 2:
      pReason = _T("Clock generator frequency cannot be overridden");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  bIsOverridden = (frequency != 0U && frequency != 0xFFFFFFFFU);

  if (bIsOverridden) {
    _tprintf(_T("NV override frequency for clock generator %u set to %lu Hz\n"),
      clockIndex, (unsigned long)frequency);
  } else {
    _tprintf(_T("NV override frequency for clock generator %u set to %lu(0x%lX), which will not result in programming at power-up.\n"),
      clockIndex, (unsigned long)frequency,  (unsigned long)frequency);
  }

done:
  return ret;
}

static int
i2cReadToFileCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  unsigned int length,
  const TCHAR* pFilename)
{
  uint8_t command[6];
  uint8_t response[4];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  FILE* pFile = NULL;
  uint8_t* pBuffer = NULL;
  size_t position, nWritten;
  int ret = EXIT_OK;

  if (bus > 0xFFU) {
    _tprintf(_T("*** I2C bus number be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_BUS;
  }
  if (dev > 0x7FU) {
    _tprintf(_T("*** I2C device number must be in the range 0 to 127.\n"));
    return EXIT_INVALID_I2C_DEVICE;
  }
  if (address > 0xFFU) {
    _tprintf(_T("*** Address must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_ADDRESS;
  }

  pBuffer = (uint8_t*)malloc(length);
  if (NULL == pBuffer) {
    _tprintf(_T("*** Failed to allocate data buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The i2c-read-to-file command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  for (position = 0; position < length; position++) {
    command[0] = 0x05; /* User extended command group */
    command[1] = 0x80; /* I2CRead command */
    command[2] = (uint8_t)bus; /* I2C bus number */
    command[3] = (uint8_t)dev; /* I2C device number */
    command[4] = (uint8_t)address; /* Address within device */
    command[5] = (uint8_t)1; /* Read 1 byte */
    expResponse[0] = 0x05; /* User extended command group */
    expResponse[1] = 0x00; /* I2CRead response */

    memset(response, 0, sizeof(response));
    ret = avr2utilSendAvr2Command(
      pDevice,
      bVerbose,
      pDevice->nCommandTimeoutUs,
      command,
      sizeof(command),
      expResponse,
      response,
      sizeof(response),
      &responseLength);
    if (EXIT_OK != ret) {
      goto out;
    }

    avr2Status = response[2];
    if (0 != avr2Status) {
      const TCHAR* pReason;

      switch (avr2Status) {
      case 1:
        pReason = _T("General failure");
        break;

      default:
        pReason = _T("** UNEXPECTED ERROR CODE **");
        break;
      }
      _tprintf(_T("*** AVR2 returned status 0x%02X for byte %llu => %s\n"),
        (unsigned int)response[2], (unsigned long long)position, pReason);
      ret = EXIT_AVR2_BAD_STATUS;
      goto out;
    }

    pBuffer[position] = response[3];

    address++;
  }

out:
  if (0 != _tfopen_s(&pFile, pFilename, _T("wt"))) {
    _tprintf(_T("*** Failed to open file '%s' for writing.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }

  nWritten = fwrite(pBuffer, 1, position, pFile);
  if (nWritten != (size_t)position) {
    _tprintf(_T("*** Failed to write expected number of bytes to file '%s'.\n"), pFilename);
    ret = EXIT_I2C_WRITE_FILE_FAILED;
    goto done;
  }
  fclose(pFile);
  pFile = NULL;

done:
  if (NULL != pBuffer) {
    free(pBuffer);
  }
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
i2cVerifyWithFileCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  const TCHAR* pFilename)
{
  const unsigned int maxErrorReported = 20;
  uint8_t command[6];
  uint8_t response[4];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  FILE* pFile = NULL;
  uint8_t* pFileBuffer = NULL;
  uint8_t* pReadBuffer = NULL;
  long length, position;
  unsigned int currentAddress;
  size_t nRead;
  unsigned int errorCount = 0;
  int ret = EXIT_OK;

  if (bus > 0xFFU) {
    _tprintf(_T("*** I2C bus number be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_BUS;
  }
  if (dev > 0x7FU) {
    _tprintf(_T("*** I2C device number must be in the range 0 to 127.\n"));
    return EXIT_INVALID_I2C_DEVICE;
  }
  if (address > 0xFFU) {
    _tprintf(_T("*** Address must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_ADDRESS;
  }

  if (0 != _tfopen_s(&pFile, pFilename, _T("rb"))) {
    _tprintf(_T("*** Failed to open file '%s' for reading.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_END)) {
    _tprintf(_T("*** Failed to seek to end of file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  length = ftell(pFile);
  if (length < 0) {
    _tprintf(_T("*** Failed to get length of file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_SET)) {
    _tprintf(_T("*** Failed to seek to beginning of file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  _tprintf(_T("File '%s' length is %u(0x%X) byte(s).\n"),
    pFilename, (unsigned int)length, (unsigned int)length); /* Cast safe due to previous range checks */

  pReadBuffer = (uint8_t*)malloc(length);
  if (NULL == pReadBuffer) {
    _tprintf(_T("*** Failed to allocate read data buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  pFileBuffer = (uint8_t*)malloc(length);
  if (NULL == pFileBuffer) {
    _tprintf(_T("*** Failed to allocate file data buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  nRead = fread(pFileBuffer, 1, length, pFile);
  if (nRead != (size_t)length) {
    _tprintf(_T("*** Failed to read expected number of bytes from file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  fclose(pFile);
  pFile = NULL;

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The i2c-verify-with-file command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  currentAddress = address;
  for (position = 0; position < length; position++) {
    command[0] = 0x05; /* User extended command group */
    command[1] = 0x80; /* I2CRead command */
    command[2] = (uint8_t)bus; /* I2C bus number */
    command[3] = (uint8_t)dev; /* I2C device number */
    command[4] = (uint8_t)currentAddress; /* Address within device */
    command[5] = (uint8_t)1; /* Read 1 byte */
    expResponse[0] = 0x05; /* User extended command group */
    expResponse[1] = 0x00; /* I2CRead response */

    memset(response, 0, sizeof(response));
    ret = avr2utilSendAvr2Command(
      pDevice,
      bVerbose,
      pDevice->nCommandTimeoutUs,
      command,
      sizeof(command),
      expResponse,
      response,
      sizeof(response),
      &responseLength);
    if (EXIT_OK != ret) {
      goto done;
    }

    avr2Status = response[2];
    if (0 != avr2Status) {
      const TCHAR* pReason;

      switch (avr2Status) {
      case 1:
        pReason = _T("General failure");
        break;

      default:
        pReason = _T("** UNEXPECTED ERROR CODE **");
        break;
      }
      _tprintf(_T("*** AVR2 returned status 0x%02X for byte %ld => %s\n"), (unsigned int)response[2], position, pReason);
      ret = EXIT_AVR2_BAD_STATUS;
      goto done;
    }

    pReadBuffer[position] = response[3];

    currentAddress++;
  }

  currentAddress = address;
  for (position = 0; position < length; position++) {
    uint8_t expected = pFileBuffer[position];
    uint8_t actual = pReadBuffer[position];

    if (actual != expected) {
      if (errorCount < maxErrorReported) {
        if (expected != actual) {
          _tprintf(_T("*** Verification error at address 0x%lX; expected=0x%02X actual=0x%02X\n"),
            (unsigned long)currentAddress, (unsigned int)expected, (unsigned int)actual);
        }
      } else if (errorCount == maxErrorReported) {
        _tprintf(_T("*** More than %u verification errors detected.\n"), maxErrorReported);
      }
      errorCount++;
    }
    currentAddress++;
  }

  if (errorCount) {
    _tprintf(_T("*** Total of %u verification errors detected.\n"), errorCount);
    ret = EXIT_VERIFY_FAILED;
  } else {
    _tprintf(_T("Verified OK.\n"));
  }

done:
  if (NULL != pReadBuffer) {
    free(pReadBuffer);
  }
  if (NULL != pFileBuffer) {
    free(pFileBuffer);
  }
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
i2cWriteFromFileCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  const TCHAR* pFilename)
{
  uint8_t command[7];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  FILE* pFile = NULL;
  uint8_t* pBuffer = NULL;
  long length, position;
  size_t nRead;
  int ret = EXIT_OK;

  if (bus > 0xFFU) {
    _tprintf(_T("*** I2C bus number be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_BUS;
  }
  if (dev > 0x7FU) {
    _tprintf(_T("*** I2C device number must be in the range 0 to 127.\n"));
    return EXIT_INVALID_I2C_DEVICE;
  }
  if (address > 0xFFU) {
    _tprintf(_T("*** Address must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_ADDRESS;
  }

  if (0 != _tfopen_s(&pFile, pFilename, _T("rb"))) {
    _tprintf(_T("*** Failed to open file '%s' for reading.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_END)) {
    _tprintf(_T("*** Failed to seek to end of file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  length = ftell(pFile);
  if (length < 0) {
    _tprintf(_T("*** Failed to get length of file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_SET)) {
    _tprintf(_T("*** Failed to seek to beginning of file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  _tprintf(_T("File '%s' length is %u(0x%X) byte(s).\n"),
    pFilename, (unsigned int)length, (unsigned int)length); /* Cast safe due to previous range checks */

  pBuffer = (uint8_t*)malloc(length);
  if (NULL == pBuffer) {
    _tprintf(_T("*** Failed to allocate data buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  nRead = fread(pBuffer, 1, length, pFile);
  if (nRead != (size_t)length) {
    _tprintf(_T("*** Failed to read expected number of bytes from file '%s'.\n"), pFilename);
    ret = EXIT_I2C_READ_FILE_FAILED;
    goto done;
  }
  fclose(pFile);
  pFile = NULL;

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The i2c-write-from-file command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  for (position = 0; position < length; position++) {
    command[0] = 0x05; /* User extended command group */
    command[1] = 0x82; /* I2CWrite command */
    command[2] = (uint8_t)bus; /* I2C bus number */
    command[3] = (uint8_t)dev; /* I2C device number */
    command[4] = (uint8_t)address; /* Address within device */
    command[5] = (uint8_t)1; /* Write 1 byte */
    command[6] = pBuffer[position]; /* The byte to write */
    expResponse[0] = 0x05; /* User extended command group */
    expResponse[1] = 0x02; /* I2CWrite response */

    memset(response, 0, sizeof(response));
    ret = avr2utilSendAvr2Command(
      pDevice,
      bVerbose,
      pDevice->nCommandTimeoutUs,
      command,
      sizeof(command),
      expResponse,
      response,
      sizeof(response),
      &responseLength);
    if (EXIT_OK != ret) {
      goto done;
    }

    avr2Status = response[2];
    if (0 != avr2Status) {
      const TCHAR* pReason;

      switch (avr2Status) {
      case 1:
        pReason = _T("General failure");
        break;

      default:
        pReason = _T("** UNEXPECTED ERROR CODE **");
        break;
      }
      _tprintf(_T("*** AVR2 returned status 0x%02X for byte %ld => %s\n"), (unsigned int)response[2], position, pReason);
      ret = EXIT_AVR2_BAD_STATUS;
      goto done;
    }

    address++;
  }

done:
  if (NULL != pBuffer) {
    free(pBuffer);
  }
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
i2cReadCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  unsigned int length)
{
  uint8_t command[6];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  uint8_t* pResponse = NULL;
  unsigned int position, expResponseLength;
  int ret = EXIT_OK;

  if (bus > 0xFFU) {
    _tprintf(_T("*** I2C bus number be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_BUS;
  }
  if (dev > 0x7FU) {
    _tprintf(_T("*** I2C device number must be in the range 0 to 127.\n"));
    return EXIT_INVALID_I2C_DEVICE;
  }
  if (address > 0xFFU) {
    _tprintf(_T("*** Address must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_ADDRESS;
  }
  if (length > 0xFFU) {
    _tprintf(_T("*** Byte count to return must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_COUNT;
  }

  expResponseLength = length + 3;
  pResponse = (uint8_t*)malloc(expResponseLength);
  if (NULL == pResponse) {
    _tprintf(_T("*** Failed to allocate response buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The i2c-read command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x80; /* I2CRead command */
  command[2] = (uint8_t)bus; /* I2C bus number */
  command[3] = (uint8_t)dev; /* I2C device number */
  command[4] = (uint8_t)address; /* Address within device */
  command[5] = (uint8_t)length; /* Number of bytes to read, returned in response */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x00; /* I2CRead response */

  memset(pResponse, 0, expResponseLength);
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    pResponse,
    expResponseLength,
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = pResponse[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("General failure");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"),
      (unsigned int)pResponse[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  for (position = 0; position < length; position++) {
    _tprintf(_T("%02X "), pResponse[position + 3]);
  }
  _tprintf(_T("\n"));

done:
  if (NULL != pResponse) {
    free(pResponse);
  }

  return ret;
}

static int
i2cWriteCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  unsigned int length,
  const uint8_t* pBytes)
{
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  uint8_t* pCommand = NULL;
  unsigned int position, commandLength;
  int ret = EXIT_OK;

  if (bus > 0xFFU) {
    _tprintf(_T("*** I2C bus number be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_BUS;
  }
  if (dev > 0x7FU) {
    _tprintf(_T("*** I2C device number must be in the range 0 to 127.\n"));
    return EXIT_INVALID_I2C_DEVICE;
  }
  if (address > 0xFFU) {
    _tprintf(_T("*** Address must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_ADDRESS;
  }
  if (length > 0xFFU) {
    _tprintf(_T("*** Byte count to write must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_COUNT;
  }

  commandLength = length + 6;
  pCommand = (uint8_t*)malloc(commandLength);
  if (NULL == pCommand) {
    _tprintf(_T("*** Failed to allocate command buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The i2c-write command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  pCommand[0] = 0x05; /* User extended command group */
  pCommand[1] = 0x82; /* I2CWrite command */
  pCommand[2] = (uint8_t)bus; /* I2C bus number */
  pCommand[3] = (uint8_t)dev; /* I2C device number */
  pCommand[4] = (uint8_t)address; /* Address within device */
  pCommand[5] = (uint8_t)length;
  for (position = 0; position < length; position++) {
    pCommand[position + 6] = pBytes[position];
  }
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x02; /* I2CWrite response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    pCommand,
    commandLength,
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("General failure");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

done:
  if (NULL != pCommand) {
    free(pCommand);
  }

  return ret;
}

static int
i2cWriteReadCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int bus,
  unsigned int dev,
  unsigned int writeCount,
  unsigned int readCount,
  const uint8_t* pBytes)
{
  uint8_t expResponse[2];
  uint32_t expectedResponseLength, responseLength;
  uint8_t avr2Status;
  uint8_t* pCommand = NULL;
  uint8_t* pResponse = NULL;
  unsigned int position, commandLength;
  unsigned int actualTransferCount, expectedTransferCount, minimumReadTransferCount;
  unsigned int actualReadCount;
  int ret = EXIT_OK;

  if (bus > 0xFFU) {
    _tprintf(_T("*** I2C bus number be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_BUS;
  }
  if (dev > 0x7FU) {
    _tprintf(_T("*** I2C device number must be in the range 0 to 127.\n"));
    return EXIT_INVALID_I2C_DEVICE;
  }
  if (writeCount > 0xFFU) {
    _tprintf(_T("*** Byte count to write must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_COUNT;
  }
  if (readCount > 0xFFU) {
    _tprintf(_T("*** Byte count to read must be in the range 0 to 255.\n"));
    return EXIT_INVALID_I2C_COUNT;
  }

  commandLength = writeCount + 6;
  pCommand = (uint8_t*)malloc(commandLength);
  if (NULL == pCommand) {
    _tprintf(_T("*** Failed to allocate command buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  expectedResponseLength = readCount + 4;
  pResponse = (uint8_t*)malloc(expectedResponseLength);
  if (NULL == pResponse) {
    _tprintf(_T("*** Failed to allocate response buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The i2c-write-read command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  pCommand[0] = 0x05; /* User extended command group */
  pCommand[1] = 0x94; /* I2CWriteRead command */
  pCommand[2] = (uint8_t)bus; /* I2C bus number */
  pCommand[3] = (uint8_t)dev; /* I2C device number */
  pCommand[4] = (uint8_t)writeCount;
  pCommand[5] = (uint8_t)readCount;
  for (position = 0; position < writeCount; position++) {
    pCommand[position + 6] = pBytes[position];
  }
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x14; /* I2CWriteRead response */

  memset(pResponse, 0, expectedResponseLength);
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    pCommand,
    commandLength,
    expResponse,
    pResponse,
    expectedResponseLength,
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = pResponse[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid I2C bus number");
      break;

    case 2:
      pReason = _T("I2C slave NACKed, or transaction timed out.");
      break;

    case 3:
      pReason = _T("Invalid write byte count.");
      break;

    case 4:
      pReason = _T("Invalid read byte count.");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)pResponse[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
    goto done;
  }

  actualTransferCount = pResponse[3];

  expectedTransferCount = 0;
  minimumReadTransferCount = 0;
  if (writeCount) {
    minimumReadTransferCount += 1 + writeCount;
    expectedTransferCount += 1 + writeCount;
  }
  if (readCount) {
    minimumReadTransferCount += 1;
    expectedTransferCount += 1 + readCount;
  }

  if (actualTransferCount > expectedTransferCount) {
    _tprintf(_T("+++ Reponse from uC indicates that it transferred more than requested number of bytes; actual %u vs. expected %u\n"), actualTransferCount, expectedTransferCount);
    actualTransferCount = expectedTransferCount;
  } else if (actualTransferCount < expectedTransferCount) {
    _tprintf(_T("+++ Reponse from uC indicates that it transferred less than requested number of bytes; actual %u vs. expected %u\n"), actualTransferCount, expectedTransferCount);
  }

  if (writeCount) {
    if (actualTransferCount < 1 + writeCount) {
      _tprintf(_T("+++ Reponse from uC indicates that write phase was truncated.\n"));
    }
  }

  if (readCount) {
    if (actualTransferCount > minimumReadTransferCount) {
      if (actualTransferCount < expectedTransferCount) {
        _tprintf(_T("+++ Reponse from uC indicates that read phase was truncated.\n"));
      }
      actualReadCount = actualTransferCount - minimumReadTransferCount;
      for (position = 0; position < actualReadCount; position++) {
        _tprintf(_T("%02X "), pResponse[position + 4]);
      }
      _tprintf(_T("\n"));
    } else {
      _tprintf(_T("+++ Reponse from uC indicates that no bytes were successfully read.\n"));
    }
  }

done:
  if (NULL != pResponse) {
    free(pResponse);
  }

  if (NULL != pCommand) {
    free(pCommand);
  }

  return ret;
}

static int
spiRawCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  unsigned int readCount,
  unsigned int writeCount,
  const uint8_t* pWriteBytes)
{
  const unsigned int maxChunk = 255;
  uint8_t command[260]; /* Worst-case command length (writeCount is 255) */
  uint8_t response[258]; /* Worst-case response length (readCount is 255) */
  uint8_t expResponse[2];
  uint32_t responseLength, actualResponseLength;
  uint8_t avr2Status;
  uint8_t* pReadBuffer = NULL;
  uint8_t readChunk, writeChunk;
  unsigned int i, readPos, writePos, commandLength;
  int ret = EXIT_OK;

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  pReadBuffer = (uint8_t*)malloc(readCount);
  if (NULL == pReadBuffer) {
    _tprintf(_T("*** Failed to allocate read data buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-raw command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  readPos = 0;
  writePos = 0;

  while (writeCount || readCount) {
    if (writeCount > maxChunk) {
      writeChunk = (uint8_t)maxChunk;
      /* Can't do any reads until writeCount is 255 or less */
      readChunk = 0;
    } else {
      writeChunk = (uint8_t)writeCount;
      /* writeCount is 255 or less, so can read some data */
      readChunk = (uint8_t)((readCount > maxChunk) ? maxChunk : readCount);
    }

    commandLength = 5 + writeChunk;
    responseLength = 3 + readChunk;

    command[0] = 0x05; /* User extended command group */
    command[1] = 0x90; /* Raw SPI command */
    command[2] = (uint8_t)chipIndex; /* SPI chip index */
    command[3] = writeChunk; /* Number of bytes to write */
    command[4] = readChunk; /* Number of bytes to read */
    memcpy(&command[5], pWriteBytes + writePos, writeChunk);
    expResponse[0] = 0x05; /* User extended command group */
    expResponse[1] = 0x10; /* Raw SPI response */

    memset(response, 0, sizeof(response));
    ret = avr2utilSendAvr2Command(
      pDevice,
      bVerbose,
      pDevice->nCommandTimeoutUs,
      command,
      commandLength,
      expResponse,
      response,
      responseLength,
      &actualResponseLength);
    if (EXIT_OK != ret) {
      goto done;
    }

    avr2Status = response[2];
    if (0 != avr2Status) {
      const TCHAR* pReason;

      switch (avr2Status) {
      case 1:
        pReason = _T("Invalid SPI chip index");
        break;

      case 2:
        pReason = _T("The board appears to be powered off (standby power only). SPI accesses require the board to be powered on.");
        break;

      default:
        pReason = _T("** UNEXPECTED ERROR CODE **");
        break;
      }
      _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
      ret = EXIT_AVR2_BAD_STATUS;
      goto out;
    }

    memcpy(pReadBuffer + readPos, &response[3], readChunk);

    writePos += writeChunk;
    writeCount -= writeChunk;
    readPos += readChunk;
    readCount -= readChunk;
  }

out:
  for (i = 0; i < readPos; i++) {
    _tprintf(_T("%02X "), pReadBuffer[i]);
  }
  _tprintf(_T("\n"));

done:
  if (NULL != pReadBuffer) {
    free(pReadBuffer);
  }

  return ret;
}

static int
spiInfoCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex)
{
  SFDPHeader header;
  SFDPTableHeader tableHeader;
  int ret = EXIT_OK, ret2;
  unsigned int i, standardTableSize, tableSize, readLength;
  uint32_t signature, pointer24;
  uint16_t tableID;
  bool_t bIsStandardTable;
  void* pTable = NULL;

  assert(sizeof(SFDPHeader) == 8); /* As per JEDEC JESD216B */
  assert(sizeof(SFDPTableHeader) == 8); /* As per JEDEC JESD216B */
  assert(sizeof(SFDPTable) == 64); /* As per JEDEC JESD216B */

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-info command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  ret = avr2utilSpiFlashHardwareReset(pDevice, bVerbose);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to perform hardware reset of all SPI Flash chips.\n"));
    goto done;
  }

  /* Inform the uC that a lengthy SPI Flash operation is commencing */
  ret = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to inform uC that a lengthy SPI Flash operation is commencing.\n"));
    goto done;
  }

  ret = avr2utilSpiFlashReadSFDP(pDevice, bVerbose, chipIndex, 0, (uint8_t*)&header, sizeof(SFDPHeader));
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to read SPI Flash SFDP Header.\n"));
    goto ended;
  }

  avr2utilDisplaySFDPHeader(&header, 0, &signature, &standardTableSize);

  for (i = 0; i < header.nParameterHeaders; i++) {
    uint32_t address = (uint32_t)(sizeof(SFDPHeader) + i * sizeof(SFDPTableHeader));

    ret = avr2utilSpiFlashReadSFDP(
      pDevice,
      bVerbose,
      chipIndex,
      address,
      (uint8_t*)&tableHeader,
      (unsigned int)sizeof(SFDPTableHeader));
    if (EXIT_OK != ret) {
      _tprintf(_T("+++ Failed to read SPI Flash SFDP Table Header %u.\n"), i);
      continue;
    }

    bIsStandardTable = avr2utilDisplaySFDPTableHeader(&tableHeader, address, i, &tableSize, &pointer24, &tableID);
    if (!bIsStandardTable) {
      continue;
    }

    pTable = (void*)malloc(tableSize);
    if (NULL == pTable) {
      _tprintf(_T("*** Failed to allocate 0x%llX bytes for SFDP Parameter Table %u.\n"),
        (unsigned long long)tableSize, i);
      ret = EXIT_ALLOCATION_FAILED;
      break;
    }
    memset(pTable, 0, sizeof(tableSize));

    readLength = standardTableSize;
    if (readLength > tableSize) {
      readLength = tableSize;
      _tprintf(_T("+++ SPI Flash SFDP Table %u is less than expected %u DWORDs in length; padding with zeroes.\n"),
        i, standardTableSize);
    }

    ret = avr2utilSpiFlashReadSFDP(pDevice, bVerbose, chipIndex, pointer24, (uint8_t*)pTable, tableSize);
    if (EXIT_OK != ret) {
      free(pTable);
      _tprintf(_T("+++ Failed to read SPI Flash SFDP Table %u.\n"), i);
      continue;
    }

    if (tableID == SFDP_ID_STANDARD_TABLE) {
      avr2utilDisplaySFDPTable(pTable, pointer24, i, tableSize);
    } else if (tableID == SFDP_ID_SECTOR_MAP) {
      avr2utilDisplaySFDPSectorMap(pTable, pointer24, i, tableSize);
    } else {
      /* Should never get here */
      assert(FALSE);
    }

    free(pTable);
    pTable = NULL;
  }

ended:
  /* Inform the uC that the lengthy SPI Flash operation has finished */
  ret2 = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to inform uC that the lengthy SPI Flash operation has ended.\n"));
  }

done:
  if (NULL != pTable) {
    free(pTable);
  }
  return ret;
}

static int
spiCheckBlankCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  unsigned int address,
  unsigned int count)
{
  const unsigned int maxErrorsDisplayed = 10;
  SPIChipDescription chipDescription = { 0 };
  uint32_t totalErrorCount = 0;
  int ret = EXIT_OK, ret2;

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-check-blank command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  ret = avr2utilSpiFlashHardwareReset(pDevice, bVerbose);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to perform hardware reset of all SPI Flash chips.\n"));
    goto done;
  }

  /* Inform the uC that a lengthy SPI Flash operation is commencing */
  ret = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to inform uC that a lengthy SPI Flash operation is commencing.\n"));
    goto done;
  }

  ret = avr2utilSpiFlashGetDescription(pDevice, bVerbose, chipIndex, &chipDescription, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to discover parameters of SPI Flash chip %u.\n"), chipIndex);
    goto ended;
  }

  if (chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
    ret = avr2utilSpiFlash4ByteMode(pDevice, bVerbose, &chipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to set SPI Flash chip %u to 4-byte address mode.\n"), chipIndex);
      goto ended;
    }
  }

  ret = avr2utilSpiFlashVerify(pDevice, bVerbose, &chipDescription, chipIndex, address, count, NULL /* => blank-check */, maxErrorsDisplayed, &totalErrorCount);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** SPI Flash blank-check operation failed.\n"));
    avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
    goto ended;
  }

  if (totalErrorCount) {
    _tprintf(_T("*** Blank-check FAILED: A total of %u(0x%X) bytes(s) were found that do not have blank value (0xFF).\n"),
      totalErrorCount, totalErrorCount);
    ret = EXIT_VERIFY_FAILED;
  } else {
    _tprintf(_T("Blank-check OK: The specified region is blank.\n"));
  }

  ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to disable SPI Flash Write Enable Latch.\n"));
    goto ended;
  }

ended:
  /* Inform the uC that the lengthy SPI Flash operation has finished */
  ret2 = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to inform uC that the lengthy SPI Flash operation has ended.\n"));
  }

done:
  avr2utilSpiFlashPutDescription(&chipDescription);

  return ret;
}

static int
spiEraseCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  unsigned int address,
  unsigned int count)
{
  SPIChipDescription chipDescription = { 0 };
  int ret = EXIT_OK, ret2;

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-erase command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  ret = avr2utilSpiFlashHardwareReset(pDevice, bVerbose);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to perform hardware reset of all SPI Flash chips.\n"));
    goto done;
  }

  /* Inform the uC that a lengthy SPI Flash operation is commencing */
  ret = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to inform uC that a lengthy SPI Flash operation is commencing.\n"));
    goto done;
  }

  ret = avr2utilSpiFlashGetDescription(pDevice, bVerbose, chipIndex, &chipDescription, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to discover parameters of SPI Flash chip %u.\n"), chipIndex);
    goto ended;
  }

  if (chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
    ret = avr2utilSpiFlash4ByteMode(pDevice, bVerbose, &chipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to set SPI Flash chip %u to 4-byte address mode.\n"), chipIndex);
      goto ended;
    }
  }

  ret = avr2utilSpiFlashErase(pDevice, bVerbose, &chipDescription, chipIndex, address, count);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** SPI Flash erase operation failed.\n"));
    avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
    goto ended;
  }

  ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to disable SPI Flash Write Enable Latch.\n"));
    goto ended;
  }

ended:
  /* Inform the uC that the lengthy SPI Flash operation has finished */
  ret2 = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to inform uC that the lengthy SPI Flash operation has ended.\n"));
  }

done:
  avr2utilSpiFlashPutDescription(&chipDescription);

  return ret;
}

static int
spiProgramIntelHexCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  const TCHAR* pFilename,
  int32_t translation)
{
  SPIChipDescription chipDescription = { 0 };
  IntelHexFile* pIntelHexFile = NULL;
  IntelHexError readErr;
  size_t i;
  int ret = EXIT_OK, ret2;

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  readErr = avr2utilReadIntelHex(pFilename, &pIntelHexFile);
  switch (readErr) {
  case IntelHexErrorOk:
    break;

  case IntelHexErrorAllocationError:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: unable to allocate memory.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorPermissionDenied:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: access denied.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorNotFound:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: file not found.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorOpenFailed:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: unexpected error opening file.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorSeekError:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: seek error while reading file.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorReadError:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: error while reading file.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  default:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format; error code %u\n"), pFilename, readErr);
    return EXIT_READ_INTEL_HEX_FAILED;
  }

  _tprintf(_T("Intel Hex file '%s':\n"), pFilename);
  avr2utilDisplayIntelHexInfo(pIntelHexFile, _T("  "));

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-program-mcs command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  ret = avr2utilSpiFlashHardwareReset(pDevice, bVerbose);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to perform hardware reset of all SPI Flash chips.\n"));
    goto done;
  }

  /* Inform the uC that a lengthy SPI Flash operation is commencing */
  ret = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to inform uC that a lengthy SPI Flash operation is commencing.\n"));
    goto done;
  }

  ret = avr2utilSpiFlashGetDescription(pDevice, bVerbose, chipIndex, &chipDescription, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to discover parameters of SPI Flash chip %u.\n"), chipIndex);
    goto ended;
  }

  if (chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
    ret = avr2utilSpiFlash4ByteMode(pDevice, bVerbose, &chipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to set SPI Flash chip %u to 4-byte address mode.\n"), chipIndex);
      goto ended;
    }
  }

  for (i = 0; i < pIntelHexFile->sectionCount; i++) {
    IntelHexFileSection* pSection = &pIntelHexFile->sections[i];
    uint32_t address = pSection->address;

    address = (uint32_t)(address + translation);
    _tprintf(_T("Writing section %llu at byte address 0x%X ...\n"),
      (unsigned long long)i, address);
    ret = avr2utilSpiFlashWrite(pDevice, bVerbose, &chipDescription, chipIndex, address, pSection->length, pSection->pData);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** SPI Flash program operation failed.\n"));
      avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
      goto ended;
    }
  }

  ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to disable SPI Flash Write Enable Latch.\n"));
    goto ended;
  }

ended:
  /* Inform the uC that the lengthy SPI Flash operation has finished */
  ret2 = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to inform uC that the lengthy SPI Flash operation has ended.\n"));
  }

done:
  if (NULL != pIntelHexFile) {
    avr2utilDisposeIntelHex(pIntelHexFile);
  }

  avr2utilSpiFlashPutDescription(&chipDescription);

  return ret;
}

static int
spiVerifyIntelHexCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  const TCHAR* pFilename,
  int32_t translation)
{
  const unsigned int maxErrorsDisplayed = 10;
  SPIChipDescription chipDescription = { 0 };
  IntelHexFile* pIntelHexFile = NULL;
  IntelHexError readErr;
  uint64_t totalErrorCount = 0;
  size_t i;
  int ret = EXIT_OK, ret2;

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  readErr = avr2utilReadIntelHex(pFilename, &pIntelHexFile);
  switch (readErr) {
  case IntelHexErrorOk:
    break;

  case IntelHexErrorAllocationError:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: unable to allocate memory.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorPermissionDenied:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: access denied.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorNotFound:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: file not found.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorOpenFailed:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: unexpected error opening file.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorSeekError:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: seek error while reading file.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  case IntelHexErrorReadError:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format: error while reading file.\n"), pFilename);
    return EXIT_READ_INTEL_HEX_FAILED;

  default:
    _tprintf(_T("*** Failed to read file '%s' in Intel Hex format; error code %u\n"), pFilename, readErr);
    return EXIT_READ_INTEL_HEX_FAILED;
  }

  _tprintf(_T("Intel Hex file '%s':\n"), pFilename);
  avr2utilDisplayIntelHexInfo(pIntelHexFile, _T("  "));

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-program-mcs command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  ret = avr2utilSpiFlashHardwareReset(pDevice, bVerbose);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to perform hardware reset of all SPI Flash chips.\n"));
    goto done;
  }

  /* Inform the uC that a lengthy SPI Flash operation is commencing */
  ret = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to inform uC that a lengthy SPI Flash operation is commencing.\n"));
    goto done;
  }

  ret = avr2utilSpiFlashGetDescription(pDevice, bVerbose, chipIndex, &chipDescription, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to discover parameters of SPI Flash chip %u.\n"), chipIndex);
    goto ended;
  }

  if (chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
    ret = avr2utilSpiFlash4ByteMode(pDevice, bVerbose, &chipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to set SPI Flash chip %u to 4-byte address mode.\n"), chipIndex);
      goto ended;
    }
  }

  for (i = 0; i < pIntelHexFile->sectionCount; i++) {
    IntelHexFileSection* pSection = &pIntelHexFile->sections[i];
    uint32_t sectionErrorCount;
    uint32_t address = pSection->address;

    address = (uint32_t)(address + translation);
    _tprintf(_T("Verifying section %llu at byte address 0x%X ...\n"),
      (unsigned long long)i, address);
    ret = avr2utilSpiFlashVerify(pDevice, bVerbose, &chipDescription, chipIndex, address, pSection->length, pSection->pData, maxErrorsDisplayed, &sectionErrorCount);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** SPI Flash verify operation failed.\n"));
      goto ended;
    }

    if (sectionErrorCount) {
      _tprintf(_T("+++ %u(0x%X) bytes do not match section %llu of specified file.\n"),
        sectionErrorCount, sectionErrorCount, (unsigned long long)i);
    }
    totalErrorCount += sectionErrorCount;
  }

  if (totalErrorCount) {
    _tprintf(_T("*** Verification FAILED: A total of %llu(0x%llX) bytes(s) were found that do not match the data in the specified file.\n"),
      (unsigned long long)totalErrorCount, (unsigned long long)totalErrorCount);
    ret = EXIT_VERIFY_FAILED;
  } else {
    _tprintf(_T("Verification OK: The contents of the SPI Flash chip %u matches the data in the specified file.\n"), chipIndex);
  }

  ret2 = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, &chipDescription, chipIndex, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to disable SPI Flash Write Enable Latch.\n"));
  }

ended:
  /* Inform the uC that the lengthy SPI Flash operation has finished */
  ret2 = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to inform uC that the lengthy SPI Flash operation has ended.\n"));
  }

done:
  if (NULL != pIntelHexFile) {
    avr2utilDisposeIntelHex(pIntelHexFile);
  }

  avr2utilSpiFlashPutDescription(&chipDescription);

  return ret;
}

static int
spiSaveIntelHexCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  const TCHAR* pFilename,
  unsigned int address,
  unsigned int count)
{
  SPIChipDescription chipDescription = { 0 };
  IntelHexFile intelHexFile;
  IntelHexError writeErr;
  uint8_t* pBuffer = NULL;
  int ret = EXIT_OK, ret2;

  memset(&intelHexFile, 0, sizeof(intelHexFile));

  if (chipIndex > 0xFFU) {
    _tprintf(_T("*** SPI chip index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_SPI_INDEX;
  }

  pBuffer = (uint8_t*)malloc(count);
  if (NULL == pBuffer) {
    _tprintf(_T("*** Failed to allocate buffer of %u(0x%X) bytes for reading data from SPI Flash.\n"), count, count);
    return EXIT_ALLOCATION_FAILED;
  }

  intelHexFile.sectionCount = 1;
  intelHexFile.sections[0].address = address;
  intelHexFile.sections[0].length = count;
  intelHexFile.sections[0].pData = pBuffer;

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The spi-save-to-mcs command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    ret = EXIT_WRONG_MODE;
    goto done;
  }

  ret = avr2utilSpiFlashHardwareReset(pDevice, bVerbose);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to perform hardware reset of all SPI Flash chips.\n"));
    goto done;
  }

  /* Inform the uC that a lengthy SPI Flash operation is commencing */
  ret = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to inform uC that a lengthy SPI Flash operation is commencing.\n"));
    goto done;
  }

  ret = avr2utilSpiFlashGetDescription(pDevice, bVerbose, chipIndex, &chipDescription, TRUE);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to discover parameters of SPI Flash chip %u.\n"), chipIndex);
    goto ended;
  }

  if (chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
    ret = avr2utilSpiFlash4ByteMode(pDevice, bVerbose, &chipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to set SPI Flash chip %u to 4-byte address mode.\n"), chipIndex);
      goto ended;
    }
  }

  ret = avr2utilSpiFlashRead(pDevice, bVerbose, &chipDescription, chipIndex, address, count, pBuffer);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to read data from SPI Flash chip %u.\n"), chipIndex);
    goto ended;
  }

ended:
  /* Inform the uC that the lengthy SPI Flash operation has finished */
  ret2 = avr2utilSpiFlashStartEndOp(pDevice, bVerbose, FALSE);
  if (EXIT_OK != ret2) {
    _tprintf(_T("*** Failed to inform uC that the lengthy SPI Flash operation has ended.\n"));
  }

  _tprintf(_T("Saving data in '%s' ...\n"), pFilename);
  writeErr = avr2utilWriteIntelHex(pFilename, &intelHexFile, 16);
  switch (writeErr) {
  case IntelHexErrorOk:
    break;

  case IntelHexErrorPermissionDenied:
    _tprintf(_T("*** Failed to write file '%s' in Intel Hex format: access denied.\n"), pFilename);
    ret = EXIT_READ_INTEL_HEX_FAILED;
    break;

  case IntelHexErrorOpenFailed:
    _tprintf(_T("*** Failed to write file '%s' in Intel Hex format: unexpected error opening file.\n"), pFilename);
    ret = EXIT_READ_INTEL_HEX_FAILED;
    break;

  case IntelHexErrorNotFound:
    _tprintf(_T("*** Failed to write file '%s' in Intel Hex format: path not found.\n"), pFilename);
    ret = EXIT_READ_INTEL_HEX_FAILED;
    break;

  case IntelHexErrorWriteError:
    _tprintf(_T("*** Failed to write file '%s' in Intel Hex format: error while writing data.\n"), pFilename);
    ret = EXIT_READ_INTEL_HEX_FAILED;
    break;

  default:
    _tprintf(_T("*** Failed to write file '%s' in Intel Hex format; error code %u\n"), pFilename, writeErr);
    ret = EXIT_READ_INTEL_HEX_FAILED;
    break;
  }

done:
  if (NULL != pBuffer) {
    free(pBuffer);
  }

  avr2utilSpiFlashPutDescription(&chipDescription);

  return ret;
}

#define FLASH_PAGE_ORDER (9)
#define FLASH_PAGE_SIZE (1U << FLASH_PAGE_ORDER)
#define FLASH_PAGE_MASK (FLASH_PAGE_SIZE - 1U)

static int
readApplicationFlashPage(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t pageAddress,
  uint8_t* pPageBuffer)
{
  uint8_t command[5];
  uint8_t response[3 + FLASH_PAGE_SIZE];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint16_t pageIndex;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  _tprintf(_T("Reading Application Flash page @ 0x%lX...\n"), (unsigned long)pageAddress);

  pageIndex = (uint16_t)(pageAddress >> FLASH_PAGE_ORDER); /* Cast should be safe because range of pageAddress is limited by callers */

  command[0] = 0x06; /* Boot Flash command group */
  command[1] = 0x80; /* Flash Application Read command */
  command[2] = FLASH_PAGE_ORDER;
  command[3] = (uint8_t)((pageIndex >> 0) & 0xFFU);
  command[4] = (uint8_t)((pageIndex >> 8) & 0xFFU);
  expResponse[0] = 0x06; /* Boot Flash command group */
  expResponse[1] = 0x00; /* Flash Application Read response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    _tprintf(_T("*** AVR2 returned status 0x%02X for Flash Application Read command\n"), avr2Status);
    return EXIT_AVR2_COMMAND_ERROR;
  }

  memcpy(pPageBuffer, &response[3], FLASH_PAGE_SIZE);

  return EXIT_OK;
}

static int
writeApplicationFlashPage(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t pageAddress,
  const uint8_t* pPageBuffer)
{
  uint8_t command[5 + FLASH_PAGE_SIZE];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint16_t pageIndex;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  _tprintf(_T("Writing Application Flash page @ 0x%lX...\n"), (unsigned long)pageAddress);

  pageIndex = (uint16_t)(pageAddress >> FLASH_PAGE_ORDER); /* Cast should be safe because range of pageAddress is limited by callers */

  command[0] = 0x06; /* Boot Flash command group */
  command[1] = 0x82; /* Flash Application Write command */
  command[2] = FLASH_PAGE_ORDER;
  command[3] = (uint8_t)((pageIndex >> 0) & 0xFFU);
  command[4] = (uint8_t)((pageIndex >> 8) & 0xFFU);
  memcpy(&command[5], pPageBuffer, FLASH_PAGE_SIZE);
  expResponse[0] = 0x06; /* Boot Flash command group */
  expResponse[1] = 0x02; /* Flash Application Write response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    _tprintf(_T("*** AVR2 returned status 0x%02X for Flash Application Write command\n"), avr2Status);
    return EXIT_AVR2_COMMAND_ERROR;
  }

  return EXIT_OK;
}

static int
writeApplicationFlash(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t address,
  const uint8_t* pBuffer,
  uint32_t length)
{
  uint8_t pageBuffer[512];
  uint32_t pageAddress, pageOffset, chunk;
  int ret = EXIT_OK;

  while (length) {
    pageOffset = address & FLASH_PAGE_MASK;
    pageAddress = address & ~FLASH_PAGE_MASK;
    chunk = FLASH_PAGE_SIZE - pageOffset;
    if (chunk > length) {
      chunk = length;
    }

    if (chunk != FLASH_PAGE_SIZE) {
      ret = readApplicationFlashPage(pDevice, bVerbose, pageAddress, pageBuffer);
      if (EXIT_OK != ret) {
        return ret;
      }
    }
    memcpy(pageBuffer + pageOffset, pBuffer, chunk);

    ret = writeApplicationFlashPage(pDevice, bVerbose, pageAddress, pageBuffer);
    if (EXIT_OK != ret) {
      return ret;
    }

    length -= chunk;
    address += chunk;
    pBuffer += chunk;
  }

  return EXIT_OK;
}

static int
readApplicationFlash(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t address,
  uint8_t* pBuffer,
  uint32_t length)
{
  uint8_t pageBuffer[512];
  uint32_t pageAddress, pageOffset, chunk;
  int ret = EXIT_OK;

  while (length) {
    pageOffset = address & FLASH_PAGE_MASK;
    pageAddress = address & ~FLASH_PAGE_MASK;
    chunk = FLASH_PAGE_SIZE - pageOffset;
    if (chunk > length) {
      chunk = length;
    }

    ret = readApplicationFlashPage(pDevice, bVerbose, pageAddress, pageBuffer);
    if (EXIT_OK != ret) {
      return ret;
    }

    memcpy(pBuffer, pageBuffer + pageOffset, chunk);

    pBuffer += chunk;
    address += chunk;
    length -= chunk;
  }

  return ret;
}

static int
verifyApplicationFlash(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t address,
  const uint8_t* pBuffer,
  uint32_t length)
{
  const unsigned int maxErrorReported = 20;
  uint8_t pageBuffer[512];
  uint32_t i, pageAddress, pageOffset, chunk;
  uint32_t errorCount = 0;
  int ret = EXIT_OK;

  while (length) {
    pageOffset = address & FLASH_PAGE_MASK;
    pageAddress = address & ~FLASH_PAGE_MASK;
    chunk = FLASH_PAGE_SIZE - pageOffset;
    if (chunk > length) {
      chunk = length;
    }

    ret = readApplicationFlashPage(pDevice, bVerbose, pageAddress, pageBuffer);
    if (EXIT_OK != ret) {
      return ret;
    }

    for (i = 0; i < chunk; i++) {
      uint8_t expected = *pBuffer++;
      uint8_t actual = pageBuffer[pageOffset + i];

      if (actual != expected) {
        if (errorCount < maxErrorReported) {
          if (expected != actual) {
            _tprintf(_T("*** Verification error at address 0x%lX; expected=0x%02X actual=0x%02X\n"),
              (unsigned long)address, (unsigned int)expected, (unsigned int)actual);
          }
        } else if (errorCount == maxErrorReported) {
          _tprintf(_T("*** More than %u verification errors detected.\n"), maxErrorReported);
        }
        errorCount++;
      }
      address++;
    }

    length -= chunk;
  }

  if (errorCount) {
    _tprintf(_T("*** Total of %u verification errors detected.\n"), errorCount);
    ret = EXIT_VERIFY_FAILED;
  } else {
    _tprintf(_T("Verified OK.\n"));
  }

  return ret;
}

int
avr2UtilRequestVpdData(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint8_t* pVpdData) /* Must be at least 256 bytes in size */
{
  uint8_t command[2];
  uint8_t response[259];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  command[0] = 0x05; /* User Ext command group */
  command[1] = 0x8C; /* Request VPD command */
  expResponse[0] = 0x05; /* User Ext command group */
  expResponse[1] = 0x0C; /* Request VPD response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    _tprintf(_T("*** AVR2 returned status 0x%02X for Request VPD command\n"), avr2Status);
    return EXIT_AVR2_COMMAND_ERROR;
  }

  memcpy(pVpdData, response + 3, 256);

  return EXIT_OK;
}

static int
requestBlackBoxRecord(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint8_t nRecordIndex,
  uint8_t* pSensorPage) /* Must be at least SENSOR_PAGE_LENGTH_LIMIT (64) bytes in size */
{
  uint8_t command[3];
  uint8_t response[67];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  command[0] = 0x05; /* User Ext command group */
  command[1] = 0x8A; /* Request Black Box record command */
  command[2] = nRecordIndex;
  expResponse[0] = 0x05; /* User Ext command group */
  expResponse[1] = 0x0A; /* Request Black Box record response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    _tprintf(_T("*** AVR2 returned status 0x%02X for Request Black Box record command\n"), avr2Status);
    return EXIT_AVR2_COMMAND_ERROR;
  }

  memcpy(pSensorPage, response + 3, SENSOR_PAGE_LENGTH_LIMIT);

  return EXIT_OK;
}

static int
requestSensors(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint8_t* pSensorPage) /* Must be at least SENSOR_PAGE_LENGTH_LIMIT (64) bytes in size */
{
  uint8_t command[2];
  uint8_t response[67];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  command[0] = 0x05; /* User Ext command group */
  command[1] = 0x89; /* Request Sensors command */
  expResponse[0] = 0x05; /* User Ext command group */
  expResponse[1] = 0x09; /* Request Sensors response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    _tprintf(_T("*** AVR2 returned status 0x%02X for Request Sensors command\n"), avr2Status);
    return EXIT_AVR2_COMMAND_ERROR;
  }

  memcpy(pSensorPage, response + 3, SENSOR_PAGE_LENGTH_LIMIT);

  return EXIT_OK;
}

static int
overrideSensor(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint8_t sensorIndex,
  uint32_t overrideValue,
  bool_t bEnable) 
{
  uint8_t command[8];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;
  
  command[0] = 0x05; /* User extended command group */
  command[1] = 0x81; /* OverrideSensor command */
  command[2] = (uint8_t)sensorIndex; /* Index of sensor to override (model-specific) */
  command[3] = (uint8_t)((overrideValue >> 0) & 0xFFU); /* Override Value bits [7:0] (byte 0) */
  command[4] = (uint8_t)((overrideValue >> 8) & 0xFFU); /* Override Value bits [15:8] (byte 1) */
  command[5] = (uint8_t)((overrideValue >> 16) & 0xFFU); /* Override Value bits [23:16] (byte 2) */
  command[6] = (uint8_t)((overrideValue >> 24) & 0xFFU); /* Override Value bits [31:24] (byte 3) */
  command[7] = (uint8_t)(bEnable ? 0x1U : 0U); /* Enable byte */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x01; /* OverrideSensor response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    return ret;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid sensor index");
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    return EXIT_AVR2_BAD_STATUS;
  }

  return ret;
}

static int
updateOrVerifyFirmwareCommand(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bVerifyOnly,
  const TCHAR* pFilename)
{
  const unsigned int firmwareLengthLimit = FIRMWARE_LENGTH_LIMIT;
  FILE* pFile = NULL;
  uint8_t* pBuffer = NULL;
  long length;
  size_t nRead;
  bool_t bWasInServiceMode;
  int ret = EXIT_OK;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (0 != _tfopen_s(&pFile, pFilename, _T("rb"))) {
    _tprintf(_T("*** Failed to open firmware file '%s' for reading.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_END)) {
    _tprintf(_T("*** Failed to seek to end of firmware file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  length = ftell(pFile);
  if (length < 0) {
    _tprintf(_T("*** Failed to get length of firmware file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_SET)) {
    _tprintf(_T("*** Failed to seek to beginning of firmware file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if ((size_t)length > firmwareLengthLimit) { /* Cast to size_t safe due to positive check above */
    _tprintf(_T("*** Firmware file cannot be more than 0x%X bytes; actual length is 0x%llX.\n"),
      firmwareLengthLimit, (unsigned long long)length);
    ret = EXIT_FIRMWARE_TOO_LARGE;
    goto done;
  }
  _tprintf(_T("Firmware file '%s' length is %u(0x%X) byte(s).\n"),
    pFilename, (unsigned int)length, (unsigned int)length); /* Cast safe due to previous range checks */

  pBuffer = (uint8_t*)malloc(length);
  if (NULL == pBuffer) {
    _tprintf(_T("*** Failed to allocate firmware file buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  nRead = fread(pBuffer, 1, length, pFile);
  if (nRead != (size_t)length) {
    _tprintf(_T("*** Failed to read expected number of bytes from firmware file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  fclose(pFile);
  pFile = NULL;

  bWasInServiceMode = pDevice->bInServiceMode;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, FALSE);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (!bVerifyOnly) {
    ret = writeApplicationFlash(pDevice, bVerbose, FIRMWARE_BASE_ADDR, pBuffer, (uint32_t)length); /* Cast safe due to above check on 'length' */
  }
  if (EXIT_OK == ret) {
    ret = verifyApplicationFlash(pDevice, bVerbose, FIRMWARE_BASE_ADDR, pBuffer, (uint32_t)length); /* Cast safe due to above check on 'length' */
  }

  autoEnterExitServiceMode(pDevice, bVerbose, bWasInServiceMode, FALSE);

done:
  if (NULL != pBuffer) {
    free(pBuffer);
  }
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
updateOrVerifyBoardConfigCommand(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bVerifyOnly,
  const TCHAR* pFilename)
{
  const unsigned int boardConfigLengthLimit = BOARD_CONFIG_LENGTH_LIMIT;
  FILE* pFile = NULL;
  uint8_t* pBuffer = NULL;
  long length;
  size_t nRead;
  bool_t bWasInServiceMode;
  int ret = EXIT_OK;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (0 != _tfopen_s(&pFile, pFilename, _T("rb"))) {
    _tprintf(_T("*** Failed to open board config. file '%s' for reading.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_END)) {
    _tprintf(_T("*** Failed to seek to end of board config. file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  length = ftell(pFile);
  if (length < 0) {
    _tprintf(_T("*** Failed to get length of board config. file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_SET)) {
    _tprintf(_T("*** Failed to seek to beginning of board config. file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if ((size_t)length >= boardConfigLengthLimit) { /* Cast to size_t safe due to positive check above */
    _tprintf(_T("*** Board config. file cannot be more than 0x%X bytes; actual length is 0x%llX.\n"),
      boardConfigLengthLimit, (unsigned long long)length);
    ret = EXIT_FIRMWARE_TOO_LARGE;
    goto done;
  }
  _tprintf(_T("Board config file '%s' length is %u(0x%X) byte(s).\n"),
    pFilename, (unsigned int)length, (unsigned int)length); /* Cast safe due to previous range checks */

  pBuffer = (uint8_t*)malloc(length);
  if (NULL == pBuffer) {
    _tprintf(_T("*** Failed to allocate board config. file buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  nRead = fread(pBuffer, 1, length, pFile);
  if (nRead != (size_t)length) {
    _tprintf(_T("*** Failed to read expected number of bytes from board config. file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  fclose(pFile);
  pFile = NULL;

  bWasInServiceMode = pDevice->bInServiceMode;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, FALSE);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (!bVerifyOnly) {
    ret = writeApplicationFlash(pDevice, bVerbose, BOARD_CONFIG_BASE_ADDR, pBuffer, (uint32_t)length); /* Cast safe due to above check on 'length' */
  }
  if (EXIT_OK == ret) {
    ret = verifyApplicationFlash(pDevice, bVerbose, BOARD_CONFIG_BASE_ADDR, pBuffer, (uint32_t)length); /* Cast safe due to above check on 'length' */
  }

  autoEnterExitServiceMode(pDevice, bVerbose, bWasInServiceMode, FALSE);

done:
  if (NULL != pBuffer) {
    free(pBuffer);
  }
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
updateOrVerifyVpdCommand(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bVerifyOnly,
  const TCHAR* pFilename)
{
  const unsigned int vpdLengthLimit = VPD_LENGTH_LIMIT;
  FILE* pFile = NULL;
  uint8_t buffer[VPD_LENGTH_LIMIT];
  long length;
  size_t nRead;
  bool_t bWasInServiceMode;
  int ret = EXIT_OK;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (0 != _tfopen_s(&pFile, pFilename, _T("rb"))) {
    _tprintf(_T("*** Failed to VPD file '%s' for reading.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_END)) {
    _tprintf(_T("*** Failed to seek to end of VPD file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  length = ftell(pFile);
  if (length < 0) {
    _tprintf(_T("*** Failed to get length of VPD file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if (0 != fseek(pFile, 0, SEEK_SET)) {
    _tprintf(_T("*** Failed to seek to beginning of VPD file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  if ((size_t)length >= vpdLengthLimit) { /* Cast to size_t safe due to positive check above */
    _tprintf(_T("*** VPD file cannot be more than 0x%X bytes; actual length is 0x%llX.\n"),
      vpdLengthLimit, (unsigned long long)length);
    ret = EXIT_FIRMWARE_TOO_LARGE;
    goto done;
  }
  _tprintf(_T("VPD file '%s' length is %u(0x%X) byte(s).\n"),
    pFilename, (unsigned int)length, (unsigned int)length); /* Cast safe due to previous range checks */

  memset(buffer, 0, sizeof(buffer));
  nRead = fread(buffer, 1, length, pFile);
  if (nRead != (size_t)length) {
    _tprintf(_T("*** Failed to read expected number of bytes from VPD file '%s'.\n"), pFilename);
    ret = EXIT_READ_FIRMWARE_FAILED;
    goto done;
  }
  fclose(pFile);
  pFile = NULL;

  bWasInServiceMode = pDevice->bInServiceMode;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, FALSE);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (!bVerifyOnly) {
    ret = writeApplicationFlash(pDevice, bVerbose, VPD_BASE_ADDR, buffer, (uint32_t)length); /* Cast safe due to above check on 'length' */
  }
  if (EXIT_OK == ret) {
    ret = verifyApplicationFlash(pDevice, bVerbose, VPD_BASE_ADDR, buffer, (uint32_t)length); /* Cast safe due to above check on 'length' */
  }

  autoEnterExitServiceMode(pDevice, bVerbose, bWasInServiceMode, FALSE);

done:
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
saveFirmwareCommand(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  const TCHAR* pFilename)
{
  const unsigned int firmwareLengthLimit = FIRMWARE_LENGTH_LIMIT;
  FILE* pFile = NULL;
  uint8_t* pBuffer = NULL;
  size_t nWritten;
  bool_t bWasInServiceMode;
  int ret = EXIT_OK;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  pBuffer = (uint8_t*)malloc(firmwareLengthLimit);
  if (NULL == pBuffer) {
    _tprintf(_T("*** Failed to buffer for firmware save data.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  bWasInServiceMode = pDevice->bInServiceMode;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, FALSE);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = readApplicationFlash(pDevice, bVerbose, FIRMWARE_BASE_ADDR, pBuffer, firmwareLengthLimit);

  autoEnterExitServiceMode(pDevice, bVerbose, bWasInServiceMode, FALSE);

  if (EXIT_OK == ret) {
    if (0 != _tfopen_s(&pFile, pFilename, _T("wb"))) {
      _tprintf(_T("*** Failed to open firmware save file '%s' for writing.\n"), pFilename);
      ret = EXIT_WRITE_FIRMWARE_FAILED;
      goto done;
    }

    nWritten = fwrite(pBuffer, 1, firmwareLengthLimit, pFile);
    if (nWritten != (size_t)firmwareLengthLimit) {
      _tprintf(_T("*** Failed to write expected number of bytes to firmware save file '%s'.\n"), pFilename);
      ret = EXIT_WRITE_FIRMWARE_FAILED;
      goto done;
    }
  }

done:
  if (NULL != pFile) {
    fclose(pFile);
  }
  if (NULL != pBuffer) {
    free(pBuffer);
  }

  return ret;
}

static int
saveBoardConfigCommand(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  const TCHAR* pFilename)
{
  const unsigned int boardConfigLengthLimit = BOARD_CONFIG_LENGTH_LIMIT;
  FILE* pFile = NULL;
  uint8_t buffer[BOARD_CONFIG_LENGTH_LIMIT];
  size_t nWritten;
  bool_t bWasInServiceMode;
  int ret = EXIT_OK;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  bWasInServiceMode = pDevice->bInServiceMode;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, FALSE);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = readApplicationFlash(pDevice, bVerbose, BOARD_CONFIG_BASE_ADDR, buffer, boardConfigLengthLimit);

  autoEnterExitServiceMode(pDevice, bVerbose, bWasInServiceMode, FALSE);

  if (EXIT_OK == ret) {
    if (0 != _tfopen_s(&pFile, pFilename, _T("wb"))) {
      _tprintf(_T("*** Failed to open board config. save file '%s' for writing.\n"), pFilename);
      ret = EXIT_WRITE_FIRMWARE_FAILED;
      goto done;
    }

    nWritten = fwrite(buffer, 1, boardConfigLengthLimit, pFile);
    if (nWritten != (size_t)boardConfigLengthLimit) {
      _tprintf(_T("*** Failed to write expected number of bytes to board config. save file '%s'.\n"), pFilename);
      ret = EXIT_WRITE_FIRMWARE_FAILED;
      goto done;
    }
  }

done:
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

static int
saveVpdCommand(
  DeviceHandle* pDevice,
  bool_t bVerbose,
  const TCHAR* pFilename)
{
  const unsigned int vpdLengthLimit = VPD_LENGTH_LIMIT;
  FILE* pFile = NULL;
  uint8_t buffer[VPD_LENGTH_LIMIT];
  size_t nWritten;
  bool_t bWasInServiceMode;
  int ret = EXIT_OK;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  bWasInServiceMode = pDevice->bInServiceMode;

  ret = autoEnterExitServiceMode(pDevice, bVerbose, TRUE, FALSE);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = readApplicationFlash(pDevice, bVerbose, VPD_BASE_ADDR, buffer, vpdLengthLimit);

  autoEnterExitServiceMode(pDevice, bVerbose, bWasInServiceMode, FALSE);

  if (EXIT_OK == ret) {
    if (0 != _tfopen_s(&pFile, pFilename, _T("wb"))) {
      _tprintf(_T("*** Failed to open VPD save file '%s' for writing.\n"), pFilename);
      ret = EXIT_WRITE_FIRMWARE_FAILED;
      goto done;
    }

    nWritten = fwrite(buffer, 1, vpdLengthLimit, pFile);
    if (nWritten != (size_t)vpdLengthLimit) {
      _tprintf(_T("*** Failed to write expected number of bytes to VPD save file '%s'.\n"), pFilename);
      ret = EXIT_WRITE_FIRMWARE_FAILED;
      goto done;
    }
  }

done:
  if (NULL != pFile) {
    fclose(pFile);
  }

  return ret;
}

#define GET_VPD_VAL8(addr)  ((uint8_t)(cpu_to_le8(((uint8_t)(addr)[0]) << 0)))
#define GET_VPD_VAL16(addr) ((uint16_t)(cpu_to_le16((((uint16_t)(addr)[0]) << 0) + (((uint16_t)(addr)[1]) << 8))))
#define GET_VPD_VAL32(addr) ((uint32_t)(cpu_to_le32((((uint32_t)(addr)[0]) << 0) + (((uint32_t)(addr)[1]) << 8) + (((uint32_t)(addr)[2]) << 16) + (((uint32_t)(addr)[3]) << 24))))

static int
displayVpdCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  const unsigned int vpdLengthLimit = VPD_LENGTH_LIMIT;
  const unsigned int Gi = 0x40000000U;
  const unsigned int Mi = 0x100000U;
  uint8_t buffer[256]; /* Request VPD command requires buffer of 256 bytes */
  int ret = EXIT_OK;
  const TCHAR* pModelName;
  uint8_t checksum, calcChecksum;
  uint8_t pcbRev;
  uint16_t version, length, highestVersionRecognized = 0;
  uint32_t drawingNumber, serialNumber;
  char fpgaStepping[9], fpgaSpeedGrade[5];
  uint16_t fpgaDevice;
  uint8_t fpgaTempGrade;
  uint8_t ddr4Class;
  unsigned int i, bank;

  memset(buffer, 0, 256);

  if (pDevice->bInServiceMode) {
    /* In Service Mode, get VPD by reading AVR Flash */
    ret = readApplicationFlash(pDevice, bVerbose, VPD_BASE_ADDR, buffer, vpdLengthLimit);
  } else {
    /* In Application Mode, request VPD using command */
    ret = avr2UtilRequestVpdData(pDevice, bVerbose, buffer);
  }

  if (ret) {
    goto done;
  }

  version = GET_VPD_VAL16(&buffer[0]);
  length = GET_VPD_VAL16(&buffer[2]);
  drawingNumber = GET_VPD_VAL32(&buffer[4]);
  pModelName = getModelName(drawingNumber);
  serialNumber = GET_VPD_VAL32(&buffer[8]);

  _tprintf(_T("Human-readable VPD:\n"));
  _tprintf(_T("  Data structure version             %u (0x%04X)\n"), (unsigned int)version, (unsigned int)version);
  _tprintf(_T("  Data structure length              %u (0x%04X)\n"), (unsigned int)length, (unsigned int)length);
  _tprintf(_T("  Drawing number                     %u (0x%08X) => %s\n"), drawingNumber, drawingNumber, pModelName);
  _tprintf(_T("  Serial number                      %u (0x%08X)\n"), serialNumber, serialNumber);

  switch (drawingNumber) {
  case DRAWING_NUM_ADMXRCKU1:
    {
      const TCHAR* coolingTypeDescs[] = { _T("Air-cooled commerical"), _T("/AC1 - air-cooled industrial"), _T("/CC1 - conduction-cooled industrial") };
      const TCHAR* coatingTypeDescs[] = { _T("No coating"), _T("/A - Acrylic (Humiseal 1B31)"), _T("/P - Polyurethane (Conathane CE-1155)") };
      const TCHAR* pn4ConnectorDescs[] = { _T("NOT FITTED"), _T("FITTED") };
      const TCHAR* pCoolingTypeDesc = _T("UNRECOGNIZED");
      const TCHAR* pCoatingTypeDesc = _T("UNRECOGNIZED");
      const TCHAR* pPn4ConnectorDesc = _T("UNRECOGNIZED");
      uint8_t coolingType, coatingType, pn4Connector;
      uint32_t modifications32, si5338RefClkFreq;
      uint16_t dramFreq[4];
      uint8_t dramOrder[4];
      uint64_t dramSizeBytes;

      highestVersionRecognized = 0;
      modifications32 = GET_VPD_VAL32(&buffer[12]);
      _tprintf(_T("  Modifications bitmask              %u (0x%08X)\n"), modifications32, modifications32);
      coolingType = GET_VPD_VAL8(&buffer[16]);
      pCoolingTypeDesc = (coolingType < ARRAY_LENGTH(coolingTypeDescs)) ? coolingTypeDescs[coolingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Cooling type                       %u (0x%02X) => %s\n"),
        (unsigned int)coolingType, (unsigned int)coolingType, pCoolingTypeDesc);
      coatingType = GET_VPD_VAL8(&buffer[17]);
      pCoatingTypeDesc = (coatingType < ARRAY_LENGTH(coatingTypeDescs)) ? coatingTypeDescs[coatingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Coating type                       %u (0x%02X) => %s\n"),
        (unsigned int)coatingType, (unsigned int)coatingType, pCoatingTypeDesc);
      pn4Connector = GET_VPD_VAL8(&buffer[18]);
      pPn4ConnectorDesc = (pn4Connector < ARRAY_LENGTH(pn4ConnectorDescs)) ? pn4ConnectorDescs[pn4Connector] : _T("UNRECOGNIZED");
      _tprintf(_T("  Pn4 connector                      %u (0x%02X) => %s\n"),
        (unsigned int)pn4Connector, (unsigned int)pn4Connector, pPn4ConnectorDesc);
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[16]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      for (bank = 0; bank < 4; bank++) {
        dramFreq[bank] = GET_VPD_VAL16(&buffer[40 + 8 * bank]);
        dramOrder[bank] = GET_VPD_VAL8(&buffer[42 + 8 * bank]);
        _tprintf(_T("  DDR4 SDRAM bank %u max. frequency   %u (0x%04X) => %u MHz / DDR4-%u\n"),
          bank, (unsigned int)dramFreq[bank], (unsigned int)dramFreq[bank],
          (unsigned int)(dramFreq[bank] + 5) / 10, (unsigned int)(dramFreq[bank] + 2) / 5);
        dramSizeBytes = ((uint64_t)1 << dramOrder[bank]) /* no. of words */ * 4U; /* bytes per word */
        _tprintf(_T("  DDR4 SDRAM bank %u size             %u (0x%02X) => "),
          bank, (unsigned int)dramOrder[bank], (unsigned int)dramOrder[bank]);
        if (dramSizeBytes >= Gi) {
          _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
        } else {
          _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
        }
      }
      memcpy(fpgaStepping, &buffer[72], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[80], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[84]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[86]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
      pcbRev = GET_VPD_VAL8(&buffer[88]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
    }
    break;

  case DRAWING_NUM_ADMPCIE8K5:
  case DRAWING_NUM_ADMPCIEUCC:
  case DRAWING_NUM_ADMPCIE8K5_FH:
  case DRAWING_NUM_ADMPCIE8V3:
  case DRAWING_NUM_ADMPCIE9V3:
  case DRAWING_NUM_ADMPCIE9V3G:
    {
      uint8_t modifications8;
      uint32_t si5338RefClkFreq, emcclkFreq, fabricClkFreq;
      uint16_t dramFreq[4];
      uint8_t dramOrder[4], dramRanks[4];
      uint8_t customBuildCode, customBuildRevision;

      highestVersionRecognized = 0;
      pcbRev = GET_VPD_VAL8(&buffer[12]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      modifications8 = GET_VPD_VAL8(&buffer[13]);
      _tprintf(_T("  Modifications bitmask              %u (0x%02X)\n"),
        (unsigned int)modifications8, (unsigned int)modifications8);
      if (drawingNumber == DRAWING_NUM_ADMPCIE8K5 ||
          drawingNumber == DRAWING_NUM_ADMPCIEUCC ||
          drawingNumber == DRAWING_NUM_ADMPCIE8K5_FH) {
        _tprintf(_T("                                     => RS232 converter:          %s\n"), (modifications8 & 0x1U) ? _T("FITTED") : _T("NOT FITTED"));
        _tprintf(_T("                                     => SI5328 jitter attenuator: %s\n"), (modifications8 & 0x2U) ? _T("FITTED") : _T("NOT FITTED"));
        _tprintf(_T("                                     => FireFly modules:          %s\n"), (modifications8 & 0x4U) ? _T("FITTED") : _T("NOT FITTED"));
      } else if (drawingNumber == DRAWING_NUM_ADMPCIE8V3) {
        _tprintf(_T("                                     => RS232 converter:          %s\n"), (modifications8 & 0x1U) ? _T("FITTED") : _T("NOT FITTED"));
        _tprintf(_T("                                     => zQSFP modules:            %s\n"), (modifications8 & 0x2U) ? _T("FITTED") : _T("NOT FITTED"));
        _tprintf(_T("                                     => FireFly modules:          %s\n"), (modifications8 & 0x4U) ? _T("FITTED") : _T("NOT FITTED"));
      }
      if (drawingNumber == DRAWING_NUM_ADMPCIE8K5 ||
          drawingNumber == DRAWING_NUM_ADMPCIEUCC ||
          drawingNumber == DRAWING_NUM_ADMPCIE8K5_FH || 
          drawingNumber == DRAWING_NUM_ADMPCIE8V3 ||
          drawingNumber == DRAWING_NUM_ADMPCIE9V3)
      {
        ddr4Class = (uint8_t)((modifications8 >> 4) & 0xFU);
        switch (ddr4Class) {
        case 0:
          _tprintf(_T("                                     => DDR4-2400 CL16 (0000)\n"));
          break;

        case 1:
          _tprintf(_T("                                     => DDR4-2400 CL17 (0001)\n"));
          break;

        default:
          _tprintf(_T("                                     => UNRECOGNISED DDR4 CHIP CLASS %u(0x%X)\n"),
            (unsigned int)ddr4Class, (unsigned int)ddr4Class);
          break;
        }
      }
      if (drawingNumber == DRAWING_NUM_ADMPCIE8K5 ||
          drawingNumber == DRAWING_NUM_ADMPCIEUCC ||
          drawingNumber == DRAWING_NUM_ADMPCIE8K5_FH ||
          drawingNumber == DRAWING_NUM_ADMPCIE9V3 ||
          drawingNumber == DRAWING_NUM_ADMPCIE9V3G)
      {
        customBuildCode = GET_VPD_VAL8(&buffer[14]);
        customBuildRevision = GET_VPD_VAL8(&buffer[15]);
        _tprintf(_T("  Custom build code, revision        %u, %u => "),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
        if (0 == customBuildCode) {
          _tprintf(_T("Standard build\n"));
        } else {
          _tprintf(_T("/C%u.%u\n"),
            (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
        }
      }
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[16]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      emcclkFreq = GET_VPD_VAL32(&buffer[36]);
      _tprintf(_T("  EMCCLK clock frequency             %u (0x%08X) Hz\n"), emcclkFreq, emcclkFreq);
      if (drawingNumber == DRAWING_NUM_ADMPCIE8K5 ||
          drawingNumber == DRAWING_NUM_ADMPCIEUCC ||
          drawingNumber == DRAWING_NUM_ADMPCIE8K5_FH)
      {
        fabricClkFreq = GET_VPD_VAL32(&buffer[40]);
        _tprintf(_T("  Fabric clock frequency             %u (0x%08X) Hz\n"), fabricClkFreq, fabricClkFreq);
      }
      if (drawingNumber == DRAWING_NUM_ADMPCIE8K5 ||
          drawingNumber == DRAWING_NUM_ADMPCIE8V3 ||
          drawingNumber == DRAWING_NUM_ADMPCIEUCC ||
          drawingNumber == DRAWING_NUM_ADMPCIE8K5_FH ||
          drawingNumber == DRAWING_NUM_ADMPCIE9V3) {
        for (bank = 0; bank < 2; bank++) {
          uint64_t dramSizeBytes;

          dramFreq[bank] = GET_VPD_VAL16(&buffer[48 + 8 * bank]);
          dramOrder[bank] = GET_VPD_VAL8(&buffer[50 + 8 * bank]);
          dramRanks[bank] = GET_VPD_VAL8(&buffer[51 + 8 * bank]);
          _tprintf(_T("  DDR4 SDRAM bank %u max. frequency   %u (0x%04X) => %u MHz / DDR4-%u\n"),
            bank, (unsigned int)dramFreq[bank], (unsigned int)dramFreq[bank],
            (unsigned int)((dramFreq[bank] + 5) / 10), (unsigned int)((dramFreq[bank] + 2) / 5));
          dramSizeBytes = ((uint64_t)1 << dramOrder[bank]) /* no. of words */ * 8U; /* bytes per word */
          _tprintf(_T("  DDR4 SDRAM bank %u size             %u (0x%02X) => "),
            bank, (unsigned int)dramOrder[bank], (unsigned int)dramOrder[bank]);
          if (dramSizeBytes >= Gi) {
            _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
          } else {
            _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
          }
          _tprintf(_T("  DDR4 SDRAM bank %u ranks            %u (0x%02X) => "),
            (unsigned int)bank, (unsigned int)dramRanks[bank], (unsigned int)dramRanks[bank]);
          if (dramRanks[bank] & 0x80U) {
            _tprintf(_T("multi-die, %u dies\n"), (unsigned int)(dramRanks[bank] & 0x7F));
            if ((dramRanks[bank] & 0x7F) < 2) {
              _tprintf(_T("*** ERROR: Multi-die flag 0x80 is present, but no. of dies < 2\n"));
            }
          } else {
            if ((dramRanks[bank] & 0x7FU) == 1) {
              _tprintf(_T("single-die\n"));
            } else if ((dramRanks[bank] & 0x7FU) == 2) {
              _tprintf(_T("traditional twin-die\n"));
            } else {
              _tprintf(_T("traditional %u dies\n"), (unsigned int)(dramRanks[bank] & 0x7F));
              _tprintf(_T("*** ERROR: Multi-die flag 0x80 is absent, but no. of dies > 2\n"));
            }
          }
        }
      }
      memcpy(fpgaStepping, &buffer[64], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[72], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[76]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[78]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
    }
    break;

  case DRAWING_NUM_ADMPCIE9H3:
  case DRAWING_NUM_ADMPCIE9H7:
    {
      uint8_t modifications8;
      uint32_t si5338RefClkFreq, emcclkFreq;
      uint16_t hbmFreq;
      uint8_t hbmDieOrder, hbmDieCount;
      uint64_t hbmDieSizeBytes;
      uint8_t customBuildCode, customBuildRevision;

      highestVersionRecognized = 0;
      pcbRev = GET_VPD_VAL8(&buffer[12]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      modifications8 = GET_VPD_VAL8(&buffer[13]);
      _tprintf(_T("  Modifications bitmask              %u (0x%02X)\n"),
        (unsigned int)modifications8, (unsigned int)modifications8);
      if (DRAWING_NUM_ADMPCIE9H7 == drawingNumber) {
        _tprintf(_T("                                     => SI5328 jitter attenuator: %s\n"), (modifications8 & 0x1U) ? _T("FITTED") : _T("NOT FITTED"));
        _tprintf(_T("                                     => Active cooling fans:      %s\n"), (modifications8 & 0x2U) ? _T("FITTED") : _T("NOT FITTED"));
      }
      customBuildCode = GET_VPD_VAL8(&buffer[14]);
      customBuildRevision = GET_VPD_VAL8(&buffer[15]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[16]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      emcclkFreq = GET_VPD_VAL32(&buffer[20]);
      _tprintf(_T("  EMCCLK clock frequency             %u (0x%08X) Hz\n"), emcclkFreq, emcclkFreq);
      hbmFreq = GET_VPD_VAL16(&buffer[24]);
      hbmDieCount = GET_VPD_VAL8(&buffer[26]);
      hbmDieOrder = GET_VPD_VAL8(&buffer[27]);
      _tprintf(_T("  HBM max. frequency                 %u (0x%04X) => %u MHz\n"),
        (unsigned int)hbmFreq, (unsigned int)hbmFreq, (unsigned int)(hbmFreq / 10));
      hbmDieSizeBytes = (uint64_t)1 << hbmDieOrder;
      _tprintf(_T("  HBM die capacity                   %u (0x%02X) => "),
        (unsigned int)hbmDieOrder, (unsigned int)hbmDieOrder);
      if (hbmDieSizeBytes >= Gi) {
        _tprintf(_T("%u GiB\n"), (unsigned int)(hbmDieSizeBytes / Gi));
      } else {
        _tprintf(_T("%u MiB\n"), (unsigned int)(hbmDieSizeBytes / Mi));
      }
      _tprintf(_T("  HBM die count                      %u (0x%02X)\n"),
        (unsigned int)hbmDieCount, (unsigned int)hbmDieCount);
      memcpy(fpgaStepping, &buffer[32], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[40], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[44]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[46]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
    }
    break;

  case DRAWING_NUM_ADMPCIE9V5:
    {
      uint8_t modifications8;
      uint32_t si5338RefClkFreq, emcclkFreq;
      uint8_t customBuildCode, customBuildRevision;

      highestVersionRecognized = 0;
      pcbRev = GET_VPD_VAL8(&buffer[12]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      modifications8 = GET_VPD_VAL8(&buffer[13]);
      _tprintf(_T("  Modifications bitmask              %u (0x%02X)\n"),
        (unsigned int)modifications8, (unsigned int)modifications8);
      customBuildCode = GET_VPD_VAL8(&buffer[14]);
      customBuildRevision = GET_VPD_VAL8(&buffer[15]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[16]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      emcclkFreq = GET_VPD_VAL32(&buffer[20]);
      _tprintf(_T("  EMCCLK clock frequency             %u (0x%08X) Hz\n"), emcclkFreq, emcclkFreq);
      memcpy(fpgaStepping, &buffer[32], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[40], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[44]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[46]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
    }
    break;

  case DRAWING_NUM_ADMSDEVBASE:
    {
      uint32_t si5338RefClkFreq;
      uint8_t modifications8, customBuildCode, customBuildRevision, fpgaSpaceGrade;

      pcbRev = GET_VPD_VAL8(&buffer[12]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      modifications8 = GET_VPD_VAL8(&buffer[13]);
      _tprintf(_T("  Modifications bitmask              %u (0x%02X)\n"),
        (unsigned int)modifications8, (unsigned int)modifications8);
      customBuildCode = GET_VPD_VAL8(&buffer[14]);
      customBuildRevision = GET_VPD_VAL8(&buffer[15]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[16]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      memcpy(fpgaStepping, &buffer[64], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[72], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[76]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[78]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
      fpgaSpaceGrade = GET_VPD_VAL8(&buffer[79]);
      _tprintf(_T("  FPGA space grade                   %u (0x%02X) => %s\n"),
        (unsigned int)fpgaSpaceGrade, (unsigned int)fpgaSpaceGrade, getFpgaSpaceGradeString(fpgaSpaceGrade));
    }
    break;

  case DRAWING_NUM_ADMVPX39Z2:
    {
      const TCHAR* coolingTypeDescs[] = { _T("Air-cooled commerical"), _T("/AC1 - air-cooled industrial"), _T("/CC1 - conduction-cooled industrial") };
      const TCHAR* coatingTypeDescs[] = { _T("No coating"), _T("/A - Acrylic (Humiseal 1B31)"), _T("/P - Polyurethane (Conathane CE-1155)") };
      const TCHAR* pCoolingTypeDesc = _T("UNRECOGNIZED");
      const TCHAR* pCoatingTypeDesc = _T("UNRECOGNIZED");
      uint8_t psQspiFlashOrder, customBuildCode, customBuildRevision, dramOrder, dramRanks;
      uint8_t psEmmcFlashOrder, psSataFlashOrder, coolingType, coatingType;
      uint16_t modifications16, dramFreq;
      uint32_t si5338RefClkFreq;
      uint64_t psQspiFlashSize, dramSizeBytes, psEmmcFlashSize, psSataFlashSize;

      modifications16 = GET_VPD_VAL16(&buffer[12]);
      _tprintf(_T("  Modifications bitmask              %u (0x%08X)\n"), modifications16, modifications16);
      _tprintf(_T("                                     => Optics: %s\n"), (modifications16 & 0x1U) ? _T("FITTED") : _T("NOT FITTED"));
      _tprintf(_T("                                     => VCC_PSBATT: %s\n"), (modifications16 & 0x2U) ? _T("ENABLED") : _T("DISABLED"));
      customBuildCode = GET_VPD_VAL8(&buffer[14]);
      customBuildRevision = GET_VPD_VAL8(&buffer[15]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[16]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      for (bank = 0; bank < 2; bank++) {
        psQspiFlashOrder = GET_VPD_VAL8(&buffer[28 + 2 * bank]);
        psQspiFlashSize = (uint64_t)((uint32_t)1 << psQspiFlashOrder);
        _tprintf(_T("  PS QSPI Flash bank %u size Log 2    %u (0x%02X) => "), bank, psQspiFlashOrder, psQspiFlashOrder);
        if (psQspiFlashSize >= Gi) {
          _tprintf(_T("%u GiB\n"), (unsigned int)(psQspiFlashSize / Gi));
        } else {
          _tprintf(_T("%u MiB\n"), (unsigned int)(psQspiFlashSize / Mi));
        }
      }
      dramFreq = GET_VPD_VAL16(&buffer[32]);
      dramOrder = GET_VPD_VAL8(&buffer[34]);
      dramRanks = GET_VPD_VAL8(&buffer[35]);
      _tprintf(_T("  PS DDR4 SDRAM max. frequency       %u (0x%04X) => %u MHz / DDR4-%u\n"),
        (unsigned int)dramFreq, (unsigned int)dramFreq,
        (unsigned int)((dramFreq + 5) / 10), (unsigned int)((dramFreq + 2) / 5));
      dramSizeBytes = ((uint64_t)1 << dramOrder) /* no. of words */ * 8U; /* bytes per word */
      _tprintf(_T("  PS DDR4 SDRAM 64b word size log 2  %u (0x%02X) => "),
        (unsigned int)dramOrder, (unsigned int)dramOrder);
      if (dramSizeBytes >= Gi) {
        _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
      } else {
        _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
      }
      _tprintf(_T("  PS DDR4 SDRAM ranks                %u (0x%02X) => "),
        (unsigned int)dramRanks, (unsigned int)dramRanks);
      if (dramRanks & 0x80U) {
        _tprintf(_T("multi-die, %u dies\n"), (unsigned int)(dramRanks & 0x7F));
        if ((dramRanks & 0x7F) < 2) {
          _tprintf(_T("*** ERROR: Multi-die flag 0x80 is present, but no. of dies < 2\n"));
        }
      } else {
        if ((dramRanks & 0x7FU) == 1) {
          _tprintf(_T("single-die\n"));
        } else if ((dramRanks & 0x7FU) == 2) {
          _tprintf(_T("traditional twin-die\n"));
        } else {
          _tprintf(_T("traditional %u dies\n"), (unsigned int)(dramRanks & 0x7F));
          _tprintf(_T("*** ERROR: Multi-die flag 0x80 is absent, but no. of dies > 2\n"));
        }
      }
      psEmmcFlashOrder = GET_VPD_VAL8(&buffer[40]);
      psEmmcFlashSize = (uint64_t)((uint64_t)1 << psEmmcFlashOrder);
      _tprintf(_T("  PS EMMC Flash size log 2           %u (0x%02X) => "), psEmmcFlashOrder, psEmmcFlashOrder);
      if (psEmmcFlashSize >= Gi) {
        _tprintf(_T("%u GiB\n"), (unsigned int)(psEmmcFlashSize / Gi));
      } else {
        _tprintf(_T("%u MiB\n"), (unsigned int)(psEmmcFlashSize / Mi));
      }
      psSataFlashOrder = GET_VPD_VAL8(&buffer[42]);
      psSataFlashSize = (uint64_t)((uint64_t)1 << psSataFlashOrder);
      _tprintf(_T("  PS SATA Flash size log 2           %u (0x%02X) => "), psSataFlashOrder, psSataFlashOrder);
      if (psSataFlashSize >= Gi) {
        _tprintf(_T("%u GiB\n"), (unsigned int)(psSataFlashSize / Gi));
      } else {
        _tprintf(_T("%u MiB\n"), (unsigned int)(psSataFlashSize / Mi));
      }
      coolingType = GET_VPD_VAL8(&buffer[44]);
      pCoolingTypeDesc = (coolingType < ARRAY_LENGTH(coolingTypeDescs)) ? coolingTypeDescs[coolingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Cooling type                       %u (0x%02X) => %s\n"),
        (unsigned int)coolingType, (unsigned int)coolingType, pCoolingTypeDesc);
      coatingType = GET_VPD_VAL8(&buffer[45]);
      pCoatingTypeDesc = (coatingType < ARRAY_LENGTH(coatingTypeDescs)) ? coatingTypeDescs[coatingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Coating type                       %u (0x%02X) => %s\n"),
        (unsigned int)coatingType, (unsigned int)coatingType, pCoatingTypeDesc);
      memcpy(fpgaStepping, &buffer[46], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[54], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[58]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[60]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
      pcbRev = GET_VPD_VAL8(&buffer[62]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
    }
    break;


  case DRAWING_NUM_ADMXRC9R1:
    {
      const TCHAR* coolingTypeDescs[] = {
          _T("Air-cooled commerical"),
          _T("/AC1 - air-cooled industrial"),
          _T("/CC1 - conduction-cooled industrial")
      };
      const TCHAR* coatingTypeDescs[] = {
        _T("No coating"),
        _T("/A - Acrylic"),
        _T("/P - Polyurethane") };
      const TCHAR* rfConnectorDescs[] = {
        _T("Right-angle Nicomatic (part CMM342D000F51-0020-240002)"),
        _T("Straight Nicomatic pins (part 22-1300-12)"),
        _T("Not fitted")
      };
      const TCHAR* adcTransformerDescs[] = {
        _T("MiniCircuits TCM2-43X+"),
        _T("MiniCircuits TCM2-672X+"),
        _T("MiniCircuits TCM2-63WX+")
      };
      const TCHAR* dacTransformerDescs[] = {
        _T("MiniCircuits TCM2-43X+"),
        _T("MiniCircuits TCM2-672X+"),
        _T("MiniCircuits TCM2-63WX+")
      };
      const TCHAR* fpgaPackageDescs[] = { _T("FFVE1156"), _T("FFSE1156") };
      const TCHAR* pCoolingTypeDesc = _T("UNRECOGNIZED");
      const TCHAR* pCoatingTypeDesc = _T("UNRECOGNIZED");
      const TCHAR* pRfConnectorDesc = _T("UNRECOGNIZED");
      const TCHAR* pAdcTransformerDesc = _T("UNRECOGNIZED");
      const TCHAR* pDacTransformerDesc = _T("UNRECOGNIZED");
      const TCHAR* pFpgaPackageDesc = _T("UNRECOGNIZED");
      uint8_t customBuildCode, customBuildRevision, dramOrder, dramRanks, fpgaPackage, cpldRev;
      uint8_t coolingType, coatingType, rfConnectorType;
      uint16_t dramFreq;
      uint32_t val32, modifications32, si5338RefClkFreq, psRefClkFreq;
      uint64_t dramSizeBytes;
      unsigned int bank;

      modifications32 = GET_VPD_VAL32(&buffer[12]);
      _tprintf(_T("  Modifications bitmask              %u (0x%08X)\n"), modifications32, modifications32);
      _tprintf(_T("                                     => Pn6 connector: %s\n"), (modifications32 & 0x1U) ? _T("NOT FITTED") : _T("FITTED"));
      _tprintf(_T("                                     => Pn4 connector: %s\n"), (modifications32 & 0x2U) ? _T("NOT FITTED") : _T("FITTED"));
      val32 = (modifications32 >> 3) & 0x3;
      if (val32 < ARRAY_LENGTH(adcTransformerDescs)) {
        pAdcTransformerDesc = adcTransformerDescs[val32];
      }
      _tprintf(_T("                                     => ADC RF Transformer: %s\n"), pAdcTransformerDesc);
      val32 = (modifications32 >> 10) & 0x3;
      if (val32 < ARRAY_LENGTH(dacTransformerDescs)) {
        pDacTransformerDesc = dacTransformerDescs[val32];
      }
      _tprintf(_T("                                     => DAC RF Transformer: %s\n"), pDacTransformerDesc);
      rfConnectorType = (uint8_t)((modifications32 >> 5) & 0x3);
      pRfConnectorDesc = (rfConnectorType < ARRAY_LENGTH(rfConnectorDescs)) ? rfConnectorDescs[rfConnectorType] : _T("UNRECOGNIZED");
      _tprintf(_T("                                     => RF connector: %s\n"), pRfConnectorDesc);
      ddr4Class = (uint8_t)((modifications32 >> 6) & 0xFU);
      switch (ddr4Class) {
      case 0:
        _tprintf(_T("                                     => DDR4-2400 CL16 (0000)\n"));
        break;

      case 1:
        _tprintf(_T("                                     => DDR4-2400 CL17 (0001)\n"));
        break;

      default:
        _tprintf(_T("                                     => UNRECOGNISED DDR4 CHIP CLASS %u(0x%X)\n"), (unsigned int)ddr4Class, (unsigned int)ddr4Class);
        break;
      }
      customBuildCode = GET_VPD_VAL8(&buffer[16]);
      customBuildRevision = GET_VPD_VAL8(&buffer[17]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      coolingType = GET_VPD_VAL8(&buffer[18]);
      pCoolingTypeDesc = (coolingType < ARRAY_LENGTH(coolingTypeDescs)) ? coolingTypeDescs[coolingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Cooling type                       %u (0x%02X) => %s\n"),
        (unsigned int)coolingType, (unsigned int)coolingType, pCoolingTypeDesc);
      coatingType = GET_VPD_VAL8(&buffer[19]);
      pCoatingTypeDesc = (coatingType < ARRAY_LENGTH(coatingTypeDescs)) ? coatingTypeDescs[coatingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Coating type                       %u (0x%02X) => %s\n"),
        (unsigned int)coatingType, (unsigned int)coatingType, pCoatingTypeDesc);
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[20]);
      _tprintf(_T("  SI5338 ref. clock frequency        %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      psRefClkFreq = GET_VPD_VAL32(&buffer[24]);
      _tprintf(_T("  PS ref. clock frequency            %u (0x%08X) Hz\n"), psRefClkFreq, psRefClkFreq);
      dramFreq = GET_VPD_VAL16(&buffer[28]);
      dramOrder = GET_VPD_VAL8(&buffer[30]);
      dramRanks = GET_VPD_VAL8(&buffer[31]);
      _tprintf(_T("  PS DDR4 SDRAM max. frequency       %u (0x%04X) => %u MHz / DDR4-%u\n"),
        (unsigned int)dramFreq, (unsigned int)dramFreq,
        (unsigned int)((dramFreq + 5) / 10), (unsigned int)((dramFreq + 2) / 5));
      dramSizeBytes = ((uint64_t)1 << dramOrder) /* no. of words */ * 4U; /* bytes per word */
      _tprintf(_T("  PS DDR4 SDRAM 32b word size log 2  %u (0x%02X) => "),
        (unsigned int)dramOrder, (unsigned int)dramOrder);
      if (dramSizeBytes >= Gi) {
        _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
      } else {
        _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
      }
      for (bank = 0; bank < 2; bank++) {
        dramFreq = GET_VPD_VAL16(&buffer[32 + 4 * bank]);
        dramOrder = GET_VPD_VAL8(&buffer[34 + 4 * bank]);
        dramRanks = GET_VPD_VAL8(&buffer[35 + 4 * bank]);
        _tprintf(_T("  PL DDR4 SDRAM bank %u max. freq.    %u (0x%04X) => %u MHz / DDR4-%u\n"),
          bank, (unsigned int)dramFreq, (unsigned int)dramFreq,
          (unsigned int)((dramFreq + 5) / 10), (unsigned int)((dramFreq + 2) / 5));
        dramSizeBytes = ((uint64_t)1 << dramOrder) /* no. of words */ * 1U; /* bytes per word */
        _tprintf(_T("  PL DDR4 SDRAM bank %u size log 2    %u (0x%02X) => "),
          bank, (unsigned int)dramOrder, (unsigned int)dramOrder);
        if (dramSizeBytes >= Gi) {
          _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
        } else {
          _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
        }
        _tprintf(_T("  PL DDR4 SDRAM bank %u ranks         %u (0x%02X) => "),
          bank, (unsigned int)dramRanks, (unsigned int)dramRanks);
        if (dramRanks & 0x80U) {
          _tprintf(_T("multi-die, %u dies\n"), (unsigned int)(dramRanks & 0x7F));
          if ((dramRanks & 0x7F) < 2) {
            _tprintf(_T("*** ERROR: Multi-die flag 0x80 is present, but no. of dies < 2\n"));
          }
        } else {
          if ((dramRanks & 0x7FU) == 1) {
            _tprintf(_T("single-die\n"));
          } else if ((dramRanks & 0x7FU) == 2) {
            _tprintf(_T("traditional twin-die\n"));
          } else {
            _tprintf(_T("traditional %u dies\n"), (unsigned int)(dramRanks & 0x7F));
            _tprintf(_T("*** ERROR: Multi-die flag 0x80 is absent, but no. of dies > 2\n"));
          }
        }
      }
      val32 = GET_VPD_VAL32(&buffer[40]);
      _tprintf(_T("  LMK04208 ref. clock frequency      %u (0x%X) Hz\n"), val32, val32);
      val32 = GET_VPD_VAL32(&buffer[44]);
      _tprintf(_T("  LMK04208 VCXO clock frequency      %u (0x%X) Hz\n"), val32, val32);
      memcpy(fpgaStepping, &buffer[48], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[56], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[60]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[62]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
      fpgaPackage = GET_VPD_VAL8(&buffer[63]);
      pFpgaPackageDesc = (fpgaPackage < ARRAY_LENGTH(fpgaPackageDescs)) ? fpgaPackageDescs[fpgaPackage] : _T("UNRECOGNIZED");
      _tprintf(_T("  FPGA package                       %u (0x%02X) => %s\n"),
        (unsigned int)fpgaPackage, (unsigned int)fpgaPackage, pFpgaPackageDesc);
      pcbRev = GET_VPD_VAL8(&buffer[64]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      cpldRev = GET_VPD_VAL8(&buffer[65]);
      _tprintf(_T("  CPLD revision                      %u (0x%02X) => %u.%u\n"),
        (unsigned int)cpldRev, (unsigned int)cpldRev, (unsigned int)((cpldRev >> 4) & 0xFU), (unsigned int)(cpldRev & 0xFU));
    }
    break;

  case DRAWING_NUM_ADMVPX39V2:
    {
      const TCHAR* coolingTypeDescs[] = { _T("Air-cooled commerical"), _T("/AC1 - air-cooled industrial"), _T("/CC1 - conduction-cooled industrial") };
      const TCHAR* coatingTypeDescs[] = { _T("No coating"), _T("/A - Acrylic (Humiseal 1B31)"), _T("/P - Polyurethane (Conathane CE-1155)") };
      const TCHAR* pCoolingTypeDesc = _T("UNRECOGNIZED");
      const TCHAR* pCoatingTypeDesc = _T("UNRECOGNIZED");
      uint8_t modifications8, coolingType, coatingType;
      uint8_t customBuildCode, customBuildRevision;
      uint32_t si5338RefClkFreq, emcclkFreq;
      uint16_t dramFreq[4];
      uint8_t dramOrder[4];
      uint64_t dramSizeBytes;

      pcbRev = GET_VPD_VAL8(&buffer[12]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      modifications8 = GET_VPD_VAL8(&buffer[13]);
      _tprintf(_T("  Modifications bitmask              %u (0x%08X)\n"), modifications8, modifications8);
      _tprintf(_T("                                     => FireFly connector: %s\n"), (modifications8 & 0x1U) ? _T("FITTED") : _T("NOT FITTED"));
      _tprintf(_T("                                     => SI5338 ref. clock: %s\n"), (modifications8 & 0x2U) ? _T("From VPX conn.") : _T("Internal"));
      customBuildCode = GET_VPD_VAL8(&buffer[14]);
      customBuildRevision = GET_VPD_VAL8(&buffer[15]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      coolingType = GET_VPD_VAL8(&buffer[16]);
      pCoolingTypeDesc = (coolingType < ARRAY_LENGTH(coolingTypeDescs)) ? coolingTypeDescs[coolingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Cooling type                       %u (0x%02X) => %s\n"),
        (unsigned int)coolingType, (unsigned int)coolingType, pCoolingTypeDesc);
      coatingType = GET_VPD_VAL8(&buffer[17]);
      pCoatingTypeDesc = (coatingType < ARRAY_LENGTH(coatingTypeDescs)) ? coatingTypeDescs[coatingType] : _T("UNRECOGNIZED");
      _tprintf(_T("  Coating type                       %u (0x%02X) => %s\n"),
        (unsigned int)coatingType, (unsigned int)coatingType, pCoatingTypeDesc);
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[32]);
      _tprintf(_T("  Internal SI5338 ref. clock freq.   %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      emcclkFreq = GET_VPD_VAL32(&buffer[36]);
      _tprintf(_T("  EMCCLK clock frequency             %u (0x%08X) Hz\n"), emcclkFreq, emcclkFreq);
      for (bank = 0; bank < 4; bank++) {
        dramFreq[bank] = GET_VPD_VAL16(&buffer[48 + 4 * bank]);
        dramOrder[bank] = GET_VPD_VAL8(&buffer[50 + 4 * bank]);
        _tprintf(_T("  DDR4 SDRAM bank %u max. frequency   %u (0x%04X) => %u MHz / DDR4-%u\n"),
          bank, (unsigned int)dramFreq[bank], (unsigned int)dramFreq[bank],
          (unsigned int)(dramFreq[bank] + 5) / 10, (unsigned int)(dramFreq[bank] + 2) / 5);
        dramSizeBytes = ((uint64_t)1 << dramOrder[bank]) /* no. of words */ * 8U; /* bytes per word */
        _tprintf(_T("  DDR4 SDRAM bank %u size             %u (0x%02X) => "),
          bank, (unsigned int)dramOrder[bank], (unsigned int)dramOrder[bank]);
        if (dramSizeBytes >= Gi) {
          _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
        } else {
          _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
        }
      }
      memcpy(fpgaStepping, &buffer[64], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[72], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[76]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[78]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
    }
    break;

  case DRAWING_NUM_ADMPA100:
  case DRAWING_NUM_ADMPA101:
    {
      uint8_t modifications8;
      uint8_t customBuildCode, customBuildRevision;
      uint32_t si5338RefClkFreq, emcclkFreq;
      uint16_t dramFreq[2];
      uint8_t dramOrder[2];
      uint64_t dramSizeBytes;

	  pcbRev = GET_VPD_VAL8(&buffer[12]);
      _tprintf(_T("  PCB revision                       %u (0x%02X) => %u.%u\n"),
        (unsigned int)pcbRev, (unsigned int)pcbRev, (unsigned int)((pcbRev >> 4) & 0xFU), (unsigned int)(pcbRev & 0xFU));
      modifications8 = GET_VPD_VAL8(&buffer[13]);
      _tprintf(_T("  Modifications bitmask              %u (0x%02X)\n"), modifications8, modifications8);
      _tprintf(_T("                                     => Heatsink: %s\n"), (modifications8 & 0x1U) ? _T("2-SLOT") : _T("1-SLOT"));
      _tprintf(_T("                                     => Fans: %s\n"), (modifications8 & 0x2U) ? _T("FITTED") : _T("NOT FITTED"));
      _tprintf(_T("                                     => Top shroud: %s\n"), (modifications8 & 0x4U) ? _T("FITTED") : _T("NOT FITTED"));
      customBuildCode = GET_VPD_VAL8(&buffer[14]);
      customBuildRevision = GET_VPD_VAL8(&buffer[15]);
      _tprintf(_T("  Custom build code, revision        %u, %u => "),
        (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      if (0 == customBuildCode) {
        _tprintf(_T("Standard build\n"));
      } else {
        _tprintf(_T("/C%u.%u\n"),
          (unsigned int)customBuildCode, (unsigned int)customBuildRevision);
      }
      si5338RefClkFreq = GET_VPD_VAL32(&buffer[32]);
      _tprintf(_T("  Internal SI5338 ref. clock freq.   %u (0x%08X) Hz\n"), si5338RefClkFreq, si5338RefClkFreq);
      emcclkFreq = GET_VPD_VAL32(&buffer[36]);
      _tprintf(_T("  EMCCLK clock frequency             %u (0x%08X) Hz\n"), emcclkFreq, emcclkFreq);
      for (bank = 0; bank < 2; bank++) {
        dramFreq[bank] = GET_VPD_VAL16(&buffer[48 + 4 * bank]);
        dramOrder[bank] = GET_VPD_VAL8(&buffer[50 + 4 * bank]);
        _tprintf(_T("  DDR4 SDRAM bank %u max. frequency   %u (0x%04X) => %u MHz / DDR4-%u\n"),
          bank, (unsigned int)dramFreq[bank], (unsigned int)dramFreq[bank],
          (unsigned int)(dramFreq[bank] + 5) / 10, (unsigned int)(dramFreq[bank] + 2) / 5);
        dramSizeBytes = ((uint64_t)1 << dramOrder[bank]) /* no. of words */ * 8U; /* bytes per word */
        _tprintf(_T("  DDR4 SDRAM bank %u size             %u (0x%02X) => "),
          bank, (unsigned int)dramOrder[bank], (unsigned int)dramOrder[bank]);
        if (dramSizeBytes >= Gi) {
          _tprintf(_T("%u GiB\n"), (unsigned int)(dramSizeBytes / Gi));
        } else {
          _tprintf(_T("%u MiB\n"), (unsigned int)(dramSizeBytes / Mi));
        }
      }
      memcpy(fpgaStepping, &buffer[64], 8);
      fpgaStepping[8] = '\0';
      _tprintf(_T("  FPGA stepping                      \""));
      printf("%s", fpgaStepping);
      _tprintf(_T("\"\n"));
      memcpy(fpgaSpeedGrade, &buffer[72], 4);
      fpgaSpeedGrade[4] = '\0';
      _tprintf(_T("  FPGA speed grade                   \""));
      printf("%s", fpgaSpeedGrade);
      _tprintf(_T("\"\n"));
      fpgaDevice = GET_VPD_VAL16(&buffer[76]);
      _tprintf(_T("  FPGA device                        %u (0x%04X) => %s\n"),
        (unsigned int)fpgaDevice, (unsigned int)fpgaDevice, getFpgaDeviceString(fpgaDevice));
      fpgaTempGrade = GET_VPD_VAL8(&buffer[78]);
      _tprintf(_T("  FPGA temperature grade             %u (0x%02X) => %s\n"),
        (unsigned int)fpgaTempGrade, (unsigned int)fpgaTempGrade, getFpgaTempGradeString(fpgaTempGrade));
	}
	break;

  default:
    _tprintf(_T("WARNING: Unable to decode remaining data for UNRECOGNIZED drawing number.\n"));
    _tprintf(_T("         Use the 'display-vpd-raw' command in order to display raw VPD.\n"));
    break;
  }

  if (length >= 5 && length <= VPD_LENGTH_LIMIT) {
    unsigned int nCheck = length - 1U;

    checksum = GET_VPD_VAL8(&buffer[length - 1]);
    _tprintf(_T("  Data structure checksum            %u (0x%02X)\n"),
      (unsigned int)checksum, (unsigned int)checksum);
    calcChecksum = 0;
    for (i = 0; i < nCheck; i++) {
      calcChecksum = (uint8_t)(calcChecksum + GET_VPD_VAL8(&buffer[i]));
    }
    calcChecksum = (uint8_t)-calcChecksum;
    if (calcChecksum != checksum) {
      _tprintf(_T("*** ERROR: Calculated checksum %u 0x%02X does not match actual checksum %u (0x%02X)\n"),
        (unsigned int)calcChecksum, (unsigned int)calcChecksum, (unsigned int)checksum, (unsigned int)checksum);
    }
  } else {
    _tprintf(_T("*** ERROR: Unable to verify checksum because data structure length %u (0x%04X) is invalid\n"),
      (unsigned int)length, (unsigned int)length);
  }

  if (version > highestVersionRecognized) {
    _tprintf(_T("WARNING: Data structure version %u is not recognized by this version of avr2util.\n"), (unsigned int)version);
    _tprintf(_T("         Highest data structure version recognised is %u.\n"), (unsigned int)highestVersionRecognized);
    _tprintf(_T("         Some fields of the VPD might not be displayed.\n"));
  }

done:
  return ret;
}

static int
displayVpdRawCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  const unsigned int vpdLengthLimit = VPD_LENGTH_LIMIT;
  uint8_t buffer[256]; /* Request VPD command requires buffer of 256 bytes */
  unsigned int i, j;
  int ret = EXIT_OK;

  memset(buffer, 0, 256);

  if (pDevice->bInServiceMode) {
    /* In Service Mode, get VPD by reading AVR Flash */
    ret = readApplicationFlash(pDevice, bVerbose, VPD_BASE_ADDR, buffer, vpdLengthLimit);
  } else {
    /* In Application Mode, request VPD using command */
    ret = avr2UtilRequestVpdData(pDevice, bVerbose, buffer);
  }

  if (ret) {
    goto done;
  }

  _tprintf(_T("Raw VPD:\n"));
  _tprintf(_T("     "));
  for (i = 0; i < 16; i++) {
    _tprintf(_T(" +%X"), i);
  }
  _tprintf(_T("\n"));
  for (i = 0; i < vpdLengthLimit; i += 16) {
    _tprintf(_T("0x%02X:"), i);
    for (j = 0; j < 16; j++) {
      _tprintf(_T(" %02X"), buffer[i + j]);
    }
    _tprintf(_T(" "));
    for (j = 0; j < 16; j++) {
      if (isprint(buffer[i + j])) {
        printf("%c", buffer[i + j]);
      } else {
        printf(".");
      }
    }
    _tprintf(_T("\n"));
  }

done:
  return ret;
}

static void
displaySensorPage(
  uint32_t nDrawingNumber,
  uint8_t buffer[64])
{
  const double adcScale = 1.0 / 4096.0;
  const double tmpScale = 1.0 / 16.0;
  const double zeroCelsiusInK = 273.15;
  uint32_t etc, ec;
  uint16_t adc, tmp;
  uint8_t mezStat, crdStat0, crdStat1, crdStat2, crdStat3, si5338Stat, si5338Err, adcStat, tmpStat, reserved63;
  SensorInfo sensorInfo;
  unsigned int i;

  etc = ((uint32_t)buffer[0] << 0) | ((uint32_t)buffer[1] << 8) | ((uint32_t)buffer[2] << 16) | ((uint32_t)buffer[3] << 24);
  _tprintf(_T("  ETC         = { 0x%02X 0x%02X 0x%02X 0x%02X } => %u (0x%08X)\n"),
    buffer[0], buffer[1], buffer[2], buffer[3], etc, etc);
  ec = ((uint32_t)buffer[4] << 0) | ((uint32_t)buffer[5] << 8) | ((uint32_t)buffer[6] << 16) | ((uint32_t)buffer[7] << 24);
  _tprintf(_T("  EC          = { 0x%02X 0x%02X 0x%02X 0x%02X } => %u (0x%08X)\n"),
    buffer[4], buffer[5], buffer[6], buffer[7], ec, ec);
  for (i = 0; i < 14; i++) {
    getSensorInfo(nDrawingNumber, i, &sensorInfo);
    adc = (uint16_t)(((uint16_t)buffer[8 + i * 2] << 0) | ((uint16_t)buffer[9 + i * 2] << 8));
    _tprintf(_T("  ADC%02u (#%02u) = { 0x%02X 0x%02X }           => 0x%04X => %.3f %s [%s]\n"),
      i, i, buffer[8 + i * 2], buffer[9 + i * 2], adc, (double)adc * adcScale,
      sensorInfo.pSensorUnit, sensorInfo.pSensorName);
    adcStat = (uint8_t)((i & 0x1U) ? (uint8_t)((buffer[54 + (i >> 1)] & 0xF0U) >> 4) : (uint8_t)((buffer[54 + (i >> 1)] & 0xFU) >> 0));
  }
  for (i = 0; i < 4; i++) {
    getSensorInfo(nDrawingNumber, i + 14, &sensorInfo);
    tmp = (uint16_t)(((uint16_t)buffer[36 + i * 2] << 0) | ((uint16_t)buffer[37 + i * 2] << 8));
    _tprintf(_T("  TMP%02u (#%02u) = { 0x%02X 0x%02X }           => 0x%04X => %.3f %s [%s]\n"),
      i, i + 14, buffer[36 + i * 2], buffer[37 + i * 2], tmp, (double)tmp * tmpScale - zeroCelsiusInK,
      sensorInfo.pSensorUnit, sensorInfo.pSensorName);
  }
  for (i = 0; i < 4; i++) {
    mezStat = buffer[44 + i];
    _tprintf(_T("  MEZ_STAT%u   = 0x%02X                    => F/PresC%c PresB%c DataErr%c CsumErr%c I2cFail%c PwrOK%c VIOEn%c PresA%c\n"),
      i, mezStat,
      (mezStat & 0x80U) ? _T('+') : _T('-'), (mezStat & 0x40U) ? _T('+') : _T('-'),
      (mezStat & 0x20U) ? _T('+') : _T('-'), (mezStat & 0x10U) ? _T('+') : _T('-'),
      (mezStat & 0x08U) ? _T('+') : _T('-'), (mezStat & 0x04U) ? _T('+') : _T('-'),
      (mezStat & 0x02U) ? _T('+') : _T('-'), (mezStat & 0x01U) ? _T('+') : _T('-'));
  }
  crdStat0 = buffer[48];
  _tprintf(_T("  CRD_STAT0   = 0x%02X                    => PSU7OK%c PSU6OK%c PSU5OK%c PSU4OK%c PSU3OK%c PSU2OK%c PSU1OK%c PSU0OK%c\n"),
    crdStat0,
    (crdStat0 & 0x80U) ? _T('+') : _T('-'), (crdStat0 & 0x40U) ? _T('+') : _T('-'),
    (crdStat0 & 0x20U) ? _T('+') : _T('-'), (crdStat0 & 0x10U) ? _T('+') : _T('-'),
    (crdStat0 & 0x08U) ? _T('+') : _T('-'), (crdStat0 & 0x04U) ? _T('+') : _T('-'),
    (crdStat0 & 0x02U) ? _T('+') : _T('-'), (crdStat0 & 0x01U) ? _T('+') : _T('-'));
  crdStat1 = buffer[49];
  _tprintf(_T("  CRD_STAT1   = 0x%02X                    => PSUOffReq%c PSU_AUX%c Resvd5%c BrdCfgVal%c DONE3%c DONE2%c DONE1%c DONE0%c\n"),
    crdStat1,
    (crdStat1 & 0x80U) ? _T('+') : _T('-'), (crdStat1 & 0x40U) ? _T('+') : _T('-'),
    (crdStat1 & 0x20U) ? _T('+') : _T('-'), (crdStat1 & 0x10U) ? _T('+') : _T('-'),
    (crdStat1 & 0x08U) ? _T('+') : _T('-'), (crdStat1 & 0x04U) ? _T('+') : _T('-'),
    (crdStat1 & 0x02U) ? _T('+') : _T('-'), (crdStat1 & 0x01U) ? _T('+') : _T('-'));
  crdStat2 = buffer[50];
  _tprintf(_T("  CRD_STAT2   = 0x%02X                    => HostRst%c USBCon%c GAP%c GA=%u(0x%x)\n"),
    crdStat2,
    (crdStat2 & 0x80U) ? _T('+') : _T('-'), (crdStat2 & 0x40U) ? _T('+') : _T('-'),
    (crdStat2 & 0x20U) ? _T('+') : _T('-'), crdStat2 & 0x1FU, crdStat2 & 0x1FU);
  crdStat3 = buffer[51];
  _tprintf(_T("  CRD_STAT3   = 0x%02X                       (reserved)\n"), crdStat3);
  si5338Stat = buffer[52];
  _tprintf(_T("  SI5338_STAT = 0x%02X                    => CFG3OK%c CFG2OK%c CFG1OK%c CFG0OK%c Resvd3%c Resvd2%c IntRegd%c InitOK%c\n"),
    si5338Stat,
    (si5338Stat & 0x80U) ? _T('+') : _T('-'), (si5338Stat & 0x40U) ? _T('+') : _T('-'),
    (si5338Stat & 0x20U) ? _T('+') : _T('-'), (si5338Stat & 0x10U) ? _T('+') : _T('-'),
    (si5338Stat & 0x08U) ? _T('+') : _T('-'), (si5338Stat & 0x04U) ? _T('+') : _T('-'),
    (si5338Stat & 0x02U) ? _T('+') : _T('-'), (si5338Stat & 0x01U) ? _T('+') : _T('-'));
  si5338Err = buffer[53];
  _tprintf(_T("  SI5338_ERR  = 0x%02X                    => ErrType=%u ErrCode=%u\n"),
    si5338Err, (si5338Err >> 4) & 0xFU, (si5338Err >> 0) & 0xFU);
  for (i = 0; i < 14; i++) {
    adcStat = (uint8_t)((i & 0x1U) ? (uint8_t)((buffer[54 + (i >> 1)] & 0xF0U) >> 4) : (uint8_t)((buffer[54 + (i >> 1)] & 0xFU) >> 0));
    _tprintf(_T("  ADC_STAT%02u  = 0x%X                     => OK%c Critical%c Over%c Under%c\n"),
      i, adcStat,
      (adcStat & 0x08U) ? _T('+') : _T('-'), (adcStat & 0x04U) ? _T('+') : _T('-'),
      (adcStat & 0x02U) ? _T('+') : _T('-'), (adcStat & 0x01U) ? _T('+') : _T('-'));
  }
  for (i = 0; i < 4; i++) {
    tmpStat = (uint8_t)((i & 0x1U) ? (uint8_t)((buffer[61 + (i >> 1)] & 0xF0U) >> 4) : (uint8_t)((buffer[61 + (i >> 1)] & 0xFU) >> 0));
    _tprintf(_T("  TMP_STAT%02u  = 0x%X                     => OK%c Critical%c Over%c Under%c\n"),
      i, tmpStat,
      (tmpStat & 0x08U) ? _T('+') : _T('-'), (tmpStat & 0x04U) ? _T('+') : _T('-'),
      (tmpStat & 0x02U) ? _T('+') : _T('-'), (tmpStat & 0x01U) ? _T('+') : _T('-'));
  }
  reserved63 = buffer[63];
  _tprintf(_T("  RESVD63     = 0x%02X                       (reserved)\n"), reserved63);
}

/* Returns true if etc1 > etc2 */
static bool_t
recordIsLater(
  uint32_t etc1,
  uint32_t etc2)
{
  if (etc1 == 0xFFFFFFFF) {
    /* Invalid timestamp, etc2 must be later */
    return FALSE;
  }
  if (etc2 == 0xFFFFFFFF) {
    /* Invalid timestamp, etc1 must be later */
    return TRUE;
  }
  return (etc1 > etc2) ? TRUE : FALSE;
}

static int
displayBlackBoxCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int nTypes,
  unsigned int nMaxRecordDisplayed)
{
  typedef struct _Record {
    uint32_t nPageIndex;
    uint8_t page[SENSOR_PAGE_LENGTH_LIMIT];
  } Record;
  Record clobberRecords[BLACK_BOX_NUM_CLOBBER_RECORD];
  Record noclobberRecords[BLACK_BOX_NUM_NOCLOBBER_RECORD];
  Record tmpRecord[SENSOR_PAGE_LENGTH_LIMIT];
  uint8_t vpdBuffer[256]; /* Request VPD command requires buffer of 256 bytes */
  uint8_t nRecordIndex, nCompareIndex;
  Record* pRecord;
  Record* pCompareRecord;
  uint32_t etc, compareEtc;
  uint32_t nDrawingNumber;
  bool_t bNeedBlankLine = FALSE;
  int ret = EXIT_OK;

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The display-sensors-raw command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  /* In Application Mode, request VPD using command */
  ret = avr2UtilRequestVpdData(pDevice, bVerbose, vpdBuffer);
  if (ret) {
    return ret;
  }

  if (nTypes & 0x1) {
    for (nRecordIndex = 0; nRecordIndex < BLACK_BOX_NUM_CLOBBER_RECORD; nRecordIndex++) {
      ret = requestBlackBoxRecord(pDevice, bVerbose, nRecordIndex, clobberRecords[nRecordIndex].page);
      if (EXIT_OK != ret) {
        _tprintf(_T("*** Failed to read black-box clobber record with index %u.\n"), nRecordIndex);
        goto done;
      }
      clobberRecords[nRecordIndex].nPageIndex = nRecordIndex;
    }
  }

  if (nTypes & 0x2) {
    for (nRecordIndex = 0; nRecordIndex < BLACK_BOX_NUM_NOCLOBBER_RECORD; nRecordIndex++) {
      ret = requestBlackBoxRecord(pDevice, bVerbose, nRecordIndex + BLACK_BOX_NUM_CLOBBER_RECORD, noclobberRecords[nRecordIndex].page);
      if (EXIT_OK != ret) {
        _tprintf(_T("*** Failed to read black-box noclobber record with index %u.\n"), nRecordIndex + BLACK_BOX_NUM_CLOBBER_RECORD);
        goto done;
      }
      noclobberRecords[nRecordIndex].nPageIndex = nRecordIndex + BLACK_BOX_NUM_CLOBBER_RECORD;
    }
  }

done:
  nDrawingNumber = GET_VPD_VAL32(&vpdBuffer[4]);

  if (nTypes & 0x1) {
    /* Sort clobber records by timestamp, from latest to oldest. */
    for (nRecordIndex = 0; nRecordIndex < BLACK_BOX_NUM_CLOBBER_RECORD; nRecordIndex++) {
      pRecord = &clobberRecords[nRecordIndex];
      etc = ((uint32_t)pRecord->page[0] << 0) | ((uint32_t)pRecord->page[1] << 8) | ((uint32_t)pRecord->page[2] << 16) | ((uint32_t)pRecord->page[3] << 24);

      for (nCompareIndex = nRecordIndex + 1; nCompareIndex < BLACK_BOX_NUM_CLOBBER_RECORD; nCompareIndex++) {
        pCompareRecord = &clobberRecords[nCompareIndex];
        compareEtc = ((uint32_t)pCompareRecord->page[0] << 0) | ((uint32_t)pCompareRecord->page[1] << 8) | ((uint32_t)pCompareRecord->page[2] << 16) | ((uint32_t)pCompareRecord->page[3] << 24);

        if (recordIsLater(compareEtc, etc)) {
          memcpy(tmpRecord, pRecord, sizeof(Record));
          memcpy(pRecord, pCompareRecord, sizeof(Record));
          memcpy(pCompareRecord, tmpRecord, sizeof(Record));
          etc = compareEtc;
        }
      }
    }

    /* Display sorted clobber records. */
    for (nRecordIndex = 0; nRecordIndex < BLACK_BOX_NUM_CLOBBER_RECORD && (nMaxRecordDisplayed == 0 || nRecordIndex < nMaxRecordDisplayed); nRecordIndex++) {
      pRecord = &clobberRecords[nRecordIndex];
      etc = ((uint32_t)pRecord->page[0] << 0) | ((uint32_t)pRecord->page[1] << 8) | ((uint32_t)pRecord->page[2] << 16) | ((uint32_t)pRecord->page[3] << 24);
      if (0xFFFFFFFF == etc) {
        /* Max. timestamp => record not valid */
        break;
      }

      if (0 == nRecordIndex) {
        _tprintf(_T("-------------------------------------------------------------------------------\n"));
      }
      _tprintf(_T("Black box clobber record (page %u):\n"), pRecord->nPageIndex);
      displaySensorPage(nDrawingNumber, pRecord->page);
      _tprintf(_T("-------------------------------------------------------------------------------\n"));
    }

    if (0 == nRecordIndex) {
      _tprintf(_T("No black box clobber records found.\n"));
    } else {
      bNeedBlankLine = TRUE;
    }
  }

  if (nTypes & 0x2) {
    /* Sort noclobber records by timestamp, from latest to oldest. */
    for (nRecordIndex = 0; nRecordIndex < BLACK_BOX_NUM_NOCLOBBER_RECORD; nRecordIndex++) {
      pRecord = &noclobberRecords[nRecordIndex];
      etc = ((uint32_t)pRecord->page[0] << 0) | ((uint32_t)pRecord->page[1] << 8) | ((uint32_t)pRecord->page[2] << 16) | ((uint32_t)pRecord->page[3] << 24);

      for (nCompareIndex = nRecordIndex + 1; nCompareIndex < BLACK_BOX_NUM_NOCLOBBER_RECORD; nCompareIndex++) {
        pCompareRecord = &noclobberRecords[nCompareIndex];
        compareEtc = ((uint32_t)pCompareRecord->page[0] << 0) | ((uint32_t)pCompareRecord->page[1] << 8) | ((uint32_t)pCompareRecord->page[2] << 16) | ((uint32_t)pCompareRecord->page[3] << 24);

        if (recordIsLater(compareEtc, etc)) {
          memcpy(tmpRecord, pRecord, sizeof(Record));
          memcpy(pRecord, pCompareRecord, sizeof(Record));
          memcpy(pCompareRecord, tmpRecord, sizeof(Record));
          etc = compareEtc;
        }
      }
    }

    /* Display sorted noclobber records. */
    for (nRecordIndex = 0; nRecordIndex < BLACK_BOX_NUM_NOCLOBBER_RECORD && (nMaxRecordDisplayed == 0 || nRecordIndex < nMaxRecordDisplayed); nRecordIndex++) {
      pRecord = &noclobberRecords[nRecordIndex];
      etc = ((uint32_t)pRecord->page[0] << 0) | ((uint32_t)pRecord->page[1] << 8) | ((uint32_t)pRecord->page[2] << 16) | ((uint32_t)pRecord->page[3] << 24);
      if (0xFFFFFFFF == etc) {
        /* Max. timestamp => record not valid */
        break;
      }

      if (0 == nRecordIndex) {
        if (bNeedBlankLine) {
          _tprintf(_T("\n"));
          bNeedBlankLine = FALSE;
        }
        _tprintf(_T("-------------------------------------------------------------------------------\n"));
      }
      _tprintf(_T("Black box noclobber record (page %u):\n"), pRecord->nPageIndex);
      displaySensorPage(nDrawingNumber, pRecord->page);
      _tprintf(_T("-------------------------------------------------------------------------------\n"));
    }

    if (0 == nRecordIndex) {
      _tprintf(_T("No black box noclobber records found.\n"));
    }
  }

  return ret;
}

static int
displaySensorsCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  uint8_t buffer[SENSOR_PAGE_LENGTH_LIMIT]; /* Request Sensors command requires buffer of SENSOR_PAGE_LENGTH_LIMIT (64) bytes */
  uint8_t vpdBuffer[256]; /* Request VPD command requires buffer of 256 bytes */
  uint32_t nDrawingNumber;
  int ret = EXIT_OK;

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The display-sensors command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  /* In Application Mode, request VPD using command */
  ret = avr2UtilRequestVpdData(pDevice, bVerbose, vpdBuffer);
  if (ret) {
    goto done;
  }

  /* In Application Mode, request sensor data using command */
  ret = requestSensors(pDevice, bVerbose, buffer);

done:
  if (EXIT_OK == ret) {
    nDrawingNumber = GET_VPD_VAL32(&vpdBuffer[4]);

    _tprintf(_T("Human-readable Sensor Page:\n"));
    displaySensorPage(nDrawingNumber, buffer);
  }

  return ret;
}

static int
displaySensorsRawCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  uint8_t sensorPage[SENSOR_PAGE_LENGTH_LIMIT]; /* Request Sensors command requires buffer of SENSOR_PAGE_LENGTH_LIMIT (64) bytes */
  unsigned int i, j;
  int ret = EXIT_OK;

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The display-sensors-raw command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }

  /* In Application Mode, request sensor data using command */
  ret = requestSensors(pDevice, bVerbose, sensorPage);

  if (EXIT_OK == ret) {
    _tprintf(_T("Raw Sensor Page:\n"));
    _tprintf(_T("     "));
    for (i = 0; i < 16; i++) {
      _tprintf(_T(" +%X"), i);
    }
    _tprintf(_T("\n"));
    for (i = 0; i < SENSOR_PAGE_LENGTH_LIMIT; i += 16) {
      _tprintf(_T("0x%02X:"), i);
      for (j = 0; j < 16; j++) {
        _tprintf(_T(" %02X"), sensorPage[i + j]);
      }
      _tprintf(_T(" "));
      for (j = 0; j < 16; j++) {
        if (isprint(sensorPage[i + j])) {
          printf("%c", sensorPage[i + j]);
        } else {
          printf(".");
        }
      }
      _tprintf(_T("\n"));
    }
  }

  return ret;
}

static int
overrideSensorUnscaledCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int sensorIndex,
  unsigned int overrideValue)
{
  int ret = EXIT_OK;

  if (sensorIndex >= 0xFFU) {
    _tprintf(_T("*** Sensor index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The override-sensor command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }
  
  ret = overrideSensor(pDevice, bVerbose, (uint8_t)sensorIndex /* cast safe due to range check above */, overrideValue, TRUE);

  return ret;
}

static int
releaseSensorCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int sensorIndex)
{
  int ret = EXIT_OK;

  if (sensorIndex >= 0xFFU) {
    _tprintf(_T("*** Sensor index must be in the range 0 to 255.\n"));
    return EXIT_INVALID_INDEX;
  }

  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The release-sensor command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }
  
  ret = overrideSensor(pDevice, bVerbose, (uint8_t)sensorIndex /* cast safe due to range check above */, 0, FALSE /* Stop overriding */);

  return ret;
}

static int
testClobberCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  uint8_t command[2];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;
  
  if (pDevice->bInServiceMode) {
    _tprintf(_T("*** The test-clobber command requires the device to not be in Service Mode.\n"));
    _tprintf(_T("    Please exit Service Mode manually using switch setting or by issuing the exit-service-mode command.\n"));
    return EXIT_WRONG_MODE;
  }
  
  command[0] = 0x05; /* User extended command group */
  command[1] = 0x86; /* InvokeProtectionProtocol command */
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x06; /* InvokeProtectionProtocol response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      break;
    }
    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
    ret = EXIT_AVR2_BAD_STATUS;
  }

done:
  return ret;
}

/* This function sends an invalid command to the microcontroller, which should always result in a time out.
** This can be used as a simple test of the timeout mechanism or for testing cancellation in the driver. */
static int
testTimeoutCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  uint8_t command[2];
  uint8_t response[2];
  uint8_t expResponse[2];
  uint32_t responseLength;
  int ret = EXIT_OK;
    
  command[0] = 0xff; /* Invalid command group */
  command[1] = 0x81;
  expResponse[0] = 0xff; /* Invalid command group */
  expResponse[1] = 0x01;

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    command,
    sizeof(command),
    expResponse,
    response,
    sizeof(response),
    &responseLength);
  if (EXIT_AVR2_COMMAND_ERROR == ret) {
    /* We expect this command to fail. */
    ret = EXIT_OK;
    goto done;
  } else if (EXIT_OK == ret) {
    _tprintf(_T("*** Microcontroller command succeeded unexpectedly.\n"));
  } else {
    _tprintf(_T("*** Microcontroller command failed, but not in the expected way.\n"));
  }

  ret = EXIT_AVR2_COMMAND_ERROR;

done:
  return ret;
}

/* This function sends an an arbitary command to the microcontroller. It is intended for firmware
** testing by Alpha Data. */
static int
rawCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int readCount,
  unsigned int writeCount,
  const uint8_t* pWriteBytes)
{
  uint8_t expResponse[2];
  uint32_t responseLength;
  uint8_t* pResponseBuffer = NULL;
  unsigned int i;
  int ret = EXIT_OK;
  
  pResponseBuffer = (uint8_t*)malloc(readCount);
  if (NULL == pResponseBuffer) {
    _tprintf(_T("*** Failed to allocate response buffer.\n"));
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  expResponse[0] = pWriteBytes[0];
  expResponse[1] = (uint8_t)(pWriteBytes[1] ^ 0x80);

  memset(pResponseBuffer, 0, readCount);

  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    pDevice->nCommandTimeoutUs,
    pWriteBytes,
    (uint32_t)writeCount,
    expResponse,
    pResponseBuffer,
    readCount,
    &responseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  _tprintf(_T("Expected/actual response length = %u / %u\n"), readCount, responseLength);
  for (i = 0; i < readCount; i++) {
    _tprintf(_T("%02X "), pResponseBuffer[i]);
  }
  _tprintf(_T("\n"));

done:
  return ret;
}

static int
modelSanityCheck(
  ADB3_HANDLE hDeviceAdb3,
  API_ADB3* pApi)
{
  ADB3_STATUS status;
  ADB3_UNIQUE_ID id;
  int i;

  status = pApi->pfnADB3_GetUniqueId(hDeviceAdb3, &id);
  if (ADB3_SUCCESS != status) {
    _tprintf(_T("*** Failed to get type of card: %s\n"), pApi->pfnADB3_GetStatusString(status, TRUE));
    return EXIT_UNSUPPORTED_MODEL;
  }

  for (i = 0; i < ARRAY_LENGTH(g_adb3SupportedModels); i++) {
    if (g_adb3SupportedModels[i].modelType == (ADMXRC3_MODEL_TYPE)id.Model) {
      return EXIT_OK;
    }
  }

  _tprintf(_T("*** This version of %s can be used only with the following models:\n"), PROGRAM_NAME);
  _tprintf(_T("\n"));
  for (i = 0; i < ARRAY_LENGTH(g_adb3SupportedModels); i++) {
    _tprintf(_T("  o %s\n"), g_adb3SupportedModels[i].pszModelName);
  }
  return EXIT_UNSUPPORTED_MODEL;
}

static void
closeDevice(
  DeviceHandle* pDevice)
{
  if (pDevice->bValid) {
    switch (pDevice->nInterfaceType) {
#if defined(AVR2_VIA_USB_SUPPORTED)
    case Avr2utilInterfaceAVR2:
      pDevice->variant.avr2.api.pfnAVR2_Close(pDevice->variant.avr2.hDevice);
      break;
#endif

#if defined(AVR2_VIA_SMBUS_SUPPORTED)
    case Avr2utilInterfaceAVR2S:
      pDevice->variant.avr2s.api.pfnAVR2S_Close(pDevice->variant.avr2s.hDevice);
      break;
#endif

#if defined(AVR2_VIA_IPMI_SUPPORTED)
    case Avr2utilInterfaceAVR2IPMI:
      pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_CloseSession(pDevice->variant.avr2ipmi.hSession);
      break;
#endif

    case Avr2utilInterfaceADB3:
      pDevice->variant.adb3.api.pfnADB3_Close(pDevice->variant.adb3.hDevice);
      break;

#if defined(AVR2_VIA_ADXDMA_SUPPORTED)
    case Avr2utilInterfaceADXDMA:
      pDevice->variant.adxdma.api.pfnADXDMA_CloseBC(pDevice->variant.adxdma.hBC);
      break;
#endif

    default:
      /* Should never get here */
      assert(FALSE);
      break;
    }

    pDevice->bValid = FALSE;
  }
}

static int
openDeviceADB3(
  unsigned int index,
  bool_t bIndexSpecified,
  unsigned int serial,
  bool_t bSerialSpecified,
  DeviceHandle* pDevice)
{
  ADB3_HANDLE hDeviceAdb3 = ADB3_HANDLE_INVALID_VALUE;
  ADB3_STATUS status;
  ADB3_AVR2_STATUS avr2Status;
  int ret = EXIT_OK;
  
  ret = LoadADB3Library(&pDevice->variant.adb3.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = sampleAdb3OpenCard(index, bIndexSpecified, serial, bSerialSpecified, FALSE, &hDeviceAdb3, &pDevice->variant.adb3.api);
  if (status != ADB3_SUCCESS) {
    _tprintf(_T("*** Failed to open card: %s\n"), pDevice->variant.adb3.api.pfnADB3_GetStatusString(status, TRUE));
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }
  pDevice->variant.adb3.hDevice = hDeviceAdb3;
  pDevice->nInterfaceType = Avr2utilInterfaceADB3;
  pDevice->pszInterfaceName = _T("ADB3 Driver (PCIe)");
  /* Entering / exiting Service Mode via PCIe is fully supported. */
  pDevice->bEnterServiceModeRequestAllowed = TRUE;
  pDevice->bExitServiceModeRequestAllowed = TRUE;
  pDevice->bAutoEnterServiceMode = TRUE;
  pDevice->bValid = TRUE;
  pDevice->nCommandTimeoutUs = DEFAULT_COMMAND_TIMEOUT_US;
  pDevice->nRebootDelayMs = UC_ADB3_REBOOT_DELAY_MS;

  ret = modelSanityCheck(pDevice->variant.adb3.hDevice, &pDevice->variant.adb3.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = pDevice->variant.adb3.api.pfnADB3_GetAVR2Status(pDevice->variant.adb3.hDevice, &avr2Status);
  if (status != ADB3_SUCCESS) {
    _tprintf(_T("*** Failed to get AVR2 microcontroller status: %s\n"), pDevice->variant.adb3.api.pfnADB3_GetStatusString(status, TRUE));
    ret = EXIT_AVR2_STATUS_ERROR;
    goto done;
  }

done:
  if (EXIT_OK != ret) {
    closeDevice(pDevice);
  }

  return ret;    
}

#if !(defined(__VXWORKS__) || defined(__vxworks))

static int
openDeviceADXDMA(
  unsigned int index,
  DeviceHandle* pDevice)
{
  int ret = EXIT_OK;

#if defined(AVR2_VIA_ADXDMA_SUPPORTED)

  ADXDMA_HBC hBC = ADXDMA_NULL_HBC;
  ADXDMA_STATUS status;
  ADXDMA_UC_STATUS avr2UcStatus;
  
  ret = LoadADXDMALibrary(&pDevice->variant.adxdma.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = pDevice->variant.adxdma.api.pfnADXDMA_OpenBC(ADXDMA_NULL_HDEVICE, index, FALSE, &hBC);
  if (status != ADXDMA_SUCCESS) {
    _tprintf(_T("*** Failed to open device: %s\n"), pDevice->variant.adxdma.api.pfnADXDMA_GetStatusString(status, TRUE));
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }

  pDevice->variant.adxdma.hBC = hBC;
  pDevice->nInterfaceType = Avr2utilInterfaceADXDMA;
  pDevice->pszInterfaceName = _T("ADXDMA Driver (PCIe)");
  /* Entering / exiting Service Mode via PCIe is fully supported. */
  pDevice->bEnterServiceModeRequestAllowed = TRUE;
  pDevice->bExitServiceModeRequestAllowed = TRUE;
  pDevice->bAutoEnterServiceMode = TRUE;
  pDevice->bValid = TRUE;
  pDevice->nCommandTimeoutUs = DEFAULT_COMMAND_TIMEOUT_US;
  pDevice->nRebootDelayMs = UC_ADXDMA_REBOOT_DELAY_MS;

  status = pDevice->variant.adxdma.api.pfnADXDMA_GetUCStatus(pDevice->variant.adxdma.hBC, &avr2UcStatus);
  if (status != ADXDMA_SUCCESS) {
    _tprintf(_T("*** Failed to get AVR2 microcontroller status: %s\n"), pDevice->variant.adxdma.api.pfnADXDMA_GetStatusString(status, TRUE));
    ret = EXIT_AVR2_STATUS_ERROR;
    goto done;
  }

  pDevice->bInServiceMode = avr2UcStatus.Flags.ServiceMode ? TRUE : FALSE;

#else

# if defined(_WIN32)

  _tprintf(_T("*** Access to the AVR2 uC via the ADXDMA Driver is currently not supported for the Windows operating system.\n"));

# elif (defined(__VXWORKS__) || defined(__vxworks))

  _tprintf(_T("*** Access to the AVR2 uC via the ADXDMA Driver is currently not supported for the VxWorks RTOS.\n"));

# else

  _tprintf(_T("*** Access to the AVR2 uC via the ADXDMA Driver is currently not supported for the GNU/Linux operating system.\n"));

# endif

  ret = EXIT_USB_NOT_SUPPORTED;
  goto done;

#endif

done:
  if (EXIT_OK != ret) {
    closeDevice(pDevice);
  }

  return ret;    
}

static int
openDevicePsuart(
  const TCHAR* pConnectionString,
  bool_t bVerbose,
  DeviceHandle* pDevice)
{
  int ret = EXIT_OK;
  AVR2_HANDLE hDeviceAvr2Usb = AVR2_HANDLE_INVALID_VALUE;
  AVR2_STATUS status;
  uint32_t productId;
  uint16_t version[4];
  TCHAR szDeviceName[32], szBaudRate[32];
  bool_t bBadConnectionString = FALSE;
  bool_t bSetBaudRate = FALSE;
  const TCHAR* p, * pEnd, * q;
  size_t n;
  unsigned int nElement, nBaudRate = 0;
  int nConverted;

  /*
  ** Parse connection string in form "<COM port>[,baud]" or "<device>[,baud]"
  ** In Linux, <device> is typically of the form "/dev/tty<something>"
  */

  nElement = 0;
  p = pConnectionString;
  pEnd = p + _tcslen(pConnectionString);

  memset(szDeviceName, 0, sizeof(szDeviceName));
  memset(szBaudRate, 0, sizeof(szBaudRate));

  while (p < pEnd) {
    q = _tcschr(p, _T(','));
    if (NULL == q) {
      q = pEnd;
    }

    n = q - p;

    if (n < 1) {
      /* Too short */
      bBadConnectionString = TRUE;
      break;
    }

    switch (nElement) {
    case 0:
      if (n > ARRAY_LENGTH(szDeviceName)) {
        n = ARRAY_LENGTH(szDeviceName);
      }
      memcpy(szDeviceName, p, n * sizeof(TCHAR));
      szDeviceName[ARRAY_LENGTH(szDeviceName) - 1] = _T('\0');
      break;

    case 1:
      if (n > ARRAY_LENGTH(szBaudRate)) {
        n = ARRAY_LENGTH(szBaudRate);
      }
      memcpy(szBaudRate, p, n * sizeof(TCHAR));
      szBaudRate[ARRAY_LENGTH(szBaudRate) - 1] = _T('\0');
      bSetBaudRate = TRUE;
      break;

    default:
      break;
    }

    if (nElement >= 2) {
      _tprintf(_T("+++ Ignoring unexpected extra elements of '-psuart' connection string: '%s'\n"), p);
      break;
    }

    nElement++;

    /* Skip to next field, if it exists */
    p = q + 1;
  }

  if (0 == nElement || bBadConnectionString) {
#ifdef _WIN32
    _tprintf(_T("*** Bad connection string '%s'; must be of form 'COM<n>[,baud]'\n"), pConnectionString);
#else
    _tprintf(_T("*** Bad connection string '%s'; must be of form '/dev/<device>[,baud]'\n"), pConnectionString);
#endif
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }

  if (bSetBaudRate) {
    nConverted = stringToUInt(szBaudRate, &nBaudRate);
    if (1 != nConverted) {
      _tprintf(_T("*** Baud rate value '%s' from '-psuart' connection string not recognized as a number.\n"), szBaudRate);
      ret = EXIT_INVALID_BAUD_RATE;
      goto done;
    }
  }

  ret = LoadAVR2Library(&pDevice->variant.avr2.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = pDevice->variant.avr2.api.pfnAVR2_OpenPort(szDeviceName, &hDeviceAvr2Usb);
  if (AVR2_SUCCESS != status) {
    _tprintf(_T("*** Failed to open port '%s': %s\n"), szDeviceName, pDevice->variant.avr2.api.pfnAVR2_GetStatusString(status, TRUE));
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }

  if (bSetBaudRate) {
    status = pDevice->variant.avr2.api.pfnAVR2_SetPortBaud(hDeviceAvr2Usb, nBaudRate);
    if (AVR2_SUCCESS != status) {
      _tprintf(_T("*** Failed to set port '%s' baud rate to %u: %s\n"),
        szDeviceName, nBaudRate, pDevice->variant.avr2.api.pfnAVR2_GetStatusString(status, TRUE));
      ret = EXIT_SET_BAUD_FAILED;
      goto done;
    }
  }

  pDevice->variant.avr2.hDevice = hDeviceAvr2Usb;
  pDevice->nInterfaceType = Avr2utilInterfaceAVR2;
  pDevice->pszInterfaceName = _T("PS UART");
  /* Assume entering Service Mode via UART serial connection is supported; will correct later. */
  pDevice->bEnterServiceModeRequestAllowed = TRUE;
  pDevice->bExitServiceModeRequestAllowed = TRUE;
  pDevice->bAutoEnterServiceMode = TRUE;
  pDevice->bValid = TRUE;
  pDevice->nCommandTimeoutUs = DEFAULT_COMMAND_TIMEOUT_US;
  pDevice->nRebootDelayMs = UC_PSUART_REBOOT_DELAY_MS;

  ret = productIdCommand(pDevice, bVerbose, TRUE, &productId);
  if (0 != ret) {
    _tprintf(_T("*** Failed to get AVR2 firmware Product ID.\n"));
    goto done;
  }

  if (productId == DRAWING_NUM_BOOTMAN2 || productId == DRAWING_NUM_BOOTMAN2_ALT1 || productId == DRAWING_NUM_BOOTMAN2_ALT2) {
    pDevice->bInServiceMode = TRUE;
  } else if (productId == DRAWING_NUM_BOARDMAN2 || productId == DRAWING_NUM_BOARDMAN2_ALT1 || productId == DRAWING_NUM_BOARDMAN2_ALT2) {
    uint8_t buffer[256]; /* Request VPD command requires buffer of 256 bytes */
    uint32_t drawingNumber;

    pDevice->bInServiceMode = FALSE;

    memset(buffer, 0, 256);

    /* In Application Mode, request VPD using command */
    ret = avr2UtilRequestVpdData(pDevice, bVerbose, buffer);
    if (0 != ret) {
      _tprintf(_T("*** Failed to get VPD.\n"));
      goto done;
    }

    /*
    ** Check that board we are talking to is one of the Zynq Ultrascale
    ** boards, because this has a PS UART connection to the microcontroller
    ** and thus switching in and out of Service Mode over the UART connection
    ** will work.
    */
    drawingNumber = GET_VPD_VAL32(&buffer[4]);
    switch (drawingNumber) {
    case DRAWING_NUM_ADMVPX39Z2:
    case DRAWING_NUM_ADMXRC9R1:
      /* OK to switch in and out of Service Mode over UART connection */
      break;

    default:
      /*
      ** Other board: this is very likely to be a USB UART connection, and
      ** switching in and out of Service Mode over this connection will not
      ** work because the USB device will disappear any time the
      ** microcontroller reboots in order to switch into Service Mode.
      */
      pDevice->bEnterServiceModeRequestAllowed = FALSE;
      pDevice->bExitServiceModeRequestAllowed = FALSE;
      pDevice->bAutoEnterServiceMode = FALSE;
      break;
    }
  } else {
    /* When connecting to uC via true UART serial connection, we can't easily check that we are talking a model whose
    ** Flash layout we know about. To protect against future models having a different Flash address map, we abort
    ** if we see a Product ID that we do not recognize.
    ** If the Flash address map is changed in a future model, it will have a different Product ID. */
    _tprintf(_T("*** AVR2 firmware Product ID %lu(0x%lX) not recognized. Aborting as a precaution against firmware corruption.\n"),
       (unsigned long)productId, (unsigned long)productId);
    ret = EXIT_UNRECOGNIZED_PRODUCTID;
    goto done;
  }

  ret = versionCommand(pDevice, bVerbose, TRUE, version);
  if (0 != ret) {
    _tprintf(_T("*** Failed to get AVR2 firmware version.\n"));
    goto done;
  }

done:
  if (EXIT_OK != ret) {
    closeDevice(pDevice);
  }

  return ret;    
}

static int
openDeviceUSBCom(
  const TCHAR* pDeviceName,
  bool_t bVerbose,
  DeviceHandle* pDevice)
{
  int ret = EXIT_OK;

#if defined(AVR2_VIA_USB_SUPPORTED)

  AVR2_HANDLE hDeviceAvr2Usb = AVR2_HANDLE_INVALID_VALUE;
  AVR2_STATUS status;
  uint32_t productId;
  uint16_t version[4];
  
  ret = LoadAVR2Library(&pDevice->variant.avr2.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = pDevice->variant.avr2.api.pfnAVR2_OpenPort(pDeviceName, &hDeviceAvr2Usb);
  if (AVR2_SUCCESS != status) {
    _tprintf(_T("*** Failed to open port '%s': %s\n"), pDeviceName, pDevice->variant.avr2.api.pfnAVR2_GetStatusString(status, TRUE));
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }

  pDevice->variant.avr2.hDevice = hDeviceAvr2Usb;
  pDevice->nInterfaceType = Avr2utilInterfaceAVR2;
  pDevice->pszInterfaceName = _T("USB");
  /* Assume entering Service Mode via USB not supported; will correct later. */
  pDevice->bEnterServiceModeRequestAllowed = FALSE;
  pDevice->bExitServiceModeRequestAllowed = FALSE;
  pDevice->bAutoEnterServiceMode = FALSE;
  pDevice->bValid = TRUE;
  pDevice->nCommandTimeoutUs = DEFAULT_COMMAND_TIMEOUT_US;
  pDevice->nRebootDelayMs = UC_USBCOM_REBOOT_DELAY_MS;

  ret = productIdCommand(pDevice, bVerbose, TRUE, &productId);
  if (0 != ret) {
    _tprintf(_T("*** Failed to get AVR2 firmware Product ID.\n"));
    goto done;
  }
  if (productId == DRAWING_NUM_BOOTMAN2 || productId == DRAWING_NUM_BOOTMAN2_ALT1 || productId == DRAWING_NUM_BOOTMAN2_ALT2) {
    pDevice->bInServiceMode = TRUE;
    /* If in Service Mode and successfully talking to uC over USB, BootMan2 must already support USB communication. */
    pDevice->bEnterServiceModeRequestAllowed = TRUE;
    pDevice->bExitServiceModeRequestAllowed = TRUE;
  } else if (productId == DRAWING_NUM_BOARDMAN2 || productId == DRAWING_NUM_BOARDMAN2_ALT1 || productId == DRAWING_NUM_BOARDMAN2_ALT2) {
    pDevice->bInServiceMode = FALSE;

    ret = versionCommand(pDevice, bVerbose, TRUE, version);
    if (0 != ret) {
      _tprintf(_T("*** Failed to get AVR2 firmware version.\n"));
      goto done;
    }
  } else {
    /* When connecting to uC via USB serial connection, we can't easily check that we are talking a model whose
    ** Flash layout we know about. To protect against future models having a different Flash address map, we abort
    ** if we see a Product ID that we do not recognize.
    ** If the Flash address map is changed in a future model, it will have a different Product ID. */
    _tprintf(_T("*** AVR2 firmware Product ID %lu(0x%lX) not recognized. Aborting as a precaution against firmware corruption.\n"),
       (unsigned long)productId, (unsigned long)productId);
    ret = EXIT_UNRECOGNIZED_PRODUCTID;
    goto done;
  }

#else

# if defined(_WIN32)

  UNREFERENCED_PARAMETER(pDeviceName);
  UNREFERENCED_PARAMETER(bVerbose);
  UNREFERENCED_PARAMETER(pDevice);

  _tprintf(_T("*** Access to the AVR2 uC via USB is currently not supported for the Windows operating system.\n"));

# elif (defined(__VXWORKS__) || defined(__vxworks))
  
  _tprintf(_T("*** Access to the AVR2 uC via USB is currently not supported for the VxWorks RTOS.\n"));

# else

  _tprintf(_T("*** Access to the AVR2 uC via USB is currently not supported for the GNU/Linux operating system.\n"));

# endif

  ret = EXIT_USB_NOT_SUPPORTED;
  goto done;

#endif

done:
  if (EXIT_OK != ret) {
    closeDevice(pDevice);
  }

  return ret;    
}

static int
openDeviceSMBUS(
  const TCHAR* pDeviceName,
  uint8_t chipAddr,
  bool_t bVerbose,
  DeviceHandle* pDevice)
{
  int ret = EXIT_OK;

#if defined(AVR2_VIA_SMBUS_SUPPORTED)

  AVR2S_HANDLE hDeviceAvr2Smbus = AVR2S_HANDLE_INVALID_VALUE;
  AVR2S_STATUS status;
  uint32_t productId;
  uint16_t version[4];

  ret = LoadAVR2SLibrary(&pDevice->variant.avr2s.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = pDevice->variant.avr2s.api.pfnAVR2S_OpenDevice(pDeviceName, chipAddr, &hDeviceAvr2Smbus);
  if (AVR2S_SUCCESS != status) {
    _tprintf(_T("*** Failed to open I2C / SMBUS device '%s': %s\n"), pDeviceName, pDevice->variant.avr2s.api.pfnAVR2S_GetStatusString(status, TRUE));
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }

  pDevice->variant.avr2s.hDevice = hDeviceAvr2Smbus;
  pDevice->nInterfaceType = Avr2utilInterfaceAVR2S;
  pDevice->pszInterfaceName = _T("SMBUS");
  /* Entering / exiting Service Mode via SMBUS is fully supported. */
  pDevice->bEnterServiceModeRequestAllowed = TRUE;
  pDevice->bExitServiceModeRequestAllowed = TRUE;
  pDevice->bAutoEnterServiceMode = TRUE;
  pDevice->bValid = TRUE;
  pDevice->nCommandTimeoutUs = DEFAULT_COMMAND_TIMEOUT_US;
  pDevice->nRebootDelayMs = UC_SMBUS_REBOOT_DELAY_MS;

  ret = productIdCommand(pDevice, bVerbose, TRUE, &productId);
  if (0 != ret) {
    _tprintf(_T("*** Failed to get AVR2 firmware Product ID.\n"));
    goto done;
  }
  if (productId == DRAWING_NUM_BOOTMAN2 || productId == DRAWING_NUM_BOOTMAN2_ALT1 || productId == DRAWING_NUM_BOOTMAN2_ALT2) {
    pDevice->bInServiceMode = TRUE;
  } else if (productId == DRAWING_NUM_BOARDMAN2 || productId == DRAWING_NUM_BOARDMAN2_ALT1 || productId == DRAWING_NUM_BOARDMAN2_ALT2) {
    pDevice->bInServiceMode = FALSE;
    ret = versionCommand(pDevice, bVerbose, TRUE, version);
    if (0 != ret) {
      _tprintf(_T("*** Failed to get AVR2 firmware version.\n"));
      goto done;
    }
  } else {
    /* When connecting to uC via USB serial connection, we can't easily check that we are talking a model whose
    ** Flash layout we know about. To protect against future models having a different Flash address map, we abort
    ** if we see a Product ID that we do not recognize.
    ** If the Flash address map is changed in a future model, it will have a different Product ID. */
    _tprintf(_T("*** AVR2 firmware Product ID %lu(0x%lX) not recognized. Aborting as a precaution against firmware corruption.\n"),
       (unsigned long)productId, (unsigned long)productId);
    ret = EXIT_UNRECOGNIZED_PRODUCTID;
    goto done;
  }

#else

# if defined(_WIN32)

  UNREFERENCED_PARAMETER(pDeviceName);
  UNREFERENCED_PARAMETER(chipAddr);
  UNREFERENCED_PARAMETER(bVerbose);
  UNREFERENCED_PARAMETER(pDevice);

  _tprintf(_T("*** Access to the AVR2 uC via SMBUS is currently not supported for the Windows operating system.\n"));

# elif (defined(__VXWORKS__) || defined(__vxworks))

  _tprintf(_T("*** Access to the AVR2 uC via SMBUS is currently not supported for the VxWorks RTOS.\n"));

# else

  _tprintf(_T("*** Access to the AVR2 uC via SMBUS is currently not supported for the GNU/Linux operating system.\n"));

# endif

  ret = EXIT_SMBUS_NOT_SUPPORTED;
  goto done;

#endif

done:
  if (EXIT_OK != ret) {
    closeDevice(pDevice);
  }
  return ret;    
}

static int
openDeviceIPMI(
  const TCHAR* pDeviceName,
  bool_t bVerbose,
  DeviceHandle* pDevice)
{
  int ret = EXIT_OK;

#if defined(AVR2_VIA_IPMI_SUPPORTED)

  AVR2IPMI_SESSION hSession = AVR2IPMI_SESSION_INVALID_VALUE;
  AVR2IPMI_OPTIONS sessionOptions;
  AVR2IPMI_ERROR_DETAIL errorDetail;
  AVR2IPMI_STATUS status;
  uint32_t productId;
  uint16_t version[4];

  ret = LoadAVR2IPMILibrary(&pDevice->variant.avr2ipmi.api);
  if (EXIT_OK != ret) {
    goto done;
  }

  status = pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_ParseOptions(pDeviceName, &sessionOptions);
  if (AVR2IPMI_SUCCESS != status) {
    _tprintf(_T("*** Failed to parse IPMI session options '%s': %s\n"), pDeviceName, pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_GetStatusString(status, TRUE));
    ret = EXIT_BAD_IPMI_OPTIONS;
    goto done;
  }

  status = pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_OpenSession(&sessionOptions, &hSession);
  if (AVR2IPMI_SUCCESS != status) {
    pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_GetErrorDetail(&errorDetail);
    _tprintf(_T("*** Failed to open IPMI session with options '%s': %s\n"), pDeviceName, pDevice->variant.avr2ipmi.api.pfnAVR2IPMI_GetStatusString(status, TRUE));
    _tprintf(_T("    Error detail is: %s\n"), errorDetail.Description);
    ret = EXIT_DEVICE_OPEN_ERROR;
    goto done;
  }

  pDevice->variant.avr2ipmi.hSession = hSession;
  pDevice->nInterfaceType = Avr2utilInterfaceAVR2IPMI;
  pDevice->pszInterfaceName = _T("IPMI");
  /* Entering / exiting Service Mode via IPMI (using SMBUS from BMC) is fully supported. */
  pDevice->bEnterServiceModeRequestAllowed = TRUE;
  pDevice->bExitServiceModeRequestAllowed = TRUE;
  pDevice->bAutoEnterServiceMode = TRUE;
  pDevice->bValid = TRUE;
  pDevice->nCommandTimeoutUs = DEFAULT_COMMAND_TIMEOUT_US;

  ret = productIdCommand(pDevice, bVerbose, TRUE, &productId);
  if (0 != ret) {
    _tprintf(_T("*** Failed to get AVR2 firmware Product ID.\n"));
    goto done;
  }
  if (productId == DRAWING_NUM_BOOTMAN2 || productId == DRAWING_NUM_BOOTMAN2_ALT1 || productId == DRAWING_NUM_BOOTMAN2_ALT2) {
    pDevice->bInServiceMode = TRUE;
  } else if (productId == DRAWING_NUM_BOARDMAN2 || productId == DRAWING_NUM_BOARDMAN2_ALT1 || productId == DRAWING_NUM_BOARDMAN2_ALT2) {
    pDevice->bInServiceMode = FALSE;
    ret = versionCommand(pDevice, bVerbose, TRUE, version);
    if (0 != ret) {
      _tprintf(_T("*** Failed to get AVR2 firmware version.\n"));
      goto done;
    }
  } else {
    /* When connecting to uC via USB serial connection, we can't easily check that we are talking a model whose
    ** Flash layout we know about. To protect against future models having a different Flash address map, we abort
    ** if we see a Product ID that we do not recognize.
    ** If the Flash address map is changed in a future model, it will have a different Product ID. */
    _tprintf(_T("*** AVR2 firmware Product ID %lu(0x%lX) not recognized. Aborting as a precaution against firmware corruption.\n"),
       (unsigned long)productId, (unsigned long)productId);
    ret = EXIT_UNRECOGNIZED_PRODUCTID;
    goto done;
  }

#else

# if defined(_WIN32)

  UNREFERENCED_PARAMETER(pDeviceName);
  UNREFERENCED_PARAMETER(bVerbose);
  UNREFERENCED_PARAMETER(pDevice);

  _tprintf(_T("*** Access to the AVR2 uC via IPMI is currently not supported for the Windows operating system.\n"));

# elif (defined(__VXWORKS__) || defined(__vxworks))

  _tprintf(_T("*** Access to the AVR2 uC via IPMI is currently not supported for the VxWorks RTOS.\n"));

# else

  _tprintf(_T("*** Access to the AVR2 uC via IPMI is currently not supported for the GNU/Linux operating system.\n"));

# endif

  ret = EXIT_IPMI_NOT_SUPPORTED;
  goto done;

#endif

done:
  if (EXIT_OK != ret) {
    closeDevice(pDevice);
  }

  return ret;    
}

#endif

static void
displayBuildInfo(
  void)
{
#if defined(AVR2_VIA_IPMI_SUPPORTED)
  const TCHAR** ppszAvailableIPMIBackends;
  API_AVR2IPMI apiAVR2IPMI;
  int ret;
#endif
  int i;

  _tprintf(_T("%s %d.%d.%d - Microcontroller maintenance tool\n"), PROGRAM_NAME, AVR2UTIL_MAJOR, AVR2UTIL_MINOR, AVR2UTIL_BUGFIX);

#if defined(AVR2_VIA_USB_SUPPORTED)
  _tprintf(_T("AVR2 API library: "));
# if defined(AVR2_LIBRARY_STATIC)
  _tprintf(_T("statically linked"));
# else
  _tprintf(_T("dynamically loaded"));
# endif
  _tprintf(_T(", <avr2.h> %d.%d.%d"), AVR2_H_VERSION_SUPER, AVR2_H_VERSION_MAJOR, AVR2_H_VERSION_MINOR);
  _tprintf(_T("\n"));
#endif

#if defined(AVR2_VIA_SMBUS_SUPPORTED)
  _tprintf(_T("AVR2S API library: "));
# if defined(AVR2S_LIBRARY_STATIC)
  _tprintf(_T("statically linked"));
# else
  _tprintf(_T("dynamically loaded"));
# endif
  _tprintf(_T(", <avr2s.h> %d.%d.%d"), AVR2S_H_VERSION_SUPER, AVR2S_H_VERSION_MAJOR, AVR2S_H_VERSION_MINOR);
  _tprintf(_T("\n"));
#endif

#if defined(AVR2_VIA_IPMI_SUPPORTED)
  _tprintf(_T("AVR2IPMI API library: "));
# if defined(AVR2IPMI_LIBRARY_STATIC)
  _tprintf(_T("statically linked"));
# else
  _tprintf(_T("dynamically loaded"));
# endif
  _tprintf(_T(", <avr2ipmi.h> %d.%d.%d"), AVR2IPMI_H_VERSION_SUPER, AVR2IPMI_H_VERSION_MAJOR, AVR2IPMI_H_VERSION_MINOR);
  _tprintf(_T("\n"));

  ret = LoadAVR2IPMILibrary(&apiAVR2IPMI);
  if (EXIT_OK == ret) {
    _tprintf(_T("Available IPMI backends: "));
    ppszAvailableIPMIBackends = apiAVR2IPMI.pfnAVR2IPMI_GetBackends();
    while (NULL != *ppszAvailableIPMIBackends) {
      _tprintf(_T("%s "), *ppszAvailableIPMIBackends);
      ppszAvailableIPMIBackends++;
    }
    _tprintf(_T("\n"));
  } else {
    _tprintf(_T("*** Failed to get list of available IPMI backends\n"));
  }
#endif

  _tprintf(_T("ADB3 API library: "));
#if defined(ADB3_LIBRARY_STATIC)
  _tprintf(_T("statically linked"));
#else
  _tprintf(_T("dynamically loaded"));
#endif
  _tprintf(_T(", <adb3.h> %d.%d.%d"), ADB3_H_VERSION_SUPER, ADB3_H_VERSION_MAJOR, ADB3_H_VERSION_MINOR);
  _tprintf(_T("\n"));

#if defined(AVR2_VIA_ADXDMA_SUPPORTED)
  _tprintf(_T("ADXMDA API library: "));
#if defined(ADXDMA_LIBRARY_STATIC)
  _tprintf(_T("statically linked"));
#else
  _tprintf(_T("dynamically loaded"));
#endif
  _tprintf(_T(", <adxdma.h> %d.%d.%d"), ADXDMA_H_VERSION_SUPER, ADXDMA_H_VERSION_MAJOR, ADXDMA_H_VERSION_MINOR);
  _tprintf(_T("\n"));
#endif

  _tprintf(_T("Supported models:"));
  for (i = 0; i < ARRAY_LENGTH(g_supportedModels); i++) {
    _tprintf(_T(" %s"), g_supportedModels[i].pszModelName);
  }
  _tprintf(_T("\n"));
}

#if (defined(__VXWORKS__) || defined(__vxworks))

/***************************************************
 * VxWorks DKM entry points                        *
 ***************************************************/

#define FLAG_BYSERIAL  (0x1U)  /* Interpret 'indexOrSerial' as a serial number */
#define FLAG_VERBOSE   (0x2U)  /* Verbose operation */

static void
decodeFlags(
  unsigned int flags,
  bool_t* pbOpenBySerial,
  bool_t* pbVerbose)
{
  *pbOpenBySerial = (flags & FLAG_BYSERIAL) ? TRUE : FALSE;
  *pbVerbose = (flags & FLAG_VERBOSE) ? TRUE : FALSE;
}

int
avr2utilHelp(
  void)
{
  _tprintf(_T("Available entry points:\n"));
  _tprintf(_T("  avr2utilBuildInfo()\n"));
  _tprintf(_T("  avr2utilHelp()\n"));
  _tprintf(_T("  avr2utilVersion(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilProductID(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilCommTest(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilEnterServiceMode(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilExitServiceMode(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilGetSMBUSAddr(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilGetSMBUSAddrNV(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilSetSMBUSAddr(indexOrSerial, flags, chipAddr7Bit)\n"));
  _tprintf(_T("  avr2utilSetSMBUSAddrNV(indexOrSerial, flags, chipAddr7Bit)\n"));
  _tprintf(_T("  avr2utilGetClk(indexOrSerial, flags, clockIndex)\n"));
  _tprintf(_T("  avr2utilSetClk(indexOrSerial, flags, clockIndex, frequencyHz)\n"));
  _tprintf(_T("  avr2utilGetClkNV(indexOrSerial, flags, clockIndex)\n"));
  _tprintf(_T("  avr2utilSetClkNV(indexOrSerial, flags, clockIndex, frequencyHz)\n"));
  _tprintf(_T("  avr2utilI2cRead(indexOrSerial, flags, bus, device, address, count)\n"));
  _tprintf(_T("  avr2utilI2cReadToFile(indexOrSerial, flags, bus, device, address, count, pOutFilename)\n"));
  _tprintf(_T("  avr2utilI2cWrite(indexOrSerial, flags, bus, device, address, count, ...)\n"));
  _tprintf(_T("  avr2utilI2cWriteRead(indexOrSerial, flags, bus, device, writeCount, readCount, ...)\n"));
  _tprintf(_T("  avr2utilI2cWriteFromFile(indexOrSerial, flags, bus, device, address, pInFilename)\n"));
  _tprintf(_T("  avr2utilI2cVerifyWithFile(indexOrSerial, flags, bus, device, address, pInFilename)\n"));
  _tprintf(_T("  avr2utilSPIInfo(indexOrSerial, flags, chipIndex)\n"));
  _tprintf(_T("  avr2utilSPIRaw(indexOrSerial, flags, chipIndex, readCount, writeCount, ...)\n"));
  _tprintf(_T("  avr2utilSPICheckBlank(indexOrSerial, flags, chipIndex, address, count)\n"));
  _tprintf(_T("  avr2utilSPIErase(indexOrSerial, flags, chipIndex, address, count)\n"));
  _tprintf(_T("  avr2utilSPIProgramMCS(indexOrSerial, flags, chipIndex, pInFilename, translation)\n"));
  _tprintf(_T("  avr2utilSPIVerifyMCS(indexOrSerial, flags, chipIndex, pInFilename, translation)\n"));
  _tprintf(_T("  avr2utilSPISaveToMCS(indexOrSerial, flags, chipIndex, pOutFilename, address, count)\n"));
  _tprintf(_T("  avr2utilUpdateBrdCfg(indexOrSerial, flags, pBrdCfgFile)\n"));
  _tprintf(_T("  avr2utilUpdateFirmware(indexOrSerial, flags, pFirmwareFile)\n"));
  _tprintf(_T("  avr2utilUpdateVPD(indexOrSerial, flags, pVPDFile)\n"));
  _tprintf(_T("  avr2utilSaveBrdCfg(indexOrSerial, flags, pBrdCfgSaveFile)\n"));
  _tprintf(_T("  avr2utilSaveFirmware(indexOrSerial, flags, pFirmwareSaveFile)\n"));
  _tprintf(_T("  avr2utilSaveVPD(indexOrSerial, flags, pVPDSaveFile)\n"));
  _tprintf(_T("  avr2utilVerifyBrdCfg(indexOrSerial, flags, pBrdCfgFile)\n"));
  _tprintf(_T("  avr2utilVerifyFirmware(indexOrSerial, flags, pFirmwareFile)\n"));
  _tprintf(_T("  avr2utilVerifyVPD(indexOrSerial, flags, pVPDFile)\n"));
  _tprintf(_T("  avr2utilDisplayVPD(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilDisplayVPDRaw(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilDisplaySensors(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilDisplaySensorsRaw(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilOverrideSensor(indexOrSerial, flags, sensorIndex, overrideValue)\n"));
  _tprintf(_T("  avr2utilReleaseSensor(indexOrSerial, flags, sensorIndex)\n"));
  _tprintf(_T("  avr2utilTestClobber(indexOrSerial, flags, sensorIndex)\n"));
  _tprintf(_T("  avr2utilTestTimeout(indexOrSerial, flags)\n"));
  _tprintf(_T("  avr2utilDisplayBlackBox(indexOrSerial, flags[, types[, max]])\n"));
  _tprintf(_T("  avr2utilRaw(indexOrSerial, flags, readCount, writeCount, ...)\n"));
  _tprintf(_T("'flags' is a bitmask of:\n"));
  _tprintf(_T("  FLAG_BYSERIAL 0x%X => Interpret 'indexOrSerial' as a serial number\n"), FLAG_BYSERIAL);
  _tprintf(_T("  FLAG_VERBOSE  0x%X => Verbose output\n"), FLAG_VERBOSE);
  _tprintf(_T("A return value of 0 indicates success.\n"));
  return 0;
}

int
avr2utilBuildInfo(
  void)
{
  displayBuildInfo();
  return 0;
}

int
avr2utilProductID(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);

  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = productIdCommand(&device, bVerbose, FALSE, NULL);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilVersion(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = versionCommand(&device, bVerbose, FALSE, NULL);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilCommTest(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = commTestCommand(&device, bVerbose);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilEnterServiceMode(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (device.bInServiceMode) {
    _tprintf(_T("Nothing to do.\n"));
    goto done;
  }

  ret = enterExitServiceMode(&device, bVerbose, TRUE, FALSE);
  
done:
  closeDevice(&device);  
  return ret;
}


int
avr2utilExitServiceMode(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  if (!device.bInServiceMode) {
    _tprintf(_T("Nothing to do.\n"));
    goto done;
  }

  ret = enterExitServiceMode(&device, bVerbose, FALSE, FALSE);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilGetSMBUSAddr(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = getSMBUSChipAddrCommand(&device, bVerbose, FALSE);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilGetSMBUSAddrNV(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = getSMBUSChipAddrCommand(&device, bVerbose, TRUE);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSetSMBUSAddr(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipAddr7Bit)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = setSMBUSChipAddrCommand(&device, bVerbose, FALSE, chipAddr7Bit);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSetSMBUSAddrNV(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipAddr7Bit)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = setSMBUSChipAddrCommand(&device, bVerbose, TRUE, chipAddr7Bit);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilGetClk(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int clockIndex)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = getClkCommand(&device, bVerbose, clockIndex);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSetClk(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int clockIndex,
  unsigned int frequencyHz)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = setClkCommand(&device, bVerbose, clockIndex, (uint32_t)frequencyHz);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilGetClkNV(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int clockIndex)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = getClkNvCommand(&device, bVerbose, clockIndex);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSetClkNV(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int clockIndex,
  unsigned int frequencyHz)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = setClkNvCommand(&device, bVerbose, clockIndex, (uint32_t)frequencyHz);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilI2cReadToFile(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  unsigned int count,
  const TCHAR* pOutFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = i2cReadToFileCommand(&device, bVerbose, bus, dev, address, count, pOutFilename);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilI2cWriteFromFile(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  const TCHAR* pInFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = i2cWriteFromFileCommand(&device, bVerbose, bus, dev, address, pInFilename);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilI2cVerifyWithFile(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  const TCHAR* pInFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = i2cVerifyWithFileCommand(&device, bVerbose, bus, dev, address, pInFilename);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilI2cRead(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  unsigned int count)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = i2cReadCommand(&device, bVerbose, bus, dev, address, count);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilI2cWrite(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int bus,
  unsigned int dev,
  unsigned int address,
  unsigned int count,
  ...)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  va_list args;
  uint8_t* pBytes = NULL;
  unsigned int i;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  pBytes = (uint8_t*)malloc(sizeof(uint8_t) * count);
  if (NULL == pBytes) {
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  va_start(args, count);
  for (i = 0; i < count; i++) {
    pBytes[i] = (uint8_t)va_arg(args, unsigned int);
  }
  va_end(args);

  ret = i2cWriteCommand(&device, bVerbose, bus, dev, address, count, pBytes);

done:
  if (NULL != pBytes) {
    free(pBytes);
  }
  closeDevice(&device);  
  return ret;
}

int
avr2utilI2cWriteRead(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int bus,
  unsigned int dev,
  unsigned int writeCount,
  unsigned int readCount,
  ...)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  va_list args;
  uint8_t* pWriteBytes = NULL;
  unsigned int i;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  pWriteBytes = (uint8_t*)malloc(sizeof(uint8_t) * writeCount);
  if (NULL == pWriteBytes) {
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  va_start(args, readCount);
  for (i = 0; i < writeCount; i++) {
    pWriteBytes[i] = (uint8_t)va_arg(args, unsigned int);
  }
  va_end(args);

  ret = i2cWriteReadCommand(&device, bVerbose, bus, dev, writeCount, readCount, pWriteBytes);

done:
  if (NULL != pWriteBytes) {
    free(pWriteBytes);
  }
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPIRaw(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex,
  unsigned int readCount,
  unsigned int writeCount,
  ... /* Write bytes */)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  va_list args;
  uint8_t* pWriteBytes = NULL;
  unsigned int i;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  pWriteBytes = (uint8_t*)malloc(sizeof(uint8_t) * writeCount);
  if (NULL == pWriteBytes) {
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  va_start(args, writeCount);
  for (i = 0; i < writeCount; i++) {
    pWriteBytes[i] = (uint8_t)va_arg(args, unsigned int);
  }
  va_end(args);

  ret = spiRawCommand(&device, bVerbose, chipIndex, readCount, writeCount, pWriteBytes);

done:
  if (NULL != pWriteBytes) {
    free(pWriteBytes);
  }
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPIInfo(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = spiInfoCommand(&device, bVerbose, chipIndex);

done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPICheckBlank(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex,
  unsigned int address,
  unsigned int count)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = spiCheckBlankCommand(&device, bVerbose, chipIndex, address, count);

done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPIErase(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex,
  unsigned int address,
  unsigned int count)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = spiEraseCommand(&device, bVerbose, chipIndex, address, count);

done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPIProgramMCS(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex,
  const TCHAR* pInFilename,
  int translation)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = spiProgramIntelHexCommand(&device, bVerbose, chipIndex, pInFilename, translation);

done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPIVerifyMCS(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex,
  const TCHAR* pInFilename,
  int translation)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = spiVerifyIntelHexCommand(&device, bVerbose, chipIndex, pInFilename, translation);

done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSPISaveToMCS(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int chipIndex,
  const TCHAR* pOutFilename,
  unsigned int address,
  unsigned int count)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = spiSaveIntelHexCommand(&device, bVerbose, chipIndex, pOutFilename, address, count);

done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilUpdateFirmware(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pFilename) {
    _tprintf(_T("avr2utilUpdateFirmware requires the firmware filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = updateOrVerifyFirmwareCommand(&device, bVerbose, FALSE, pFilename);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilUpdateBrdCfg(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pFilename) {
    _tprintf(_T("avr2utilUpdateBrdCfg requires the board config. filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = updateOrVerifyBoardConfigCommand(&device, bVerbose, FALSE, pFilename);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilUpdateVPD(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pFilename) {
    _tprintf(_T("avr2utilUpdateVPD requires the VPD filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = updateOrVerifyVpdCommand(&device, bVerbose, FALSE, pFilename);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilSaveFirmware(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pSaveFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pSaveFilename) {
    _tprintf(_T("avr2utilSaveFirmware requires the firmware save filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = saveFirmwareCommand(&device, bVerbose, pSaveFilename);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilSaveBrdCfg(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pSaveFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pSaveFilename) {
    _tprintf(_T("avr2utilSaveBrdCfg requires the board config. save filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = saveBoardConfigCommand(&device, bVerbose, pSaveFilename);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilSaveVPD(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pSaveFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pSaveFilename) {
    _tprintf(_T("avr2utilSaveVPD requires the VPD save filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = saveVpdCommand(&device, bVerbose, pSaveFilename);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilVerifyBrdCfg(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pFilename) {
    _tprintf(_T("avr2utilVerifyBrdCfg requires the board config. filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = updateOrVerifyBoardConfigCommand(&device, bVerbose, TRUE, pFilename);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilVerifyFirmware(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pFilename) {
    _tprintf(_T("avr2utilVerifyFirmware requires the firmware filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = updateOrVerifyFirmwareCommand(&device, bVerbose, TRUE, pFilename);
  
done:
  closeDevice(&device);  
  return ret;
}

int
avr2utilVerifyVPD(
  unsigned int indexOrSerial,
  unsigned int flags,
  const TCHAR* pFilename)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  if (NULL == pFilename) {
    _tprintf(_T("avr2utilVerifyVPD requires the VPD filename (.bin) as the first argument.\n"));
    ret = EXIT_INSUFFICIENT_ARGS;
    goto done;
  }
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = updateOrVerifyVpdCommand(&device, bVerbose, TRUE, pFilename);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilDisplayVPD(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = displayVpdCommand(&device, bVerbose);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilDisplayVPDRaw(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = displayVpdRawCommand(&device, bVerbose);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilDisplaySensors(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = displaySensorsCommand(&device, bVerbose);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilDisplaySensorsRaw(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = displaySensorsRawCommand(&device, bVerbose);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilOverrideSensor(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int sensorIndex,
  unsigned int overrideValue)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = overrideSensorUnscaledCommand(&device, bVerbose, sensorIndex, overrideValue);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilReleaseSensor(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int sensorIndex)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = releaseSensorCommand(&device, bVerbose, sensorIndex);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilTestClobber(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = testClobberCommand(&device, bVerbose);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilTestTimeout(
  unsigned int indexOrSerial,
  unsigned int flags)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = testTimeoutCommand(&device, bVerbose);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilDisplayBlackBox(
  unsigned int indexOrSerial,
  unsigned int flags,
  char* pTypes,
  unsigned int nRecordCount) /* 0 => all records, other => number of records to display */
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  unsigned int nTypes = 0x3; /* 0x1 => clobber records, 0x2 => noclobber records, 0x3 => both */
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  if (pTypes == NULL) {
    pTypes = "both";
  }

  if (_tcsicmp(pTypes, "both") == 0) {
    nTypes = 0x3;
  } else if (_tcsicmp(pTypes, "clobber") == 0) {
    nTypes = 0x1;
  } else if (_tcsicmp(pTypes, "noclobber") == 0) {
    nTypes = 0x2;
  } else {
      _tprintf(_T("*** Valid Black Box record types are: both, clobber, noclobber.\n"));
      ret = EXIT_INVALID_RECORD_TYPE;
      goto done;
  }

  if (0 == nRecordCount) {
    nRecordCount = 0xffffffff;
  }

  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = displayBlackBoxCommand(&device, bVerbose, nTypes, nRecordCount);
  
done:
  closeDevice(&device);    
  return ret;
}

int
avr2utilRaw(
  unsigned int indexOrSerial,
  unsigned int flags,
  unsigned int readCount,
  unsigned int writeCount,
  ... /* Command bytes */)
{
  DeviceHandle device = { FALSE };
  bool_t bOpenBySerial, bVerbose;
  va_list args;
  uint8_t* pWriteBytes = NULL;
  unsigned int i;
  int ret;
  
  decodeFlags(flags, &bOpenBySerial, &bVerbose);
  
  ret = openDeviceADB3(indexOrSerial, !bOpenBySerial, indexOrSerial, bOpenBySerial, &device);
  if (EXIT_OK != ret) {
    goto done;
  }

  pWriteBytes = (uint8_t*)malloc(sizeof(uint8_t) * writeCount);
  if (NULL == pWriteBytes) {
    ret = EXIT_ALLOCATION_FAILED;
    goto done;
  }

  va_start(args, writeCount);
  for (i = 0; i < writeCount; i++) {
    pWriteBytes[i] = (uint8_t)va_arg(args, unsigned int);
  }
  va_end(args);

  ret = rawCommand(&device, bVerbose, readCount, writeCount, pWriteBytes);

done:
  if (NULL != pWriteBytes) {
    free(pWriteBytes);
  }
  closeDevice(&device);  
  return ret;
}

#endif

#if !(defined(__VXWORKS__) || defined(__vxworks))

/***************************************************
 * Windows/Linux entry point                       *
 ***************************************************/

static void
checkEnvironment(
  DeviceHandle* pDevice)
{
  unsigned int flags = 0;
  size_t reqLen = 0;
  TCHAR buf[16];

  _tgetenv_s(&reqLen, buf, ARRAY_LENGTH(buf), _T("AVR2UTIL_FLAGS"));
  if (0 != reqLen) {
    if (1 == _tscanf_s(_T("%u"), &flags)) {
      if (flags & AVR2UTIL_FLAG_EN_ENTER_SM) {
        pDevice->bEnterServiceModeRequestAllowed = TRUE;
      }
      if (flags & AVR2UTIL_FLAG_EN_EXIT_SM) {
        pDevice->bExitServiceModeRequestAllowed = TRUE;
      }
      if (flags & AVR2UTIL_FLAG_EN_AUTO_SM) {
        pDevice->bAutoEnterServiceMode = TRUE;
      }
      if (flags & AVR2UTIL_FLAG_DIS_ENTER_SM) {
        pDevice->bEnterServiceModeRequestAllowed = FALSE;
      }
      if (flags & AVR2UTIL_FLAG_DIS_EXIT_SM) {
        pDevice->bExitServiceModeRequestAllowed = FALSE;
      }
      if (flags & AVR2UTIL_FLAG_DIS_AUTO_SM) {
        pDevice->bAutoEnterServiceMode = FALSE;
      }
    }
  }
}

int _tmain(
  int argc,
  TCHAR* argv[])
{
  int ret = EXIT_OK;
  DeviceHandle device = { FALSE };
  Arguments arguments = g_initArguments;
  Option options[10];
  OptionType paramType[1];
  TCHAR* paramInfo[1];
  TCHAR* paramMeaning[1];
  bool_t bIndexSpecified, bAdxdmaSpecified, bPsuartSpecified, bUsbcomSpecified;
  bool_t bSmbusSpecified, bIpmiSpecified, bSerialSpecified;
  unsigned int chipAddr, nOpenOptionSpecified = 0, timeoutMs;
  bool_t bVerbose;
  TCHAR* pCommand;
  
  options[0].key = _T("index");
  options[0].type = OptionUInt;
  options[0].def.uintVal = 0;
  options[0].meaning = _T("index of card to use (ADB3 Driver)");
  options[1].key = _T("adxdma");
  options[1].type = OptionUInt;
  options[1].def.uintVal = 0;
  options[1].meaning = _T("index of card to use (ADXDMA Driver)");
  options[2].key = _T("psuart");
  options[2].type = OptionString;
  options[2].def.pStringVal = _T("");
#ifdef _WIN32
  options[2].meaning = _T("Zynq UltraScale+ PS UART and baud rate to use, e.g. COM1,171428");
#else
  options[2].meaning = _T("Zynq UltraScale+ PS UART and baud rate to use, e.g. /dev/ttyPS1,171428");
#endif
  options[3].key = _T("usbcom");
  options[3].type = OptionString;
  options[3].def.pStringVal = _T("");
#ifdef _WIN32
  options[3].meaning = _T("USB serial port to use, e.g. COM1");
#else
  options[3].meaning = _T("USB serial port to use, e.g. /dev/ttyACM0");
#endif
  options[4].key = _T("smbus");
  options[4].type = OptionString;
  options[4].def.pStringVal = _T("");
#ifdef _WIN32
  options[4].meaning = _T("SMBUS device to use, e.g. ?");
#else
  options[4].meaning = _T("SMBUS device to use, e.g. /dev/i2c-0");
#endif
  options[5].key = _T("ipmi");
  options[5].type = OptionString;
  options[5].def.pStringVal = _T("");
  options[5].meaning = _T("Use IPMI; specifies IPMI options string");
  options[6].key = _T("sn");
  options[6].type = OptionUInt;
  options[6].def.uintVal = 0;
  options[6].meaning = _T("serial number of card to use");
  options[7].key = _T("verbose");
  options[7].type = OptionBoolean;
  options[7].def.booleanVal = 0;
  options[7].meaning = _T("TRUE => verbose output");
  options[8].key = _T("chipaddr");
  options[8].type = OptionHex;
  options[8].def.uintVal = UC_SMBUS_CHIP_ADDR;
  options[8].meaning = _T("SMBUS address of the AVR2 microcontroller (hexadecimal)");
  options[9].key = _T("timeout");
  options[9].type = OptionUInt;
  options[9].def.uintVal = 1000;
  options[9].meaning = _T("Timeout for AVR2 microcontroller commands (milliseconds)");
  arguments.nOption = ARRAY_LENGTH(options);
  arguments.option = options;
  arguments.bNoStdOptions = TRUE;
   
  paramType[0] = OptionString;
  paramInfo[0] = _T("command");
  paramMeaning[0] =
    _T("One of:\n")
    _T("\n     build-info")
    _T("\n     product-id")
    _T("\n     version")
    _T("\n     comm-test")
    _T("\n     enter-service-mode")
    _T("\n     exit-service-mode")
    _T("\n     get-smbus-addr")
    _T("\n     set-smbus-addr <7-bit SMBUS address>")
    _T("\n     get-smbus-addr-nv")
    _T("\n     set-smbus-addr-nv <7-bit SMBUS address>")
    _T("\n     getclk <index>")
    _T("\n     setclk <index> <Hz>")
    _T("\n     getclknv <index>")
    _T("\n     setclknv <index> <Hz>")
    _T("\n     i2c-read-to-file <bus> <device> <address> <count> <output file.bin>")
    _T("\n     i2c-verify-with-file <bus> <device> <address> <input file.bin>")
    _T("\n     i2c-write-from-file <bus> <device> <address> <input file.bin>")
    _T("\n     i2c-read <bus> <device> <address> <count>")
    _T("\n     i2c-write <bus> <device> <address> <data byte> ...")
    _T("\n     i2c-write-read <bus> <device> <read count> <write address/data byte> ...")
    _T("\n     spi-raw <chip index> <read count> <write data byte> ...")
    _T("\n     spi-info <chip index>")
    _T("\n     spi-check-blank <chip index> <address> <count>")
    _T("\n     spi-erase <chip index> <address> <count>")
    _T("\n     spi-program-mcs <chip index> <filename.mcs> [translation]")
    _T("\n     spi-verify-mcs <chip index> <filename.mcs> [translation]")
    _T("\n     spi-save-to-mcs <chip index> <filename.mcs> <address> <count>")
    _T("\n     update-brdcfg <board configuration file.bin>")
    _T("\n     save-brdcfg <board configuration save file.bin>")
    _T("\n     verify-brdcfg <board configuration file.bin>")
    _T("\n     update-firmware <firmware file.bin>")
    _T("\n     save-firmware <firmware save file.bin>")
    _T("\n     verify-firmware <firmware file.bin>")
    _T("\n     display-vpd")
    _T("\n     display-vpd-raw")
    _T("\n     update-vpd <VPD file.bin>")
    _T("\n     save-vpd <VPD save file.bin>")
    _T("\n     verify-vpd <VPD file.bin>")
    _T("\n     display-black-box [clobber|noclobber|both] [count]")
    _T("\n     display-sensors")
    _T("\n     display-sensors-raw")
    _T("\n     override-sensor <index> <unscaled value>")
    _T("\n     release-sensor <index>")
    _T("\n     test-clobber")
    _T("\n     test-timeout")
    _T("\n     raw <expected response length> <command bytes ...>")
  ;

  arguments.nParamType = ARRAY_LENGTH(paramType);
  arguments.minNParam = 1;
  arguments.paramType = paramType;
  arguments.paramInfo = paramInfo;
  arguments.paramMeaning = paramMeaning;

  if (sampleParseCommandLine(PROGRAM_NAME, argc, argv, &arguments) < 0) {
    ret = EXIT_BAD_COMMAND_LINE;
    goto done;
  }

  bIndexSpecified = options[0].specified;

  bAdxdmaSpecified = options[1].specified;

  bPsuartSpecified = options[2].specified;

  bUsbcomSpecified = options[3].specified;

  bSmbusSpecified = options[4].specified;

  bIpmiSpecified = options[5].specified;

  bSerialSpecified = options[6].specified;

  bVerbose = options[7].value.booleanVal;

  chipAddr = options[8].value.hexVal;
  if (0 == chipAddr || chipAddr >= 0xFF) {
    _tprintf(_T("*** Value for '-chipaddr' option must be in the range 0x1 to 0x7F inclusive.\n"));
    ret = EXIT_BAD_CHIP_ADDR;
    goto done;
  }

  pCommand = arguments.param[0].pStringVal;

  /* Check that no more than one open option has been passed on the command line */
  if (bIndexSpecified) {
    nOpenOptionSpecified++;
  }
  if (bAdxdmaSpecified) {
    nOpenOptionSpecified++;
  }
  if (bPsuartSpecified) {
    nOpenOptionSpecified++;
  }
  if (bUsbcomSpecified) {
    nOpenOptionSpecified++;
  }
  if (bSmbusSpecified) {
    nOpenOptionSpecified++;
  }
  if (bIpmiSpecified) {
    nOpenOptionSpecified++;
  }
  if (nOpenOptionSpecified > 1) {
    _tprintf(_T("*** Too many open options specifed; at most of one '-index', '-adxdma', '-usbcom', '-smbus' and '-ipmi' can be passed on the command line.\n"));
    ret = EXIT_TOO_MANY_COMM_OPTIONS;
    goto done;
  }

  if (_tcsicmp(pCommand, _T("build-info")) == 0) {
    displayBuildInfo();
    goto done;
  }

  /* Open the device using the chosen method of opening */
  if (bAdxdmaSpecified) {
    ret = openDeviceADXDMA(
      options[1].value.uintVal,
      &device);
  } else if (bPsuartSpecified) {
    ret = openDevicePsuart(
      options[2].value.pStringVal,
      bVerbose,
      &device);
  } else if (bUsbcomSpecified) {
    ret = openDeviceUSBCom(
      options[3].value.pStringVal,
      bVerbose,
      &device);
  } else if (bSmbusSpecified) {
    ret = openDeviceSMBUS(
      options[4].value.pStringVal,
      (uint8_t)chipAddr, /* Cast safe due to range check above */
      bVerbose,
      &device);
  } else if (bIpmiSpecified) {
    ret = openDeviceIPMI(
      options[5].value.pStringVal,
      bVerbose,
      &device);
  } else {
    ret = openDeviceADB3(
      options[0].value.uintVal,
      bIndexSpecified,
      options[6].value.uintVal,
      bSerialSpecified,
      &device);
  }

  checkEnvironment(&device);

  if (options[9].specified) {
    timeoutMs = options[9].value.uintVal;

    if (timeoutMs < 1 || timeoutMs > 3600000) {
      _tprintf(_T("*** Value for '-timeout' option must be in the range 1 .. 3600000.\n"));
      ret = EXIT_BAD_TIMEOUT_VALUE;
      goto done;
    }

    device.nCommandTimeoutUs = timeoutMs * 1000;
  }

  if (EXIT_OK != ret) {
    goto done;
  }

  _tprintf(_T("%s Service Mode\n"), device.bInServiceMode ? _T("In") : _T("Not in"));
  
  if (_tcsicmp(pCommand, _T("version")) == 0) {
    ret = versionCommand(&device, bVerbose, FALSE, NULL);
  } else if (_tcsicmp(pCommand, _T("product-id")) == 0) {
    ret = productIdCommand(&device, bVerbose, FALSE, NULL);
  } else if (_tcsicmp(pCommand, _T("comm-test")) == 0) {
    ret = commTestCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("enter-service-mode")) == 0) {
    if (device.bInServiceMode) {
      _tprintf(_T("Nothing to do.\n"));
    } else {
      ret = enterExitServiceMode(&device, bVerbose, TRUE, FALSE);
    }
  } else if (_tcsicmp(pCommand, _T("exit-service-mode")) == 0) {
    if (!device.bInServiceMode) {
      _tprintf(_T("Nothing to do.\n"));
    } else {
      ret = enterExitServiceMode(&device, bVerbose, FALSE, FALSE);
    }
  } else if (_tcsicmp(pCommand, _T("get-smbus-addr")) == 0 ||
             _tcsicmp(pCommand, _T("get-smbus-addr-nv")) == 0)
  {
    bool_t bNonvolatile = (_tcsicmp(pCommand, _T("get-smbus-addr-nv")) == 0) ? TRUE : FALSE;

    ret = getSMBUSChipAddrCommand(&device, bVerbose, bNonvolatile);
  } else if (_tcsicmp(pCommand, _T("set-smbus-addr")) == 0 ||
             _tcsicmp(pCommand, _T("set-smbus-addr-nv")) == 0)
  {
    bool_t bNonvolatile = (_tcsicmp(pCommand, _T("set-smbus-addr-nv")) == 0) ? TRUE : FALSE;
    unsigned int nChipAddress;
    int nConverted;

    if (arguments.nParam < 2) {
      _tprintf(_T("*** '%s' command must be followed by a 7-bit SMBUS chip address.\n"), pCommand);
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &nChipAddress);
    if (1 != nConverted) {
      _tprintf(_T("*** SMBUS chip address value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }
    
    ret = setSMBUSChipAddrCommand(&device, bVerbose, bNonvolatile, nChipAddress);
  } else if (_tcsicmp(pCommand, _T("getclk")) == 0) {
    unsigned int clockIndex;
    int nConverted;
    
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'getclk' command must be followed by a clock generator index.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &clockIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** Clock generator index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }
    
    ret = getClkCommand(&device, bVerbose, clockIndex);
  } else if (_tcsicmp(pCommand, _T("setclk")) == 0) {
    const TCHAR* pszFrequency;
    unsigned int clockIndex;
    unsigned long frequency;
    int nConverted;
    
    if (arguments.nParam < 3) {
      _tprintf(_T("*** 'setclk' command must be followed by (1) a clock generator index and (2) a frequency (Hz).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &clockIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** Clock generator index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }
    if (clockIndex > 0xFFU) {
      _tprintf(_T("*** Clock generator index must be in the range 0 to 255.\n"));
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    pszFrequency = arguments.param[2].pStringVal;
    nConverted = stringToULong(pszFrequency, &frequency);
    if (1 != nConverted) {
      _tprintf(_T("*** Frequency value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_FREQUENCY;
      goto done;
    }
    if (frequency > 0xFFFFFFFFU) {
      _tprintf(_T("*** Frequency must be in the range 0 to 4294967295.\n"));
      ret = EXIT_INVALID_FREQUENCY;
      goto done;
    }
    
    ret = setClkCommand(&device, bVerbose, clockIndex, (uint32_t)frequency);
  } else if (_tcsicmp(pCommand, _T("getclknv")) == 0) {
    unsigned int clockIndex;
    int nConverted;
    
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'getclknv' command must be followed by a clock generator index.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &clockIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** Clock generator index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }
    
    ret = getClkNvCommand(&device, bVerbose, clockIndex);
  } else if (_tcsicmp(pCommand, _T("setclknv")) == 0) {
    const TCHAR* pszFrequency;
    unsigned int clockIndex;
    unsigned long frequency;
    int nConverted;
    
    if (arguments.nParam < 3) {
      _tprintf(_T("*** 'setclknv' command must be followed by (1) a clock generator index and (2) an override frequency (Hz).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &clockIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** Clock generator index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }
    if (clockIndex > 0xFFU) {
      _tprintf(_T("*** Clock generator index must be in the range 0 to 255.\n"));
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    pszFrequency = arguments.param[2].pStringVal;
    nConverted = stringToULong(pszFrequency, &frequency);
    if (1 != nConverted) {
      _tprintf(_T("*** Override frequency value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_FREQUENCY;
      goto done;
    }
    if (frequency > 0xFFFFFFFFU) {
      _tprintf(_T("*** Override frequency must be in the range 0 to 4294967295.\n"));
      ret = EXIT_INVALID_FREQUENCY;
      goto done;
    }
    
    ret = setClkNvCommand(&device, bVerbose, clockIndex, (uint32_t)frequency);
  } else if (_tcsicmp(pCommand, _T("i2c-read-to-file")) == 0) {
    unsigned int bus, dev, address;
    unsigned int count;
    int nConverted;

    if (arguments.nParam < 6) {
      _tprintf(_T("*** 'i2c-read-to-file' command must be followed by (1) the I2C bus number, (2) the I2C chip address, (3) the address, (4) the byte count, and (5) the filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &bus);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C bus number value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_I2C_BUS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &dev);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C chip address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_I2C_DEVICE;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** Address value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_I2C_ADDRESS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[4].pStringVal, &count);
    if (1 != nConverted) {
      _tprintf(_T("*** Count value '%s' not recognized as a number.\n"), arguments.param[4].pStringVal);
      ret = EXIT_INVALID_I2C_COUNT;
      goto done;
    }

    ret = i2cReadToFileCommand(&device, bVerbose, bus, dev, address, count, arguments.param[5].pStringVal);
  } else if (_tcsicmp(pCommand, _T("i2c-write-from-file")) == 0) {
    unsigned int bus, dev, address;
    int nConverted;

    if (arguments.nParam < 5) {
      _tprintf(_T("*** 'i2c-write-from-file' command must be followed by (1) the I2C bus number, (2) the I2C chip address, (3) the address and (4) the filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &bus);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C bus number value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_I2C_BUS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &dev);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C chip address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_I2C_DEVICE;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** Address value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_I2C_ADDRESS;
      goto done;
    }

    ret = i2cWriteFromFileCommand(&device, bVerbose, bus, dev, address, arguments.param[4].pStringVal);
  } else if (_tcsicmp(pCommand, _T("i2c-verify-with-file")) == 0) {
    unsigned int bus, dev, address;
    int nConverted;

    if (arguments.nParam < 5) {
      _tprintf(_T("*** 'i2c-verify-with-file' command must be followed by (1) the I2C bus number, (2) the I2C chip address, (3) the address and (4) the filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &bus);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C bus number value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &dev);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C chip address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** Address value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    ret = i2cVerifyWithFileCommand(&device, bVerbose, bus, dev, address, arguments.param[4].pStringVal);
  } else if (_tcsicmp(pCommand, _T("i2c-read")) == 0) {
    unsigned int bus, dev, address;
    unsigned int count;
    int nConverted;

    if (arguments.nParam < 5) {
      _tprintf(_T("*** 'i2c-read' command must be followed by (1) the I2C bus number, (2) the I2C chip address, (3) the address, (4) the byte count\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &bus);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C bus number value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_I2C_BUS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &dev);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C chip address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_I2C_DEVICE;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** Address value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_I2C_ADDRESS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[4].pStringVal, &count);
    if (1 != nConverted) {
      _tprintf(_T("*** Count value '%s' not recognized as a number.\n"), arguments.param[4].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    ret = i2cReadCommand(&device, bVerbose, bus, dev, address, count);
  } else if (_tcsicmp(pCommand, _T("i2c-write")) == 0) {
    unsigned int bus, dev, address;
    unsigned int count, i, byte;
    int nConverted;
    uint8_t* pBytes = NULL;

    if (arguments.nParam < 5) {
      _tprintf(_T("*** 'i2c-write' command must be followed by (1) the I2C bus number, (2) the I2C chip address, (3) the address, (4) one or more address/data bytes to write\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &bus);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C bus number value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_I2C_BUS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &dev);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C chip address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_I2C_DEVICE;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** Address value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_I2C_ADDRESS;
      goto done;
    }

    count = arguments.nParam - 4;

    pBytes = (uint8_t*)malloc(count * sizeof(uint8_t));
    if (NULL == pBytes) {
      _tprintf(_T("*** Failed to allocate byte buffer of %u byte(s).\n"), count);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }

    for (i = 0; i < count; i++) {
      nConverted = stringToUInt(arguments.param[i + 4].pStringVal, &byte);
      if (1 != nConverted) {
        free(pBytes);
        _tprintf(_T("*** Byte value '%s' not recognized as a number.\n"), arguments.param[i + 4].pStringVal);
        ret = EXIT_INVALID_I2C_BYTEVAL;
        goto done;
      }
      pBytes[i] = (uint8_t)byte;
    }

    ret = i2cWriteCommand(&device, bVerbose, bus, dev, address, count, pBytes);

    free(pBytes);
  } else if (_tcsicmp(pCommand, _T("i2c-write-read")) == 0) {
    unsigned int bus, dev;
    unsigned int readCount, writeCount, i, byte;
    int nConverted;
    uint8_t* pWriteBytes = NULL;

    if (arguments.nParam < 4) {
      _tprintf(_T("*** 'i2c-write-read' command must be followed by (1) the I2C bus number, (2) the I2C chip address, (3) read byte count, (4) zero or more address/data bytes to write\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &bus);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C bus number value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_I2C_BUS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &dev);
    if (1 != nConverted) {
      _tprintf(_T("*** I2C chip address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_I2C_DEVICE;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &readCount);
    if (1 != nConverted) {
      _tprintf(_T("*** Read byte count value '%s' not recognized as a number.\n"), arguments.param[4].pStringVal);
      ret = EXIT_INVALID_I2C_COUNT;
      goto done;
    }

    writeCount = arguments.nParam - 4;

    pWriteBytes = (uint8_t*)malloc(writeCount * sizeof(uint8_t));
    if (NULL == pWriteBytes) {
      _tprintf(_T("*** Failed to allocate write byte buffer of %u byte(s).\n"), writeCount);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }

    for (i = 0; i < writeCount; i++) {
      nConverted = stringToUInt(arguments.param[i + 4].pStringVal, &byte);
      if (1 != nConverted) {
        free(pWriteBytes);
        _tprintf(_T("*** Byte value '%s' not recognized as a number.\n"), arguments.param[i + 4].pStringVal);
        ret = EXIT_INVALID_I2C_BYTEVAL;
        goto done;
      }
      pWriteBytes[i] = (uint8_t)byte;
    }

    ret = i2cWriteReadCommand(&device, bVerbose, bus, dev, writeCount, readCount, pWriteBytes);

    free(pWriteBytes);
  } else if (_tcsicmp(pCommand, _T("spi-raw")) == 0) {
    unsigned int chipIndex, readCount, writeCount;
    unsigned int i, byte;
    int nConverted;
    uint8_t* pWriteBytes = NULL;

    if (arguments.nParam < 3) {
      _tprintf(_T("*** 'spi-raw' command must be followed by (1) the SPI chip index, (2) number of bytes to read, (3) zero or more bytes to write\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &readCount);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI read count value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_SPI_READ_COUNT;
      goto done;
    }

    writeCount = arguments.nParam - 3;

    pWriteBytes = (uint8_t*)malloc(writeCount * sizeof(uint8_t));
    if (NULL == pWriteBytes) {
      _tprintf(_T("*** Failed to allocate write buffer of %u byte(s).\n"), writeCount);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }

    for (i = 0; i < writeCount; i++) {
      nConverted = stringToUInt(arguments.param[i + 3].pStringVal, &byte);
      if (1 != nConverted) {
        free(pWriteBytes);
        _tprintf(_T("*** Byte value '%s' not recognized as a number.\n"), arguments.param[i + 3].pStringVal);
        ret = EXIT_INVALID_SPI_BYTEVAL;
        goto done;
      }
      pWriteBytes[i] = (uint8_t)byte;
    }

    ret = spiRawCommand(&device, bVerbose, chipIndex, readCount, writeCount, pWriteBytes);

    free(pWriteBytes);
  } else if (_tcsicmp(pCommand, _T("spi-info")) == 0) {
    unsigned int chipIndex;
    int nConverted;

    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'spi-info' command must be followed by (1) the SPI chip index.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    ret = spiInfoCommand(&device, bVerbose, chipIndex);
  } else if (_tcsicmp(pCommand, _T("spi-check-blank")) == 0) {
    unsigned int chipIndex, address, count;
    int nConverted;

    if (arguments.nParam < 4) {
      _tprintf(_T("*** 'spi-check-blank' command must be followed by (1) the SPI chip index, (2) starting address, (3) number of bytes to erase\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_SPI_ADDRESS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &count);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI blank-check count value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_SPI_BYTE_COUNT;
      goto done;
    }

    ret = spiCheckBlankCommand(&device, bVerbose, chipIndex, address, count);
  } else if (_tcsicmp(pCommand, _T("spi-erase")) == 0) {
    unsigned int chipIndex, address, count;
    int nConverted;

    if (arguments.nParam < 4) {
      _tprintf(_T("*** 'spi-erase' command must be followed by (1) the SPI chip index, (2) starting address, (3) number of bytes to erase\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI address value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_SPI_ADDRESS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[3].pStringVal, &count);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI erase count value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_SPI_BYTE_COUNT;
      goto done;
    }

    ret = spiEraseCommand(&device, bVerbose, chipIndex, address, count);
  } else if (_tcsicmp(pCommand, _T("spi-program-mcs")) == 0) {
    unsigned int chipIndex;
    TCHAR* pFilename;
    int translation = 0;
    int nConverted;

    if (arguments.nParam < 3) {
      _tprintf(_T("*** 'spi-program-mcs' command must be followed by (1) the SPI chip index, (2) the filename of an Intel Hex (.mcs) file.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    pFilename = arguments.param[2].pStringVal;

    if (arguments.nParam >= 4) {
      nConverted = stringToInt(arguments.param[3].pStringVal, &translation);
      if (1 != nConverted) {
        _tprintf(_T("*** Translation value '%s' not recognized as a signed number.\n"), arguments.param[3].pStringVal);
        ret = EXIT_INVALID_TRANSLATION;
        goto done;
      }
    }

    ret = spiProgramIntelHexCommand(&device, bVerbose, chipIndex, pFilename, (int32_t)translation);
  } else if (_tcsicmp(pCommand, _T("spi-verify-mcs")) == 0) {
    unsigned int chipIndex;
    TCHAR* pFilename;
    int translation = 0;
    int nConverted;

    if (arguments.nParam < 3) {
      _tprintf(_T("*** 'spi-verify-mcs' command must be followed by (1) the SPI chip index, (2) the filename of an Intel Hex (.mcs) file.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    pFilename = arguments.param[2].pStringVal;

    if (arguments.nParam >= 4) {
      nConverted = stringToInt(arguments.param[3].pStringVal, &translation);
      if (1 != nConverted) {
        _tprintf(_T("*** Translation value '%s' not recognized as a signed number.\n"), arguments.param[3].pStringVal);
        ret = EXIT_INVALID_TRANSLATION;
        goto done;
      }
    }

    ret = spiVerifyIntelHexCommand(&device, bVerbose, chipIndex, pFilename, translation);
  } else if (_tcsicmp(pCommand, _T("spi-save-to-mcs")) == 0) {
    unsigned int chipIndex, address, count;
    TCHAR* pFilename;
    int nConverted;

    if (arguments.nParam < 5) {
      _tprintf(_T("*** 'spi-save-to-mcs' command must be followed by (1) the SPI chip index, (2) the filename of an Intel Hex (.mcs) file, (3) starting address, (4) byte count\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &chipIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** SPI chip index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    pFilename = arguments.param[2].pStringVal;

    nConverted = stringToUInt(arguments.param[3].pStringVal, &address);
    if (1 != nConverted) {
      _tprintf(_T("*** Starting address value '%s' not recognized as a number.\n"), arguments.param[3].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[4].pStringVal, &count);
    if (1 != nConverted) {
      _tprintf(_T("*** Byte count value '%s' not recognized as a number.\n"), arguments.param[4].pStringVal);
      ret = EXIT_INVALID_SPI_INDEX;
      goto done;
    }

    ret = spiSaveIntelHexCommand(&device, bVerbose, chipIndex, pFilename, address, count);
  } else if (_tcsicmp(pCommand, _T("update-firmware")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'update-firmware' command must be followed by the firmware filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = updateOrVerifyFirmwareCommand(&device, bVerbose, FALSE, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("update-brdcfg")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'update-brdcfg' command must be followed by the board config. filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = updateOrVerifyBoardConfigCommand(&device, bVerbose, FALSE, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("update-vpd")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'update-vpd' command must be followed by the VPD filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = updateOrVerifyVpdCommand(&device, bVerbose, FALSE, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("save-firmware")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'save-firmware' command must be followed by the filename (.bin) into which the firmware is to be saved.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = saveFirmwareCommand(&device, bVerbose, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("save-brdcfg")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'save-brdcfg' command must be followed by the filename (.bin) into which the board config. is to be saved.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = saveBoardConfigCommand(&device, bVerbose, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("save-vpd")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'save-vpd' command must be followed by the filename (.bin) into which the VPD is to be saved.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = saveVpdCommand(&device, bVerbose, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("verify-brdcfg")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'verify-brdcfg' command must be followed by the board config. filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = updateOrVerifyBoardConfigCommand(&device, bVerbose, TRUE, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("verify-firmware")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'verify-firmware' command must be followed by the firmware filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = updateOrVerifyFirmwareCommand(&device, bVerbose, TRUE, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("verify-vpd")) == 0) {
    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'verify-vpd' command must be followed by the VPD filename (.bin).\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    ret = updateOrVerifyVpdCommand(&device, bVerbose, TRUE, arguments.param[1].pStringVal);
  } else if (_tcsicmp(pCommand, _T("display-vpd")) == 0) {
    ret = displayVpdCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("display-vpd-raw")) == 0) {
    ret = displayVpdRawCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("display-black-box")) == 0) {
    unsigned int nTypes = 0x3; /* 0x1 => clobber records, 0x2 => noclobber records, 0x3 => both */
    unsigned int nRecordCount = 0; /* 0 => all records, other => number of records to display */
    unsigned int nConverted;
    TCHAR* pTypes;

    if (arguments.nParam >= 2) {
      pTypes = arguments.param[1].pStringVal;

      if (_tcsicmp(pTypes, _T("both")) == 0) {
        nTypes = 0x3;
      } else if (_tcsicmp(pTypes, _T("clobber")) == 0) {
        nTypes = 0x1;
      } else if (_tcsicmp(pTypes, _T("noclobber")) == 0) {
        nTypes = 0x2;
      } else {
        _tprintf(_T("*** Valid 'display-black-box' command record types are: clobber, noclobber.\n"));
        ret = EXIT_INVALID_RECORD_TYPE;
        goto done;
      }
    }

    if (arguments.nParam >= 3) {
      nConverted = stringToUInt(arguments.param[2].pStringVal, &nRecordCount);
      if (1 != nConverted) {
        _tprintf(_T("*** Black Box record count value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
        ret = EXIT_INVALID_RECORD_COUNT;
        goto done;
      }
    }

    ret = displayBlackBoxCommand(&device, bVerbose, nTypes, nRecordCount);
  } else if (_tcsicmp(pCommand, _T("display-sensors")) == 0) {
    ret = displaySensorsCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("display-sensors-raw")) == 0) {
    ret = displaySensorsRawCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("override-sensor")) == 0) {
    unsigned int sensorIndex, overrideValue;
    int nConverted;

    if (arguments.nParam < 3) {
      _tprintf(_T("*** 'override-sensor-raw' must be followed by the (1) sensor index and (2) the unscaled override value.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &sensorIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** Sensor index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[2].pStringVal, &overrideValue);
    if (1 != nConverted) {
      _tprintf(_T("*** Override value '%s' not recognized as a number.\n"), arguments.param[2].pStringVal);
      ret = EXIT_INVALID_OVERRIDE;
      goto done;
    }

    ret = overrideSensorUnscaledCommand(&device, bVerbose, sensorIndex, overrideValue);
  } else if (_tcsicmp(pCommand, _T("release-sensor")) == 0) {
    unsigned int sensorIndex;
    int nConverted;

    if (arguments.nParam < 2) {
      _tprintf(_T("*** 'release-sensor' must be followed by the sensor index.\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &sensorIndex);
    if (1 != nConverted) {
      _tprintf(_T("*** Sensor index value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_INDEX;
      goto done;
    }

    ret = releaseSensorCommand(&device, bVerbose, sensorIndex);
  } else if (_tcsicmp(pCommand, _T("test-clobber")) == 0) {
    ret = testClobberCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("test-timeout")) == 0) {
    ret = testTimeoutCommand(&device, bVerbose);
  } else if (_tcsicmp(pCommand, _T("raw")) == 0) {
    unsigned int readCount, writeCount, i, byte;
    int nConverted;
    uint8_t* pWriteBytes = NULL;

    if (arguments.nParam < 4) {
      _tprintf(_T("*** 'raw' command must be followed by (1) the expected response length, (2) two or more command bytes to write\n"));
      ret = EXIT_INSUFFICIENT_ARGS;
      goto done;
    }

    nConverted = stringToUInt(arguments.param[1].pStringVal, &readCount);
    if (1 != nConverted) {
      _tprintf(_T("*** Expected response length value '%s' not recognized as a number.\n"), arguments.param[1].pStringVal);
      ret = EXIT_INVALID_RAW_READ_COUNT;
      goto done;
    }

    writeCount = arguments.nParam - 2;

    pWriteBytes = (uint8_t*)malloc(writeCount * sizeof(uint8_t));
    if (NULL == pWriteBytes) {
      _tprintf(_T("*** Failed to allocate write byte buffer of %u byte(s).\n"), writeCount);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }

    for (i = 0; i < writeCount; i++) {
      nConverted = stringToUInt(arguments.param[i + 2].pStringVal, &byte);
      if (1 != nConverted) {
        free(pWriteBytes);
        _tprintf(_T("*** Command byte value '%s' not recognized as a number.\n"), arguments.param[i + 2].pStringVal);
        ret = EXIT_INVALID_RAW_BYTEVAL;
        goto done;
      }
      pWriteBytes[i] = (uint8_t)byte;
    }

    ret = rawCommand(&device, bVerbose, readCount, writeCount, pWriteBytes);

    free(pWriteBytes);
  } else {
    _tprintf(_T("*** Unrecognised command: %s\n"), pCommand);
    _tprintf(_T("    Use '%s -h' for help.\n"), PROGRAM_NAME);
    ret = EXIT_UNRECOGNIZED_COMMAND;
    goto done;
  }

done:
  closeDevice(&device);

  sampleCleanupCommandLine(&arguments);
  return ret;
}

#endif
