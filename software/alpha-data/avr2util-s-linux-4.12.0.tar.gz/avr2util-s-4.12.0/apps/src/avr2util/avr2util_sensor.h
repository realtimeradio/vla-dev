#ifndef _ADATA_AVR2UTIL_SENSOR_H
#define _ADATA_AVR2UTIL_SENSOR_H

#include "avr2util_model.h"

typedef struct _SensorInfo {
  const TCHAR* pSensorName;
  const TCHAR* pSensorUnit;
} SensorInfo;

static void
getSensorInfo(
  uint32_t drawingNumber,
  unsigned int index,
  SensorInfo* pSensorInfo)
{
  static const SensorInfo infoAdmxrcku1[] = {
    { _T("5V/12V XMC VPWR rail"), _T("V") },
    { _T("12V XMC power rail"), _T("V") },
    { _T("5V XMC power rail"), _T("V") },
    { _T("3.3V XMC power rail"), _T("V") },
    { _T("2.5V power rail"), _T("V") },
    { _T("1.8V power rail"), _T("V") },
    { _T("0.95V power rail"), _T("V") },
    { _T("1.8V bridge VCCAux"), _T("V") },
    { _T("1.2V DDR4 SDRAM power rail"), _T("V") },
    { _T("XRM variable VI/O rail"), _T("V") },
    { _T("1.0V power rail"), _T("V") },
    { _T("1.2V target MGT AVCC"), _T("V") },
    { _T("1.0V target MGT AVCC"), _T("V") },
    { _T("1.0V bridge MGT AVCC"), _T("V") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temp. (central)"), _T("deg. C") },
    { _T("Bridge FPGA int temp. diode"), _T("deg. C") },
    { _T("Target FPGA int temp. diode"), _T("deg. C") }
  };
  
  static const SensorInfo infoAdmpcie8v3[] = {
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("2.5V power"), _T("V") },
    { _T("1.8V MGT power"), _T("V") },
    { _T("1.2V DDR4 SDRAM power"), _T("V") },
    { _T("1.2V MGT AVTT"), _T("V") },
    { _T("1.0V MGT AVCC"), _T("V") },
    { _T("0.95V FPGA core power"), _T("V") },
    { _T("0.6V DDR4 SDRAM VTT"), _T("V") },
    { _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V current (edge conn.)"), _T("A") },
    { _T("1.8V MGT current"), _T("A") },
    { _T("2.5V current"), _T("A") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") }
  };

  static const SensorInfo infoAdmpcie8k5[] = {
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (internal)"), _T("V") },
    { _T("2.5V clock power"), _T("V") },
    { _T("1.8V rail"), _T("V") },
    { _T("1.8V MGT Aux. power"), _T("V") },
    { _T("1.2V DDR4 SDRAM power"), _T("V") },
    { _T("1.2V MGT AVTT"), _T("V") },
    { _T("1.0V MGT AVCC"), _T("V") },
    { _T("0.95V FPGA core rail"), _T("V") },
    { _T("0.6V DDR4 SDRAM VTT"), _T("V") },
    { _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V current (edge conn.)"), _T("A") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") }
  };

  static const SensorInfo infoAdmpcie9v3[] = {
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("2.5V (clock) power"), _T("V") },
    { _T("1.8V MGTVCCAux power"), _T("V") },
    { _T("1.2V DDR4 SDRAM power"), _T("V") },
    { _T("1.2V MGT AVTT"), _T("V") },
    { _T("0.9V MGT AVCC"), _T("V") },
    { _T("FPGA core power"), _T("V") },
    { _T("0.6V DDR4 SDRAM VTT"), _T("V") },
    { _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V current (edge conn.)"), _T("A") },
    { _T("1.8V MGTVCCAux current"), _T("A") },
    { _T("2.5V (digital) current "), _T("A") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U89"), _T("deg. C") },
    { _T("Board temperature at U90"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdmvpx39z2[] = {
    { _T("5V/12V main power rail"), _T("V") },
    { _T("12V VPX power rail"), _T("V") },
    { _T("5V VPX power rail"), _T("V") },
    { _T("3.3V VPX power rail"), _T("V") },
    { _T("2.5V power rail (int.)"), _T("V") },
    { _T("1.8V power rail (int.)"), _T("V") },
    { _T("FPGA core power rail (int.)"), _T("V") },
    { _T("MGT AVCCAux rail (int.)"), _T("V") },
    { _T("1.2V DDR4 SDRAM power (int.)"), _T("V") },
    { _T("FMC VADJ power rail (int.)"), _T("V") },
    { _T("FPGA BRAM power rail (int.)"), _T("V") },
    { _T("1.2V PL MGT AVTT (int.)"), _T("V") },
    { _T("0.9V PL MGT AVcc (int.)"), _T("V") },
    { _T("FPGA PS power rail (int.)"), _T("V") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U18"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdmpcie9v3g[] = {
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("2.5V (clock) power"), _T("V") },
    { _T("1.8V MGTVCCAux power"), _T("V") },
    { _T("FMC VAdj power"), _T("V") },
    { _T("1.2V MGT AVTT"), _T("V") },
    { _T("0.9V MGT AVCC"), _T("V") },
    { _T("FPGA core power"), _T("V") },
    { _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V current (edge conn.)"), _T("A") },
    { _T("1.8V MGTVCCAux current"), _T("A") },
    { _T("2.5V (digital) current"), _T("A") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U89"), _T("deg. C") },
    { _T("Board temperature at U90"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdmpcie9h7[] = {
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("12V rail (J26 8-pin conn.)"), _T("V") },
    { _T("12V rail (J30 6-pin conn.)"), _T("V") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V current (edge conn.)"), _T("A") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("2.5V rail (internal)"), _T("V") },
    { _T("1.8V rail (internal"), _T("V") },
    { _T("1.8V MGT Aux rail (internal)"), _T("V") },
    { _T("1.2V rail (internal)"), _T("V") },
    { _T("1.2V MGT AVTT (internal)"), _T("V") },
    { _T("0.9V MGT AVCC (internal)"), _T("V") },
    { _T("FPGA I/O rail (internal)"), _T("V") },
    { _T("FPGA core rail (internal)"), _T("V") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U85"), _T("deg. C") },
    { _T("Board temperature at U1"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdasdevbase[] = {
    { _T("12V rail"), _T("V") },
    { _T("5V rail"), _T("V") },
    { _T("3.3V rail"), _T("V") },
    { _T("FMC VI/O rail"), _T("V") },
    { _T("2.5V rail"), _T("V") },
    { _T("1.8V rail"), _T("V") },
    { _T("FPGA core rail"), _T("V") },
    { _T("1.8V MGT AVCCAux rail"), _T("V") },
    { _T("1.5V DDR3 SDRAM power"), _T("V") },
    { _T("1.2V MGT AVTT"), _T("V") },
    { _T("1V MGT AVCC"), _T("V") },
    { _T("12V current"), _T("A") },
    { _T("5V current"), _T("A") },
    { _T("3.3V current"), _T("A") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U13"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") }
  };

  static const SensorInfo infoAdmpcie9h3[] = {
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V current (edge conn.)"), _T("A") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (internal)"), _T("V") },
    { _T("2.5V rail (internal)"), _T("V") },
    { _T("1.8V rail (internal"), _T("V") },
    { _T("1.8V MGT Aux rail (internal)"), _T("V") },
    { _T("1.2V rail (internal)"), _T("V") },
    { _T("1.2V MGT AVTT (internal)"), _T("V") },
    { _T("0.9V MGT AVCC (internal)"), _T("V") },
    { _T("FPGA I/O rail (internal)"), _T("V") },
    { _T("FPGA core rail (internal)"), _T("V") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U27"), _T("deg. C") },
    { _T("Board temperature at U15"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdmpcie9v5[] = {
    { _T("12V rail (J4 conn.)"), _T("V") },
    { _T("12V current (J4 conn.)"), _T("A") },
    { _T("12V rail (edge conn.)"), _T("V") },
    { _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (internal)"), _T("V") },
    { _T("2.5V rail"), _T("V") },
    { _T("1.8V rail"), _T("V") },
    { _T("1.8V MGTVCCAux rail"), _T("V") },
    { _T("1.2V MGT AVTT rail"), _T("V") },
    { _T("0.9V MGT AVCC rail"), _T("V") },
    { _T("FPGA core power rail"), _T("V") },
    { _T("Reserved"), _T("?") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U23"), _T("deg. C") },
    { _T("Board temperature at U3"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdmxrc9r1[] = {
    { _T("5V/12V VPWR rail (P5 conn.)"), _T("V") },
    { _T("12V rail (P5 conn.)"), _T("V") },
    { _T("5V rail (int.)"), _T("V") },
    { _T("3.3V rail (P5 conn.)"), _T("V") },
    { _T("3.3V IC rail (int.)"), _T("V") },
    { _T("2.5V rail (int.)"), _T("V") },
    { _T("1.8V rail (int.)"), _T("V") },
    { _T("0.85V FPGA core power rail (int.)"), _T("V") },
    { _T("1.8V MGT AVCCAux rail (int.)"), _T("V") },
    { _T("1.2V DDR4 SDRAM power (int.)"), _T("V") },
    { _T("0.85V FPGA BRAM power (int.)"), _T("V") },
    { _T("1.2V PL MGT AVTT rail (int.)"), _T("V") },
    { _T("0.9V PL MGT AVCC rail (int.)"), _T("V") },
    { _T("0.85V PS full-power rail (int.)"), _T("V") },
    { _T("uC internal temperature"), _T("deg. C") },
    { _T("Board temperature at U8"), _T("deg. C") },
    { _T("Reserved"), _T("deg. C") },
    { _T("FPGA temperature"), _T("deg. C") }
  };

  static const SensorInfo infoAdmvpx39v2[] = {
    { _T("12V rail (VPX conn.)"), _T("V") },
    { _T("12V current (VPX conn.)"), _T("A") },
    { _T("3.3V Aux rail (VPX conn.)"), _T("V") },
    { _T("3.3V rail (VPX conn.)"), _T("V") },
    { _T("2.5V rail (internal)"), _T("V") },
    { _T("2.5V clock rail (internal)"), _T("V") },
    { _T("1.8V rail (internal)"), _T("V") },
    { _T("1.8V MGT Aux rail (internal)"), _T("V") },
    { _T("1.2V rail (internal)"), _T("V") },
    { _T("1.2V AVTT rail (internal)"), _T("V") },
    { _T("0.9V AVCC rail (internal)"), _T("V") },
    { _T("0.85V rail (internal)"), _T("V") },
    { _T("0.6V DRAM VTT1 (internal)"), _T("V") },
    { _T("0.6V DRAM VTT0 (internal)"), _T("V") },
	{ _T("uC internal temperature (U25)"), _T("deg. C") },
    { _T("Board temperature at U6"), _T("deg. C") },
    { _T("Board temperature at U71"), _T("deg. C") },
    { _T("FPGA temperature (U38)"), _T("deg. C") }
  };

  /* Applies to ADM-PA100 & ADM-PA101 */
  static const SensorInfo infoAdmpa100[] = {
    { _T("12V rail (AUX8 conn.)"), _T("V") },
    { _T("12V rail (edge conn.)"), _T("V") },
	{ _T("12V current (edge conn.)"), _T("A") },
    { _T("3.3V Aux rail (edge conn.)"), _T("V") },
    { _T("3.3V rail (edge conn.)"), _T("V") },
    { _T("3.3V VCCO rail (internal)"), _T("V") },
    { _T("1.8V rail (internal)"), _T("V") },
    { _T("1.5V rail (internal)"), _T("V") },
    { _T("1.5V AVCCAux rail (internal)"), _T("V") },
    { _T("1.2V AVTT (internal)"), _T("V") },
    { _T("1.2V rail (internal)"), _T("V") },
    { _T("0.88V AVCC (internal)"), _T("V") },
    { _T("FPGA core rail (internal)"), _T("V") },
    { _T("FMC VAdj rail (internal)"), _T("V") },
	{ _T("uC internal temperature (U66)"), _T("deg. C") },
    { _T("Board temperature at U24"), _T("deg. C") },
    { _T("Board temperature at U57"), _T("deg. C") },
    { _T("FPGA temperature (U42)"), _T("deg. C") }
  };

  /* Establish defaults in case not matched. */
  
  pSensorInfo->pSensorName = _T("");

  if (index < 14) {
    /* Sensors 0 to 13, if used, are either current or voltage. */
    pSensorInfo->pSensorUnit = _T("A or V");
  } else if (index < 18) {
    /* Sensors 14 to 17, if used, are temperature. */
    pSensorInfo->pSensorUnit = _T("deg. C");
  } else if (index < 20) {
    switch (index) {
    case 18:
      /* Sensor 18 is Elapsed Time Counter, in 1/4 units. Counts time spent powered on. */
      pSensorInfo->pSensorName = _T("Elapsed time counter");
      pSensorInfo->pSensorUnit = _T("s");
      break;

    case 19:
      /* Sensor 19 is Event Counter; counts power cycles on most models. */
      pSensorInfo->pSensorName = _T("Event counter");
      pSensorInfo->pSensorUnit = _T("");
      break;
    }
  } else {
    /* Don't expect a sensor index of 20 or higher */
    pSensorInfo->pSensorUnit = _T("?");
  }

  /* Fill in sensor information according drawing number and index */
  
  switch (drawingNumber) {
  case DRAWING_NUM_ADMXRCKU1:
    if (index < ARRAY_LENGTH(infoAdmxrcku1)) {
      *pSensorInfo = infoAdmxrcku1[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE8V3:
    if (index < ARRAY_LENGTH(infoAdmpcie8v3)) {
      *pSensorInfo = infoAdmpcie8v3[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE8K5:
  case DRAWING_NUM_ADMPCIEUCC:
  case DRAWING_NUM_ADMPCIE8K5_FH:
    if (index < ARRAY_LENGTH(infoAdmpcie8k5)) {
      *pSensorInfo = infoAdmpcie8k5[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE9V3:
    if (index < ARRAY_LENGTH(infoAdmpcie9v3)) {
      *pSensorInfo = infoAdmpcie9v3[index];
    }
    break;

  case DRAWING_NUM_ADMVPX39Z2:
    if (index < ARRAY_LENGTH(infoAdmvpx39z2)) {
      *pSensorInfo = infoAdmvpx39z2[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE9V3G:
    if (index < ARRAY_LENGTH(infoAdmpcie9v3g)) {
      *pSensorInfo = infoAdmpcie9v3g[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE9H7:
    if (index < ARRAY_LENGTH(infoAdmpcie9h7)) {
      *pSensorInfo = infoAdmpcie9h7[index];
    }
    break;

  case DRAWING_NUM_ADMSDEVBASE:
    if (index < ARRAY_LENGTH(infoAdasdevbase)) {
      *pSensorInfo = infoAdasdevbase[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE9H3:
    if (index < ARRAY_LENGTH(infoAdmpcie9h3)) {
      *pSensorInfo = infoAdmpcie9h3[index];
    }
    break;

  case DRAWING_NUM_ADMPCIE9V5:
    if (index < ARRAY_LENGTH(infoAdmpcie9v5)) {
      *pSensorInfo = infoAdmpcie9v5[index];
    }
    break;

  case DRAWING_NUM_ADMXRC9R1:
    if (index < ARRAY_LENGTH(infoAdmxrc9r1)) {
      *pSensorInfo = infoAdmxrc9r1[index];
    }
    break;

  case DRAWING_NUM_ADMVPX39V2:
    if (index < ARRAY_LENGTH(infoAdmvpx39v2)) {
      *pSensorInfo = infoAdmvpx39v2[index];
    }
    break;

  case DRAWING_NUM_ADMPA100:
  case DRAWING_NUM_ADMPA101:
    if (index < ARRAY_LENGTH(infoAdmpa100)) {
      *pSensorInfo = infoAdmpa100[index];
    }
    break;
  }
}

#endif
