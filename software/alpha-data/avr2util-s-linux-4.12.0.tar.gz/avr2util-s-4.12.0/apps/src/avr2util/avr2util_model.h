#ifndef _ADATA_AVR2UTIL_MODEL_H
#define _ADATA_AVR2UTIL_MODEL_H

/* Possible values for VPD drawing number field */
#define DRAWING_NUM_ADMXRCKU1     (1305)
#define DRAWING_NUM_ADMPCIE8V3    (1308)
#define DRAWING_NUM_ADMPCIE8K5    (1319)
#define DRAWING_NUM_ADMPCIE9V3    (1322)
#define DRAWING_NUM_ADMVPX39Z2    (1323)
#define DRAWING_NUM_ADMPCIEUCC    (1329)
#define DRAWING_NUM_ADMPCIE9V3G   (1339)
#define DRAWING_NUM_ADMPCIE9H7    (1341)
#define DRAWING_NUM_ADMPCIE8K5_FH (1342)
#define DRAWING_NUM_ADMXRC9R1     (1353)
#define DRAWING_NUM_ADMSDEVBASE   (1360)
#define DRAWING_NUM_ADMPCIE9H3    (1365)
#define DRAWING_NUM_ADMVPX39V2    (1377)
#define DRAWING_NUM_ADMPCIE9V5    (1385)
#define DRAWING_NUM_ADMPA100      (1429)
#define DRAWING_NUM_ADMPA101      (1430)


static const TCHAR*
getModelName(
  uint32_t drawingNumber)
{
  const TCHAR* pModelName = _T("UNRECOGNIZED");
  
  switch (drawingNumber) {
  case DRAWING_NUM_ADMXRCKU1:
    pModelName = _T("ADM-XRC-KU1");
    break;

  case DRAWING_NUM_ADMPCIE8V3:
    pModelName = _T("ADM-PCIE-8V3");
    break;

  case DRAWING_NUM_ADMPCIE8K5:
    pModelName = _T("ADM-PCIE-8K5");
    break;

  case DRAWING_NUM_ADMPCIEUCC:
    pModelName = _T("ADM-PCIE-UCC");
    break;

  case DRAWING_NUM_ADMPCIE9V3:
    pModelName = _T("ADM-PCIE-9V3");
    break;

  case DRAWING_NUM_ADMPCIE9V5:
    pModelName = _T("ADM-PCIE-9V5");
    break;

  case DRAWING_NUM_ADMPCIE8K5_FH:
    pModelName = _T("ADM-PCIE-8K5-FH");
    break;

  case DRAWING_NUM_ADMPCIE9V3G:
    pModelName = _T("ADM-PCIE-9V3G");
    break;

  case DRAWING_NUM_ADMPCIE9H7:
    pModelName = _T("ADM-PCIE-9H7");
    break;

  case DRAWING_NUM_ADMSDEVBASE:
    pModelName = _T("ADM-SDEV-BASE");
    break;

  case DRAWING_NUM_ADMPCIE9H3:
    pModelName = _T("ADM-PCIE-9H3");
    break;

  case DRAWING_NUM_ADMVPX39Z2:
    pModelName = _T("ADM-VPX3-9Z2");
    break;

  case DRAWING_NUM_ADMXRC9R1:
    pModelName = _T("ADM-XRC-9R1");
    break;

  case DRAWING_NUM_ADMVPX39V2:
    pModelName = _T("ADM-VPX3-9V2");
    break;

  case DRAWING_NUM_ADMPA100:
    pModelName = _T("ADM-PA100");
    break;
  
  case DRAWING_NUM_ADMPA101:
    pModelName = _T("ADM-PA101");
    break;
  }
  
  return pModelName;
}

#endif