#ifndef _ADATA_SPI_FLASH_H
#define _ADATA_SPI_FLASH_H

#include <sdk_common.h>

/* An Entry in the Sector Map.
** Only the entries corresponding to the current configuration ID are retained. */
typedef struct _SPIChipSectorMapRegion {
  uint64_t sizeBytes;  /* Region size */
  uint8_t  eraseTypes; /* Bit [0] corresponds to sector type 1, [1] to type 2, ..., [3] => type 4 */
} SPIChipSectorMapRegion;

/* This structure is essentially a summary of the SFDP read from the SPI Flash chip,
** and contains sufficient information for this driver to be able to read, write &
** erase the SPI Flash chip. */
typedef struct _SPIChipDescription {
  uint32_t densityBytes;

  /* Values for fourByteAddressEnter & fourByteAddressExit */
#define SPI_CHIP_4BYTE_ADDR_ALWAYS      (0) /* Always in 4-byte address mode */
#define SPI_CHIP_4BYTE_ADDR_VIA_CMD     (1) /* Dedicated commands for entering (0x06) / exiting (0x04) 4-byte addressing mode */
#define SPI_CHIP_4BYTE_ADDR_VIA_BAR     (2) /* Bank Address Register (BAR) bit 7 controls whether or not in 4-byte addressing mode */
#define SPI_CHIP_4BYTE_ADDR_VIA_EAR     (3) /* No 4-byte address mode, but extended address register contains bits [31:24] of address */
  struct {
    uint8_t type; /* See definitions above */
    union {
      struct {
        bool_t bNeedWriteEnable;
        uint8_t command;
      } viaCmd;
      struct {
        uint8_t readCommand;
        uint8_t writeCommand;
        uint8_t value;
        uint8_t mask;
      } viaBAR;
    } variant;
  } fourByteAddressEnter, fourByteAddressExit;

#define SPI_CHIP_SOFTRESET_NONE         (0) /* No software reset function provided */
#define SPI_CHIP_SOFTRESET_1_FOR_8_CLK  (1) /* Drive 1s on all 4 data wires for 8 clocks */
#define SPI_CHIP_SOFTRESET_1_FOR_10_CLK (2) /* Drive 1s on all 4 data wires for 10 clocks if in 4-byte address mode */
#define SPI_CHIP_SOFTRESET_1_FOR_16_CLK (3) /* Drive 1s on all 4 data wires for 16 clocks */
#define SPI_CHIP_SOFTRESET_LEGACY_F0    (4) /* Issue legacy 0xF0 opcode to software-reset */
#define SPI_CHIP_SOFTRESET_66_99        (5) /* Issue reset-enable (0x66) opcode followed by reset (0x99) opcode */
  uint8_t softResetType;

  uint8_t readStatusCommand; /* Read status register command */

  uint8_t readCommand; /* Basic 1-1-1 read command */

  struct {
    uint8_t enableCommand;
    uint8_t disableCommand;
  } writeEnable;

  struct {
    uint8_t command; /* Basic 1-1-1 page program command */
    uint32_t pageSizeBytes; /* Program page size */
  } pageProgram;

  struct { /* Supported sector/subsector sizes */
    uint32_t sizeBytes;
    uint8_t eraseCommand;
  } blockType[4];
  uint8_t smallestBlockType; /* An index into blockType member */

  /* Keep track of certain state in SPI Flash chip */
  struct {
    bool_t bIn4ByteAddressMode; /* TRUE => currently in 4-byte address mode */
    uint16_t currentPage; /* Used when there is no 4-byte address mode but a page register is provided for address [31:24] */
  } state;

  /* Used for partial sector/subsector erase / write operations. */
  /* Large enough for largest sector/subsector size. */
  /* Also used for verification. */
  uint8_t* pMergeBuffer;

  /* Optional Sector Map */
  struct {
    unsigned int regionCount;
    uint8_t currentConfigurationID;
    SPIChipSectorMapRegion* pRegions;
  } sectorMap;

} SPIChipDescription;

extern int
avr2utilSpiFlashHardwareReset(
  const DeviceHandle* pDevice,
  bool_t bVerbose);

extern int
avr2utilSpiFlashSoftwareReset(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  SPIChipDescription* pChipDescription);

extern int
avr2utilSpiFlashStartEndOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bStartNotStop);

extern int
avr2utilSpiFlashGetDescription(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  SPIChipDescription* pChipDescription,
  bool_t bAllocateMergeBuffer);

extern void
avr2utilSpiFlashPutDescription(
  SPIChipDescription* pChipDescription);

extern void
avr2utilSpiFlashDumpDescription(
  const SPIChipDescription* pChipDescription);

extern int
avr2utilSpiFlashReadSFDP(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  uint32_t address,
  uint8_t* pBuffer,
  unsigned int count);

extern int
avr2utilSpiFlashWriteEnableOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  bool_t bEnableNotDisable);

extern int
avr2utilSpiFlash4ByteMode(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  bool_t bEnterNotExit);

extern int
avr2utilSpiFlashErase(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count);

extern int
avr2utilSpiFlashRead(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  void* pBuffer);

extern int
avr2utilSpiFlashWrite(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  const void* pBuffer);

extern int
avr2utilSpiFlashVerify(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  const void* pData, /* If NULL, performs a blank-check */
  uint32_t maxErrorsDisplayed,
  uint32_t* pErrorCount);

#endif