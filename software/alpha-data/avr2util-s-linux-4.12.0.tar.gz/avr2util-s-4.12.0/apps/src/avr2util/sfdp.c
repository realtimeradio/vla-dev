/*
** sfdp.c - Functions for working with SPI Flash SFDP data.
**
** (C) Copyright 2017 Alpha Data
*/

#if defined(_WIN32)

/* Windows */
# include <windows.h>
# include <tchar.h>

#else

/* Linux or VxWorks */
# define _T(x) x
# define _tprintf printf
# define _stprintf_s snprintf
# define FALSE (0)
# define TRUE (1)

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <sdk_common.h>
#include <platform_endian.h>

#include "sfdp.h"

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

void
avr2utilDisplaySFDPTable(
  const SFDPTable* pTable,
  uint32_t tableAddress,
  unsigned int tableIndex,
  unsigned int tableSize)
{
  static const TCHAR* eraseSizeDesc[] = {
    _T("** Reserved value (0) **"),
    _T("4 kiB erase"),
    _T("** Reserved value (2) **"),
    _T("4 kiB erase unavailable **")
  };
  static const TCHAR* writeGranularityDesc[] = {
    _T("1 byte write granularity / buffer-programmable < 64 bytes"),
    _T("Buffer-programmable >= 64 bytes")
  };
  static const TCHAR* writeEnableInstDesc[] = {
    _T("Nonvolatile status bit"),
    _T("Requires 0x00 written to status register to allow writes and erases")
  };
  static const TCHAR* writeEnableOpcodeDesc[] = {
    _T("Opcode is 0x50 for status register write"),
    _T("Opcode is 0x06 for status register write")
  };
  static const TCHAR* addressBytesDesc[] = {
    _T("3-byte addressing only"),
    _T("3 or 4 byte addressing, depending on mode"),
    _T("4-byte addressing onlys"),
    _T("** Reserved value (3) **")
  };
  uint16_t fastReadSupport1;
  uint32_t density, fastReadSupport2;
  uint64_t densityBits;

  _tprintf(_T("SFDP Table %u @ 0x%X is a Standard Parameter Table:\n"), tableIndex, tableAddress);

  /* For chips predating JESD216, first four DWORDs of table are present */

  _tprintf(_T("  Erase and write capabilities .. 0x%02X\n"), pTable->eraseAndWriteCaps);
  _tprintf(_T("    => %s\n"), eraseSizeDesc[(pTable->eraseAndWriteCaps >> 0) & 0x3U]);
  _tprintf(_T("    => %s\n"), writeGranularityDesc[(pTable->eraseAndWriteCaps >> 2) & 0x1]);
  _tprintf(_T("    => %s\n"), writeEnableInstDesc[(pTable->eraseAndWriteCaps >> 3) & 0x1]);
  _tprintf(_T("    => %s\n"), writeEnableOpcodeDesc[(pTable->eraseAndWriteCaps >> 4) & 0x1]);

  _tprintf(_T("  Erase opcode .................. 0x%02X\n"), pTable->eraseOpcode);

  fastReadSupport1 = le16_to_cpu(pTable->fastReadSupport1);
  _tprintf(_T("  Fast Read support 1 ........... 0x%04X\n"), fastReadSupport1);
  _tprintf(_T("    => 1-1-2 Fast Read %s\n"), ((fastReadSupport1 >> 0) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));
  _tprintf(_T("    => %s\n"), addressBytesDesc[(fastReadSupport1 >> 1) & 0x3U]);
  _tprintf(_T("    => Double transfer rate (DTR) clocking %s\n"), ((fastReadSupport1 >> 3) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));
  _tprintf(_T("    => 1-2-2 Fast Read %s\n"), ((fastReadSupport1 >> 4) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));
  _tprintf(_T("    => 1-4-4 Fast Read %s\n"), ((fastReadSupport1 >> 5) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));
  _tprintf(_T("    => 1-1-4 Fast Read %s\n"), ((fastReadSupport1 >> 6) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));

  density = le32_to_cpu(pTable->density);
  densityBits = (density & 0x80000000) ? 1 << (density & 0x7FFFFFFF) : (density & 0x7FFFFFFF) + 1;
  _tprintf(_T("  Density ....................... 0x%08X => 0x%llX b / 0x%llX B\n"),
    density, (unsigned long long)densityBits, (unsigned long long)(densityBits / 8));

  _tprintf(_T("  1-4-4 Fast Read capabilities .. 0x%02X => %u wait state(s), %u mode bit(s)\n"),
    pTable->fastReadCaps144, (pTable->fastReadCaps144 >> 0) & 0x1FU, (pTable->fastReadCaps144 >> 5) & 0x7U);
  _tprintf(_T("  1-4-4 Fast Read opcode ........ 0x%02X\n"), pTable->fastReadOpcode144);

  _tprintf(_T("  1-1-4 Fast Read capabilities .. 0x%02X => %u wait state(s), %u mode bit(s)\n"),
    pTable->fastReadCaps114, (pTable->fastReadCaps114 >> 0) & 0x1FU, (pTable->fastReadCaps114 >> 5) & 0x7U);
  _tprintf(_T("  1-1-4 Fast Read opcode ........ 0x%02X\n"), pTable->fastReadOpcode114);

  _tprintf(_T("  1-1-2 Fast Read capabilities .. 0x%02X => %u wait state(s), %u mode bit(s)\n"),
    pTable->fastReadCaps112, (pTable->fastReadCaps112 >> 0) & 0x1FU, (pTable->fastReadCaps112 >> 5) & 0x7U);
  _tprintf(_T("  1-1-2 Fast Read opcode ........ 0x%02X\n"), pTable->fastReadOpcode112);

  _tprintf(_T("  1-2-2 Fast Read capabilities .. 0x%02X => %u wait state(s), %u mode bit(s)\n"),
    pTable->fastReadCaps122, (pTable->fastReadCaps122 >> 0) & 0x1FU, (pTable->fastReadCaps122 >> 5) & 0x7U);
  _tprintf(_T("  1-2-2 Fast Read opcode ........ 0x%02X\n"), pTable->fastReadOpcode122);

  if (tableSize >= 36) { /* JESD216 */
    unsigned int i;

    fastReadSupport2 = le32_to_cpu(pTable->fastReadSupport2);
    _tprintf(_T("  Fast read support 2 ........... 0x%08X\n"), fastReadSupport2);
    _tprintf(_T("    => 2-2-2 Fast Read %s\n"), ((fastReadSupport2 >> 0) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));
    _tprintf(_T("    => 4-4-4 Fast Read %s\n"), ((fastReadSupport2 >> 4) & 0x1U) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));

    _tprintf(_T("  2-2-2 Fast Read capabilities .. 0x%02X => %u wait state(s), %u mode bit(s)\n"),
      pTable->fastReadCaps222, (pTable->fastReadCaps222 >> 0) & 0x1FU, (pTable->fastReadCaps222 >> 5) & 0x7U);
    _tprintf(_T("  2-2-2 Fast Read opcode ........ 0x%02X\n"), pTable->fastReadOpcode222);

    _tprintf(_T("  4-4-4 Fast Read capabilities .. 0x%02X => %u wait state(s), %u mode bit(s)\n"),
      pTable->fastReadCaps444, (pTable->fastReadCaps444 >> 0) & 0x1FU, (pTable->fastReadCaps444 >> 5) & 0x7U);
    _tprintf(_T("  4-4-4 Fast Read opcode ........ 0x%02X\n"), pTable->fastReadOpcode444);

    for (i = 0; i < ARRAY_LENGTH(pTable->sectorSize); i++) {
      _tprintf(_T("  Sector Type %u size ............ %u(0x%02X) => "),
        i + 1, (unsigned int)pTable->sectorSize[i].power, (unsigned int)pTable->sectorSize[i].power);
      if (0 == pTable->sectorSize[i].power) {
        _tprintf(_T("NOT SUPPORTED\n"));
      } else {
        _tprintf(_T("0x%llX B\n"), (unsigned long long)((uint64_t)0x1 << pTable->sectorSize[i].power));
      }
      _tprintf(_T("  Sector Type %u erase opcode .... 0x%02X\n"), i + 1, pTable->sectorSize[i].eraseOpcode);
    }
  }

  if (tableSize >= 64) { /* JESD216B */
    unsigned int i;

    static const unsigned int eraseUnitMultipliers[4] = { 1, 16, 128, 1000 };
    static const unsigned int programPageUnitMultipliers[2] = { 8, 64 };
    static const unsigned int programByteUnitMultipliers[2] = { 1, 8 };
    static const unsigned int eraseChipUnitMultipliers[4] = { 16, 256, 128, 1000 };
    uint32_t eraseTimes, programTimes, suspendCaps, suspendOpcodes, powerDownCaps, quadModeCaps, miscCaps;
    uint8_t unit, nvStatusRegister, softReset, enter4ByteAddress;
    uint16_t exit4ByteAddress;
    uint8_t exit444Mode, enter444Mode, exit044Mode, enter044Mode, quadEnableRequirements;
    unsigned int worstCaseMultiplier, count, milliseconds, microseconds, programPageSize;

    eraseTimes = le32_to_cpu(pTable->eraseTimes);
    _tprintf(_T("  Erase times ................... 0x%08X\n"), eraseTimes);
    worstCaseMultiplier = (unsigned int)(2 * ((eraseTimes & 0xF) + 1));
    _tprintf(_T("    => Worst case multiplier = %u\n"), worstCaseMultiplier);
    for (i = 0; i < ARRAY_LENGTH(pTable->sectorSize); i++) {
      _tprintf(_T("    => Sector Type %u erase time (typ.) = "), i + 1);
      if (pTable->sectorSize[i].power != 0) {
        count = (unsigned int)(((eraseTimes >> (4 + 7 * i)) & 0x1F) + 1);
        unit = (uint8_t)((eraseTimes >> (9 + 7 * i)) & 0x3);
        milliseconds = count * eraseUnitMultipliers[unit];
        _tprintf(_T("%u ms\n"), count);
      } else {
        _tprintf(_T("N/A\n"));
      }
    }

    programTimes = le32_to_cpu(pTable->programTimes);
    _tprintf(_T("  Program times ................. 0x%08X\n"), programTimes);
    worstCaseMultiplier = (unsigned int)(2 * ((programTimes & 0xF) + 1));
    _tprintf(_T("    => Worst case multiplier = %u\n"), worstCaseMultiplier);
    programPageSize = (unsigned int)1 << ((programTimes >> 4) & 0xF);
    _tprintf(_T("    => Program page size = %u B\n"), programPageSize);
    count = (unsigned int)(((programTimes >> 8) & 0x1F) + 1);
    unit = (uint8_t)((programTimes >> 13) & 0x1);
    microseconds = count * programPageUnitMultipliers[unit];
    _tprintf(_T("    => Program page time (typ.) = %u us\n"), microseconds);
    count = (unsigned int)(((programTimes >> 14) & 0xF) + 1);
    unit = (uint8_t)((programTimes >> 18) & 0x1);
    microseconds = count * programByteUnitMultipliers[unit];
    _tprintf(_T("    => Program byte time (typ.) = %u us\n"), microseconds);
    count = (unsigned int)(((programTimes >> 19) & 0xF) + 1);
    unit = (uint8_t)((programTimes >> 23) & 0x1);
    microseconds = count * programByteUnitMultipliers[unit];
    _tprintf(_T("    => Program byte additional time (typ.) = %u us\n"), microseconds);
    count = (unsigned int)(((programTimes >> 24) & 0x1F) + 1);
    unit = (uint8_t)((programTimes >> 29) & 0x3);
    milliseconds = count * eraseChipUnitMultipliers[unit];
    _tprintf(_T("    => Erase chip time (typ.) = %u ms\n"), milliseconds);

    suspendCaps = le32_to_cpu(pTable->suspendCaps);
    _tprintf(_T("  Suspend capabilities .......... 0x%08X\n"), suspendCaps);

    suspendOpcodes = le32_to_cpu(pTable->suspendOpcodes);
    _tprintf(_T("  Suspend opcodes ............... 0x%08X\n"), suspendOpcodes);

    powerDownCaps = le32_to_cpu(pTable->powerDownCaps);
    _tprintf(_T("  Powerdown / status cap. ....... 0x%08X\n"), powerDownCaps);
    if (powerDownCaps & 0x4) {
      _tprintf(_T("    => Legacy polling using opcode 0x05, WIP bit (0)\n"));
    }
    if (powerDownCaps & 0x8) {
      _tprintf(_T("    => Poll device busy via status register bit 7 using opcode 0x70\n"));
    }

    quadModeCaps = le32_to_cpu(pTable->quadModeCaps);
    _tprintf(_T("  Quad enable / hold cap. ....... 0x%08X\n"), quadModeCaps);
    exit444Mode = (uint8_t)(quadModeCaps & 0xF);
    if (exit444Mode & 0x1) {
      _tprintf(_T("    => Opcode 0xFF exits 4-4-4 Mode\n"));
    }
    if (exit444Mode & 0x2) {
      _tprintf(_T("    => Opcode 0xF5 exits 4-4-4 Mode\n"));
    }
    if (exit444Mode & 0x4) {
      _tprintf(_T("    => Read-modify-write (volatile) exits 4-4-4 Mode:\n"));
      _tprintf(_T("       (a) Read config. (opcode 0x65) to address 0x800003, (b) clear bit 6,\n"));
      _tprintf(_T("       (c) Write config. back (opcode 0x71) to address 0x800003\n"));
    }
    if (exit444Mode & 0x8) {
      _tprintf(_T("    => Soft reset exits 4-4-4 Mode: opcode 0x66 then opcode 0x99\n"));
    }
    enter444Mode = (uint8_t)((quadModeCaps >> 4) & 0x1F);
    if (enter444Mode & 0x1) {
      _tprintf(_T("    => Set Quad Enable, then opcode 0x38 to enter 4-4-4 Mode\n"));
    }
    if (enter444Mode & 0x2) {
      _tprintf(_T("    => Opcode 0x38 enters 4-4-4 Mode\n"));
    }
    if (enter444Mode & 0x4) {
      _tprintf(_T("    => Opcode 0x35 enters 4-4-4 Mode\n"));
    }
    if (enter444Mode & 0x8) {
      _tprintf(_T("    => RMW sequence (volatile) exits 4-4-4 Mode:\n"));
      _tprintf(_T("       (a) Read config. (opcode 0x65 address 0x800003), (b) set bit 6,\n"));
      _tprintf(_T("       (c) Write config. back (opcode 0x71 address 0x800003)\n"));
    }
    if (enter444Mode & 0x10) {
      _tprintf(_T("    => RMW sequence (volatile) enters/exits 4-4-4 Mode:\n"));
      _tprintf(_T("       (a) Read config. (opcode 0x65 no address), (b) set/clear bit 7,\n"));
      _tprintf(_T("       (c) Write config. back (opcode 0x71 no address)\n"));
    }
    _tprintf(_T("    => 0-4-4 Mode is %s\n"), (quadModeCaps & 0x200) ? _T("SUPPORTED") : _T("NOT SUPPORTED"));
    exit044Mode = (uint8_t)((quadModeCaps >> 10) & 0x3F);
    enter044Mode = (uint8_t)((quadModeCaps >> 16) & 0xF);
    if (exit044Mode & 0x1) {
      _tprintf(_T("    => If mode bits [7:0] = 0, exits 0-4-4 Mode at end of current read\n"));
    }
    if (exit044Mode & 0x2) {
      _tprintf(_T("    => If 3-byte address mode, drive 1s on DQ for 8 clocks to exit 0-4-4 Mode\n"));
      _tprintf(_T("       If 4-byte address mode, drive 1s on DQ for 10 clocks to exit 0-4-4 Mode\n"));
    }
    if (exit044Mode & 0x8) {
      _tprintf(_T("    => Drive 1s on DQ for 8 clocks to exit 0-4-4 Mode\n"));
    }
    if (exit044Mode & 0x10) {
      _tprintf(_T("    => Mode bits [7:4] != 0xA exits 0-4-4 Mode\n"));
    }
    if (enter044Mode & 0x1) {
      _tprintf(_T("    => Mode bits [7:0] = 0xA5 enters 0-4-4 Mode (requires Quad Enable)\n"));
    }
    if (enter044Mode & 0x2) {
      _tprintf(_T("    => RMW sequence (volatile) enters/exits 0-4-4 Mode:\n"));
      _tprintf(_T("       (a) Read config. (opcode 0x85 no address), (b) set/clear bit 3 (XIP),\n"));
      _tprintf(_T("       (c) Write config. back (opcode 0x81 no address),\n"));
      _tprintf(_T("       (d) Set mode bits [7:0] to 0x01\n"));
    }
    if (exit044Mode & 0x4) {
      _tprintf(_T("    => Mode bits [7:4] = 0xA enters 0-4-4 Mode\n"));
    }
    quadEnableRequirements = (uint8_t)((quadModeCaps >> 20) & 0x7);
    switch (quadEnableRequirements) {
    case 0:
      _tprintf(_T("    => No QE bit; detects 1-1-4 and 1-4-4 based on opcode (refer to JESD216B)\n"));
      break;

    case 1:
      _tprintf(_T("    => QE is status reg. 2 bit 2 (refer to JESD216B)\n"));
      break;

    case 2:
      _tprintf(_T("    => QE is status reg. 1 bit 6 (refer to JESD216B)\n"));
      break;

    case 3:
      _tprintf(_T("    => QE is status reg. 2 bit 7 (refer to JESD216B)\n"));
      break;

    case 4:
      _tprintf(_T("    => QE is status reg. 2 bit 1 (2 byte read/write; refer to JESD216B)\n"));
      break;

    case 5:
      _tprintf(_T("    => QE is status reg. 2 bit 1 (1 byte read, 2 byte write; refer to JESD216B)\n"));
      break;

    default:
      _tprintf(_T("    => Unknown QE requirements code (%u), not defined by JESD216B\n"), (unsigned int)quadEnableRequirements);
      break;
    }
    if (quadModeCaps & 0x800000) {
      _tprintf(_T("    => Set bit 4 of NV ext. config. reg. to 0 to disable HOLD / RESET\n"));
    } else {
      _tprintf(_T("    => HOLD / RESET disable function is NOT SUPPORTED\n"));
    }

    miscCaps = le32_to_cpu(pTable->miscCaps);
    _tprintf(_T("  Miscellanous capabilities ..... 0x%08X\n"), miscCaps);
    nvStatusRegister = (uint8_t)(miscCaps & 0x3F);
    if (nvStatusRegister & 0x1) {
      _tprintf(_T("    => Nonvolatile status register 1, opcode 0x60 to write\n"));
    }
    if (nvStatusRegister & 0x2) {
      _tprintf(_T("    => Volatile status register 1, powers up with 1s, opcode 0x06 to write\n"));
    }
    if (nvStatusRegister & 0x4) {
      _tprintf(_T("    => Volatile status register 1, powers up with 1s, opcode 0x50 to write\n"));
    }
    if (nvStatusRegister & 0x8) {
      _tprintf(_T("    => NV/Volatile status register 1, opcode 0x06 to write volatile, 0x50 to write NV\n"));
    }
    if (nvStatusRegister & 0x10) {
      _tprintf(_T("    => Status register 1 has mix of volatile and NV bits, opcode 0x06 to write\n"));
    }
    softReset = (uint8_t)((miscCaps >> 8) & 0x1F);
    if (softReset == 0) {
      _tprintf(_T("    => No software reset function\n"));
    }
    if (softReset & 0x1) {
      _tprintf(_T("    => Drive 1s on all 4 data wires for 8 clocks to soft-reset\n"));
    }
    if (softReset & 0x2) {
      _tprintf(_T("    => Drive 1s on all 4 data wires for 10 clocks, if in 4-byte address mode, to soft-reset\n"));
    }
    if (softReset & 0x4) {
      _tprintf(_T("    => Drive 1s on all 4 data wires for 16 clocks to soft-reset\n"));
    }
    if (softReset & 0x8) {
      _tprintf(_T("    => Opcode 0xF0 performs soft-reset\n"));
    }
    if (softReset & 0x10) {
      _tprintf(_T("    => Issue opcode 0x66 (reset enable) followed by opcode 0x99 to soft-reset\n"));
    }
    if (softReset & 0x20) {
      _tprintf(_T("    => Exit from 0-4-4 mode required before reset sequence\n"));
    }
    exit4ByteAddress = (uint16_t)((miscCaps >> 14) & 0x3FF);
    enter4ByteAddress = (uint8_t)((miscCaps >> 24) & 0xFF);
    if (exit4ByteAddress & 0x1) {
      _tprintf(_T("    => Opcode 0xE9 exits 4-byte address mode\n"));
    }
    if (exit4ByteAddress & 0x2) {
      _tprintf(_T("    => Opcode 0x06 (write enable) then opcode 0xE9 exits 4-byte address mode\n"));
    }
    if ((exit4ByteAddress & 0x4) || (enter4ByteAddress & 0x4)) {
      _tprintf(_T("    => Addr. [31:24] in extended address register\n"));
      _tprintf(_T("       Read & write register (volatile) using opcodes 0xC8 & 0xC5 (1 data byte)\n"));
    }
    if ((exit4ByteAddress & 0x8) || (enter4ByteAddress & 0x8)) {
      _tprintf(_T("    => Bank register bit 7 = 0 => bank register [6:0] = address bits [30:24]\n"));
      _tprintf(_T("       Bank register bit 7 = 1 => 4-byte address mode\n"));
      _tprintf(_T("       Read & write register (volatile) using opcodes 0x16 & 0x17 (1 data byte)\n"));
    }
    if ((exit4ByteAddress & 0x10) || (enter4ByteAddress & 0x10)) {
      _tprintf(_T("    => 16-bit config. register bit 0 = 0 => 3-byte address mode\n"));
      _tprintf(_T("       16-bit config. register bit 0 = 1 => 4-byte address mode\n"));
      _tprintf(_T("       Write register (NV) using opcode 0xB1 (2 data bytes)\n"));
    }
    if (exit4ByteAddress & 0x20) {
      _tprintf(_T("    => Hardware reset exits 4-byte address mode\n"));
    }
    if (exit4ByteAddress & 0x40) {
      _tprintf(_T("    => Software reset exits 4-byte address mode\n"));
    }
    if (exit4ByteAddress & 0x80) {
      _tprintf(_T("    => Power cycle exits 4-byte address mode\n"));
    }
    if (enter4ByteAddress & 0x1) {
      _tprintf(_T("    => Opcode 0xB7 enters 4-byte address mode\n"));
    }
    if (enter4ByteAddress & 0x2) {
      _tprintf(_T("    => Opcode 0x06 (write enable) then opcode 0xB7 enters 4-byte address mode\n"));
    }
    if (enter4ByteAddress & 0x20) {
      _tprintf(_T("    => Has vendor-specific opcode set for 4-byte reads and writes\n"));
    }
    if (enter4ByteAddress & 0x40) {
      _tprintf(_T("    => Always operates in 4-byte address mode\n"));
    }
  }
}

void
avr2utilDisplaySFDPSectorMap(
  const uint32_t* pTable,
  uint32_t tableAddress,
  unsigned int tableIndex,
  unsigned int tableSize)
{
  uint32_t pos = 0;

  _tprintf(_T("SFDP Table %u @ 0x%X is a Sector Map:\n"), tableIndex, tableAddress);
  _tprintf(_T("Pos.  DWORD val.    Human-readable interpretation\n"));
  _tprintf(_T("-------------------------------------------------------------------------------\n"));

  while (pos < tableSize) {
    bool_t bMapDescriptor, bLastDescriptor;
    uint32_t val32;

    val32 = *pTable++;
    val32 = le32_to_cpu(val32);

    bLastDescriptor = (uint8_t)(val32 & 0x1U) ? TRUE : FALSE;
    bMapDescriptor = (uint8_t)(val32 & 0x2U) ? TRUE : FALSE;

    if (bMapDescriptor) {
      unsigned int nRegion;
      uint8_t configurationID;
      uint64_t regionSize;

      nRegion = (unsigned int)((val32 >> 16) & 0xFFU) + 1;
      configurationID = (uint8_t)((val32 >> 8) & 0xFFU);

      _tprintf(_T("0x%03X 0x%08X => Map Descriptor; last=%-5s nRgn=%u configID=%u\n"),
        pos, val32, bLastDescriptor ? _T("TRUE") : _T("FALSE"), nRegion, (unsigned int)configurationID);
      pos += 4;

      while (nRegion && pos < tableSize) {
        val32 = *pTable++;
        val32 = le32_to_cpu(val32);

        regionSize = (uint64_t)(((val32 >> 8) & 0xFFFFFFU) + 1) * 256;
        _tprintf(_T("0x%03X 0x%08X => RgnSize=0x%09llX Type1=%-3s Type2=%-3s Type3=%-3s Type4=%-3s\n"),
          pos, val32, (unsigned long long)regionSize,
          (val32 & 0x1) ? _T("yes") : _T("no"),
          (val32 & 0x2) ? _T("yes") : _T("no"),
          (val32 & 0x4) ? _T("yes") : _T("no"),
          (val32 & 0x8) ? _T("yes") : _T("no"));
        pos += 4;
        nRegion--;
      }
    } else {
      uint8_t mask, latency, opcode;
      const TCHAR* pAddrLenDesc = _T("?");
      TCHAR latencyDesc[12] = { 0 };

      mask = (uint8_t)((val32 >> 24) & 0xFFU);
      switch ((val32 >> 22) & 0x3) {
      case 0:
        pAddrLenDesc = _T("none");
        break;

      case 1:
        pAddrLenDesc = _T("3-byte");
        break;

      case 2:
        pAddrLenDesc = _T("4-byte");
        break;

      case 3:
        pAddrLenDesc = _T("variable");
        break;

      default:
        assert(FALSE);
        break;
      }
      latency = (uint8_t)((val32 >> 16) & 0xFU);
      if (0xF == latency) {
        _stprintf_s(latencyDesc, ARRAY_LENGTH(latencyDesc), _T("%s"), _T("variable"));
      } else {
        _stprintf_s(latencyDesc, ARRAY_LENGTH(latencyDesc), _T("%u"), (unsigned int)latency);
      }
      opcode = (uint8_t)((val32 >> 8) & 0xFFU);
      _tprintf(_T("0x%03X 0x%08X => Configuration Detection Descriptor; last=%-5s\n"),
        pos, val32, bLastDescriptor ? _T("TRUE") : _T("FALSE"));
      _tprintf(_T("                    Mask=0x%02X addrLen=%s latency=%s opcode=0x%02X\n"),
        mask, pAddrLenDesc, latencyDesc, opcode);
      pos += 4;
      if (pos < tableSize) {
        val32 = *pTable++;
        val32 = le32_to_cpu(val32);
        _tprintf(_T("0x%03X 0x%08X => Address=0x%08X\n"), pos, val32, val32);
        pos += 4;
      }
    }
  }
}

bool_t /* TRUE if header indicates standard JEDEC table */
avr2utilDisplaySFDPTableHeader(
  const SFDPTableHeader* pTableHeader,
  uint32_t address,
  unsigned int tableIndex,
  unsigned int* pTableSize,
  uint32_t* pPointer24,
  uint16_t* pTableID)
{
  const TCHAR* pTypeDesc = _T("?");
  uint32_t pointer24;
  uint8_t idMSB;
  bool_t bStandardTable = FALSE;
  uint16_t tableID;

  pointer24 = le32_to_cpu(pTableHeader->pointer24IDMSB) & 0xFFFFFF;
  idMSB = (uint8_t)((le32_to_cpu(pTableHeader->pointer24IDMSB) >> 24) & 0xFF);

  tableID = (uint16_t)(((uint16_t)idMSB << 8) | (uint16_t)pTableHeader->idLSB);
  if (SFDP_ID_STANDARD_TABLE == tableID) {
    pTypeDesc = _T("Std. Parameter Table");
    bStandardTable = TRUE;
  } else if (SFDP_ID_SECTOR_MAP == tableID) {
    pTypeDesc = _T("Std. Sector Map");
    bStandardTable = TRUE;
  } else {
    pTypeDesc = _T("Unknown Table type");
  }

  _tprintf(_T("SFDP Table Header %u @ 0x%X:\n"), tableIndex, address);
  _tprintf(_T("  ID MSB, LSB ................... %u, %u (0x%02X, 0x%02X) => %s\n"),
    (unsigned int)pTableHeader->idLSB, (unsigned int)idMSB, (unsigned int)pTableHeader->idLSB, (unsigned int)idMSB, pTypeDesc);
  _tprintf(_T("  Revision Number ............... %u.%u\n"),
    (unsigned int)pTableHeader->major, (unsigned int)pTableHeader->minor);
  _tprintf(_T("  Table length (DWORDs) ......... %u(0x%02X)\n"),
    (unsigned int)pTableHeader->nLengthDwords, (unsigned int)pTableHeader->nLengthDwords);
  _tprintf(_T("  Table pointer ................. %u(0x%06X)\n"), pointer24, pointer24);

  if (NULL != pTableSize) {
    *pTableSize = 4 * pTableHeader->nLengthDwords;
  }

  if (NULL != pPointer24) {
    *pPointer24 = pointer24;
  }

  if (NULL != pTableID) {
    *pTableID = tableID;
  }

  return bStandardTable;
}

void
avr2utilDisplaySFDPHeader(
  const SFDPHeader* pHeader,
  uint32_t address,
  uint32_t* pSignature,
  unsigned int* pTableSize)
{
  uint32_t signature;
  unsigned int tableLength = 16; /* Assume predates JESD216 */
  const TCHAR* pJESD216VersionDesc = _T("Predates JESD216");

  signature = le32_to_cpu(pHeader->signature);

  if (pHeader->major > 1) {
    tableLength = 16 * 4; /* JESD216B */
    pJESD216VersionDesc = _T("JESD216B");
  } else if (pHeader->major == 1) {
    if (pHeader->minor >= 6) {
      tableLength = 16 * 4; /* JESD216B */
      pJESD216VersionDesc = _T("JESD216B");
    } else {
      tableLength = 9 * 4; /* JESD216 */
      pJESD216VersionDesc = _T("JESD216");
    }
  } else {
    /* Predates JESD216 */
  }

  _tprintf(_T("SFDP Header @ 0x%X:\n"), address);
  printf("  SFDP Signature ................ 0x%08X => %c%c%c%c\n",
    signature,
    (char)((signature >>  0) & 0xFF),
    (char)((signature >>  8) & 0xFF),
    (char)((signature >> 16) & 0xFF),
    (char)((signature >> 24) & 0xFF));
  _tprintf(_T("  SFDP Revision Number .......... %u.%u => %s\n"),
    (unsigned int)pHeader->major, (unsigned int)pHeader->minor, pJESD216VersionDesc);
  _tprintf(_T("  Number of Parameter Headers ... %u\n"),
    (unsigned int)pHeader->nParameterHeaders);
  _tprintf(_T("  Unused byte ................... %u(0x%02X)\n"),
    (unsigned int)pHeader->_reserved1, (unsigned int)pHeader->_reserved1);

  if (signature != SPI_SFDP_HEADER_SIGNATURE) {
    _tprintf(_T("+++ Signature 0x%08X in header is not expected value 0x%08X. Following records may be nonsense.\n"),
      signature, SPI_SFDP_HEADER_SIGNATURE);
  }

  if (NULL != pSignature) {
    *pSignature = signature;
  }

  if (NULL != pTableSize) {
    *pTableSize = tableLength;
  }
}
