#ifndef _ADATA_INTEL_HEX_H
#define _ADATA_INTEL_HEX_H

#include <sdk_common.h>

#define INTEL_HEX_RECORD_DATA         (0)
#define INTEL_HEX_RECORD_EOF          (1)
#define INTEL_HEX_RECORD_EXT_SEG_ADDR (2)
#define INTEL_HEX_RECORD_SEG_ADDR     (3)
#define INTEL_HEX_RECORD_EXT_LIN_ADDR (4)
#define INTEL_HEX_RECORD_LIN_ADDR     (5)

typedef struct _IntelHexFileSection {
  uint32_t address;
  uint32_t length;
  uint8_t* pData;
} IntelHexFileSection;

#define INTEL_HEX_ERROR_CSUM_ERROR     (1) /* At least one with a bad checksum was encountered */
#define INTEL_HEX_ERROR_UNSUPP_RECORD  (2) /* At least one record with unsupported type was encountered */
#define INTEL_HEX_ERROR_NO_EOF_RECORD  (3) /* No end-of-file record was encountered */
#define INTEL_HEX_ERROR_EOF_EXTRA      (4) /* More records after end-of-file record */
#define INTEL_HEX_ERROR_BAD_RECORD     (5) /* At least one malformed record was encountered */
#define INTEL_HEX_ERROR_SHORT_RECORD   (6) /* At least one record with less bytes than the record length indicator */
#define INTEL_HEX_ERROR_LONG_RECORD    (7) /* At least one record with more bytes than the record length indicator */
#define INTEL_HEX_ERROR_BAD_CHARACTER  (8) /* At least one line with unexpected nonprinting characters encountered */
#define INTEL_HEX_ERROR_EOF_NOT_EMPTY  (9) /* Found an EOF record with nonzero length field */
#define INTEL_HEX_ERROR_BAD_ADDR_LEN  (10) /* Found an address record (2, 3, 4 or 5) with length field that was not the expected value  */

#define INTEL_HEX_FILE_MAX_ERROR (10)

typedef struct _IntelHexFile {
  size_t              errorCount;
  struct {
    uint32_t          code;
    unsigned int      line;
  } errors[INTEL_HEX_FILE_MAX_ERROR];
  size_t              sectionCount;
  IntelHexFileSection sections[1]; /* Variable-length array of sections */
} IntelHexFile;

typedef enum _IntelHexError {
  IntelHexErrorOk               = 0,
  IntelHexErrorAllocationError  = 1, /* Could not allocate memory for data structures */
  IntelHexErrorPermissionDenied = 2, /* Could not open file due to permissions of file */
  IntelHexErrorNotFound         = 3, /* File not found or at least one directory in path not found */
  IntelHexErrorOpenFailed       = 4, /* Failed to open file due to unexpected error */
  IntelHexErrorSeekError        = 5, /* Unspecified error occurred when seeking to beginning of file */
  IntelHexErrorReadError        = 6, /* Unspecified error occurred when reading file */
  IntelHexErrorWriteError       = 7, /* Unspecified error occurred when writing file */
} IntelHexError;

extern IntelHexError
avr2utilReadIntelHex(
  const TCHAR* pFilename,
  IntelHexFile** ppIntelHexFile);

extern IntelHexError
avr2utilWriteIntelHex(
  const TCHAR* pFilename,
  const IntelHexFile* pIntelHexFile,
  uint8_t maxBytesPerRecord);

extern void
avr2utilDisposeIntelHex(
  IntelHexFile* pIntelHexFile);

extern void
avr2utilDisplayIntelHexInfo(
  const IntelHexFile* pIntelHexFile,
  const TCHAR* pIndent);

#endif
