/*
** spi_flash.c - Functions for reading and writing SPI chips accessible from
**               the microcontroller.
**
**               This is effectively a user-mode driver which communicates
**               with SPI Flash chips via the microcontroller.
**
**               The driver is somewhat generic in the sense that it uses
**               Serial Flash Discovery Parameters as per JEDEC JESD216B
**               specification in order to determine the particular sequences
**               of bytes requires to perform read, write, erase etc.
**               operations for the particular SPI Flash chip that it finds.
**
** (C) Copyright 2017 Alpha Data
**
** Supports the following models:
**
**   o ADM-PCIE-9V3
**
** Has been tested with the following chips:
**
**   o MT25QL256
**   o MT25QU256
**   o S25FS256S
*/

#if defined(_WIN32)

/* Windows */
# include <windows.h>
# include <tchar.h>

#else

/* Linux or VxWorks */
# define _T(x) x
# define _tprintf printf
# define FALSE (0)
# define TRUE (1)
# define UNREFERENCED_PARAMETER(x)

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <sdk_common.h>
#include <platform_endian.h>

#include "avr2util.h"
#include "spi_flash.h"
#include "sfdp.h"

#define ARRAY_LENGTH(x) (sizeof(x) / sizeof((x)[0]))

#define VERIFY_BLOCK_SIZE (0x10000)

/*
** Figure out which sector/subsector contains the first byte of the address range
**
**   [ address, address + count - 1 ]
**
** In general there will be multiple block types that could be used, so we choose
** the one that minimizes the number of bytes that have to be saved and restored.
*/
static bool_t
identifyEraseBlock(
  const SPIChipDescription* pChipDescription,
  uint32_t address,
  uint32_t count,
  uint8_t* pBlockType,
  uint32_t* pBlockAddress,
  uint32_t* pBlockSize)
{
  unsigned int i;
  uint32_t limit, blockAddress, blockLimitAddress, blockSize, blockMask, saveBytes;
  uint32_t bestBlockAddress, bestBlockSize, bestSaveBytes;
  uint32_t regionAddress = 0, regionLimitAddress = 0xFFFFFFFFU;
  uint8_t regionEraseTypes = 0xFU;
  int8_t bestBlockType;

  if (address + count < address) {
    return FALSE;
  }
  if (address >= pChipDescription->densityBytes) {
    return FALSE;
  }

  limit = address + count - 1;

  if (NULL != pChipDescription->sectorMap.pRegions) {
    SPIChipSectorMapRegion* pRegion = pChipDescription->sectorMap.pRegions;
    unsigned int i, regionCount = pChipDescription->sectorMap.regionCount;

    /* SPI Flash chip has a sector map; locate the region containing "address". */
    regionAddress = 0;
    for (i = 0; i < regionCount; i++) {
      regionLimitAddress = regionAddress + ((uint32_t)pRegion->sizeBytes - 1);

      if (regionAddress <= address && address <= regionLimitAddress) {
        regionEraseTypes = pRegion->eraseTypes;
        break;
      }
      regionAddress = regionLimitAddress + 1;
      pRegion++;
    }

    if (i == regionCount) {
      /* Did not find a region containing "address". */
      return FALSE;
    }
  } else {
    /* SPI Flash has no sector map; in this case, consider the entire chip to be one region. */
  }


  bestBlockType = -1;
  bestBlockSize = 0xFFFFFFFF;
  bestSaveBytes = 0xFFFFFFFF;
  bestBlockAddress = 0;

  for (i = 0; i < ARRAY_LENGTH(pChipDescription->blockType); i++) {
    bool_t bBlockTypeSupported =
      ((regionEraseTypes & (0x1U << i)) &&       /* A 1 bit indicates that region containing "address" permits this block type */
       pChipDescription->blockType[i].sizeBytes) /* Nonzero => Chip advertises this block type as supported */
       ? TRUE : FALSE;

    if (!bBlockTypeSupported) {
      continue;
    }

    blockSize = pChipDescription->blockType[i].sizeBytes;
    blockMask = blockSize - 1;

    blockAddress = address & ~blockMask;
    blockLimitAddress = address + blockMask;

    /* Some SPI Flash chips (e.g. S25FS256S) have a region in the Sector Map that
    ** is smaller than the sector/subsector size that it supports. While this might
    ** seem to be a bug in the SFDP information, we have to adjust the block
    ** address & limit that we just calculated to account for this. */
    if (blockAddress < regionAddress) {
      blockAddress = regionAddress;
    }
    if (blockLimitAddress > regionLimitAddress) {
      blockLimitAddress = regionLimitAddress;
    }

    /* Now recalculate block size from possibly adjusted block base & limit addresses */
    blockSize = blockLimitAddress - blockAddress + 1;

    /* Figure out how many bytes of data need to be saved and restored */
    saveBytes = address - blockAddress;
    if (limit < blockLimitAddress) {
      saveBytes += blockLimitAddress - limit;
    }

    if (-1 == bestBlockType || saveBytes < bestSaveBytes || (saveBytes == bestSaveBytes && blockSize > bestBlockSize)) {
      bestBlockType = (int8_t)i;
      bestBlockSize = blockSize;
      bestBlockAddress = blockAddress;
      bestSaveBytes = saveBytes;
    }
  }

  assert(bestBlockType >= 0);

  *pBlockType = (uint8_t)bestBlockType;
  *pBlockAddress = bestBlockAddress;
  *pBlockSize = bestBlockSize;

  return TRUE;
}

/* Subcommands for BoardMan2 SPI Flash Interface control command */
#define SPI_IF_CONTROL_RESET    (1) /* Reset all SPI Flash chips */
#define SPI_IF_CONTROL_START_OP (2) /* Informs uC that a length SPI Flash operation is starting */
#define SPI_IF_CONTROL_END_OP   (3) /* Informs uC that a length SPI Flash operation has ended */

/* This returns all SPI Flash chips to 1-bit wide mode and 3-byte address mode,
** Assuming that the chips implement the RESET# pin (not all chips do). */
int
avr2utilSpiFlashHardwareReset(
  const DeviceHandle* pDevice,
  bool_t bVerbose)
{
  const uint32_t timeoutUs = 1000000;
  const uint32_t commandLength = 7;
  const uint32_t responseLength = 7;
  uint8_t command[7];
  uint8_t response[7];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x91; /* SPI interface control command */
  command[2] = SPI_IF_CONTROL_RESET; /* Reset all SPI chips */
  command[3] = 0; /* 4 bytes of parameters not used for this subcommand */
  command[4] = 0;
  command[5] = 0;
  command[6] = 0;

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x11; /* SPI interface control response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    timeoutUs,
    command,
    commandLength,
    expResponse,
    response,
    responseLength,
    &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid SPI control command");
      ret = EXIT_AVR2_BAD_STATUS;
      break;

    case 2:
      pReason = _T("The board appears to be powered off (standby power only). SPI accesses require the board to be powered on.");
      ret = EXIT_NOT_POWERED;
      break;

    case 3:
      pReason = _T("The board has no SPI Flash that is accessible via the microcontroller.");
      ret = EXIT_NO_SPI_FLASH;
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      ret = EXIT_AVR2_BAD_STATUS;
      break;
    }

    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
  }

done:
  return ret;
}


/* This informs the uC that a lengthy SPI Flash operation is
** about to start or has ended. This works around a CCLK contention issue
** on ADM-PCIE-9V3(G) revision 1 board. */
int
avr2utilSpiFlashStartEndOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  bool_t bStartNotStop)
{
  const uint32_t timeoutUs = 1000000;
  const uint32_t commandLength = 7;
  const uint32_t responseLength = 7;
  uint8_t command[7];
  uint8_t response[7];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x91; /* SPI interface control command */
  command[2] = (uint8_t)(bStartNotStop ? SPI_IF_CONTROL_START_OP : SPI_IF_CONTROL_END_OP);
  command[3] = 0; /* 4 bytes of parameters not used for these subcommands */
  command[4] = 0;
  command[5] = 0;
  command[6] = 0;

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x11; /* SPI interface control response */

  memset(response, 0, sizeof(response));
  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    timeoutUs,
    command,
    commandLength,
    expResponse,
    response,
    responseLength,
    &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  avr2Status = response[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid SPI control command");
      ret = EXIT_AVR2_BAD_STATUS;
      break;

    case 2:
      pReason = _T("The board appears to be powered off (standby power only). SPI accesses require the board to be powered on.");
      ret = EXIT_NOT_POWERED;
      break;

    case 3:
      pReason = _T("The board has no SPI Flash that is accessible via the microcontroller.");
      ret = EXIT_NO_SPI_FLASH;
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      ret = EXIT_AVR2_BAD_STATUS;
      break;
    }

    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)response[2], pReason);
  }

done:
  return ret;
}

static int
spiTransaction(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const uint8_t* pCommand,
  uint32_t commandLength,
  const uint8_t* pExpectedResponse,
  uint8_t* pResponseBuffer,
  uint32_t responseBufferLength,
  uint32_t* pActualResponseLength)
{
  const uint32_t timeoutUs = 1000000;
  uint32_t actualResponseLength;
  uint8_t avr2Status;
  int ret = EXIT_OK;

  memset(pResponseBuffer, 0, responseBufferLength);

  ret = avr2utilSendAvr2Command(
    pDevice,
    bVerbose,
    timeoutUs,
    pCommand,
    commandLength,
    pExpectedResponse,
    pResponseBuffer,
    responseBufferLength,
    &actualResponseLength);
  if (EXIT_OK != ret) {
    goto out;
  }

  if (EXIT_OK == ret) {
    *pActualResponseLength = actualResponseLength;
  }

  avr2Status = pResponseBuffer[2];
  if (0 != avr2Status) {
    const TCHAR* pReason;

    switch (avr2Status) {
    case 1:
      pReason = _T("Invalid SPI chip index");
      ret = EXIT_INVALID_SPI_INDEX;
      break;

    case 2:
      pReason = _T("The board appears to be powered off (standby power only). SPI accesses require the board to be powered on.");
      ret = EXIT_NOT_POWERED;
      break;

    default:
      pReason = _T("** UNEXPECTED ERROR CODE **");
      ret = EXIT_AVR2_BAD_STATUS;
      break;
    }

    _tprintf(_T("*** AVR2 returned status 0x%02X => %s\n"), (unsigned int)pResponseBuffer[2], pReason);
  }

out:
  return ret;
}

int
avr2utilSpiFlashReadSFDP(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  uint32_t address,
  uint8_t* pBuffer,
  unsigned int count)
{
  const unsigned int maxChunk = 255;
  const uint32_t commandLength = 10;
  uint8_t command[10];
  uint8_t response[258]; /* Worst-case response length (count is 255) */
  uint8_t expResponse[2];
  uint32_t responseLength, actualResponseLength;
  uint8_t chunk;
  int ret = EXIT_OK;

  while (count) {
    chunk = (uint8_t)((count > maxChunk) ? maxChunk : count);

    responseLength = 3 + chunk;

    command[0] = 0x05; /* User extended command group */
    command[1] = 0x90; /* Raw SPI command */
    command[2] = (uint8_t)chipIndex; /* SPI chip index */
    command[3] = 5; /* Number of bytes to write: SPI command + 3 byte address + dummy byte */
    command[4] = chunk; /* Number of bytes to read */

    /* Following 5 bytes are output to SPI Flash chip */
    command[5] = SPI_COMMAND_READ_SFDP;
    /* Address is output MS byte first */
    command[6] = (uint8_t)(address >> 16);
    command[7] = (uint8_t)(address >> 8);
    command[8] = (uint8_t)(address >> 0);
    command[9] = 0; /* Dummy byte required for read SFDP command */

    expResponse[0] = 0x05; /* User extended command group */
    expResponse[1] = 0x10; /* Raw SPI response */

    ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
    if (EXIT_OK != ret) {
      goto done;
    }

    memcpy(pBuffer, &response[3], chunk);

    pBuffer += chunk;
    address += chunk;
    count -= chunk;
  }

done:
  return ret;
}

static int
executeConfigDetectDesc(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  bool_t b4ByteAddressMode,
  uint32_t dwFirst,
  uint32_t dwSecond, /* Up to 4-byte read address */
  uint8_t* pConfigurationID)
{
  const uint32_t responseLength = 4;
  uint8_t command[5 + 1 + 4 + 16]; /* Large enough for 4-byte address and read latency of 16 */
  uint32_t commandLength = 0, actualResponseLength;
  uint8_t expResponse[2];
  uint8_t response[4];
  uint8_t payloadLength;
  uint8_t mask, addrLengthCode, addressLength = 0, readLatencyCode, opcode;
  unsigned int i, readLatency;
  uint8_t detectionValue, configurationID = *pConfigurationID;
  int ret = EXIT_OK;

  mask = (uint8_t)((dwFirst >> 24) & 0xFFU);
  addrLengthCode = (uint8_t)((dwFirst >> 22) & 0x3U);
  readLatencyCode = (uint8_t)((dwFirst >> 16) & 0xFU);
  opcode = (uint8_t)((dwFirst >> 8) & 0xFFU);

  /* Read latency code of 15 means variable, i.e. whatever the read latency setting is for the chip.
  ** But getting the read latency in a generic way is impossible, so we assume worst-case 16 cycles
  ** and also assume that the read command repeats the data indefinitely provided that more dummy
  ** cycles are provided. */
  readLatency = (readLatencyCode == 0xFU) ? 16U : readLatencyCode;

  switch (addrLengthCode) {
  case 0:
    /* No address in command */
    addressLength = 0;
    break;

  case 1:
    /* 3-byte address in command */
    addressLength = 3;
    break;

  case 2:
    /* 4-byte address in command */
    addressLength = 4;
    break;

  case 3:
    /* Address length depends on whether or not in 4-byte address mode */
    addressLength = (uint8_t)(b4ByteAddressMode ? 4 : 3);
    break;

  default:
    assert(FALSE);
    break;
  }

  command[commandLength++] = 0x05; /* User extended command group */
  command[commandLength++] = 0x90; /* Raw SPI command */
  command[commandLength++] = (uint8_t)chipIndex; /* SPI chip index */
  payloadLength = (uint8_t)(1 + addressLength + readLatency);  /* Number of bytes to write: SPI command + address + dummy bytes */
  command[commandLength++] = payloadLength;
  command[commandLength++] = 1; /* Number of bytes to read */

  /* SPI write payload */
  command[commandLength++] = opcode;
  if (addressLength >= 4) {
    command[commandLength++] = (uint8_t)((dwSecond >> 24) & 0xFFU);
  }
  if (addressLength >= 3) {
    command[commandLength++] = (uint8_t)((dwSecond >> 16) & 0xFFU);
    command[commandLength++] = (uint8_t)((dwSecond >> 8) & 0xFFU);
    command[commandLength++] = (uint8_t)((dwSecond >> 0) & 0xFFU);
  }
  for (i = 0; i < readLatency; i++) {
    command[commandLength++] = 0;
  }

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  detectionValue = (uint8_t)(response[3] & mask);
#if 0
  _tprintf(_T("detectionValue=0x%X\n"), detectionValue);
#endif
  if (detectionValue) {
    configurationID = (uint8_t)((configurationID << 1) | 0x1U);
  } else {
    configurationID = (uint8_t)(configurationID << 1);
  }
 
  *pConfigurationID = configurationID;

done:
  return ret;
}

int
avr2utilSpiFlashGetDescription(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  SPIChipDescription* pChipDescription,
  bool_t bAllocateMergeBuffer)
{
  SPIChipDescription chipDescription = { 0 };
  SFDPHeader header = { 0 };
  SFDPTableHeader tableHeader = { 0 }, sectorMapHeader = { 0 };
  SFDPTable table = { 0 };
  uint32_t signature, pointer24;
  uint32_t largestBlock = 0, smallestBlock = 0xFFFFFFFF;
  uint64_t densityBytes;
  uint16_t exit4ByteAddress;
  uint8_t enter4ByteAddress, softReset;
  uint8_t pageSizeLog2;
  unsigned int tableLength, expectedTableLength;
  unsigned int i, preferredTableIndex, tableIndex;
  bool_t bHasSectorMap = FALSE; /* Assume no sector map; will correct later if necessary. */
  uint32_t* pSectorMapRaw = NULL;
  uint16_t highestRevision;
  int ret = EXIT_OK;

  assert(sizeof(SFDPHeader) == 8); /* As per JEDEC JESD216B */
  assert(sizeof(SFDPTableHeader) == 8); /* As per JEDEC JESD216B */
  assert(sizeof(SFDPTable) == 64); /* As per JEDEC JESD216B */

  ret = avr2utilSpiFlashReadSFDP(pDevice, bVerbose, chipIndex, 0, (uint8_t*)&header, sizeof(SFDPHeader));
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to read SPI Flash SFDP Header.\n"));
    goto done;
  }

  signature = le32_to_cpu(header.signature);
  if (signature != SPI_SFDP_HEADER_SIGNATURE) {
    _tprintf(_T("*** Signature 0x%08X in SPI Flash SFDP Header is not expected value 0x%08X.\n"), signature, SPI_SFDP_HEADER_SIGNATURE);
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  if (header.major > 1) {
    expectedTableLength = 16 * 4; /* JESD216B */
  } else if (header.major == 1) {
    if (header.minor >= 6) {
      expectedTableLength = 16 * 4; /* JESD216B */
    } else {
      expectedTableLength = 9 * 4; /* JESD216 */
    }
  } else {
    _tprintf(_T("*** SPI Flash SFDP Header version %u.%u indicates that this SPI Flash chip predates JESD216.\n"),
      (unsigned int)header.major, (unsigned int)header.minor);
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  if (0 == header.nParameterHeaders) {
    _tprintf(_T("*** SPI Flash SFDP Header indicates no parameter tables.\n"));
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  /* Iterate over the parameter table headers, because some SPI Flash chips have more than one. */
  /* We're looking for the longest standard parameter table header (i.e. ID field is 0xFF00). */
  preferredTableIndex = (unsigned int)-1;
  highestRevision = 0;
  for (tableIndex = 0; tableIndex < header.nParameterHeaders; tableIndex++) {
    SFDPTableHeader tmpTableHeader;
    uint32_t pointer24IDMSB;
    uint16_t revision;
    uint8_t idMSB;

    ret = avr2utilSpiFlashReadSFDP(
      pDevice,
      bVerbose,
      chipIndex,
      (uint32_t)(sizeof(SFDPHeader) + tableIndex * sizeof(SFDPTableHeader)),
      (uint8_t*)&tmpTableHeader,
      (unsigned int)sizeof(SFDPTableHeader));
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to read SPI Flash SFDP Table Header %u.\n"), tableIndex);
      goto done;
    }

    revision = (uint16_t)(((uint16_t)tmpTableHeader.major << 8) | (uint16_t)tmpTableHeader.minor);
    pointer24IDMSB = le32_to_cpu(tmpTableHeader.pointer24IDMSB);
    idMSB = (uint8_t)((pointer24IDMSB >> 24) & 0xFFU);
    if (0 == tmpTableHeader.idLSB && 0xFF == idMSB) {
      /* Standard SFDP Parameter Table Header */
      if (revision > highestRevision) {
        highestRevision = revision;
        preferredTableIndex = tableIndex;
        tableHeader = tmpTableHeader;
      }
    }

    if (0x81 == tmpTableHeader.idLSB && 0xFF == idMSB) {
      /* SFDP Sector Map Table Header */
      sectorMapHeader = tmpTableHeader;
      bHasSectorMap = TRUE;
    }
  }

  if ((unsigned int)-1 == preferredTableIndex) {
    _tprintf(_T("+++ Failed to find a standard SFDP Table Header in SPI Flash chip.\n"));
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  /*
  ** Process the SFDP Standard Parameter Table.
  */

  pointer24 = le32_to_cpu(tableHeader.pointer24IDMSB) & 0xFFFFFF;
  tableLength = 4 * tableHeader.nLengthDwords;
  if (bVerbose && tableLength != expectedTableLength) {
    _tprintf(_T("+++ SPI Flash SFDP Table %u length (%u B) is inconsistent with expected length (%u B) implied by SFDP version %u.%u.\n"),
      tableIndex, tableLength, expectedTableLength, (unsigned int)header.major, (unsigned int)header.minor);
  }
  if (tableLength > sizeof(table)) {
    _tprintf(_T("+++ SPI Flash SFDP Table %u length (%u B) is more than maximum expected (%u B); extra data will be ignored.\n"),
      tableIndex, tableLength, (unsigned int)sizeof(table));
    tableLength = sizeof(table);
  }

  ret = avr2utilSpiFlashReadSFDP(pDevice, bVerbose, chipIndex, pointer24, (uint8_t*)&table, tableLength);
  if (EXIT_OK != ret) {
    _tprintf(_T("*** Failed to read SPI Flash SFDP Table %u.\n"), tableIndex);
    goto done;
  }

  if (table.density & 0x80000000) {
    uint32_t power = table.density & 0x7FFFFFFF;
    if (power > 63) {
      _tprintf(_T("*** SPI Flash SFDP Table %u indicates capacity of more than 2^63 bits.\n"), tableIndex);
      ret = EXIT_BAD_SPI_SFDP;
      goto done;
    }
    densityBytes = ((uint64_t)0x1 << power) / 8;
  } else {
    densityBytes = ((table.density & 0x7FFFFFFF) + 1) / 8;
  }
  if (densityBytes > 0x80000000) {
    _tprintf(_T("+++ SPI Flash SFDP Table %u indicates capacity of more than 2 GiB. This program can access only the lowest 2 GiB.\n"),
      tableIndex);
    densityBytes = 0x80000000U;
  }
  chipDescription.densityBytes = (uint32_t)densityBytes; /* Cast safe due to above range check */

  /* Get supported sector/subsector sizes */
  for (i = 0; i < ARRAY_LENGTH(chipDescription.blockType); i++) {
    uint8_t power = table.sectorSize[i].power;
    uint8_t opcode = table.sectorSize[i].eraseOpcode;
    uint32_t sectorSize;

    if (0 == power) {
      continue;
    }
    if (power > 31) {
      _tprintf(_T("+++ Ignoring SPI Flash SFDP sector size of 2^%u.\n"), (unsigned int)power);
      continue;
    }

    sectorSize = (uint32_t)0x1 << power;
    chipDescription.blockType[i].sizeBytes = sectorSize;
    chipDescription.blockType[i].eraseCommand = opcode;

    if (sectorSize < smallestBlock) {
      smallestBlock = sectorSize;
      chipDescription.smallestBlockType = (uint8_t)i;
    }
    if (sectorSize > largestBlock) {
      largestBlock = sectorSize;
    }
  }

  /* If no supported sector/subsector sizes, check for legacy flag that indicates 4 kiB sectors */
  if (0 == largestBlock) {
    if ((table.eraseAndWriteCaps & 0x3U) == 0x1U) {
      chipDescription.blockType[0].sizeBytes = 0x1000;
      chipDescription.blockType[0].eraseCommand = table.eraseOpcode;
      chipDescription.smallestBlockType = 0;
      smallestBlock = largestBlock = chipDescription.blockType[0].sizeBytes;
    }
  }

  if (0 == largestBlock) {
    _tprintf(_T("*** SPI Flash SFDP Table %u does not advertise any valid sector/subsector sizes.\n"), tableIndex);
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  if (largestBlock > chipDescription.densityBytes) {
    _tprintf(_T("*** SPI Flash SFDP Table %u largest block size (0x%X B) is inconsistent with capacity (0x%X B).\n"),
      tableIndex, largestBlock, chipDescription.densityBytes);
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  chipDescription.state.bIn4ByteAddressMode = FALSE; /* Assume FALSE initially, may correct later */

  /*
  ** Here we determine which methods of entering and exiting 4-byte address mode are
  ** supported by the SPI Flash chip and choose one.
  ** We don't support any method that involves changing nonvolatile registers.
  */
  enter4ByteAddress = (uint8_t)((table.miscCaps >> 24) & 0xFF);
  /* Assume write enable not required befor exit 4-byte address mode; will correct later if necessary */
  if (enter4ByteAddress & 0x40) { /* Most-preferred option */
    chipDescription.fourByteAddressEnter.type = SPI_CHIP_4BYTE_ADDR_ALWAYS;
    chipDescription.fourByteAddressExit.type = SPI_CHIP_4BYTE_ADDR_ALWAYS;
    chipDescription.state.bIn4ByteAddressMode = TRUE;
  } else if (enter4ByteAddress & 0x1) {
    chipDescription.fourByteAddressEnter.type = SPI_CHIP_4BYTE_ADDR_VIA_CMD;
    chipDescription.fourByteAddressEnter.variant.viaCmd.command = 0xB7;
  } else if (enter4ByteAddress & 0x2) {
    chipDescription.fourByteAddressEnter.type = SPI_CHIP_4BYTE_ADDR_VIA_CMD;
    chipDescription.fourByteAddressEnter.variant.viaCmd.command = 0xB7;
    chipDescription.fourByteAddressEnter.variant.viaCmd.bNeedWriteEnable = TRUE;
  } else if (enter4ByteAddress & 0x8) {
    chipDescription.fourByteAddressEnter.type = SPI_CHIP_4BYTE_ADDR_VIA_BAR;
    chipDescription.fourByteAddressEnter.variant.viaBAR.readCommand = 0x16;
    chipDescription.fourByteAddressEnter.variant.viaBAR.writeCommand = 0x17;
    chipDescription.fourByteAddressEnter.variant.viaBAR.value = 0x80;
    chipDescription.fourByteAddressEnter.variant.viaBAR.mask = 0x80;
  } else if (enter4ByteAddress & 0x4) { /* Least-preferred option */
    chipDescription.fourByteAddressEnter.type = SPI_CHIP_4BYTE_ADDR_VIA_EAR;
    chipDescription.fourByteAddressExit.type = SPI_CHIP_4BYTE_ADDR_VIA_EAR;
  } else {
    /* Chip doesn't use any of the methods that we support */
    _tprintf(_T("*** SPI Flash chip does advertise any of the methods for entering 4-byte address mode that this program supports.\n"));
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  if (chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_ALWAYS &&
      chipDescription.fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_VIA_EAR)
  {
    /* Assume write enable not required befor exit 4-byte address mode; will correct later if necessary */
    exit4ByteAddress = (uint16_t)((table.miscCaps >> 14) & 0x3FF);
    if (exit4ByteAddress & 0x1) { /* Most-preferred option */
      chipDescription.fourByteAddressExit.type = SPI_CHIP_4BYTE_ADDR_VIA_CMD;
      chipDescription.fourByteAddressExit.variant.viaCmd.command = 0xE9;
    } else if (exit4ByteAddress & 0x2) {
      chipDescription.fourByteAddressExit.type = SPI_CHIP_4BYTE_ADDR_VIA_CMD;
      chipDescription.fourByteAddressExit.variant.viaCmd.command = 0xE9;
      chipDescription.fourByteAddressExit.variant.viaCmd.bNeedWriteEnable = TRUE;
    } else if (exit4ByteAddress & 0x8) { /* Least-preferred option */
      chipDescription.fourByteAddressExit.type = SPI_CHIP_4BYTE_ADDR_VIA_BAR;
      chipDescription.fourByteAddressExit.variant.viaBAR.readCommand = 0x16;
      chipDescription.fourByteAddressExit.variant.viaBAR.writeCommand = 0x17;
      chipDescription.fourByteAddressExit.variant.viaBAR.value = 0x80;
      chipDescription.fourByteAddressExit.variant.viaBAR.mask = 0x80;
    } else {
      /*
      ** Currently this program doesn't ever try to exit 4-byte address mode, except by
      ** asserting hardware reset to all SPI Flash chips. So if we can't find a way of
      ** exiting 4-byte address mode (other than hardware reset), we don't worry about it
      */
#if 0
      /* Chip doesn't use any of the methods that we support */
      _tprintf(_T("*** SPI Flash chip does not advertise any of the methods for exiting 4-byte address mode that this program supports.\n"));
      ret = EXIT_BAD_SPI_SFDP;
      goto done;
#endif
    }

    /* We require that the SPI Flash chip exits 4-byte address mode on hardware reset OR software reset. */
    if (!(exit4ByteAddress & 0x20) && !(exit4ByteAddress & 0x40)) {
      /* Chip doesn't exit 4-byte address mode on hardware or software reset */
      _tprintf(_T("*** SPI Flash chip does not exit 4-byte address mode on hardware or software reset.\n"));
      ret = EXIT_BAD_SPI_SFDP;
      goto done;
    }
  }

  softReset = (uint8_t)((table.miscCaps >> 8) & 0x3F);
  if (softReset & 0x10U) {
    chipDescription.softResetType = SPI_CHIP_SOFTRESET_66_99;
  } else if (softReset & 0x8U) {
    chipDescription.softResetType = SPI_CHIP_SOFTRESET_LEGACY_F0;
  } else if (softReset & 0x1U) {
    chipDescription.softResetType = SPI_CHIP_SOFTRESET_1_FOR_8_CLK;
  } else if (softReset & 0x2U) {
    chipDescription.softResetType = SPI_CHIP_SOFTRESET_1_FOR_10_CLK;
  } else if (softReset & 0x4U) {
    chipDescription.softResetType = SPI_CHIP_SOFTRESET_1_FOR_16_CLK;
  } else {
    /* Chip doesn't use any of the software reset methods that we support */
    _tprintf(_T("*** SPI Flash chip does advertise any of the methods for performing software reset that this program supports.\n"));
    ret = EXIT_BAD_SPI_SFDP;
    goto done;
  }

  /* The write enable & disable commands are the same for all SPI Flash chips (right?) */
  chipDescription.writeEnable.enableCommand = 0x06U;
  chipDescription.writeEnable.disableCommand = 0x04U;

  /* The read status register command is the same for all SPI Flash chips (right?) */
  chipDescription.readStatusCommand = 0x05U;

  /* The basic 1-1-1 read command is the same for all SPI Flash chips (right?) */
  chipDescription.readCommand = 0x03U;

  /* The basic 1-1-1 (page) program command is the same for all SPI Flash chips (right?) */
  chipDescription.pageProgram.command = 0x02U;
  pageSizeLog2 = (uint8_t)((table.programTimes >> 4) & 0xFU);
  chipDescription.pageProgram.pageSizeBytes = (uint32_t)0x1U << pageSizeLog2;
  if (0 == pageSizeLog2) {
    _tprintf(_T("+++ SPI Flash SFDP advertises a program page size of 1 byte; programming and/or erasing will be extremely slow.\n"));
  }

  /* Initially, current page is unknown, so set an invalid value for current page. */
  /* This will force the driver to establish it on the first read, program or erase command. */
  chipDescription.state.currentPage = 0xFFFFU;

  /*
  ** Allocate the merge buffer. This is used when a sector or subsector must be
  ** only partially erased.
  */

  if (bAllocateMergeBuffer) {
    size_t mergeBufferSize = largestBlock;

    if (mergeBufferSize < VERIFY_BLOCK_SIZE) {
      mergeBufferSize = VERIFY_BLOCK_SIZE;
    }
    chipDescription.pMergeBuffer = (uint8_t*)malloc(mergeBufferSize);
    if (NULL == chipDescription.pMergeBuffer) {
      _tprintf(_T("*** Failed to allocate SPI Flash merge buffer of 0x%llX bytes.\n"),
        (unsigned long long)mergeBufferSize);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }
  }

  /* Issue a software reset before doing anything else. */
  ret = avr2utilSpiFlashSoftwareReset(pDevice, bVerbose, chipIndex, &chipDescription);
  if (EXIT_OK != ret) {
    return ret;
  }

  /*
  ** Process the sector map, if there is one.
  */

  if (bHasSectorMap) {
    unsigned int lengthBytes = 4 * (unsigned int)sectorMapHeader.nLengthDwords;
    uint8_t currentConfigurationID = 0;
    uint32_t nMatchedRegion = 0;
    size_t sectorMapSize;

    pSectorMapRaw = (uint32_t*)malloc(lengthBytes);
    if (NULL == pSectorMapRaw) {
      _tprintf(_T("*** Failed to allocate buffer to read SFDP Sector Map of 0x%X bytes.\n"), lengthBytes);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }

    pointer24 = le32_to_cpu(sectorMapHeader.pointer24IDMSB) & 0xFFFFFF;
    ret = avr2utilSpiFlashReadSFDP(pDevice, bVerbose, chipIndex, pointer24, (uint8_t*)pSectorMapRaw, lengthBytes);
    if (EXIT_OK != ret) {
      _tprintf(_T("*** Failed to read SFDP Sector Map.\n"));
      goto done;
    }

    /* First pass through the Sector Map looks for Configuration Detection Descriptors, and
    ** executes their implied commands, to produce a value that identifies the current
    ** configuration. */

    for (i = 0; i < sectorMapHeader.nLengthDwords;) {
      uint32_t dwFirst, dwSecond;
      unsigned int nRegion;

      dwFirst = pSectorMapRaw[i++];
      if ((dwFirst & 0x2) == 0x2) {
        /* Shouldn't see any Configuration Map Descriptors before Configuration Detection
        ** Descriptors, but skip them if we do. */
        nRegion = (unsigned int)((dwFirst >> 16) & 0xFFU) + 1;
        i += nRegion;
        continue;
      }

      /* 2nd DWORD of descriptor is address for read command */
      if (i >= sectorMapHeader.nLengthDwords) {
        /* Fell off end of table (implies that SFDP in chip is faulty). */
        break;
      }
      dwSecond = pSectorMapRaw[i++];

      /* Configuration Detection Descriptor */
      ret = executeConfigDetectDesc(
        pDevice,
        bVerbose,
        chipIndex,
        chipDescription.state.bIn4ByteAddressMode,
        dwFirst,
        dwSecond,
        &currentConfigurationID);
      if (EXIT_OK != ret) {
        goto done;
      }

      if (dwFirst & 0x1) {
        /* This is the last Configuration Detection Descriptor */
        break;
      }
    }
    chipDescription.sectorMap.currentConfigurationID = currentConfigurationID;
#if 0
    _tprintf(_T("currentConfigurationID=0x%X\n"), currentConfigurationID);
#endif

    /* Second pass through the Sector Map counts Configuration Map Descriptors whose
    ** configuration ID matches the current configuration. When found, we copy these descriptors 
    ** into the Chip Description. */
    for (i = 0; i < sectorMapHeader.nLengthDwords;) {
      uint32_t dwFirst;
      uint8_t configurationID;
      unsigned int nRegion;

      dwFirst = pSectorMapRaw[i++];
      if ((dwFirst & 0x2) == 0x0) {
        /* Skip any Configuration Detection Descriptors */
        i++;
        continue;
      }

      nRegion = (unsigned int)((dwFirst >> 16) & 0xFFU) + 1;
      configurationID = (uint8_t)((dwFirst >> 8) & 0xFFU);
      if (configurationID == currentConfigurationID) {
        nMatchedRegion += nRegion;
      }

      i += nRegion;

      if (dwFirst & 0x1) {
        /* This is the last Configuration Map Descriptor */
        break;
      }
    }
#if 0
    _tprintf(_T("nMatchedRegion=%u\n"), nMatchedRegion);
#endif

    if (0 == nMatchedRegion) {
      _tprintf(_T("*** Cannot find any Configuration Map Descriptors for current configuration of SPI chip %u.\n"), chipIndex);
      ret = EXIT_BAD_SPI_SFDP;
      goto done;
    }

    sectorMapSize = nMatchedRegion * sizeof(SPIChipSectorMapRegion);
    chipDescription.sectorMap.pRegions = (SPIChipSectorMapRegion*)malloc(sectorMapSize);
    if (NULL == chipDescription.sectorMap.pRegions) {
      _tprintf(_T("*** Failed to allocate sector map array of 0x%llX bytes.\n"), (unsigned long long)sectorMapSize);
      ret = EXIT_ALLOCATION_FAILED;
      goto done;
    }
    chipDescription.sectorMap.regionCount = nMatchedRegion;

    /* Third pass through the Sector Map copies Configuration Map Descriptors whose
    ** configuration ID matches the current configuration into the Chip Description. */
    for (i = 0; i < sectorMapHeader.nLengthDwords;) {
      uint32_t dwFirst, dwRegion;
      uint8_t configurationID, eraseTypes;
      unsigned int nRegion, j, k = 0;
      uint64_t regionSize;

      dwFirst = pSectorMapRaw[i++];
      if ((dwFirst & 0x2) == 0x0) {
        /* Skip any Configuration Detection Descriptors */
        i++;
        continue;
      }

      nRegion = (unsigned int)((dwFirst >> 16) & 0xFFU) + 1;
      configurationID = (uint8_t)((dwFirst >> 8) & 0xFFU);
      if (configurationID == currentConfigurationID) {
        for (j = 0; j < nRegion && i < sectorMapHeader.nLengthDwords; j++) {
          dwRegion = pSectorMapRaw[i++];
          regionSize = (uint64_t)256 * (((dwRegion >> 8) & 0xFFFFFFU) + 1);
          eraseTypes = (uint8_t)((dwRegion >> 00) & 0xFFU);
          chipDescription.sectorMap.pRegions[k].sizeBytes = regionSize;
          chipDescription.sectorMap.pRegions[k].eraseTypes = eraseTypes;
          k++;
        }
      } else {
        i += nRegion;
      }

      if (dwFirst & 0x1) {
        /* This is the last Configuration Map Descriptor */
        break;
      }
    }
  }

done:
  if (NULL != pSectorMapRaw) {
    free(pSectorMapRaw);
  }

  if (EXIT_OK != ret) {
    if (NULL != pChipDescription->sectorMap.pRegions) {
      free(pChipDescription->sectorMap.pRegions);
      pChipDescription->sectorMap.pRegions = NULL;
    }

    if (NULL != chipDescription.pMergeBuffer) {
      free(chipDescription.pMergeBuffer);
      chipDescription.pMergeBuffer = NULL;
    }
  } else {
#if 0
    avr2utilSpiFlashDumpDescription(&chipDescription);
#endif
    *pChipDescription = chipDescription;
  }

  return ret;
}

void
avr2utilSpiFlashPutDescription(
  SPIChipDescription* pChipDescription)
{
  if (NULL != pChipDescription->sectorMap.pRegions) {
    free(pChipDescription->sectorMap.pRegions);
    pChipDescription->sectorMap.pRegions = NULL;
  }

  if (NULL != pChipDescription->pMergeBuffer) {
    free(pChipDescription->pMergeBuffer);
    pChipDescription->pMergeBuffer = NULL;
  }
}

void
avr2utilSpiFlashDumpDescription(
  const SPIChipDescription* pChipDescription)
{
  unsigned int i;

  _tprintf(_T("densityBytes=0x%X\n"), pChipDescription->densityBytes);

  switch (pChipDescription->fourByteAddressEnter.type) {
  case SPI_CHIP_4BYTE_ADDR_ALWAYS:
    _tprintf(_T("fourByteAddressEnter.type = always 4-byte addressing\n"));
    break;

  case SPI_CHIP_4BYTE_ADDR_VIA_CMD:
    _tprintf(_T("fourByteAddressEnter.type = via a command\n"));
    _tprintf(_T("fourByteAddressEnter.variant.viaCmd = { .bNeedWriteEnable=%s, .command=0x%02X }\n"),
      pChipDescription->fourByteAddressEnter.variant.viaCmd.bNeedWriteEnable ? _T("TRUE") : _T("FALSE"),
      pChipDescription->fourByteAddressEnter.variant.viaCmd.command);
    break;

  case SPI_CHIP_4BYTE_ADDR_VIA_BAR:
    _tprintf(_T("fourByteAddressEnter.type = via writing to BAR\n"));
    _tprintf(_T("fourByteAddressEnter.variant.viaBAR = { .readCommand=0x%02X, .writeCommand=0x%02X .value=0x%02X .mask=0x%02X }\n"),
      pChipDescription->fourByteAddressEnter.variant.viaBAR.readCommand,
      pChipDescription->fourByteAddressEnter.variant.viaBAR.writeCommand,
      pChipDescription->fourByteAddressEnter.variant.viaBAR.value,
      pChipDescription->fourByteAddressEnter.variant.viaBAR.mask);
    break;

  case SPI_CHIP_4BYTE_ADDR_VIA_EAR:
    _tprintf(_T("fourByteAddressEnter.type = extended address register provided\n"));
    break;

  default:
    assert(FALSE);
    break;
  }

  switch (pChipDescription->fourByteAddressExit.type) {
  case SPI_CHIP_4BYTE_ADDR_ALWAYS:
    _tprintf(_T("fourByteAddressExit.type = always 4-byte addressing\n"));
    break;

  case SPI_CHIP_4BYTE_ADDR_VIA_CMD:
    _tprintf(_T("fourByteAddressExit.type = via a command\n"));
    _tprintf(_T("fourByteAddressExit.variant.viaCmd = { .bNeedWriteEnable=%s, .command=0x%02X }\n"),
      pChipDescription->fourByteAddressExit.variant.viaCmd.bNeedWriteEnable ? _T("TRUE") : _T("FALSE"),
      pChipDescription->fourByteAddressExit.variant.viaCmd.command);
    break;

  case SPI_CHIP_4BYTE_ADDR_VIA_BAR:
    _tprintf(_T("fourByteAddressExit.type = via writing to BAR\n"));
    _tprintf(_T("fourByteAddressExit.variant.viaCmd = { .readCommand=0x%02X, .writeCommand=0x%02X .value=0x%02X .mask=0x%02X }\n"),
      pChipDescription->fourByteAddressExit.variant.viaBAR.readCommand,
      pChipDescription->fourByteAddressExit.variant.viaBAR.writeCommand,
      pChipDescription->fourByteAddressExit.variant.viaBAR.value,
      pChipDescription->fourByteAddressExit.variant.viaBAR.mask);
    break;

  case SPI_CHIP_4BYTE_ADDR_VIA_EAR:
    _tprintf(_T("fourByteAddressExit.type = extended address register provided\n"));
    break;

  default:
    assert(FALSE);
    break;
  }

  switch (pChipDescription->softResetType) {
  case SPI_CHIP_SOFTRESET_NONE:
    _tprintf(_T("softResetType = none provided\n"));
    break;

  case SPI_CHIP_SOFTRESET_1_FOR_8_CLK:
    _tprintf(_T("softResetType = drive 1111 on DQ for 8 clocks\n"));
    break;

  case SPI_CHIP_SOFTRESET_1_FOR_10_CLK:
    _tprintf(_T("softResetType = drive 1111 on DQ for 10 clocks if in 4-byte mode\n"));
    break;

  case SPI_CHIP_SOFTRESET_1_FOR_16_CLK:
    _tprintf(_T("softResetType = drive 1111 on DQ for 16 clocks\n"));
    break;

  case SPI_CHIP_SOFTRESET_LEGACY_F0:
    _tprintf(_T("softResetType = issue legacy reset opcode (0xF0)\n"));
    break;

  case SPI_CHIP_SOFTRESET_66_99:
    _tprintf(_T("softResetType = issue reset-enable opcode (0x66) followed by reset opcode (0x99)\n"));
    break;

  default:
    assert(FALSE);
    break;
  }

  _tprintf(_T("readStatusCommand=0x%02X\n"), pChipDescription->readStatusCommand);

  _tprintf(_T("readCommand=0x%02X\n"), pChipDescription->readCommand);

  _tprintf(_T("writeEnable { .enableCommand, .disableCommand } = { 0x%02X, 0x%02X}\n"),
    pChipDescription->writeEnable.enableCommand,
    pChipDescription->writeEnable.disableCommand);

  _tprintf(_T("pageProgram { .command, .pageSizeBytes } = { 0x%02X, 0x%X}\n"),
    pChipDescription->pageProgram.command,
    pChipDescription->pageProgram.pageSizeBytes);

  for (i = 0; i < ARRAY_LENGTH(pChipDescription->blockType); i++) {
    _tprintf(_T("blockType[%u] { .sizeBytes, .eraseCommand } = { 0x%X, 0x%02X }\n"),
      i,
      pChipDescription->blockType[i].sizeBytes,
      pChipDescription->blockType[i].eraseCommand);
  }

  _tprintf(_T("smallestBlockType=%u\n"), (unsigned int)pChipDescription->smallestBlockType);

  _tprintf(_T("state { .bIn4ByteAddressMode, .currentPage }  = { %s, 0x%02X }\n"),
    pChipDescription->state.bIn4ByteAddressMode ? _T("TRUE") : _T("FALSE"),
    pChipDescription->state.currentPage);

  _tprintf(_T("sectorMap.regionCount = %u\n"), pChipDescription->sectorMap.regionCount);
  _tprintf(_T("sectorMap.currentConfigurationID = %u\n"), (unsigned int)pChipDescription->sectorMap.currentConfigurationID);
  _tprintf(_T("sectorMap.pRegions = %p {\n"), pChipDescription->sectorMap.pRegions);
  for (i = 0; i < pChipDescription->sectorMap.regionCount; i++) {
    uint8_t eraseTypes = pChipDescription->sectorMap.pRegions[i].eraseTypes;

    _tprintf(_T(" .size = 0x%llX, eraseTypes = {%s%s%s%s }\n"),
      (unsigned long long)pChipDescription->sectorMap.pRegions[i].sizeBytes,
      (eraseTypes & 0x1) ? _T(" 1") : _T(""),
      (eraseTypes & 0x2) ? _T(" 2") : _T(""),
      (eraseTypes & 0x4) ? _T(" 4") : _T(""),
      (eraseTypes & 0x8) ? _T(" 8") : _T(""));
  }
  _tprintf(_T("}\n"));

  _tprintf(_T("pMergeBuffer = %p\n"), pChipDescription->pMergeBuffer);
}

static int
spiFlashSoftResetDriving1111(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex)
{
  const uint32_t responseLength = 3;
  const uint32_t commandLength = 21;
  uint8_t command[5 + 16]; /* Large enough 16 bytes of 1s */
  uint32_t actualResponseLength;
  uint8_t expResponse[2];
  uint8_t response[3];

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex; /* SPI chip index */
  command[3] = 16; /* Number of bytes to write: 16 bytes of all 1s */
  command[4] = 0; /* Nothing to read */

  /* SPI write payload */
  memset(&command[5], 0, 16);

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  return spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
}

static int
spiFlashSoftResetLegacyF0(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex)
{
  const uint32_t responseLength = 3;
  const uint32_t commandLength = 6;
  uint8_t command[5 + 1];
  uint32_t actualResponseLength;
  uint8_t expResponse[2];
  uint8_t response[3];

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex; /* SPI chip index */
  command[3] = 1; /* Number of bytes to write: Legacy reset command */
  command[4] = 0; /* Nothing to read */

  /* SPI write payload */
  command[5] = 0xF0;

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  return spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
}

static int
spiFlashSoftReset6699(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex)
{
  const uint32_t responseLength = 3;
  const uint32_t commandLength = 6;
  uint8_t command[5 + 1];
  uint32_t actualResponseLength;
  uint8_t expResponse[2];
  uint8_t response[3];
  int ret = EXIT_OK;

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex; /* SPI chip index */
  command[3] = 1; /* Number of bytes to write: Reset enable command / Reset command */
  command[4] = 0; /* Nothing to read */

  /* SPI write payload */
  command[5] = 0x66; /* Reset enable command */

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  /* SPI write payload */
  command[5] = 0x99; /* Reset command */

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

done:
  return ret;
}

extern int
avr2utilSpiFlashSoftwareReset(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  unsigned int chipIndex,
  SPIChipDescription* pChipDescription)
{
  int ret = EXIT_OK;

  switch (pChipDescription->softResetType) {
  case SPI_CHIP_SOFTRESET_NONE:
    /* If no software reset provided, nobody should call us */
    assert(FALSE);
    ret = EXIT_BAD_SPI_SFDP;
    break;

  case SPI_CHIP_SOFTRESET_1_FOR_8_CLK:
  case SPI_CHIP_SOFTRESET_1_FOR_10_CLK:
  case SPI_CHIP_SOFTRESET_1_FOR_16_CLK:
    return spiFlashSoftResetDriving1111(pDevice, bVerbose, chipIndex);

  case SPI_CHIP_SOFTRESET_LEGACY_F0:
    return spiFlashSoftResetLegacyF0(pDevice, bVerbose, chipIndex);

  case SPI_CHIP_SOFTRESET_66_99:
    return spiFlashSoftReset6699(pDevice, bVerbose, chipIndex);

  default:
    /* We should never get here */
    assert(FALSE);
    ret = EXIT_BAD_SPI_SFDP;
    break;
  }

  if (EXIT_OK == ret) {
    if (pChipDescription->fourByteAddressEnter.type != SPI_CHIP_4BYTE_ADDR_ALWAYS) {
      pChipDescription->state.bIn4ByteAddressMode = FALSE;
    }
  }

  return ret;
}

/* Enter or exit 4-byte address mode by sending corresponding single-byte SPI Flash command */
static int
avr2utilSpiFlash4ByteModeViaCmd(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  bool_t bEnterNotExit)
{
  const uint32_t responseLength = 3;
  const uint32_t commandLength = 6;
  uint8_t command[6];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  if (bEnterNotExit) {
    assert(pChipDescription->fourByteAddressEnter.type == SPI_CHIP_4BYTE_ADDR_VIA_CMD);
  } else {
    assert(pChipDescription->fourByteAddressExit.type == SPI_CHIP_4BYTE_ADDR_VIA_CMD);
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex;
  command[3] = 1; /* Number of bytes to write: SPI command for Enter/exit 4-byte address mode */
  command[4] = 0; /* Number of bytes to read */

  /* SPI write payload */
  command[5] = (uint8_t)(bEnterNotExit ?
    pChipDescription->fourByteAddressEnter.variant.viaCmd.command : /* SPI command for enter 4-byte addressing mode */
    pChipDescription->fourByteAddressExit.variant.viaCmd.command);  /* SPI command for exit 4-byte addressing mode */

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  return spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
}

/* Enter or exit 4-byte address mode by performing a read-modify-write of Bank Address Register (BAR) in SPI Flash chip */
static int
avr2utilSpiFlash4ByteModeBAR(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  bool_t bEnterNotExit)
{
  uint32_t commandLength, responseLength;
  uint8_t command[7];
  uint8_t response[4];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;
  uint8_t readBARCommand, writeBARCommand, mask, value, newValue;
  int ret = EXIT_OK;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  if (bEnterNotExit) {
    assert(pChipDescription->fourByteAddressEnter.type == SPI_CHIP_4BYTE_ADDR_VIA_BAR);
    readBARCommand = pChipDescription->fourByteAddressEnter.variant.viaBAR.readCommand;
    writeBARCommand = pChipDescription->fourByteAddressEnter.variant.viaBAR.writeCommand;
    mask = pChipDescription->fourByteAddressEnter.variant.viaBAR.mask;
    value = pChipDescription->fourByteAddressEnter.variant.viaBAR.value;
  } else {
    assert(pChipDescription->fourByteAddressExit.type == SPI_CHIP_4BYTE_ADDR_VIA_BAR);
    readBARCommand = pChipDescription->fourByteAddressExit.variant.viaBAR.readCommand;
    writeBARCommand = pChipDescription->fourByteAddressExit.variant.viaBAR.writeCommand;
    mask = pChipDescription->fourByteAddressExit.variant.viaBAR.mask;
    value = pChipDescription->fourByteAddressExit.variant.viaBAR.value;
  }

  /* Read of BAR */

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex;
  command[3] = 1; /* Number of bytes to write: SPI command for BAR read */
  command[4] = 1; /* Number of bytes to read: BAR value */

  /* SPI write payload */
  command[5] = readBARCommand; /* SPI command for BAR read */

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  commandLength = 6;
  responseLength = 4;

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  newValue = (uint8_t)((response[3] & ~mask) | (value & mask));

  /* Write to BAR */

  command[3] = 2; /* Number of bytes to write: SPI command for BAR write + new BAR value */
  command[4] = 0; /* Nothing to read */

  /* SPI write payload */
  command[5] = writeBARCommand; /* SPI command for BAR read */
  command[6] = newValue;

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  commandLength = 7;
  responseLength = 3;

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

done:
  return ret;
}

int
avr2utilSpiFlash4ByteMode(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  bool_t bEnterNotExit)
{
  int ret = EXIT_OK;

  if (bEnterNotExit) {
    switch (pChipDescription->fourByteAddressEnter.type) {
    case SPI_CHIP_4BYTE_ADDR_ALWAYS:
      /* If 4-byte address mode always active, nothing to do */
      break;

    case SPI_CHIP_4BYTE_ADDR_VIA_CMD:
      if (pChipDescription->fourByteAddressEnter.variant.viaCmd.bNeedWriteEnable) {
        /* Write enable must be set in order to enter 4-byte address mode */
        ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, pChipDescription, chipIndex, TRUE);
        if (EXIT_OK != ret) {
          return ret;
        }
      }
      ret = avr2utilSpiFlash4ByteModeViaCmd(pDevice, bVerbose, pChipDescription, chipIndex, bEnterNotExit);
      break;

    case SPI_CHIP_4BYTE_ADDR_VIA_BAR:
      ret = avr2utilSpiFlash4ByteModeBAR(pDevice, bVerbose, pChipDescription, chipIndex, bEnterNotExit);
      break;

    case SPI_CHIP_4BYTE_ADDR_VIA_EAR:
      /* Address [31:24] provided by page register, so should not be attempting to enter 4-byte address mode */
      assert(FALSE);
      return EXIT_BAD_SPI_SFDP;

    default:
      /* Should never get here; maybe got here because of bad SFDP? */
      assert(FALSE);
      return EXIT_BAD_SPI_SFDP;
    }
  } else {
    switch (pChipDescription->fourByteAddressExit.type) {
    case SPI_CHIP_4BYTE_ADDR_ALWAYS:
      /* If 4-byte address mode always active, should not be attempting to exit 4-byte address mode */
      assert(FALSE);
      return EXIT_BAD_SPI_SFDP;

    case SPI_CHIP_4BYTE_ADDR_VIA_CMD:
      if (pChipDescription->fourByteAddressExit.variant.viaCmd.bNeedWriteEnable) {
        /* Write enable must be set in order to exit 4-byte address mode */
        ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, pChipDescription, chipIndex, TRUE);
        if (EXIT_OK != ret) {
          return ret;
        }
      }
      ret = avr2utilSpiFlash4ByteModeViaCmd(pDevice, bVerbose, pChipDescription, chipIndex, bEnterNotExit);
      break;

    case SPI_CHIP_4BYTE_ADDR_VIA_BAR:
      ret = avr2utilSpiFlash4ByteModeBAR(pDevice, bVerbose, pChipDescription, chipIndex, bEnterNotExit);
      break;

    case SPI_CHIP_4BYTE_ADDR_VIA_EAR:
      /* Address [31:24] provided by page register, so should not be attempting to exit 4-byte address mode */
      assert(FALSE);
      return EXIT_BAD_SPI_SFDP;

    default:
      /* Should never get here; maybe got here because of bad SFDP? */
      assert(FALSE);
      return EXIT_BAD_SPI_SFDP;
    }
  }

  if (EXIT_OK == ret) {
    pChipDescription->state.bIn4ByteAddressMode = bEnterNotExit;
  }

  return ret;
}

int
avr2utilSpiFlashWriteEnableOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  bool_t bEnableNotDisable)
{
  const uint32_t commandLength = 6;
  const uint32_t responseLength = 3;
  uint8_t command[6];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex;
  command[3] = 1; /* Number of bytes to write: SPI command for Enter/exit 4-byte address mode */
  command[4] = 0; /* Number of bytes to read */

  /* SPI write payload */
  command[5] = (uint8_t)(bEnableNotDisable ?
    pChipDescription->writeEnable.enableCommand :
    pChipDescription->writeEnable.disableCommand); /* SPI command for Write Enable/Disable */

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  return spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
}

/* Set extended address register, which supplies bits [31:24] of the address when not in 4-byte address mode. */
static int
avr2utilSpiFlashSetPageOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint8_t page)
{
  const uint32_t responseLength = 3;
  const uint32_t commandLength = 7;
  uint8_t command[7];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;
  int ret = EXIT_OK;

  /* Actually, only unreferenced in non-debug build */
  UNREFERENCED_PARAMETER(pChipDescription);

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex;
  command[3] = 2; /* Number of bytes to write: SPI command for write ext. addr. reg + page value */
  command[4] = 0; /* Number of bytes to read */

  /* SPI write payload */
  command[5] = 0xC5; /* SPI command for write ext. addr. reg */
  command[6] = page;

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  pChipDescription->state.currentPage = page;

done:
  return ret;
}

/* Set extended address register, which supplies bits [31:24] of the address when not in 4-byte address mode. */
static int
avr2utilSpiFlashSetPage(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint8_t page)
{
  int ret = EXIT_OK;

  assert(pChipDescription->fourByteAddressEnter.type == SPI_CHIP_4BYTE_ADDR_VIA_EAR);
  assert(pChipDescription->fourByteAddressExit.type == SPI_CHIP_4BYTE_ADDR_VIA_EAR);

  if (pChipDescription->state.currentPage != page) {
    ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, pChipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      return ret;
    }

    ret = avr2utilSpiFlashSetPageOp(pDevice, bVerbose, pChipDescription, chipIndex, page);
    if (EXIT_OK != ret) {
      return ret;
    }
  }

  return ret;
}
static int
avr2utilSpiFlashReadStatusOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint8_t* pStatus)
{
  const uint32_t commandLength = 6;
  const uint32_t responseLength = 4;
  uint8_t command[6];
  uint8_t response[4];
  uint8_t expResponse[2];
  uint32_t actualResponseLength;
  int ret = EXIT_OK;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  command[0] = 0x05; /* User extended command group */
  command[1] = 0x90; /* Raw SPI command */
  command[2] = (uint8_t)chipIndex;
  command[3] = 1; /* Number of bytes to write: SPI command for Read Status */
  command[4] = 1; /* Number of bytes to read */

  /* SPI write payload */
  command[5] = pChipDescription->readStatusCommand; /* SPI command for Read Status */

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  *pStatus = response[3];

done:
  return ret;
}

static int
avr2utilSpiFlashReadOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint8_t count,
  void* pBuffer)
{
  uint8_t command[10];
  uint8_t response[3 + 252]; /* Large enough for reading 252 bytes from SPI Flash */
  uint8_t expResponse[2];
  uint8_t payloadLength;
  uint32_t commandLength, responseLength, actualResponseLength;
  int ret = EXIT_OK;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  assert(count <= 252);

  commandLength = 0;

  command[commandLength++] = 0x05; /* User extended command group */
  command[commandLength++] = 0x90; /* Raw SPI command */
  command[commandLength++] = (uint8_t)chipIndex;
  payloadLength = (uint8_t)(pChipDescription->state.bIn4ByteAddressMode ? 5 : 4); /* Number of bytes to write: SPI command for 1-1-1 read followed by 3/4-byte address */
  command[commandLength++] = payloadLength;
  command[commandLength++] = count; /* Number of bytes to read */

  /* SPI write payload */
  command[commandLength++] = pChipDescription->readCommand; /* SPI command for 1-1-1 read */
  if (pChipDescription->state.bIn4ByteAddressMode) {
    command[commandLength++] = (uint8_t)((address >> 24) & 0xFF);
  } else {
    assert(((address >> 24) & 0xFF) == pChipDescription->state.currentPage);
  }
  command[commandLength++] = (uint8_t)((address >> 16) & 0xFF);
  command[commandLength++] = (uint8_t)((address >> 8) & 0xFF);
  command[commandLength++] = (uint8_t)((address >> 0) & 0xFF);

  responseLength = 3 + count;
  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  ret = spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
  if (EXIT_OK != ret) {
    goto done;
  }

  memcpy(pBuffer, &response[3], count);

done:
  return ret;  
}

static int
avr2utilSpiFlashReadBlock(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  void* pBuffer)
{
  const uint8_t maxChunk = 252; /* Max. that avr2utilSpiFlashReadBlockOp allows */
  uint8_t* p;
  uint32_t chunk;
  uint8_t page;
  int ret = EXIT_OK;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  p = (uint8_t*)pBuffer;

  while (count) {
    /* Read in chunks of up to 252 bytes, but don't cross a 16 MiB boundary */
    chunk = 0x1000000 - (address & 0xFFFFFF);
    if (chunk > maxChunk) {
      chunk = maxChunk;
    }
    if (chunk > count) {
      chunk = count;
    }

    if (pChipDescription->fourByteAddressEnter.type == SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
      page = (uint8_t)((address >> 24) & 0xFF);
      ret = avr2utilSpiFlashSetPage(pDevice, bVerbose, pChipDescription, chipIndex, page);
      if (EXIT_OK != ret) {
        goto done;
      }
    }

    ret = avr2utilSpiFlashReadOp(pDevice, bVerbose, pChipDescription, chipIndex, address, (uint8_t)chunk, p);
    if (EXIT_OK != ret) {
      goto done;
    }

    p += chunk;
    address += chunk;
    count -= chunk;
  }

done:
  return ret;  
}

static int
avr2utilSpiFlashEraseOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint8_t blockType,
  uint32_t address)
{
  const uint32_t responseLength = 3;
  uint8_t command[10];
  uint8_t response[3];
  uint8_t expResponse[2];
  uint8_t payloadLength;
  uint32_t commandLength, actualResponseLength;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  commandLength = 0;

  command[commandLength++] = 0x05; /* User extended command group */
  command[commandLength++] = 0x90; /* Raw SPI command */
  command[commandLength++] = (uint8_t)chipIndex;
  payloadLength = (uint8_t)(pChipDescription->state.bIn4ByteAddressMode ? 5 : 4); /* Number of bytes to write: SPI command for erase followed by 3/4-byte address */
  command[commandLength++] = payloadLength;
  command[commandLength++] = 0; /* Nothing to read */

  /* SPI write payload */
  command[commandLength++] = pChipDescription->blockType[blockType].eraseCommand; /* SPI command for erase subsector/sector */
  if (pChipDescription->state.bIn4ByteAddressMode) {
    command[commandLength++] = (uint8_t)((address >> 24) & 0xFF);
  } else {
    assert(((address >> 24) & 0xFF) == pChipDescription->state.currentPage);
  }
  command[commandLength++] = (uint8_t)((address >> 16) & 0xFF);
  command[commandLength++] = (uint8_t)((address >> 8) & 0xFF);
  command[commandLength++] = (uint8_t)((address >> 0) & 0xFF);

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  return spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
}

static int
avr2utilSpiFlashEraseBlock(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint8_t blockType,
  uint32_t blockAddress)
{
  uint8_t statusReg, page;
  int ret = EXIT_OK;

  do {
    ret = avr2utilSpiFlashReadStatusOp(pDevice, bVerbose, pChipDescription, chipIndex, &statusReg);
    if (EXIT_OK != ret) {
      goto done;
    }
  } while (statusReg & 0x1);

  if (pChipDescription->fourByteAddressEnter.type == SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
    page = (uint8_t)((blockAddress >> 24) & 0xFF);
    ret = avr2utilSpiFlashSetPage(pDevice, bVerbose, pChipDescription, chipIndex, page);
    if (EXIT_OK != ret) {
      goto done;
    }
  }

  ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, pChipDescription, chipIndex, TRUE);
  if (EXIT_OK != ret) {
    goto done;
  }

  ret = avr2utilSpiFlashEraseOp(pDevice, bVerbose, pChipDescription, chipIndex, blockType, blockAddress);
  if (EXIT_OK != ret) {
    goto done;
  }

  do {
    ret = avr2utilSpiFlashReadStatusOp(pDevice, bVerbose, pChipDescription, chipIndex, &statusReg);
    if (EXIT_OK != ret) {
      goto done;
    }
  } while (statusReg & 0x1);

done:
  return ret;  
}

static int
avr2utilSpiFlashProgramOp(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  const SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint8_t count,
  const uint8_t* pData)
{
  const uint32_t responseLength = 3;
  uint8_t command[10 + 250]; /* Large enough to program a chunk of 250 bytes */
  uint8_t response[3];
  uint8_t expResponse[2];
  uint32_t commandLength, actualResponseLength;
  uint8_t payloadLength;
  uint8_t maxChunk = 250;

  if (chipIndex > 255) {
    return EXIT_INVALID_SPI_INDEX;
  }

  if (count > maxChunk) {
    assert(FALSE);
  }

  commandLength = 0;
  payloadLength = (uint8_t)(count + (pChipDescription->state.bIn4ByteAddressMode ? 5 : 4));

  command[commandLength++] = 0x05; /* User extended command group */
  command[commandLength++] = 0x90; /* Raw SPI command */
  command[commandLength++] = (uint8_t)chipIndex;
  command[commandLength++] = payloadLength; /* Number of bytes to write: SPI command for page program + 3/4 byte address + write bytes */
  command[commandLength++] = 0; /* Number of bytes to read */

  /* SPI write payload */
  command[commandLength++] = pChipDescription->pageProgram.command; /* SPI command for page program */
  if (pChipDescription->state.bIn4ByteAddressMode) {
    command[commandLength++] = (uint8_t)((address >> 24) & 0xFF);
  } else {
    assert(((address >> 24) & 0xFF) == pChipDescription->state.currentPage);
  }
  command[commandLength++] = (uint8_t)((address >> 16) & 0xFF);
  command[commandLength++] = (uint8_t)((address >> 8) & 0xFF);
  command[commandLength++] = (uint8_t)((address >> 0) & 0xFF);
  memcpy(&command[commandLength], pData, count);
  commandLength += count;

  expResponse[0] = 0x05; /* User extended command group */
  expResponse[1] = 0x10; /* Raw SPI response */

  return spiTransaction(pDevice, bVerbose, command, commandLength, expResponse, response, responseLength, &actualResponseLength);
}

static int
avr2utilSpiFlashWriteBlock(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  const uint8_t* pData)
{
  uint8_t maxChunk = 128;
  uint8_t chunk, statusReg, page;
  bool_t bFirstChunk;
  int ret = EXIT_OK;

  if (pChipDescription->pageProgram.pageSizeBytes < maxChunk) {
    maxChunk = (uint8_t)pChipDescription->pageProgram.pageSizeBytes;
  }

  bFirstChunk = TRUE;
  while (count) {
    /* Program in chunks of up to maxChunk bytes, aligning to maxChunk bytes where possible, so as not to cross a page boundary */
    chunk = (uint8_t)(maxChunk - (address & (maxChunk - 1)));
    if (chunk > count) {
      chunk = (uint8_t)count;
    }

    if (pChipDescription->fourByteAddressEnter.type == SPI_CHIP_4BYTE_ADDR_VIA_EAR) {
      page = (uint8_t)((address >> 24) & 0xFF);
      ret = avr2utilSpiFlashSetPage(pDevice, bVerbose, pChipDescription, chipIndex, page);
      if (EXIT_OK != ret) {
        goto done;
      }
    }

    if (bFirstChunk) {
      do {
        ret = avr2utilSpiFlashReadStatusOp(pDevice, bVerbose, pChipDescription, chipIndex, &statusReg);
        if (EXIT_OK != ret) {
          goto done;
        }
      } while (statusReg & 0x1);

      bFirstChunk = FALSE;
    }

    ret = avr2utilSpiFlashWriteEnableOp(pDevice, bVerbose, pChipDescription, chipIndex, TRUE);
    if (EXIT_OK != ret) {
      goto done;
    }

    ret = avr2utilSpiFlashProgramOp(pDevice, bVerbose, pChipDescription, chipIndex, address, chunk, pData);
    if (EXIT_OK != ret) {
      goto done;
    }

    do {
      ret = avr2utilSpiFlashReadStatusOp(pDevice, bVerbose, pChipDescription, chipIndex, &statusReg);
      if (EXIT_OK != ret) {
        goto done;
      }
    } while (statusReg & 0x1);

    pData += chunk;
    count -= chunk;
    address += chunk;
  }

done:
  return ret;  
}

int
avr2utilSpiFlashRead(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  void* pBuffer)
{
  const uint32_t blockSize = 0x10000U;
  uint32_t offset, chunk;
  uint8_t* p = (uint8_t*)pBuffer;
  int ret = EXIT_OK;

  while (count) {
    offset = address & (blockSize - 1);
    chunk = blockSize - offset;
    if (chunk > count) {
      chunk = count;
    }

    _tprintf(_T("Reading 0x%X B at 0x%X-0x%X\n"), chunk, address, address + chunk - 1);
    ret = avr2utilSpiFlashReadBlock(pDevice, bVerbose, pChipDescription, chipIndex, address, chunk, p);
    if (EXIT_OK != ret) {
      goto done;
    }

    address += chunk;
    count -= chunk;
    p += chunk;
  }

done:
  return ret;  
}

int
avr2utilSpiFlashErase(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count)
{
  uint32_t blockAddress, blockSize;
  uint32_t offset, chunk;
  uint8_t blockType;
  int ret = EXIT_OK;

  while (count) {
    if (!identifyEraseBlock(pChipDescription, address, count, &blockType, &blockAddress, &blockSize)) {
      /* 'address' out of range */
      return EXIT_INVALID_SPI_ADDRESS;
    }

    offset = address - blockAddress;
    chunk = blockSize - offset;
    if (chunk > count) {
      chunk = count;
    }

    if (offset) {
      /* Read bytes of block up to offset into merge buffer */
      _tprintf(_T("Reading 0x%X B at 0x%X-0x%X into merge buffer\n"), offset, blockAddress, blockAddress + offset - 1);
      ret = avr2utilSpiFlashReadBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockAddress, offset, pChipDescription->pMergeBuffer);
      if (EXIT_OK != ret) {
        goto done;
      }
    }
    if (offset + chunk < blockSize) {
      /* Read bytes to end of block into merge buffer */
      uint32_t after = offset + chunk;
      _tprintf(_T("Reading 0x%X B at 0x%X-0x%X into merge buffer\n"), blockSize - after, blockAddress + after, blockAddress + blockSize - 1);
      ret = avr2utilSpiFlashReadBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockAddress + after, blockSize - after, pChipDescription->pMergeBuffer + after);
      if (EXIT_OK != ret) {
        goto done;
      }
    }

    _tprintf(_T("Erasing 0x%X B block at 0x%X-0x%X\n"), blockSize, blockAddress, blockAddress + blockSize - 1);
    ret = avr2utilSpiFlashEraseBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockType, blockAddress);
    if (EXIT_OK != ret) {
      goto done;
    }

    if (offset) {
      _tprintf(_T("Restoring 0x%X B at 0x%X-0x%X\n"), offset, blockAddress, blockAddress + offset - 1);
      ret = avr2utilSpiFlashWriteBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockAddress, offset, pChipDescription->pMergeBuffer);
      if (EXIT_OK != ret) {
        goto done;
      }
    }
    if (offset + chunk < blockSize) {
      uint32_t after = offset + chunk;
      _tprintf(_T("Restoring 0x%X B at 0x%X-0x%X\n"), blockSize - after, blockAddress + after, blockAddress + blockSize - 1);
      ret = avr2utilSpiFlashWriteBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockAddress + after, blockSize - after, pChipDescription->pMergeBuffer + after);
      if (EXIT_OK != ret) {
        goto done;
      }
    }

    address += chunk;
    count -= chunk;
  }

done:
  return ret;  
}

int
avr2utilSpiFlashWrite(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  const void* pData)
{
  uint32_t blockAddress, blockSize;
  uint32_t offset, chunk;
  uint8_t blockType;
  uint8_t* p = (uint8_t*)pData;
  int ret = EXIT_OK;

  while (count) {
    if (!identifyEraseBlock(pChipDescription, address, count, &blockType, &blockAddress, &blockSize)) {
      /* 'address' out of range */
      return EXIT_INVALID_SPI_ADDRESS;
    }

    offset = address - blockAddress;
    chunk = blockSize - offset;
    if (chunk > count) {
      chunk = count;
    }

    if (offset) {
      /* Read bytes of block up to offset into merge buffer */
      _tprintf(_T("Reading 0x%X B at 0x%X-0x%X into merge buffer\n"), offset, blockAddress, blockAddress + offset - 1);
      ret = avr2utilSpiFlashReadBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockAddress, offset, pChipDescription->pMergeBuffer);
      if (EXIT_OK != ret) {
        goto done;
      }
    }
    if (offset + chunk < blockSize) {
      /* Read bytes to end of block into merge buffer */
      uint32_t after = offset + chunk;
      _tprintf(_T("Reading 0x%X B at 0x%X-0x%X into merge buffer\n"), blockSize - after, blockAddress + after, blockAddress + blockSize - 1);
      ret = avr2utilSpiFlashReadBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockAddress + after, blockSize - after, pChipDescription->pMergeBuffer + after);
      if (EXIT_OK != ret) {
        goto done;
      }
    }

    memcpy(pChipDescription->pMergeBuffer + offset, p, chunk);

    _tprintf(_T("Erasing 0x%X B block at 0x%X-0x%X\n"), blockSize, blockAddress, blockAddress + blockSize - 1);
    ret = avr2utilSpiFlashEraseBlock(pDevice, bVerbose, pChipDescription, chipIndex, blockType, blockAddress);
    if (EXIT_OK != ret) {
      goto done;
    }

    _tprintf(_T("Writing 0x%X B block at 0x%X-0x%X\n"), blockSize, blockAddress, blockAddress + blockSize - 1);
    ret = avr2utilSpiFlashWriteBlock(pDevice,  bVerbose, pChipDescription, chipIndex, blockAddress, blockSize, pChipDescription->pMergeBuffer);
    if (EXIT_OK != ret) {
      goto done;
    }

    address += chunk;
    count -= chunk;
    p += chunk;
  }

done:
  return ret;  
}

extern int
avr2utilSpiFlashVerify(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  SPIChipDescription* pChipDescription,
  unsigned int chipIndex,
  uint32_t address,
  uint32_t count,
  const void* pData,
  uint32_t maxErrorsDisplayed,
  uint32_t* pErrorCount)
{
  const uint32_t blockSize = VERIFY_BLOCK_SIZE;
  uint32_t i, offset, chunk;
  uint8_t* p = (uint8_t*)pData;
  uint8_t expected, actual;
  uint32_t errorCount = 0;
  uint8_t* pMergeBuffer = pChipDescription->pMergeBuffer;
  bool_t bBlankCheck = (NULL == pData) ? TRUE : FALSE;
  bool_t bFirstErrorInChunk;
  int ret = EXIT_OK;

  while (count) {
    offset = address & (blockSize - 1);
    chunk = blockSize - offset;
    if (chunk > count) {
      chunk = count;
    }

    _tprintf(_T("Reading 0x%X B at 0x%X-0x%X\n"), chunk, address, address + chunk - 1);
    ret = avr2utilSpiFlashReadBlock(pDevice, bVerbose, pChipDescription, chipIndex, address, chunk, pMergeBuffer + offset);
    if (EXIT_OK != ret) {
      goto done;
    }

    bFirstErrorInChunk = TRUE;
    for (i = 0; i < chunk; i++) {
      expected = (uint8_t)(bBlankCheck ? 0xFF : p[i]);
      actual = pMergeBuffer[offset + i];
      if (expected != actual) {
        if (errorCount < maxErrorsDisplayed) {
          _tprintf(_T("+++ At address 0x%08X, expected byte value 0x%02X found 0x%02X\n"),
            address + i, expected, actual);
        } else if (bFirstErrorInChunk || errorCount == maxErrorsDisplayed) {
          _tprintf(_T("+++ Further mismatches found.\n"));
        }
        errorCount++;
        bFirstErrorInChunk = FALSE;
      }
    }

    address += chunk;
    count -= chunk;
    if (!bBlankCheck) {
      p += chunk;
    }
  }

  *pErrorCount = errorCount;

done:
  return ret;  
}
