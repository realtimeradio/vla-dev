#ifndef _ADATA_AVR2UTIL_H
#define _ADATA_AVR2UTIL_H


#include <adb3.h>
#include <adb3/avr2.h>

#include <sdk_common.h>


#if defined(AVR2_VIA_USB_SUPPORTED)
# include <avr2.h>
#endif

#if defined(AVR2_VIA_SMBUS_SUPPORTED)
# include <avr2s.h>
#endif

#if defined(AVR2_VIA_IPMI_SUPPORTED)
# include <avr2ipmi.h>
#endif

#if defined(AVR2_VIA_ADXDMA_SUPPORTED)
# include <adxdma.h>
# include <adxdma/bc.h>
#endif


/* Exit codes */
#define EXIT_OK                      (0) /* Success */
#define EXIT_UNRECOGNIZED_COMMAND    (1) /* Invalid command passed as 1st positional argument */
#define EXIT_INSUFFICIENT_ARGS       (2) /* Not enough positional arguments following command */
#define EXIT_INVALID_INDEX           (3) /* Index value out of range or not a valid number */
#define EXIT_INVALID_FREQUENCY       (4) /* Frequency value out of range or not a valid number */
#define EXIT_READ_FIRMWARE_FAILED    (5) /* Failed to read firmware from file */
#define EXIT_FIRMWARE_TOO_LARGE      (6) /* Firmware file is too large for uC */
#define EXIT_ALLOCATION_FAILED       (7) /* Failed to allocate buffer for firmware or board config data */
#define EXIT_VERIFY_FAILED           (8) /* Errors found when verifying updated firmware or board config data */
#define EXIT_UNSUPPORTED_MODEL       (9) /* Attempting to use this utility on an unsupported model */
#define EXIT_BAD_COMMAND_LINE       (10) /* Illegal basic command-line syntax */
#define EXIT_USB_NOT_SUPPORTED      (11) /* Access to AVR2 uC via USB is currently not supported for this OS */
#define EXIT_MODE_CHANGE_FAILED     (12) /* AVR2 uC did not enter or exit Service Mode as requested */
#define EXIT_WRONG_MODE             (13) /* Device is in the wrong mode (Service Mode vs. non-Service Mode) for the requested command */
#define EXIT_UNRECOGNIZED_PRODUCTID (14) /* Product ID not recognized; aborting as a precaution against firmware corruption. */
#define EXIT_INVALID_I2C_BUS        (15) /* I2C bus number is not valid */
#define EXIT_INVALID_I2C_DEVICE     (16) /* I2C device number is not valid */
#define EXIT_INVALID_I2C_ADDRESS    (17) /* I2C address is not valid */
#define EXIT_I2C_READ_FILE_FAILED   (18) /* Failed to read data for I2C write from file */
#define EXIT_I2C_WRITE_FILE_FAILED  (19) /* Failed to write data from I2C read to file */
#define EXIT_INVALID_I2C_COUNT      (20) /* I2C data byte count is not valid */
#define EXIT_INVALID_I2C_BYTEVAL    (21) /* I2C data byte value is not valid */
#define EXIT_WRITE_FIRMWARE_FAILED  (22) /* Failed to write firmware/VPD/board config to a file */
#define EXIT_INVALID_OVERRIDE       (23) /* Sensor override value out of range or not a valid number */
#define EXIT_BAD_SPI_SFDP           (24) /* SFDP data from SPI Flash chip does not conform to JESD216/JESD216B */
#define EXIT_INVALID_SPI_INDEX      (25) /* SPI chip index is not valid */
#define EXIT_INVALID_SPI_READ_COUNT (26) /* SPI raw read byte count is not valid */
#define EXIT_INVALID_SPI_WRITE_COUNT (27) /* SPI raw write byte count is not valid */
#define EXIT_INVALID_SPI_BYTEVAL    (28) /* SPI data byte value is not valid */
#define EXIT_INVALID_SPI_ADDRESS    (29) /* SPI address out of range */
#define EXIT_INVALID_SPI_BYTE_COUNT (30) /* SPI program/read/erase byte count out of range or not valid */
#define EXIT_READ_INTEL_HEX_FAILED  (31) /* Failed to read file in Intel Hex (.mcs) format */
#define EXIT_INVALID_TRANSLATION    (32) /* Address translation value is not valid */
#define EXIT_NOT_POWERED            (33) /* Device is not powered on */
#define EXIT_SMBUS_NOT_SUPPORTED    (34) /* SMBUS communication with the AVR2 uC is not supported */
#define EXIT_IPMI_NOT_SUPPORTED     (35) /* IPMI communication with the AVR2 uC is not supported */
#define EXIT_NO_SPI_FLASH           (36) /* No SPI Flash that is accessible from the AVR2 uC */
#define EXIT_INVALID_RAW_READ_COUNT (37) /* "raw" command read byte count not valid */
#define EXIT_INVALID_RAW_BYTEVAL    (38) /* "raw" command bad write byte value */
#define EXIT_INVALID_RECORD_TYPE    (39) /* "display-black-box" bad record type following command */
#define EXIT_INVALID_RECORD_COUNT   (40) /* "display-black-box" bad record count following record type */
#define EXIT_DEVICE_OPEN_ERROR     (100) /* Failed to open device */
#define EXIT_AVR2_STATUS_ERROR     (101) /* Failed to get AVR2 uC status */
#define EXIT_AVR2_COMMAND_ERROR    (102) /* Failed to send command to AVR2 uC */
#define EXIT_AVR2_BAD_STATUS       (103) /* AVR2 uC returned nonzero status for operation */
#define EXIT_AVR2_SHORT_RESPONSE   (104) /* AVR2 uC's response was too short (< 2 bytes) to be valid */
#define EXIT_LIBRARY_NOT_FOUND     (105) /* Could not find AVR2 or ADB3 shared library/DLL */
#define EXIT_TOO_MANY_COMM_OPTIONS (106) /* Specified more than one communication option, e.g. -smbus and -ipmi */
#define EXIT_BAD_CHIP_ADDR         (107) /* Invalid value passed for -chipaddr option */
#define EXIT_BAD_IPMI_OPTIONS      (108) /* Bad options for opening an IPMI session */
#define EXIT_BAD_TIMEOUT_VALUE     (109) /* Invalid value passed for -timeout option */
#define EXIT_INVALID_BAUD_RATE     (110) /* Invalid value passed for baud rate in -com option connection string */
#define EXIT_SET_BAUD_FAILED       (111) /* Failed to set UART baud rate */

/* Flags for AVR2UTIL_FLAGS environment variable */
#define AVR2UTIL_FLAG_EN_ENTER_SM  (1 << 0)
#define AVR2UTIL_FLAG_EN_EXIT_SM   (1 << 1)
#define AVR2UTIL_FLAG_EN_AUTO_SM   (1 << 2)
#define AVR2UTIL_FLAG_DIS_ENTER_SM (1 << 4)
#define AVR2UTIL_FLAG_DIS_EXIT_SM  (1 << 5)
#define AVR2UTIL_FLAG_DIS_AUTO_SM  (1 << 6)


#if defined(AVR2_VIA_USB_SUPPORTED)

/* Signatures for AVR2 API functions, when dynamically loading the DLL/shared object */
typedef AVR2_STATUS AVR2_CALLING_CONVENTION FN_AVR2_Close(
  AVR2_HANDLE             hDevice);

typedef AVR2_STATUS AVR2_CALLING_CONVENTION FN_AVR2_Command(
  AVR2_HANDLE             hDevice,
  _AVR2_UINT32            flags,
  _AVR2_UINT32            timeoutUs,
  _AVR2_UINT32            commandLength,
  const _AVR2_UINT8*      pCommand,
  _AVR2_UINT32            responseLength,
  _AVR2_UINT8*            pResponse,
  _AVR2_UINT32*           pActualResponseLength);

typedef const TCHAR* AVR2_CALLING_CONVENTION FN_AVR2_GetStatusString(
  AVR2_STATUS             code,
  _AVR2_BOOL              bShort);

typedef AVR2_STATUS AVR2_CALLING_CONVENTION FN_AVR2_OpenPort(
  const TCHAR*            pPortName,
  AVR2_HANDLE*            phDevice);

typedef AVR2_STATUS AVR2_CALLING_CONVENTION FN_AVR2_SetPortBaud(
  AVR2_HANDLE             hDevice,
  _AVR2_UINT32            nBaudRate);

/* Structure to contain pointers to AVR2 API functions */
typedef struct _API_AVR2 {
  FN_AVR2_Close*           pfnAVR2_Close;
  FN_AVR2_Command*         pfnAVR2_Command;
  FN_AVR2_GetStatusString* pfnAVR2_GetStatusString;
  FN_AVR2_OpenPort*        pfnAVR2_OpenPort;
  FN_AVR2_SetPortBaud*     pfnAVR2_SetPortBaud;
} API_AVR2;

#endif


#if defined(AVR2_VIA_SMBUS_SUPPORTED)

/* Signatures for AVR2S API functions, when dynamically loading the DLL/shared object */
typedef AVR2S_STATUS AVR2S_CALLING_CONVENTION FN_AVR2S_Close(
  AVR2S_HANDLE             hDevice);

typedef AVR2S_STATUS AVR2S_CALLING_CONVENTION FN_AVR2S_Command(
  AVR2S_HANDLE             hDevice,
  _AVR2S_UINT32            flags,
  _AVR2S_UINT32            timeoutUs,
  _AVR2S_UINT32            commandLength,
  const _AVR2S_UINT8*      pCommand,
  _AVR2S_UINT8             chipAddrOverride,
  _AVR2S_UINT32            responseLength,
  _AVR2S_UINT8*            pResponse,
  _AVR2S_UINT32*           pActualResponseLength);

typedef const TCHAR* AVR2S_CALLING_CONVENTION FN_AVR2S_GetStatusString(
  AVR2S_STATUS             code,
  _AVR2S_BOOL              bShort);

typedef AVR2S_STATUS AVR2S_CALLING_CONVENTION FN_AVR2S_OpenDevice(
  const TCHAR*             pDeviceName,
  _AVR2S_UINT8             chipAddr,
  AVR2S_HANDLE*            phDevice);

/* Structure to contain pointers to AVR2S API functions */
typedef struct _API_AVR2S {
  FN_AVR2S_Close*           pfnAVR2S_Close;
  FN_AVR2S_Command*         pfnAVR2S_Command;
  FN_AVR2S_GetStatusString* pfnAVR2S_GetStatusString;
  FN_AVR2S_OpenDevice*      pfnAVR2S_OpenDevice;
} API_AVR2S;

#endif


#if defined(AVR2_VIA_IPMI_SUPPORTED)

/* Signatures for AVR2IPMI API functions, when dynamically loading the DLL/shared object */
typedef AVR2IPMI_STATUS AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_CloseSession(
  AVR2IPMI_SESSION            hSession);

typedef AVR2IPMI_STATUS AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_Command(
  AVR2IPMI_SESSION            hSession,
  _AVR2IPMI_UINT32            flags,
  _AVR2IPMI_UINT32            timeoutUs,
  _AVR2IPMI_UINT32            commandLength,
  const _AVR2IPMI_UINT8*      pCommand,
  _AVR2IPMI_UINT8             chipAddrOverride,
  _AVR2IPMI_UINT32            responseLength,
  _AVR2IPMI_UINT8*            pResponse,
  _AVR2IPMI_UINT32*           pActualResponseLength);

typedef const TCHAR** AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_GetBackends(
  void);

typedef void AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_GetErrorDetail(
  AVR2IPMI_ERROR_DETAIL*      pErrorDetail);

typedef const TCHAR* AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_GetStatusString(
  AVR2IPMI_STATUS             code,
  _AVR2IPMI_BOOL              bShort);

typedef AVR2IPMI_STATUS AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_OpenSession(
  const AVR2IPMI_OPTIONS*     pOptions,
  AVR2IPMI_SESSION*           phSession);

typedef AVR2IPMI_STATUS AVR2IPMI_CALLING_CONVENTION FN_AVR2IPMI_ParseOptions(
  const TCHAR*                pOptionsString,
  AVR2IPMI_OPTIONS*           pOptions);

/* Structure to contain pointers to AVR2IPMI API functions */
typedef struct _API_AVR2IPMI {
  FN_AVR2IPMI_CloseSession*    pfnAVR2IPMI_CloseSession;
  FN_AVR2IPMI_Command*         pfnAVR2IPMI_Command;
  FN_AVR2IPMI_GetBackends*     pfnAVR2IPMI_GetBackends;
  FN_AVR2IPMI_GetErrorDetail*  pfnAVR2IPMI_GetErrorDetail;
  FN_AVR2IPMI_GetStatusString* pfnAVR2IPMI_GetStatusString;
  FN_AVR2IPMI_OpenSession*     pfnAVR2IPMI_OpenSession;
  FN_AVR2IPMI_ParseOptions*    pfnAVR2IPMI_ParseOptions;
} API_AVR2IPMI;

#endif


#if defined(AVR2_VIA_ADXDMA_SUPPORTED)

/* Signatures for ADXDMA API functions, when dynamically loading the DLL/shared object */

typedef ADXDMA_STATUS ADXDMA_CALLING_CONVENTION FN_ADXDMA_CloseBC(
  ADXDMA_HBC                 hBC);

typedef ADXDMA_STATUS ADXDMA_CALLING_CONVENTION FN_ADXDMA_CommandUC(
  ADXDMA_HBC                 hBC,
  _ADXDMA_UINT32             flags,
  _ADXDMA_UINT32             timeoutUs,
  _ADXDMA_UINT32             commandLength,
  const _ADXDMA_UINT8*       pCommand,
  _ADXDMA_UINT32             responseLength,
  _ADXDMA_UINT8*             pResponse,
  _ADXDMA_UINT32*            pActualResponseLength);

typedef ADXDMA_STATUS ADXDMA_CALLING_CONVENTION FN_ADXDMA_GetUCStatus(
  ADXDMA_HBC                 hBC,
  ADXDMA_UC_STATUS*          pUCStatus);

typedef const TCHAR* ADXDMA_CALLING_CONVENTION FN_ADXDMA_GetStatusString(
  ADXDMA_STATUS              code,
  _ADXDMA_BOOL               bShort);

typedef ADXDMA_STATUS ADXDMA_CALLING_CONVENTION FN_ADXDMA_OpenBC(
  ADXDMA_HDEVICE             hParentDevice,
  unsigned int               deviceIndex,
  _ADXDMA_BOOL               bPassive,
  ADXDMA_HBC*                phBC);

/* Structure to contain pointers to ADXDMA API functions */
typedef struct _API_ADXDMA {
  FN_ADXDMA_CloseBC*         pfnADXDMA_CloseBC;
  FN_ADXDMA_CommandUC*       pfnADXDMA_CommandUC;
  FN_ADXDMA_GetStatusString* pfnADXDMA_GetStatusString;
  FN_ADXDMA_GetUCStatus*     pfnADXDMA_GetUCStatus;
  FN_ADXDMA_OpenBC*          pfnADXDMA_OpenBC;
} API_ADXDMA;

#endif


/* Signatures for ADB3 API functions, when dynamically loading the DLL/shared object */

typedef ADB3_STATUS ADB3_CALLING_CONVENTION FN_ADB3_Close(
  ADB3_HANDLE             hCard);

typedef ADB3_STATUS ADB3_CALLING_CONVENTION FN_ADB3_CommandAVR2(
  ADB3_HANDLE             hCard,
  _ADB3_UINT32            flags,
  _ADB3_UINT32            timeoutUs,
  _ADB3_UINT32            commandLength,
  const _ADB3_UINT8*      pCommand,
  _ADB3_UINT32            responseLength,
  _ADB3_UINT8*            pResponse,
  _ADB3_UINT32*           pActualResponseLength);

typedef ADB3_STATUS ADB3_CALLING_CONVENTION FN_ADB3_GetAVR2Status(
  ADB3_HANDLE             hCard,
  ADB3_AVR2_STATUS*       pAVR2Status);

typedef const TCHAR* ADB3_CALLING_CONVENTION FN_ADB3_GetStatusString(
  ADB3_STATUS             code,
  _ADB3_BOOL              bShort);

typedef ADB3_STATUS ADB3_CALLING_CONVENTION FN_ADB3_GetUniqueId(
  ADB3_HANDLE             hCard,
  ADB3_UNIQUE_ID*         pUniqueId);

typedef ADB3_STATUS ADB3_CALLING_CONVENTION FN_ADB3_Open(
  unsigned int            index,
  _ADB3_BOOL              bPassive,
  _ADB3_UINT32            cooperativeLevel,
  ADB3_HANDLE*            phCard);

/* Structure to contain pointers to ADB3 API functions */
typedef struct _API_ADB3 {
  FN_ADB3_Close*           pfnADB3_Close;
  FN_ADB3_CommandAVR2*     pfnADB3_CommandAVR2;
  FN_ADB3_GetAVR2Status*   pfnADB3_GetAVR2Status;
  FN_ADB3_GetStatusString* pfnADB3_GetStatusString;
  FN_ADB3_GetUniqueId*     pfnADB3_GetUniqueId;
  FN_ADB3_Open*            pfnADB3_Open;
} API_ADB3;

typedef enum _Avr2utilInterfaceType {
  Avr2utilInterfaceADB3     = 1, /* Via ADB3_* API (PCIe) */
  Avr2utilInterfaceAVR2     = 2, /* Via AVR2_* API (USB or PS UART) */
  Avr2utilInterfaceAVR2S    = 3, /* Via AVR2S_* API (SMBUS) */
  Avr2utilInterfaceAVR2IPMI = 4, /* Via AVR2IPMI_* API (IPMI and then SMBUS from BMC) */
  Avr2utilInterfaceADXDMA   = 5  /* Via ADXDMA_* API (PCIe) */
} Avr2utilInterfaceType;

/* A handle to a device; it is either an ADB3_HANDLE or an AVR2_HANDLE
** depending on whether opened by ADB3 API or AVR2 API */
typedef struct _DeviceHandle {
  bool_t bValid;
  Avr2utilInterfaceType nInterfaceType;
  TCHAR* pszInterfaceName;
  bool_t bEnterServiceModeRequestAllowed;
  bool_t bExitServiceModeRequestAllowed;
  bool_t bAutoEnterServiceMode;
  bool_t bInServiceMode;
  unsigned int nCommandTimeoutUs;
  unsigned int nRebootDelayMs;
  union _Variant {
#if defined(AVR2_VIA_USB_SUPPORTED)
    struct {
      AVR2_HANDLE hDevice;
      API_AVR2 api;
    } avr2;
#endif
#if defined(AVR2_VIA_SMBUS_SUPPORTED)
    struct {
      AVR2S_HANDLE hDevice;
      API_AVR2S api;
    } avr2s;
#endif
#if defined(AVR2_VIA_IPMI_SUPPORTED)
    struct {
      AVR2IPMI_SESSION hSession;
      API_AVR2IPMI api;
    } avr2ipmi;
#endif
#if defined(AVR2_VIA_ADXDMA_SUPPORTED)
    struct {
      ADXDMA_HBC hBC;
      API_ADXDMA api;
    } adxdma;
#endif
    struct {
      ADB3_HANDLE hDevice;
      API_ADB3 api;
    } adb3;
  } variant;
} DeviceHandle;


/* Function that performs a transaction with the microcontroller via AVR2_* API (USB) */
extern int
avr2utilSendAvr2Command(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t timeoutUs,
  const uint8_t* pCommand,
  uint32_t commandLength,
  const uint8_t expResponse[2],
  uint8_t* pResponse,
  uint32_t responseLength,
  uint32_t* pActualLength);

/* Function that performs a transaction with the microcontroller via AVR2S_* API (SMBUS) */
extern int
avr2utilSendAvr2sCommand(
  const DeviceHandle* pDevice,
  bool_t bVerbose,
  uint32_t timeoutUs,
  const uint8_t* pCommand,
  uint32_t commandLength,
  const uint8_t expResponse[2],
  uint8_t* pResponse,
  uint32_t responseLength,
  uint32_t* pActualLength);

#endif