#ifndef _ADATA_SFDP_H
#define _ADATA_SFDP_H

/* Following definitions as per JEDEC JESD216B */

#define SPI_COMMAND_READ_SFDP (0x5A)

#define SPI_SFDP_HEADER_SIGNATURE (0x50444653) /* 'S', 'F', 'D', 'P' in ASCII */

/* JESD216  <=> minor.major == 1.0 */
/* JESD216B <=> minor.major == 1.6 */
typedef struct _SFDPHeader {
  uint32_t signature; /* 0x50444653 */
  uint8_t  minor;
  uint8_t  major;
  uint8_t  nParameterHeaders;
  uint8_t  _reserved1; /* Must be 0xFF */
} SFDPHeader;

typedef struct _SFDPTableHeader {
  uint8_t  idLSB; /* 0 => JESD216B standard parameter header */
  uint8_t  minor;
  uint8_t  major;
  uint8_t  nLengthDwords;
  /* Bits [23:0] are pointer to Parameter Table */
  /* Bits [31:24] are ID MSB. */
  uint32_t pointer24IDMSB;
} SFDPTableHeader;

#define SFDP_ID_STANDARD_TABLE (0xFF00)
#define SFDP_ID_SECTOR_MAP     (0xFF81)

typedef struct _SFDPTable {
  /* First 9 DWORDs defined by JESD216 */
  uint8_t  eraseAndWriteCaps;  /* 0x00 */
  uint8_t  eraseOpcode;        /* 0x01 */
  uint16_t fastReadSupport1;   /* 0x02 */
  uint32_t density;            /* 0x04 */
  uint8_t  fastReadCaps144;    /* 0x08 */
  uint8_t  fastReadOpcode144;  /* 0x09 */
  uint8_t  fastReadCaps114;    /* 0x0A */
  uint8_t  fastReadOpcode114;  /* 0x0B */
  uint8_t  fastReadCaps112;    /* 0x0C */
  uint8_t  fastReadOpcode112;  /* 0x0D */
  uint8_t  fastReadCaps122;    /* 0x0E */
  uint8_t  fastReadOpcode122;  /* 0x0F */
  uint32_t fastReadSupport2;   /* 0x10 */
  uint16_t _reserved1;         /* 0x14 */
  uint8_t  fastReadCaps222;    /* 0x16 */
  uint8_t  fastReadOpcode222;  /* 0x17 */
  uint16_t _reserved2;         /* 0x18 */
  uint8_t  fastReadCaps444;    /* 0x1A */
  uint8_t  fastReadOpcode444;  /* 0x1B */
  struct {
    uint8_t power;             /* 0x1C + 2 * index */
    uint8_t eraseOpcode;       /* 0x1D + 2 * index */
  } sectorSize[4];
  /* Next 7 DWORDs added by JESD216B */
  uint32_t eraseTimes;         /* 0x24 */
  uint32_t programTimes;       /* 0x28 */
  uint32_t suspendCaps;        /* 0x2C */
  uint32_t suspendOpcodes;     /* 0x30 */
  uint32_t powerDownCaps;      /* 0x34 */
  uint32_t quadModeCaps;       /* 0x38 */
  uint32_t miscCaps;           /* 0x3C */
} SFDPTable;

extern void
avr2utilDisplaySFDPTable(
  const SFDPTable* pTable,
  uint32_t address,
  unsigned int tableIndex,
  unsigned int tableSize);

extern void
avr2utilDisplaySFDPSectorMap(
  const uint32_t* pTable,
  uint32_t address,
  unsigned int tableIndex,
  unsigned int tableSize);

extern bool_t /* TRUE if header indicates standard JEDEC table */
avr2utilDisplaySFDPTableHeader(
  const SFDPTableHeader* pTableHeader,
  uint32_t address,
  unsigned int tableIndex,
  unsigned int* pTableSize,
  uint32_t* pPointer24,
  uint16_t* pTableID);

void
avr2utilDisplaySFDPHeader(
  const SFDPHeader* pHeader,
  uint32_t address,
  uint32_t* pSignature,
  unsigned int* pTableSize);

#endif